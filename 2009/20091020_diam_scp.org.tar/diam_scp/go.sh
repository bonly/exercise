./diam_cli_scp -p 30018 -s 10.200.2.17 -x gprs.xml -l gg  -M PS -L ./300.lst 
