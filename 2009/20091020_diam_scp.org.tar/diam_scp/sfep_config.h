#ifndef SFEP_CONFIG_H
#define SFEP_CONFIG_H

#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <set>
#include <string>
#include <vector>
#include <sys/msg.h>
#include <dlfcn.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/wait.h>
#include "utility_fep.h"
#include "DiamUtil.h"
#include "iniconfig.h"
#include "avp_code.h"
#include "DictionaryManager.h"
#include "sysinfo.h"

#ifdef __WM_HP_UNIX
typedef int SOCKETLEN_T;
#endif

#ifdef __WM_IBM_AIX
typedef unsigned int SOCKETLEN_T;
#endif

#ifdef __WM_LINUX
typedef unsigned int SOCKETLEN_T;
#endif

#define FEP_R5_DEBUG(...)\
        R5_DEBUG(("[fep] " __VA_ARGS__))
#define FEP_R5_INFO(...)\
        R5_INFO(("[fep] " __VA_ARGS__))
#define FEP_R5_ERROR(...)\
        R5_ERROR(("[fep] " __VA_ARGS__))
#define FEP_R5_WARN(...)\
        R5_WARN(("[fep] " __VA_ARGS__))
#define FEP_R5_TRACE(...)\
        R5_TRACE("[fep] " __VA_ARGS__)

#endif
