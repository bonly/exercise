#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/tcp.h>

#include "xml_utility.h"
#include "diam_cli_scp.h"
#include "com_date.h"

#include "avp_code.h"


#define DIAMETER_PACKET_MAX_SIZE  10240

const char Version[] = "diam_cli_scp.UX version 1.53\n";

bool TimeStampFlag = false;

int g_debug = 0;

R5_Log g_r5_log;

time_t g_start_time = 0;

const char optstring[] = "hvp:s:f:gx:o:dl:D:L:X:M:T:b:k:"; 
int print_usage()
{
	printf("Usage : diam_cli_scp [-p port] [-s ip] [-f file_name] [-n number of subscribe ] [-i interval] [-a CAPS]  [-t timestamp] [-x xml_file][-D duration][-d] [-b subscribe ][-o timeout][-l log_file][-h] [-L no_list_file] [-v] [-c] [-k skip length of header]\n");
	printf("        -h Show help\n");
	printf("        -v Show version\n");
	printf("        -p port (3868 for default)\n");
	printf("        -s ip address of server\n");
	printf("        -g printf debug info\n");
	printf("        -f binary file name for diamter\n");
	printf("        -x xml file name for diamter description file\n");
	printf("        -o timeout(seconds) for receive process from socket\n");
	printf("        -l log file(log_file.send for send process , log_file.receive for receive process)\n");
	printf("        -d delete old log file\n");
	printf("        -D duration(seconds) for send packages continuously \n");
	printf("        -L number and req_type list file\n");
	printf("        -X change the speed of send xml\n");
	printf("        -M Domain Type IN, PS, VASP, VAC_E, VAC_S \n");
	printf("        -b Binary cap file name for diamter \n");
	printf("        -k Skip length of package header when using cap file\n");
	printf("        -A Application-Id: 1-errison , 2-hw\n");
	return 0;
}

void ShowVersion()
{/*
	printf("Module: %s\n", PROGRAM_NAME);
	printf("Version: %s\n", PROGRAM_VERSION);
	printf("Opening time: %s\n", OPENING_TIME);	
	printf("Test Time: %s\n", TEST_TIME);*/
}

int initDiamDict(const char *DomainType)
{
	string xml_file = "/home/lqb/OCSPL/etc/";//ETC_PATH();

	if(strcmp(DomainType, "IN") == 0 || strcmp(DomainType, "PS") == 0)
	{
		xml_file += "dictionary.xml";
	}
	else if (strcmp(DomainType, "VASP") == 0)
	{
		xml_file += "dictionary_vasp1.xml";
	}
	else if (strcmp(DomainType, "VAC_E") == 0 || strcmp(DomainType, "VAC_S") == 0)
	{
		xml_file += "dictionary_vac.xml";
	} 
	else
	{
		printf("Not support this Domain Type: %s\n", DomainType);
		return -1;
	}
	

	printf("Diameter dictionary file is %s\n" , xml_file.c_str());

	return DictionaryManager::instance()->init(xml_file.c_str());
}

void sig_term_receive(int signo)
{
	printf( "get the terminal signal\n");
	fflush(stdout);
	close(1);
	exit(-1);
}


void sig_term_main(int signo)
{
	//ɱ���ӽ���
	printf( "kill the child process\n");
	fflush(stdout);
	close(STDOUT_FILENO);
	kill(g_childid , SIGTERM );
	exit(-1);
}

void sig_alarm_send(int signo)
{
	//the duration is expired , so we stop the send process.
	//printf( "alarm signal for send process received\n");

	//g_stop = 1;
}

void sig_alarm_receive(int signo)
{
	//the duration is expired , so we stop the send process.
	printf( "alarm signal for receive process received\n");
	//fflush(stdout);
	//close(STDOUT_FILENO);
	//exit(0);
}

// ����CCA��������Log
int get_diameter_msg(int fd, int timeout)
{
	char buf[2048];

	//alarm(timeout);

	//-------------------------------------
	// ����CCA��Ϣͷ
	//-------------------------------------

	// ��ȡCCA��Ϣͷ
	int n = my_read(fd, buf, SUNRISE_CMDHEADER_LEN);

	if (g_debug == 1)
	{
		printf("Read CCA head , len=%d\n", n);
	}	
	
	if (n == 0)
	{
		return -9999;
	}	
	else if (n == -1 || n != SUNRISE_CMDHEADER_LEN)
	{
		printf( "get diameter header failed!\n");
		return -1;
	}  
	else if(n == EINTR)
	{
		//alarm(0);
		printf("Timeout : %d expired , Exiting...\n" , timeout);
		fflush(stdout);
		close(1);
		exit(0);
	}	

	//alarm(0);

	char *p = buf;

	// ��ȡCCA��Ϣͷ�е���Ϣ����
	int nLen = ntohl(*((OCP_UINT32*)(p))) & 0x00ffffff;

	// �����Ϣ�����Ƿ�Ϸ�
	if (nLen < SUNRISE_CMDHEADER_LEN || nLen > 10000)
	{
		printf("receive a diameter message with invalid length\n");
		return -1;
	}

	if (g_debug == 1)
	{
		printf("CCA package len=%d, head len=%d, body len=%d\n", nLen, SUNRISE_CMDHEADER_LEN, nLen-SUNRISE_CMDHEADER_LEN);
	}	

	//-------------------------------------
	// ����CCA��Ϣ��
	//-------------------------------------

	// ��ȡCCA��Ϣ��
	n = my_read(fd , buf + SUNRISE_CMDHEADER_LEN , nLen - SUNRISE_CMDHEADER_LEN);  
	if (g_debug == 1)
	{
		printf("Read CCA body, len=%d\n", n);
	}
	if (n == -1 || n !=  nLen - SUNRISE_CMDHEADER_LEN)
	{
		printf( "get diameter header failed!\n");
		return -1;
	}

	struct timezone tz; 
	struct timeval now;

	gettimeofday(&now, &tz);

	// ����CCA��Ϣ��
	SunriseOCP OCP(buf, sizeof(buf) , nLen);     // �����ⲿ��Ϣ����,ʹ�÷��ϸ�У��
    
    if(!OCP)
    {
        printf("SunriseOCP OCP() error:%d!\n" , OCP.error());
        return(-1);
    }
    
	AVPGroup *pTopGroup;
	AVPGroup *p_subscribe_id;

	// Get TOP-GROUP
	pTopGroup = OCP.getTopmostGroup();
	if (pTopGroup == NULL)
	{
		printf("Get pTopGroup Error \n");
		return(-1);
	}

	if(g_debug == 1)
	{
		printf("Massage type = %d\n", OCP.cmdHeader.cmdCode);		
	}

	//-------------------------------------
	// ��ӡCCA��Ϣ����־  
	//-------------------------------------

	if(g_debug == 1)
	{	
	    string sun_in_s;
        OCP.dump(sun_in_s);
        printf("CCA is:\n %s \n" , sun_in_s.c_str());
	}

	char SessionID[128];
	unsigned int ResultCode, CCRType;

	//pTopGroup->getField(AVPCODE_SESSION_ID, SessionID, 128, 0);	//"Session-Id"
	pTopGroup->getField(AVPCODE_RESULT_CODE, ResultCode, 0); //"Result-Code"
	//pTopGroup->getField(AVPCODE_CC_REQUEST_TYPE, CCRType, 0); //"CC-Request-Type"

	printf("[%ld.%06ld] RECEIVE: %u  %u\n", now.tv_sec, now.tv_usec, OCP.cmdHeader.hop_by_hop_id, ResultCode);

	return 0;
}



//-----------------------------------------------------------------------------
// �ļ���־�ȼ����ն���־�ȼ�
int initLog(const char* prefix_name)
{
	SET_LOG_NAME_HEAD(prefix_name);

	string str_conf = ETC_PATH();
	str_conf += "log.conf";

	IniConfig conf;
	if ( conf.open(str_conf.data())<0 )
	{
		perror("diam_cli_scp:��log�����ļ�ʧ��");
		return -1;
	}

	IniSection *sct = conf.getSection();
    initLogLevel(conf);
	//SET_LOG_LEVEL(atoi(sct->getValue("LEVEL_FILE")), atoi(sct->getValue("LEVEL_TERM"))); // ������־�ȼ�
	return 0;
}

void MemDump(const char* pInMsg, const int nInLen, char *pOutMsg)
{

	register int i = 0;		// ptr into source buffer
	register int j = 1;		// pair elements counter
	register int k = 1;		// pairs counter [0;16[

	const char *pSrc;		// ptr into source buffer
	char       *pHex;		// pHex ptr into destination buffer
	char       *pAscii;		// pAscii ptr into destination buffer

	long lFinalLen;

	if (nInLen <= 0)
	{
		return;
	}

	if (pInMsg == NULL || pOutMsg == NULL) 
	{
		printf("MemDump: error parameter\n");
		return;
	}

	/*---
	Each row holds 16 bytes of data. It requres 74 characters maximum.
	Here's some examples:

	0         1         2         3         4         5         6         7
	0123456789012345678901234567890123456789012345678901234567890123456789012
	-------------------------------------------------------------------------
	3132 3037 3039 3039 3031 3130 3839 3033  1207090901108903
	3038 3132 3030 3331 3030 0d0a 3839 3033  0812003100\r\n8903
	0d0a 0d0a 0d0a 0d0a 0d0a 0d0a 0d0a 0d0a  \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n

	If all 16 bytes are control characters, the ASCII representation
	will extend line to 72 characters plus cartrige return and line 
	feed at the end of the line.

	If nInLen is not multiple of 16, we add one more row and another row
	just to be on a safe side.
	---*/

	lFinalLen = (int (nInLen/16) + 1 + (nInLen % 16 ? 1:0)) * 74;

	char *pDump = new char[lFinalLen];
	memset(pDump, ' ', lFinalLen);

	pSrc   = pInMsg;			// ptr to original image
	pHex   = pDump;			// current ptr to pHex image
	pAscii = pDump + 41;		// current ptr to pAscii image

	for ( i = 0; i < nInLen; i++)
	{
		// �����Ӧ��16������
		sprintf(pHex,"%01x%01x", pSrc[i] >> 4 & 0x0f, pSrc[i] & 0x0f); 
		pHex+=2;

		// �����ӦASCII�ַ�
		if (pSrc[i] == '\n')
		{ 
			sprintf(pAscii,"\\n"); 
			pAscii+=2; 
		}
		else if (pSrc[i] == '\t') 
		{ 
			sprintf(pAscii,"\\t");
			pAscii+=2;
		}
		else if (pSrc[i] == '\v') 
		{ 
			sprintf(pAscii,"\\v"); 
			pAscii+=2; 
		}
		else if (pSrc[i] == '\b') 
		{
			sprintf(pAscii,"\\b");
			pAscii+=2;
		}
		else if (pSrc[i] == '\r')
		{
			sprintf(pAscii,"\\r"); 
			pAscii+=2; 
		}
		else if (pSrc[i] == '\f')
		{
			sprintf(pAscii,"\\f");
			pAscii+=2; 
		}
		else if (pSrc[i] == '\a')
		{ 
			sprintf(pAscii,"\\a"); 
			pAscii+=2;
		}
		else if (pSrc[i] == '\0') 
		{ 
			sprintf(pAscii,"\\0"); 
			pAscii+=2; 
		}
		else 
		{
			sprintf(pAscii++,"%c",((pSrc[i]<' ' || pSrc[i]>'~')?'.':pSrc[i]));
		}

		if (!(j++ % 2)) 
		{
			sprintf(pHex++," ");
		}

		// ÿ������16���ַ�����л���
		k %= 16;
		if (!(k++)) 
		{
			*pHex = ' ';
			sprintf(pAscii++,"\n");
			pHex = pAscii;
			pAscii +=  41;
		}
	}

	*pHex = ' ';
	pDump[lFinalLen-1] = '\0';

	strcpy(pOutMsg, pDump);
	delete[] pDump;

	return;
}


typedef struct _CALL_INFO 
{
	// ��ͬ��Ҫʹ�õ�AVP
	char SessionId[128];         // �ỰID
	char CCRType;	             // ��������I, U, T, E
	unsigned int TimeStamp;	     // ҵ����ʱ��1900-01-01/00:00:00����������
	unsigned int USU;            // ʹ����
	char Subscription[32];       // �Ʒѷ�����

	// IN DOMAIN
	char CallType;	             // A Calling,  B Called,  T  Transit
	char ANO[32];
	char BNO[32];
	char VLR[32];	             // VLR MSC Number
	char LAI[32];
	char SAI[32];

	// PS DOMAIN
	unsigned int RG;
	unsigned int CCRNum;

	// VASP DOMAIN
	unsigned int RequestAction;
	char MessageId[32+1];

	// VAC DOMAIN
	char szServiceId[128];            // ҵ���ʶ
	char szSPId[128];                 // SP��ʶ
	char szProductId[128];            // BSS��Ʒ��ʶ
	char szSPCProductId[128];         // BSS��Ʒ���ɱ�ʶ
	char szSPProductId[128];          // SP��Ʒ��ʶ
	char szOrderMethodID[128];        // ������ʶ

	unsigned int nChargingType;       // �������ͣ�0Ϊһ�����շѣ������հ��·ѣ�1Ϊһ��ʹ���շѣ����Σ�
	OCP_UINT64   lServiceType;        // ҵ�����������ͣ�1ΪMOAT��2ΪAOMT��3ΪMOMT �ն˵��նˣ�4Ϊ MOET �ն˵�email��5ΪEOMT email ���նˣ�6Ϊ״̬����
	OCP_UINT64   lServiceEnablerType; // ҵ���������
	unsigned int nEventType;          // ���з���1Ϊ���У�2Ϊ���У�3Ϊ��ת
	unsigned int nChargePartyType;    // �Ʒѷ����ͣ�1Ϊ�Է��𷽼Ʒѣ�2Ϊ��Ŀ�ķ��Ʒѣ�3Ϊ�Է��𷽺�Ŀ�ķ�ͬʱ�Ʒѣ�4Ϊ�Ե������Ʒѣ�5Ϊ��SP�Ʒѡ�Ŀǰֻ֧��1��2��


	char szOASubscription[32];        // ���𷽺���
	char szDASubscription[32];        // Ŀ�ķ�����
	char szFASubscription[32];        // ��ת������

	unsigned int nUnitType;           // ��Ԫ�ϱ���ʹ�������ͣ�0Ϊʱ����1Ϊ������3Ϊ��Ԫ��9Ϊֱ�ӿ۷ѵĽ�10Ϊ����
	unsigned int nCCTime;             // ʱ��
	OCP_UINT64   lCCTotalOctets;      // �ֽ���
	OCP_UINT64   lCCSpecificUnits;    // ��Ԫ
	OCP_UINT64   lValueDigits;        // ����еı���
	unsigned int nExponent;           // ����е�ָ��

	void dump()
	{
		printf("=====Begin dump CALLINFO=====\n");
		printf("SessionId = %s\n",              SessionId);
		printf("CCRType = %c\n",                CCRType);
		printf("TimeStamp = %u\n",              TimeStamp);
		printf("USU = %u\n",                    USU);
		printf("Subscription = %s\n",           Subscription);

		printf("CallType = %c\n",               CallType);
		printf("ANO = %s\n",                    ANO);
		printf("BNO = %s\n",                    BNO);
		printf("VLR = %s\n",                    VLR);
		printf("LAI = %s\n",                    LAI);
		printf("SAI = %s\n",                    SAI);

		printf("RG = %u\n",                     RG);
		printf("CCRNum = %u\n",                 CCRNum);

		printf("RequestAction = %d\n",          RequestAction);
		printf("MessageId = %s\n",              MessageId);

		printf("szServiceId = %s\n",            szServiceId);
		printf("szSPId = %s\n",                 szSPId);
		printf("szProductId = %s\n",            szProductId);	
		printf("szSPCProductId = %s\n",         szSPCProductId);
		printf("szSPProductId = %s\n",          szSPProductId);
		printf("szOrderMethodID = %s\n",        szOrderMethodID);

		printf("nChargingType = %u\n",          nChargingType);
		printf("lServiceType = %lld\n",         lServiceType);
		printf("lServiceEnablerType = %lld\n",  lServiceEnablerType);
		printf("nChargePartyType = %u\n",       nChargePartyType);

		printf("szOASubscription = %s\n",       szOASubscription);
		printf("szDASubscription = %s\n",       szDASubscription);
		printf("szFASubscription = %s\n",       szFASubscription);

		printf("nUnitType = %u\n",              nUnitType);
		printf("nCCTime = %u\n",                nCCTime);
		printf("lCCTotalOctets = %lld\n",       lCCTotalOctets);
		printf("lCCSpecificUnits = %lld\n",     lCCSpecificUnits);
		printf("lValueDigits = %lld\n",         lValueDigits);
		printf("nExponent = %u\n",              nExponent);


	}

} CALLINFO;


//SessionId, CCRType, CallType, ANO, BNO, VLR, LAI, SAI, USU, TimeStamp
int FillCallInfo(CALLINFO *CI, const char *line, long HopByHop)
{
	char *p;
	char buf[256] = {0};
	int SessionId;

	char prefix[32] = {0};

	//buf[256] - '\0';
	strncpy(buf, line, 255);


	if(TimeStampFlag == false)
	{
		//prefix
		p=strtok(buf, ", ");
		strcpy(prefix, p);

		// SessionId
		p=strtok(NULL, ", ");
		SessionId = atoi(p);
		if (SessionId <= 0)
		{
			printf("SESSION_ID Error: %s, %s\n", p, line);
			return(-1);
		}

		sprintf(CI->SessionId, "CX_SIM_%010ld_%d", HopByHop, SessionId);
		// sprintf(CI->SessionId, "CX_SIM_%s_%d", prefix, SessionId);
	}
	else
	{
		// SessionId
		p=strtok(buf, ", ");
		SessionId = atoi(p);
		if (SessionId <= 0)
		{
			printf("SESSION_ID Error: %s, %s\n", p, line);
			return(-1);
		}

		sprintf(CI->SessionId, "CX_SIM_%010ld_%d", HopByHop, SessionId);
	}
	// CCRType
	p=strtok(NULL, ", ");		
	CI->CCRType = p[0];

	// CallType
	p=strtok(NULL, ", ");		
	CI->CallType = p[0];

	// ANO
	p=strtok(NULL, ", ");		
	strcpy(CI->ANO, p);

	// BNO
	p=strtok(NULL, ", ");		
	strcpy(CI->BNO, p);

	// VLR
	p=strtok(NULL, ", ");		
	strcpy(CI->VLR, p);

	// LAI
	p=strtok(NULL, ", ");		
	strcpy(CI->LAI, p);

	// SAI
	p=strtok(NULL, ", ");		
	strcpy(CI->SAI, p);

	// USU
	p = strtok(NULL, ", ");
	CI->USU = atoi(p);


	// TimeStamp
	p=strtok(NULL, ", ");		
	CI->TimeStamp = atol(p);
	if (CI->TimeStamp < 3000000000)
	{
		printf("TimeStamp Error: %s, %s\n", p, line);
		return(-1);
	}

	if (CI->CallType == 'B')
	{
	    CI->nEventType = 2;
		strcpy(CI->Subscription, CI->BNO);
	}
	else
	{
	    CI->nEventType = 1;
		strcpy(CI->Subscription, CI->ANO);
	}

	return(0);
}


// SessionID, CCRType, CCRNum, NO, SGSN-Address, RG, USU, TIMESTAMP
int FillPSInfo(CALLINFO *CI, const char *line, long HopByHop)
{
	char *p;
	char buf[256] = {0};
	int SessionId;

	char prefix[32] = {0};

	strncpy(buf, line, 255);

	if(TimeStampFlag == false)
	{
		// prefix
		p=strtok(buf, ", ");
		strcpy(prefix, p);

		// SessionId
		p=strtok(NULL, ", ");		
		SessionId = atoi(p);
		if (SessionId <= 0)
		{
			printf("SESSION_ID Error: %s, %s\n", p, line);
			return(-1);
		}		

		//sprintf(CI->SessionId, "CX_SIM_%s_%d_%ld", prefix, SessionId, HopByHop );
		sprintf(CI->SessionId, "CX_SIM_%s_%d_%u", prefix, SessionId, g_start_time);
	}
	else
	{
		// SessionId
		p=strtok(buf, ", ");		
		SessionId = atoi(p);
		if (SessionId <= 0)
		{
			printf("SESSION_ID Error: %s, %s\n", p, line);
			return(-1);
		}		

		sprintf(CI->SessionId, "CX_SIM_%010ld_%d_%u", HopByHop, SessionId, g_start_time);	
	}


	// CCRType
	p=strtok(NULL, ", ");		
	CI->CCRType = p[0];

	// CCRNUM
	p=strtok(NULL, ", ");		
	CI->CCRNum = atoi(p);

	// NO
	p=strtok(NULL, ", ");		
	strcpy(CI->Subscription, p);

	// SGSN-Address
	p=strtok(NULL, ", ");		
	strcpy(CI->BNO, p);

	// RG
	p=strtok(NULL, ", ");		
	CI->RG = atoi(p);

	// USU
	p = strtok(NULL, ", ");
	CI->USU = atoi(p);

	// TimeStamp
	p=strtok(NULL, ", ");		
	CI->TimeStamp = atol(p);
	if (CI->TimeStamp < 3000000000)
	{
		printf("TimeStamp Error: %s, %s\n", p, line);
		return(-1);
	}

	CI->CallType = '0' + CI->CCRNum;

	return(0);
}

int FillVASPInfo(CALLINFO *CI, const char *line, long HopByHop)
{
	char *p;
	char buf[1024] = {0};	
	char prefix[32] = {0};
	int  packno = 0;

	strncpy(buf, line, 1024);
	if(TimeStampFlag == false)
	{
		// prefix
		p=strtok(buf, ", ");
		strcpy(prefix, p);

		// packno
		p=strtok(NULL, ", ");		
		packno = atoi(p);
	}
	else
	{
		// packno
		p=strtok(buf, ", ");		
		packno = atoi(p);
	}

	// CCRType
	p=strtok(NULL, ", ");
	CI->CCRType = p[0];

	// Subcriber-Id
	p = strtok(NULL, ", ");
	strcpy(CI->Subscription, p);

	// RequestAction
	p=strtok(NULL, ", ");		
	CI->RequestAction = atoi(p);

	// Message-Id
	p=strtok(NULL, ", ");		
	strcpy(CI->MessageId, p);

	// TimeStamp
	p=strtok(NULL, ", ");		
	CI->TimeStamp = atol(p);
	if (CI->TimeStamp < 3000000000)
	{
		printf("TimeStamp Error: %s, %s\n", p, line);
		return(-1);
	}

	return(0);
}


int FillVACEInfo(CALLINFO *CI, const char *line, long HopByHop)
{
	char *p;
	char buf[1024] = {0};	
	char prefix[32] = {0};

	int nSessionId;	
	strncpy(buf, line, 1024);

	if(TimeStampFlag == false)
	{
		// Prefix
		p = strtok(buf, ", ");
		strcpy(prefix, p);

		// SessionId
		p = strtok(NULL, ", ");
		nSessionId = atoi(p);
		if (nSessionId <= 0)
		{
			printf("SESSION_ID Error: %s, %s\n", p, line);
			return(-1);
		}

		//sprintf(CI->SessionId, "CX_SIM_%010ld_%d", HopByHop, nSessionId);	
		sprintf(CI->SessionId, "CX_SIM_123456789_%d", nSessionId);	
	}
	else
	{
		// SessionId
		p = strtok(buf, ", ");
		nSessionId = atoi(p);
		if (nSessionId <= 0)
		{
			printf("SESSION_ID Error: %s, %s\n", p, line);
			return(-1);
		}

		//sprintf(CI->SessionId, "CX_SIM_%010ld_%d", HopByHop, nSessionId);
		sprintf(CI->SessionId, "CX_SIM_123456789_%d", nSessionId);	
	}

	// RequestType
	p = strtok(NULL, ", ");
	CI->CCRType = p[0];

	// RequestNumber
	p=strtok(NULL, ", ");		
	CI->CCRNum = atoi(p);

	// EventTimestamp
	p=strtok(NULL, ", ");		
	CI->TimeStamp = atol(p);
	if (CI->TimeStamp < 3000000000)
	{
		printf("TimeStamp Error: %s, %s\n", p, line);
		return(-1);
	}

	// SubscriptionId
	p = strtok(NULL, ", ");
	strcpy(CI->Subscription, p);

	// RequestAction
	p = strtok(NULL, ", ");		
	CI->RequestAction = atoi(p);

	// MessageId
	p = strtok(NULL, ", ");		
	strcpy(CI->MessageId, p);

	// ServiceId
	p = strtok(NULL, ", ");		
	strcpy(CI->szServiceId, p);

	// SPId
	p = strtok(NULL, ", ");		
	strcpy(CI->szSPId, p);

	// ProductId
	p = strtok(NULL, ", ");		
	strcpy(CI->szProductId, p);

	// SPCProductId
	p = strtok(NULL, ", ");		
	strcpy(CI->szSPCProductId, p);

	// SPProductId
	p = strtok(NULL, ", ");		
	strcpy(CI->szSPProductId, p);

	// OrderMethodID
	p = strtok(NULL, ", ");		
	strcpy(CI->szOrderMethodID, p);

	// ChargingType
	p = strtok(NULL, ", ");
	CI->nChargingType = atoi(p);

	// ServiceType
	p = strtok(NULL, ", ");
	CI->lServiceType = atoi(p);

	// ServiceEnablerType
	p = strtok(NULL, ", ");
	CI->lServiceEnablerType = atoi(p);

	// ChargePartyType
	p = strtok(NULL, ", ");
	CI->nChargePartyType = atoi(p);

	// OASubscription
	p = strtok(NULL, ", ");		
	strcpy(CI->szOASubscription, p);

	// DASubscription
	p = strtok(NULL, ", ");		
	strcpy(CI->szDASubscription, p);

	// FASubscription
	p = strtok(NULL, ", ");		
	strcpy(CI->szFASubscription, p);

	// UnitType
	p = strtok(NULL, ", ");		
	CI->nUnitType = atoi(p);

	// CCTime
	p = strtok(NULL, ", ");		
	CI->nCCTime = atoi(p);

	// CCTotalOctets
	p = strtok(NULL, ", ");		
	CI->lCCTotalOctets = atoi(p);

	// CCSpecificUnits
	p = strtok(NULL, ", ");		
	CI->lCCSpecificUnits = atoi(p);

	// ValueDigits
	p = strtok(NULL, ", ");		
	CI->lValueDigits = atoi(p);	

	// Exponent
	p = strtok(NULL, ", ");		
	CI->nExponent = atoi(p);	

	if(g_debug == 1)
	{
		CI->dump();
	}	

	return(0);
}

int FillVACSInfo(CALLINFO *CI, const char *line, long HopByHop)
{
	char *p;
	char buf[1024] = {0};	
	char prefix[32] = {0};

	int nSessionId;	
	strncpy(buf, line, 1024);

	if(TimeStampFlag == false)
	{
		// Prefix
		p = strtok(buf, ", ");
		strcpy(prefix, p);

		// SessionId
		p = strtok(NULL, ", ");
		nSessionId = atoi(p);
		if (nSessionId <= 0)
		{
			printf("SESSION_ID Error: %s, %s\n", p, line);
			return(-1);
		}

		//sprintf(CI->SessionId, "CX_SIM_%010ld_%d", HopByHop, nSessionId);	
		sprintf(CI->SessionId, "CX_SIM_123456789_%d", nSessionId);	
	}
	else
	{
		// SessionId
		p = strtok(buf, ", ");
		nSessionId = atoi(p);
		if (nSessionId <= 0)
		{
			printf("SESSION_ID Error: %s, %s\n", p, line);
			return(-1);
		}

		//sprintf(CI->SessionId, "CX_SIM_%010ld_%d", HopByHop, nSessionId);
		sprintf(CI->SessionId, "CX_SIM_123456789_%d", nSessionId);	
	}

	// RequestType
	p = strtok(NULL, ", ");
	CI->CCRType = p[0];

	// RequestNumber
	p=strtok(NULL, ", ");		
	CI->CCRNum = atoi(p);

	// EventTimestamp
	p=strtok(NULL, ", ");		
	CI->TimeStamp = atol(p);
	if (CI->TimeStamp < 3000000000)
	{
		printf("TimeStamp Error: %s, %s\n", p, line);
		return(-1);
	}

	// SubscriptionId
	p = strtok(NULL, ", ");
	strcpy(CI->Subscription, p);

	// RequestAction
	p = strtok(NULL, ", ");		
	CI->RequestAction = atoi(p);

	// MessageId
	p = strtok(NULL, ", ");		
	strcpy(CI->MessageId, p);

	// ServiceId
	p = strtok(NULL, ", ");		
	strcpy(CI->szServiceId, p);

	// SPId
	p = strtok(NULL, ", ");		
	strcpy(CI->szSPId, p);

	// ProductId
	p = strtok(NULL, ", ");		
	strcpy(CI->szProductId, p);

	// SPCProductId
	p = strtok(NULL, ", ");		
	strcpy(CI->szSPCProductId, p);

	// SPProductId
	p = strtok(NULL, ", ");		
	strcpy(CI->szSPProductId, p);

	// OrderMethodID
	p = strtok(NULL, ", ");		
	strcpy(CI->szOrderMethodID, p);

	// ChargingType
	p = strtok(NULL, ", ");
	CI->nChargingType = atoi(p);

	// ServiceType
	p = strtok(NULL, ", ");
	CI->lServiceType = atoi(p);

	// ServiceEnablerType
	p = strtok(NULL, ", ");
	CI->lServiceEnablerType = atoi(p);

	// ChargePartyType
	p = strtok(NULL, ", ");
	CI->nChargePartyType = atoi(p);

	// OASubscription
	p = strtok(NULL, ", ");		
	strcpy(CI->szOASubscription, p);

	// DASubscription
	p = strtok(NULL, ", ");		
	strcpy(CI->szDASubscription, p);

	// FASubscription
	p = strtok(NULL, ", ");		
	strcpy(CI->szFASubscription, p);

	// UnitType
	p = strtok(NULL, ", ");		
	CI->nUnitType = atoi(p);

	// CCTime
	p = strtok(NULL, ", ");		
	CI->nCCTime = atoi(p);

	// CCTotalOctets
	p = strtok(NULL, ", ");		
	CI->lCCTotalOctets = atoi(p);

	// CCSpecificUnits
	p = strtok(NULL, ", ");		
	CI->lCCSpecificUnits = atoi(p);

	// ValueDigits
	p = strtok(NULL, ", ");		
	CI->lValueDigits = atoi(p);	

	// Exponent
	p = strtok(NULL, ", ");		
	CI->nExponent = atoi(p);	

	if(g_debug == 1)
	{
		CI->dump();
	}	

	return(0);
}

// =============
// ����OCP�����
// =============
SunriseOCP *FillINOCP(SunriseOCP *ocp_i, SunriseOCP *ocp_u, SunriseOCP *ocp_t, CALLINFO *CI, int hopbyhop)
{
	SunriseOCP *OCP;

	if (CI->CCRType == 'I')
	{
		OCP = ocp_i;
	}
	else if (CI->CCRType == 'U')
	{
		OCP = ocp_u;
	}
	else if (CI->CCRType == 'T')
	{
		OCP = ocp_t;
	}
	else
	{
		printf("Unkown CCRType [%c] \n", CI->CCRType);
		return(NULL);
	}

	AVPGroup *pTopGroup;
	AVPGroup *p_subscribe_id;

	// set host-by-host
	OCP->cmdHeader.hop_by_hop_id = hopbyhop;
	OCP->cmdHeader.end_to_end_id = hopbyhop;

	// Get TOP-GROUP
	pTopGroup = OCP->getTopmostGroup();
	if (pTopGroup == NULL)
	{
		printf("Get pTopGroup Error \n");
		return(NULL);
	}

	// set session-id
	pTopGroup->setField(AVPCODE_SESSION_ID, CI->SessionId, strlen(CI->SessionId)); //"Session-Id"

	// set Time-Stamp
	pTopGroup->setField(AVPCODE_EVENT_TIMESTAMP, (OCP_UINT32 &)CI->TimeStamp); //"Event-Timestamp"

	// set Subscription-Id-Data in Subscription-Id
	if (pTopGroup->getField(AVPCODE_SUBSCRIPTION_ID, p_subscribe_id) < 0) //"Subscription-Id"
	{
		printf("can not find the avp : Subscription-Id\n");
		return(NULL);
	}
	p_subscribe_id->setField(AVPCODE_SUBSCRIPTION_ID_DATA, CI->Subscription, strlen(CI->Subscription)); //"Subscription-Id-Data"


	if (CI->CCRType == 'I')
	{
		AVPGroup *in_information = 0;
		AVPGroup *service_info = 0;

		if (pTopGroup->getField(AVPCODE_SERVICE_INFORMATION , service_info , 0) < 0)//"Service-Information"
		{
			printf("can not find the avp: Service-Information\n");
			return(NULL);
		}

		if (service_info->getField(AVPCODE_IN_INFORMATION  , in_information , 0) < 0) //"IN-Information"
		{
			printf("can not find the avp: Service-Information:IN-Information\n");
			return(NULL);
		}

		in_information->setField(AVPCODE_CALLING_PARTY_NUMBER, CI->ANO, strlen(CI->ANO));//Calling-Party-Number	
		in_information->setField(AVPCODE_CALLED_PARTY_NUMBER, CI->BNO, strlen(CI->BNO));	//Called-Party-Number
		in_information->setField(AVPCODE_REAL_CALLED_NUMBER, CI->BNO, strlen(CI->BNO));  //Real-Called-Number
        in_information->setField(AVPCODE_EVENTTYPE_BCSM, CI->nEventType);

		if (CI->CallType == 'A')
		{	
			in_information->setField(AVPCODE_CALLING_VLR_NUMBER, CI->VLR, strlen(CI->VLR));//"Calling-Vlr-Number"	
			in_information->setField(AVPCODE_CALLING_CELLID_OR_SAI, CI->SAI, strlen(CI->SAI));//"Calling-CellID-Or-SAI"	
			in_information->setField(AVPCODE_CALLING_LAI, CI->LAI, strlen(CI->LAI));//"Calling-LAI"
		}
		else
		{
			in_information->setField(AVPCODE_CALLED_VLR_NUMBER , CI->VLR, strlen(CI->VLR));//"Called-Vlr-Number"	
			in_information->setField(AVPCODE_CALLED_CELLID_OR_SAI, CI->SAI, strlen(CI->SAI));//"Called-CellID-Or-SAI"	
		}	
	}
	else
	{
		AVPGroup *pMscc = 0;
		AVPGroup *Used_Service_Unit = 0;


		if (pTopGroup->getField(AVPCODE_MULTIPLE_SERVICES_CREDIT_CONTROL, pMscc, 0) < 0)//"MSCC"
		{
			printf("can not find the avp: MSCC\n");
			return(NULL);
		}		

		if (pMscc->getField(AVPCODE_USED_SERVICE_UNIT, Used_Service_Unit, 0) < 0)//"Used-Service-Unit"
		{
			printf("can not find the avp: Used-Service-Unit\n");
			return(NULL);
		}

		/*
		if (pTopGroup->getField(AVPCODE_USED_SERVICE_UNIT, Used_Service_Unit, 0) != 0) //"Used-Service-Unit"
		{
		printf("can not find the avp: USU\n");
		return(NULL);
		}

		*/		
		// �����ŵĵ�λ��1/10��
		// unsigned int mUSU = CI->USU*10;
		unsigned int mUSU = CI->USU;
		Used_Service_Unit->setField(AVPCODE_CC_TIME, mUSU);//"CC-Time"
	}

	return(OCP);
}

// =============
// ����OCP�����
// =============
SunriseOCP *FillPSOCP(SunriseOCP *ocp_i, SunriseOCP *ocp_u1, SunriseOCP *ocp_ux, SunriseOCP *ocp_t, CALLINFO *CI, int hopbyhop)
{
	SunriseOCP *OCP;

	if (CI->CCRType == 'I')
	{
		OCP = ocp_i;
	}
	else if (CI->CCRType == 'u')
	{
		OCP = ocp_u1;
	}
	else if (CI->CCRType == 'U')
	{
		OCP = ocp_ux;
	}
	else if (CI->CCRType == 'T')
	{
		OCP = ocp_t;
	}
	else
	{
		printf("Unkown CCRType [%c] \n", CI->CCRType);
		return(NULL);
	}

	AVPGroup *pTopGroup;
	AVPGroup *p_subscribe_id;

	// set host-by-host
	OCP->cmdHeader.hop_by_hop_id = hopbyhop;
	OCP->cmdHeader.end_to_end_id = hopbyhop;

	// Get TOP-GROUP
	pTopGroup = OCP->getTopmostGroup();
	if (pTopGroup == NULL)
	{
		printf("Get pTopGroup Error \n");
		return(NULL);
	}

	// set session-id
	pTopGroup->setField(AVPCODE_SESSION_ID , CI->SessionId, strlen(CI->SessionId));//

	// set Time-Stamp
	pTopGroup->setField(AVPCODE_EVENT_TIMESTAMP, (OCP_UINT32 &)CI->TimeStamp);//"Event-Timestamp"

	// set Subscription-Id-Data in Subscription-Id
	if (pTopGroup->getField(AVPCODE_SUBSCRIPTION_ID , p_subscribe_id) < 0)//"Subscription-Id"
	{
		printf("can not find the avp : Subscription-Id");
		return(NULL);
	}
	p_subscribe_id->setField(AVPCODE_SUBSCRIPTION_ID_DATA , CI->Subscription, strlen(CI->Subscription));//"Subscription-Id-Data"

	// set ccr_num
	pTopGroup->setField(AVPCODE_CC_REQUEST_NUMBER, (OCP_UINT32 &)CI->CCRNum);//"CC-Request-Number"

	if (CI->CCRType == 'u' || CI->CCRType == 'U' || CI->CCRType == 'T')
	{	
		//���ж��RG RG�п����ж��USU  ������� ������xml ģ���ļ���ֵ���з���
		//if(pTopGroup->getFieldCount(AVPCODE_MULTIPLE_SERVICES_CREDIT_CONTROL) > 1)
		//{	
		//	break;
		//}

		AVPGroup *MSCC = 0;

		if (pTopGroup->getField(AVPCODE_MULTIPLE_SERVICES_CREDIT_CONTROL , MSCC , 0) < 0)//"Multiple-Services-Credit-Control"
		{        
			printf("can not find the avp: Multiple-Services-Credit-Control");
			return(NULL);
		}        

		// Set RG
		unsigned int mRG = CI->RG;        		
		MSCC->setField(AVPCODE_RATING_GROUP, mRG);//"Rating-Group"

		// Ux, T, Set USU
		if (CI->CCRType == 'U' || CI->CCRType == 'T')
		{
			AVPGroup *USU = 0;
			if (MSCC->getField(AVPCODE_USED_SERVICE_UNIT , USU, 0) < 0) //"Used-Service-Unit"
			{
				printf("can not find the avp: Used-Service-Unit \n");
				return(NULL);
			}

			OCP_UINT64 mUSU = CI->USU;

			USU->setField(AVPCODE_CC_TOTAL_OCTETS, mUSU);//"CC-Total-Octets"				
		}			
	} 

	//��lst�ļ�������IP��ַ��ocp ���Ѿ�����SGSN_ADDRESSʱ����������
	if(CI->BNO[0] != 0)
	{
		AVPGroup *ServiceInformation = 0;
		AVPGroup *PSInformation = 0;
		//AVPGroup *pSgsnAddress = 0;

		avp_addressType addr;

		if(pTopGroup->getField(AVPCODE_SERVICE_INFORMATION , ServiceInformation , 0) < 0)
		{
			printf("can not find the avp: AVPCODE_SERVICE_INFORMATION \n");
			return(NULL);	
		}

		if(ServiceInformation->getField(AVPCODE_PS_INFORMATION , PSInformation , 0) < 0)
		{
			printf("can not find the avp: AVPCODE_PS_INFORMATION \n");
			return(NULL);	
		}

		if(PSInformation->getField(AVPCODE_SGSN_ADDRESS , &addr) == 0)//�ҵ�SGSN_ADDRESS
		{
			memset(&addr, 0, sizeof(avp_addressType));
			addr.sType = htons(1);
			unsigned int ip =  inet_addr(CI->BNO);
			memcpy(addr.cBuf, &ip, sizeof(unsigned int) );		
			int ret = PSInformation->setField(AVPCODE_SGSN_ADDRESS , &addr, 6);
			if(ret != 0)
			{
			    printf("setField ret = %d\n", ret);
			    return NULL;        
			}			
		}
	}

	return(OCP);
}

// =============
// VASP��ֵOCP�����
// =============
SunriseOCP *FillVASPOCP(SunriseOCP *ocp_e,   // �����E������
						CALLINFO *CI,  // �嵥�ļ���¼
						int hopbyhop)        // Hop-by-Hop��ʶ
{
	SunriseOCP *OCP;

	//-------------------------------------
	// �����ͼ��
	//-------------------------------------
	if (CI->CCRType == 'E')
	{
		OCP = ocp_e;
	}
	else
	{
		printf("Unkown CCRType [%c] \n", CI->CCRType);
		return(NULL);
	}

	AVPGroup *pTopGroup;
	AVPGroup *pServiceInfo;
	AVPGroup *pVASPInfo;
	AVPGroup *pOaSubcriberId;

	//-------------------------------------
	// ����Hop-by-Hop
	//-------------------------------------
	OCP->cmdHeader.hop_by_hop_id = hopbyhop;
	OCP->cmdHeader.end_to_end_id = hopbyhop;

	//-------------------------------------
	// ����AVPֵ
	//-------------------------------------

	// Get TOP-GROUP
	pTopGroup = OCP->getTopmostGroup();
	if (pTopGroup == NULL)
	{
		printf("Get pTopGroup Error \n");
		return(NULL);
	}

	// SERVICE_INFORMATION
	pTopGroup->getField(AVPCODE_SERVICE_INFORMATION, pServiceInfo);

	// AVPCODE_VASP_INFORMATION
	pServiceInfo->getField(20500, pVASPInfo);

	// SUBSCRIPTION_ID
	pVASPInfo->getField(20506 ,pOaSubcriberId);

	// ����SUBSCRIPTION_ID_DATA
	pOaSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA , CI->Subscription, strlen(CI->Subscription));//"Subscription-Id-Data"

	// ����Message-Id
	pVASPInfo->setField(20501, CI->MessageId, strlen(CI->MessageId));

	// ����EVENT_TIMESTAMP
	pTopGroup->setField(AVPCODE_EVENT_TIMESTAMP, (OCP_UINT32 &)CI->TimeStamp);

	// ����REQUESTED_ACTION
	pTopGroup->setField(AVPCODE_REQUESTED_ACTION, (OCP_UINT32 &)CI->RequestAction);

	return(OCP);
}

// =============
// VAC�¼���OCP�����
// =============
SunriseOCP *FillVACEOCP(SunriseOCP *ocp_e,   // �����E������
						CALLINFO *CI,  // �嵥�ļ���¼
						int hopbyhop)        // Hop-by-Hop��ʶ
{
	SunriseOCP *OCP;

	//-------------------------------------
	// �����ͼ��
	//-------------------------------------
	if (CI->CCRType == 'E')
	{
		OCP = ocp_e;
	}
	else
	{
		printf("Unkown CCRType [%c] \n", CI->CCRType);
		return(NULL);
	}
	
	//-------------------------------------
	// ����Hop-by-Hop
	//-------------------------------------
	OCP->cmdHeader.hop_by_hop_id = hopbyhop;
	OCP->cmdHeader.end_to_end_id = hopbyhop;

	//-------------------------------------
	// ����AVPֵ
	//-------------------------------------

	// ��ȡTOP-GROUP
	AVPGroup *pTopGroup = NULL;
	pTopGroup = OCP->getTopmostGroup();
	if (pTopGroup == NULL)
	{
		printf("Get pTopGroup Error \n");
		return(NULL);
	}

	/////

	// ����SESSION_ID
	pTopGroup->setField(AVPCODE_SESSION_ID, CI->SessionId, strlen(CI->SessionId));

	// ����EVENT_TIMESTAMP
	pTopGroup->setField(AVPCODE_EVENT_TIMESTAMP, (OCP_UINT32 &)CI->TimeStamp);	

	// ����REQUEST_NUMBER
	pTopGroup->setField(AVPCODE_CC_REQUEST_NUMBER, (OCP_UINT32 &)CI->CCRNum);	

	// ��ȡSUBSCRIPTION_ID
	AVPGroup *pSubcriberId = NULL;
	pTopGroup->getField(AVPCODE_SUBSCRIPTION_ID, pSubcriberId); 

	// ����SUBSCRIPTION_ID_DATA
	pSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA, CI->Subscription, strlen(CI->Subscription));
	
	// ����REQUESTED_ACTION
	pTopGroup->setField(AVPCODE_REQUESTED_ACTION, (OCP_UINT32 &)CI->RequestAction);

	/////

	AVPGroup *pMSCC      = NULL;
	pTopGroup->getField(AVPCODE_MULTIPLE_SERVICES_CREDIT_CONTROL, pMSCC); 

	AVPGroup *pUSU       = NULL;
	pMSCC->getField(AVPCODE_USED_SERVICE_UNIT, pUSU); 

	AVPGroup *pCCMoney   = NULL;
	pUSU->getField(AVPCODE_CC_MONEY, pCCMoney);

	AVPGroup *pUnitValue = NULL;
	pCCMoney->getField(AVPCODE_UNIT_VALUE, pUnitValue);

	
	switch(CI->nUnitType)
	{
	case 0:  // ʱ��
		CI->lCCTotalOctets = 0;
		CI->lCCSpecificUnits = 0;
				
		pCCMoney->removeAll();
		break;
	case 1:  // ����
		CI->nCCTime = 0;
		CI->lCCSpecificUnits = 0;
		
		pCCMoney->removeAll();
		break;
	case 3:  // ��λ
		CI->nCCTime = 0;
		CI->lCCTotalOctets = 0;
		
		pCCMoney->removeAll();
		break;
	case 9:  // ֱ�ӿ۷ѵĽ��
		CI->nCCTime = 0;
		CI->lCCSpecificUnits = 0;
		CI->lCCTotalOctets = 0;

		pUnitValue->setField(AVPCODE_VALUE_DIGITS, (OCP_UINT64 &)CI->lValueDigits);
		pUnitValue->setField(AVPCODE_EXPONENT,     (OCP_UINT32 &)CI->nExponent);		

		break;
	case 10:  // ����
	default:  // Ĭ��
		CI->nCCTime = 0;
		CI->lCCSpecificUnits = 0;
		CI->lCCTotalOctets = 0;
		pCCMoney->removeAll();
		break;
	}	

	pUSU->setField(AVPCODE_CC_TIME, (OCP_UINT32 &)CI->nCCTime);		
	pUSU->setField(AVPCODE_CC_TOTAL_OCTETS, (OCP_UINT64 &)CI->lCCTotalOctets);
	pUSU->setField(AVPCODE_CC_SERVICE_SPECIFIC_UNITS, (OCP_UINT64 &)CI->lCCSpecificUnits);

	///////

	// ��ȡSERVICE_INFORMATION
	AVPGroup *pServiceInfo = NULL;
	pTopGroup->getField(AVPCODE_SERVICE_INFORMATION, pServiceInfo);

	// ��ȡVASP_INFORMATION
	AVPGroup *pVASPInfo = NULL;
	pServiceInfo->getField(20500, pVASPInfo);

	// ����Message-Id
	pVASPInfo->setField(20501, CI->MessageId, strlen(CI->MessageId));

	// ����Service-ID
	pVASPInfo->setField(20509, CI->szServiceId, strlen(CI->szServiceId));

	// ����SP-Id
	pVASPInfo->setField(20510, CI->szSPId, strlen(CI->szSPId));

	// ����Product-Id
	pVASPInfo->setField(20511, CI->szProductId, strlen(CI->szProductId));

	// ����SPC_ProductID
	pVASPInfo->setField(20521, CI->szSPCProductId, strlen(CI->szSPCProductId));

	// ����SP_ProductID
	pVASPInfo->setField(20522, CI->szSPProductId, strlen(CI->szSPProductId));

	// ����Order_MethodID
	pVASPInfo->setField(20524, CI->szOrderMethodID, strlen(CI->szOrderMethodID));

	// ����Charging_Type
	pVASPInfo->setField(20502, (OCP_UINT32 &)CI->nChargingType);

	// ����Service_Type
	pVASPInfo->setField(20513, (OCP_UINT64 &)CI->lServiceType);

	// ����Service_Enabler_Type
	pVASPInfo->setField(20515, (OCP_UINT64 &)CI->lServiceEnablerType);

	// ����Charge_Party_Type
	pVASPInfo->setField(20503, (OCP_UINT32 &)CI->nChargePartyType);

	// ��ȡOA_SUBSCRIPTION_ID
	AVPGroup *pOaSubcriberId = NULL;
	pVASPInfo->getField(20506 ,pOaSubcriberId);

	// ����0A_SUBSCRIPTION_ID_DATA
	pOaSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA , CI->szOASubscription, strlen(CI->szOASubscription));

	// ��ȡDA_SUBSCRIPTION_ID
	AVPGroup *pDaSubcriberId = NULL;
	pVASPInfo->getField(20507 ,pDaSubcriberId);

	// ����DA_SUBSCRIPTION_ID_DATA
	pDaSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA , CI->szDASubscription, strlen(CI->szDASubscription));

	// ��ȡFA_SUBSCRIPTION_ID
	AVPGroup *pFaSubcriberId = NULL;
	pVASPInfo->getField(20508 ,pFaSubcriberId);

	// ����FA_SUBSCRIPTION_ID_DATA
	pFaSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA , CI->szFASubscription, strlen(CI->szFASubscription));

	return(OCP);
}

// =============
// VAC�Ự��OCP�����
// =============
SunriseOCP *FillVACSOCP(SunriseOCP *ocp_i, SunriseOCP *ocp_u, SunriseOCP *ocp_t, CALLINFO *CI, int hopbyhop)
{
	SunriseOCP *OCP;

	if (CI->CCRType == 'I')
	{
		OCP = ocp_i;
	}
	else if (CI->CCRType == 'U')
	{
		OCP = ocp_u;
	}
	else if (CI->CCRType == 'T')
	{
		OCP = ocp_t;
	}
	else
	{
		printf("Unkown CCRType [%c] \n", CI->CCRType);
		return(NULL);
	}


	//-------------------------------------
	// ����Hop-by-Hop
	//-------------------------------------
	OCP->cmdHeader.hop_by_hop_id = hopbyhop;
	OCP->cmdHeader.end_to_end_id = hopbyhop;

	//-------------------------------------
	// ����AVPֵ
	//-------------------------------------

	// ��ȡTOP-GROUP
	AVPGroup *pTopGroup = NULL;
	pTopGroup = OCP->getTopmostGroup();
	if (pTopGroup == NULL)
	{
		printf("Get pTopGroup Error \n");
		return(NULL);
	}

	/////

	// ����SESSION_ID
	pTopGroup->setField(AVPCODE_SESSION_ID, CI->SessionId, strlen(CI->SessionId));

	// ����EVENT_TIMESTAMP
	pTopGroup->setField(AVPCODE_EVENT_TIMESTAMP, (OCP_UINT32 &)CI->TimeStamp);	

	// ����REQUEST_NUMBER
	pTopGroup->setField(AVPCODE_CC_REQUEST_NUMBER, (OCP_UINT32 &)CI->CCRNum);	

	// ��ȡSUBSCRIPTION_ID
	AVPGroup *pSubcriberId = NULL;
	pTopGroup->getField(AVPCODE_SUBSCRIPTION_ID, pSubcriberId); 

	// ����SUBSCRIPTION_ID_DATA
	pSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA, CI->Subscription, strlen(CI->Subscription));

	// ����REQUESTED_ACTION
	pTopGroup->setField(AVPCODE_REQUESTED_ACTION, (OCP_UINT32 &)CI->RequestAction);

	/////

	if (CI->CCRType != 'I')
	{
		AVPGroup *pMSCC      = NULL;
		pTopGroup->getField(AVPCODE_MULTIPLE_SERVICES_CREDIT_CONTROL, pMSCC); 

		AVPGroup *pUSU       = NULL;
		pMSCC->getField(AVPCODE_USED_SERVICE_UNIT, pUSU); 

		AVPGroup *pCCMoney   = NULL;
		pUSU->getField(AVPCODE_CC_MONEY, pCCMoney);

		AVPGroup *pUnitValue = NULL;
		pCCMoney->getField(AVPCODE_UNIT_VALUE, pUnitValue);

		switch(CI->nUnitType)
		{
		case 0:  // ʱ��
			CI->lCCTotalOctets = 0;
			CI->lCCSpecificUnits = 0;

			pCCMoney->removeAll();
			break;
		case 1:  // ����
			CI->nCCTime = 0;
			CI->lCCSpecificUnits = 0;

			pCCMoney->removeAll();
			break;
		case 3:  // ��λ
			CI->nCCTime = 0;
			CI->lCCTotalOctets = 0;

			pCCMoney->removeAll();
			break;
		case 9:  // ֱ�ӿ۷ѵĽ��
			CI->nCCTime = 0;
			CI->lCCSpecificUnits = 0;
			CI->lCCTotalOctets = 0;

			pUnitValue->setField(AVPCODE_VALUE_DIGITS, (OCP_UINT64 &)CI->lValueDigits);
			pUnitValue->setField(AVPCODE_EXPONENT,     (OCP_UINT32 &)CI->nExponent);		

			break;
		case 10:  // ����			
		default:  // Ĭ��
			CI->nCCTime = 0;
			CI->lCCSpecificUnits = 0;
			CI->lCCTotalOctets = 0;
			pCCMoney->removeAll();
			break;
		}	

		pUSU->setField(AVPCODE_CC_TIME, (OCP_UINT32 &)CI->nCCTime);		
		pUSU->setField(AVPCODE_CC_TOTAL_OCTETS, (OCP_UINT64 &)CI->lCCTotalOctets);
		pUSU->setField(AVPCODE_CC_SERVICE_SPECIFIC_UNITS, (OCP_UINT64 &)CI->lCCSpecificUnits);	
	}

	///////

	// ��ȡSERVICE_INFORMATION
	AVPGroup *pServiceInfo = NULL;
	pTopGroup->getField(AVPCODE_SERVICE_INFORMATION, pServiceInfo);

	// ��ȡVASP_INFORMATION
	AVPGroup *pVASPInfo = NULL;
	pServiceInfo->getField(20500, pVASPInfo);

	// ����Message-Id
	pVASPInfo->setField(20501, CI->MessageId, strlen(CI->MessageId));

	// ����Service-ID
	pVASPInfo->setField(20509, CI->szServiceId, strlen(CI->szServiceId));

	// ����SP-Id
	pVASPInfo->setField(20510, CI->szSPId, strlen(CI->szSPId));

	// ����Product-Id
	pVASPInfo->setField(20511, CI->szProductId, strlen(CI->szProductId));

	// ����SPC_ProductID
	pVASPInfo->setField(20521, CI->szSPCProductId, strlen(CI->szSPCProductId));

	// ����SP_ProductID
	pVASPInfo->setField(20522, CI->szSPProductId, strlen(CI->szSPProductId));

	// ����Order_MethodID
	pVASPInfo->setField(20524, CI->szOrderMethodID, strlen(CI->szOrderMethodID));

	// ����Charging_Type
	pVASPInfo->setField(20502, (OCP_UINT32 &)CI->nChargingType);

	// ����Service_Type
	pVASPInfo->setField(20513, (OCP_UINT64 &)CI->lServiceType);

	// ����Service_Enabler_Type
	pVASPInfo->setField(20515, (OCP_UINT64 &)CI->lServiceEnablerType);

	// ����Charge_Party_Type
	pVASPInfo->setField(20503, (OCP_UINT32 &)CI->nChargePartyType);

	// ��ȡOA_SUBSCRIPTION_ID
	AVPGroup *pOaSubcriberId = NULL;
	pVASPInfo->getField(20506 ,pOaSubcriberId);

	// ����0A_SUBSCRIPTION_ID_DATA
	pOaSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA , CI->szOASubscription, strlen(CI->szOASubscription));

	// ��ȡDA_SUBSCRIPTION_ID
	AVPGroup *pDaSubcriberId = NULL;
	pVASPInfo->getField(20507 ,pDaSubcriberId);

	// ����DA_SUBSCRIPTION_ID_DATA
	pDaSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA , CI->szDASubscription, strlen(CI->szDASubscription));

	// ��ȡFA_SUBSCRIPTION_ID
	AVPGroup *pFaSubcriberId = NULL;
	pVASPInfo->getField(20508 ,pFaSubcriberId);

	// ����FA_SUBSCRIPTION_ID_DATA
	pFaSubcriberId->setField(AVPCODE_SUBSCRIPTION_ID_DATA , CI->szFASubscription, strlen(CI->szFASubscription));

	return(OCP);
}

void uDelay(int interval)
{
	static int TS = 0;

	TS = TS + interval;

	while (TS >= 10000)
	{
		usleep(10000);
		TS = TS - 10000;
	}
	//usleep(interval);
}


int SendCCR(CALLINFO *CIList,         // �嵥�ļ���¼
			int Count,                // �嵥�ļ���¼��
			unsigned int &hopbyhop, 
			int sockfd,               // �������������׽���
			int interval, 
			char *DomainType,         // ҵ������
			SunriseOCP *ocp_i,        // I���ļ�ģ��
			SunriseOCP *ocp_u1,       // U���ļ�ģ��
			SunriseOCP *ocp_ux,       // U���ļ�ģ��
			SunriseOCP *ocp_t,        // T���ļ�ģ��
			SunriseOCP *ocp_e)        // E���ļ�ģ��
{
	char msg_buf[DIAMETER_PACKET_MAX_SIZE];

	CALLINFO *CallInfo;
	SunriseOCP *ocp_x;

	int Len;
	struct timezone tz;
	struct timeval now;

	if (g_debug == 1)
	{
		printf("Begin send CCR, interval=%d...\n",interval);
	}
	
	for(int i=0; i<Count; i++)
	{
		CallInfo = &(CIList[i]);	

		if (strcmp(DomainType, "IN") == 0)
		{
			if ((ocp_x = FillINOCP(ocp_i, ocp_ux, ocp_t, CallInfo, hopbyhop)) == NULL)
			{
				return(-1);
			}
		}
		else if (strcmp(DomainType, "PS") == 0)
		{
			if ((ocp_x = FillPSOCP(ocp_i, ocp_u1, ocp_ux, ocp_t, CallInfo, hopbyhop)) == NULL)
			{
				return(-1);
			}	
		}
		else if (strcmp(DomainType, "VASP") == 0)
		{
			if ((ocp_x = FillVASPOCP(ocp_e, CallInfo, hopbyhop)) == NULL)
			{
				return(-1);
			}
		}
		else if (strcmp(DomainType, "VAC_E") == 0)
		{
			if ((ocp_x = FillVACEOCP(ocp_e, CallInfo, hopbyhop)) == NULL)
			{
				return(-1);
			}
		}
		else if (strcmp(DomainType, "VAC_S") == 0)
		{
			if ((ocp_x = FillVACSOCP(ocp_i, ocp_ux, ocp_t, CallInfo, hopbyhop)) == NULL)
			{
				return(-1);
			}
		}
		else
		{
			printf("Unknow DomainType: %s \n", DomainType); 
			return(-1);
		} 	


		//for dubug  
		//printf("in SendCCR ###################\n");
		if(g_debug == 1)
		{	
		    string sun_in_s;
            ocp_x->dump(sun_in_s);
            printf("is:\n %s \n" , sun_in_s.c_str());	
		}

		memset(msg_buf, 0, sizeof(msg_buf));
		Len = ocp_x->getBuffer(msg_buf, sizeof(msg_buf));
		if(Len <= 0)
		{
			printf("can not generate binary diameter message\n");
			return(-1);
		}

		Len = write(sockfd, msg_buf, Len);
		if(Len <= 0)
		{
			perror("write");
			return(-1);
		}		
		gettimeofday(&now, &tz);

		if(strcmp(DomainType, "IN") == 0 || strcmp(DomainType, "PS") == 0)
		{
			printf("[%ld.%06ld] SEND: %u <%s> %s, %c, %c, %u, %d\n", 
				now.tv_sec, now.tv_usec, ocp_x->cmdHeader.hop_by_hop_id, CallInfo->SessionId, CallInfo->Subscription, 
				CallInfo->CCRType, CallInfo->CallType, CallInfo->TimeStamp, CallInfo->USU);
		}
		else
		{
			printf("[%ld.%06ld] SEND: %u <%s> %s, %c, %d, %s, %u\n", 
				now.tv_sec, now.tv_usec, ocp_x->cmdHeader.hop_by_hop_id, CallInfo->SessionId, CallInfo->Subscription,
				CallInfo->CCRType, CallInfo->RequestAction, CallInfo->MessageId, CallInfo->TimeStamp);
		}

		// usleep(interval);
		uDelay(interval);

		hopbyhop ++;

	}		
	return(0);
}

int main(int argc, char **argv)
{
	extern char *optarg;
        int skip_len = 66;
	int optch;    
	char file_name[255];
	char xml_file_name[255];
	char case_file_name[255];
	char cap_file_name[255];
	int sockfd;
	int fep_id = 0;

	char log_file_name[255] = {0};
	//    sprintf(log_file_name, "diam_log");
	struct sockaddr_in servaddr;
	unsigned long timestamp;

	//-------------------------------------
	// ���ò��ֲ����ĳ�ʼֵ
	//-------------------------------------
	int delete_log = 0;

	int SpeedX = 2;
	int timeout = 30;
	int duration = 30;
	int port = 3868 ;
	char host_ip[20] = "10.200.50.248";
	char DomainType[32] = "IN";   
	bool bModify=true;
	int nAppId = 1;
	// int interval = 100;  //interval in ms


	memset(file_name,0 ,sizeof(file_name));
	memset(xml_file_name,0 ,sizeof(xml_file_name));
	//memset(log_file_name,0 ,sizeof(log_file_name));

	char _tmp_log_name[128] = {0};
	sprintf(_tmp_log_name, "diam_log");//Ĭ��ֵ

	bool bUseCapFile = false;
    
    g_start_time = time(NULL);
	//-------------------------------------
	// �����������
	//-------------------------------------
	while( (optch = getopt(argc , argv , optstring) ) != -1 ) 
	{
		switch( optch )
		{
		case 'h': // ��ʾ����
			print_usage();
			exit(-1);

		case 'v': // ��ӡ�汾
			ShowVersion();
			exit(-1);

		case 'p': // ָ���˿�
			port = atoi(optarg);
			break;

		case 's': // ָ��������ַ
			strcpy(host_ip , optarg);
			break;

		case 'g': // ����ģʽ
			g_debug = 1;
			break;

		case 'f':
			strcpy(file_name, optarg);
			break;

		case 'x': // ָ��ģ���ļ�
			strcpy(xml_file_name , optarg);
			break;

		case 'o': // ָ���հ�ʱ�ĳ�ʱʱ��
			timeout = atoi(optarg);
			break;

		case 'l': // ָ����־�ļ�
			{
				memset(_tmp_log_name, 0, sizeof(_tmp_log_name));	
				strcpy(_tmp_log_name , optarg);
			}
			break;

		case 'd': // ɾ������־�ļ�
			delete_log = 1;
			break;

		case 'L': // ָ���嵥�ļ�
			strcpy(case_file_name, optarg);
			break;

		case 'X': // ָ����������
			SpeedX = atoi(optarg);
			break;

		case 'M': // ָ��ҵ������
			strcpy(DomainType, optarg);
			break;

		case 'T':
			TimeStampFlag = true;	
			break;    

		case 'b':
			strcpy(cap_file_name, optarg);			
			bUseCapFile = true;
			break;

        case 'k':
            skip_len = atoi(optarg);
            break;
        case 'A':
            nAppId = atoi(optarg);
            break;
		}
	}

	//-------------------------------------
	// ������Ч�Լ��
	//-------------------------------------
	if((!bUseCapFile && file_name[0] == 0 && xml_file_name[0] == 0 && case_file_name[0] == 0) || (bUseCapFile && cap_file_name[0] == 0))
	{
		printf("no input file name specified!\n");
		print_usage();
		exit(-1);
	}

	if(port == 0 )
	{
		//diameter default port
	}

	//-------------------------------------
	// ����ҵ�����ȷ���ֵ��ļ������м���
	// TODO������µ�ҵ������
	//-------------------------------------	
	if (initDiamDict(DomainType) != 0)
	{
		printf("Failed to init dictnary!\n");
		exit(-1);
	}

	//-------------------------------------
	// �Ǽ��źŴ�������
	//-------------------------------------
	if (signal(SIGINT, sig_term_main) == SIG_ERR)
	{
		perror("signal error");
		exit(-1);
	}

	if (signal(SIGTERM, sig_term_main) == SIG_ERR)
	{
		perror("signal error");
		exit(-1);
	}

	if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		perror("socket");
		exit(-1);
	}

	//-------------------------------------
	// ������־�������·����
	//-------------------------------------
	char log_path[256] = {0};
	getcwd(log_path, 256);        
	snprintf(log_file_name, sizeof(log_file_name), "./%s", _tmp_log_name);

	//-------------------------------------
	// ��������    
	//-------------------------------------
	memset(&servaddr, 0 , sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(port);  /* daytime server */
	if (inet_pton(AF_INET, host_ip, &servaddr.sin_addr) <= 0)
	{
		perror("inet_pton");
		exit(-1);
	}

	if (connect(sockfd, (sockaddr *) &servaddr, sizeof(servaddr)) < 0)
	{
		perror("connect error");
		exit(-1);
	}

	//printf("connect success!\n");

	//-------------------------------------
	// �����׽���ѡ��
	//-------------------------------------

	// set BUF_SIZE to 4K
	int rcv_buf = 4096*100;
	socklen_t rcv_buf_len = sizeof(int);
	if(setsockopt(sockfd , SOL_SOCKET, SO_RCVBUF, &rcv_buf , rcv_buf_len) == -1) // ���ջ�������С
	{
		printf("setsockopt SO_RCVBUF failed:%s\n", strerror(errno));
		exit(-1);
	}

	int snd_buf = 4096*100; 
	socklen_t snd_buf_len = sizeof(int);
	if(setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, &snd_buf, snd_buf_len) == -1)  // ���ͻ�������С
	{
		printf("setsockopt SO_RCVBUF failed:%s\n", strerror(errno));
		exit(-1);
	}

	/* ʹ��NODELAYѡ������Write Error����ʱ������ */
	/*
	int flag = 1;
	if (setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (void*) &flag, sizeof(int)) < 0)
	{
	printf("setsockopt SO_RCVBUF failed:%s\n", strerror(errno));
	exit(-1);
	}
	*/


	//==================================================================
	// CER/CEA ���Ĵ�����V1.3�Ǿ͵� HardCode 
	// ���黹��ʹ��XML������

	// DIAMETER ����BUF, 1024 �ƺ�С�˵㣬�ĳ� 10240
	// ���msg_buf ֻ�Ǹ�CER/CEAʹ��
	char msg_buf[DIAMETER_PACKET_MAX_SIZE];
    memset(msg_buf , 0 , sizeof(msg_buf));
    
	SunriseOCP cer(msg_buf, sizeof(msg_buf), 0, true, 1, CER_CMD_CODE);
	AVPGroup *pGroup = cer.getTopmostGroup();
	pGroup->addField(AVPCODE_ORIGIN_HOST , "ggsn.cu.com", 20);//"Origin-Host"
	pGroup->addField(AVPCODE_ORIGIN_REALM, "cu.com", 20);     //"Origin-Realm"

	avp_addressType addr;
	addr.sType = htons(1);
	unsigned int ip =  inet_addr("10.200.50.248");
	memcpy(addr.cBuf, &ip, sizeof(unsigned int) );		
	pGroup->addField(AVPCODE_HOST_IP_ADDRESS , &addr, 6);	

	pGroup->addField(AVPCODE_VENDOR_ID, 80001);			         //"Vendor-Id"
	pGroup->addField(AVPCODE_PRODUCT_NAME, "ocs", strlen("ocs"));//"Product-Name" 
	pGroup->addField(AVPCODE_AUTH_APPLICATION_ID, 4);	         //"Product-Name" 

	if(g_debug == 1)
	{
	    string cer_s;
        cer.dump(cer_s);
        printf("CER is:\n %s \n" , cer_s.c_str());
	}

	int nLen = cer.getBuffer(msg_buf, sizeof(msg_buf));
	if(nLen <= 0 )
	{
		printf("can not generate binary diameter message\n");
		exit(-1);
	}

	nLen = write(sockfd , msg_buf , nLen);
	if(nLen <= 0)
	{
		perror("write");
		exit(-1);
	}

	// ���� CEA, ���������Ļ����ʾ
	// ��ע�⺯�������CEA/DWA����ʾ����
	// V1.3��û�п��ǵ���
	if(get_diameter_msg(sockfd, timeout)!=0)
	{
		printf("get cea failed\n");
		exit(-1);
	}
	
	// CER/CEA ���Ĵ��������
	//==================================================================


	//-------------------------------------
	// ����ģ���ļ�
	// TODO������µ�ҵ������
	//-------------------------------------

	// ��XML�����ļ��ж���I��U1��Ux��T ���Ķ���
	// Ԥ�Ƚ�����OCP�ڲ��ṹ���Թ������ĳ�����ʹ��
	// V1.3���õ�XML�ļ���������: SCP_I.xml, SCP_U.xml, SCP_T.xml
	// Ϊ֧��GPRS, ��������: GPRS_I.xml, GPRS_U1.xml, GRPS_Ux.XML, GPRS_T.xml
	// ���У�������U��ʹ��Ux�ļ�������

	// �����Ժ���������ļ���ʽ�����壬��Ϊ�Ժ�SMPP��EMPP����Ԫ��ģ����Ҫ�����XML
	// ����������������壬��Ȼ����

	//char buf_i[DIAMETER_PACKET_MAX_SIZE], buf_u1[DIAMETER_PACKET_MAX_SIZE];		// bufs for I, U1 OCP, just for xml file
	//char buf_ux[DIAMETER_PACKET_MAX_SIZE], buf_t[DIAMETER_PACKET_MAX_SIZE]; 	// bufs for Ux, T OCP, just for xml file

	char buf[DIAMETER_PACKET_MAX_SIZE]; 	// buf for binary, just for binary file

	//int n_len = 0;

	char xml_i_file_name[80], xml_u1_file_name[80], xml_ux_file_name[80], xml_t_file_name[80], xml_e_file_name[80];
	SunriseOCP *ocp_i, *ocp_u1, *ocp_ux, *ocp_t, *ocp_e;

	if (!bUseCapFile)
	{		
		if(strcmp(DomainType, "IN") == 0 || strcmp(DomainType, "PS") == 0 || strcmp(DomainType, "VAC_S") == 0) // ����������ҵ��ͻỰ��VACҵ��
		{		
			if (strcmp(DomainType, "VAC_S") == 0)
			{
				nAppId = 1;
			}

			// ƴװI����xmlģ���ļ�����·����
			strcpy(xml_i_file_name, xml_file_name);
			sprintf(xml_i_file_name+strlen(xml_i_file_name)-4, "_I.xml");
			printf("Opening I file [%s] \n", xml_i_file_name);
            
            char buf_i[10240]  = {0};    
			// ����I����xmlģ���ļ�
			ocp_i  = process_xml2diam(xml_i_file_name, nAppId, buf_i);
			if(NULL == ocp_i)
			{
				printf("Transfer xml file to diameter init package failed!\n");
				return -1;
			}
            
            if(g_debug == 1)
            {
                string str_i;
                ocp_i->dump(str_i);
                printf("OCP_I is:\n %s \n" , str_i.c_str());
            }    
			// ƴװU����xmlģ���ļ�����·����
			// ע�⣺������ʹ��U1���Ķ��壬����U��ʹ��Ux���Ķ���
			char buf_u1[10240] = {0};
			strcpy(xml_u1_file_name, xml_file_name);
			sprintf(xml_u1_file_name+strlen(xml_u1_file_name)-4, "_U1.xml");
			printf("Opening U1 file [%s] \n", xml_u1_file_name);

			// ����U����xmlģ���ļ�
			ocp_u1 = process_xml2diam(xml_u1_file_name, nAppId, buf_u1);
			if(NULL == ocp_u1)
			{
				printf("Transfer xml file to diameter U1 package failed!\n");
				return -1;
			}

            if(g_debug == 1)
            {   
                string str_u1;
                ocp_u1->dump(str_u1);
                printf("OCP_U1 is:\n %s \n" , str_u1.c_str());
            }
			// ƴװU����xmlģ���ļ�����·����
			strcpy(xml_ux_file_name, xml_file_name);
			sprintf(xml_ux_file_name+strlen(xml_ux_file_name)-4,  "_Ux.xml");
			printf("Opening UX file [%s] \n", xml_ux_file_name);

			// ����U����xmlģ���ļ�
			char buf_ux[10240] = {0};
			ocp_ux = process_xml2diam(xml_ux_file_name, nAppId, buf_ux);
			if(NULL == ocp_ux )
			{
				printf("Transfer xml file to diameter Ux package failed!\n");
				return -1;
			}

	
            if(g_debug == 1)
            {   
                string str_ux;
                ocp_ux->dump(str_ux);
                printf("OCP_Ux is:\n %s \n" , str_ux.c_str());
            }
		// ƴװT����xmlģ���ļ�����·����
			strcpy(xml_t_file_name, xml_file_name);
			sprintf(xml_t_file_name+strlen(xml_t_file_name)-4, "_T.xml");
			printf("Opening T file [%s] \n", xml_t_file_name);

			// ����T����xmlģ���ļ�
			char buf_t[10240] = {0};
			ocp_t = process_xml2diam(xml_t_file_name, nAppId, buf_t);
			if(NULL == ocp_t)
			{
				printf("Transfer xml file to diameter terminal package failed!\n");
				return -1;
			}
		
            if(g_debug == 1)
            {   
                string str_t;
                ocp_t->dump(str_t);
                printf("OCP_T is:\n %s \n" , str_t.c_str());
            }		
		}	
		#if 0
		else if (strcmp(DomainType, "VASP") == 0 || strcmp(DomainType, "VAC_E") == 0) // VASP���¼���VAC	 
		{	
			if (strcmp(DomainType, "VAC_E") == 0)
			{
				nAppId = 1;
			}

			// ƴװE����xmlģ���ļ�����·����
			strcpy(xml_e_file_name, xml_file_name);
			sprintf(xml_e_file_name+strlen(xml_e_file_name)-4, "_E.xml");
			printf("Opening E file [%s] \n", xml_e_file_name);

			// ����E����xmlģ���ļ�
			ocp_e = process_xml2diam(xml_e_file_name, nAppId);
			if(NULL == ocp_e)
			{
				printf("Transfer xml file to diameter event package failed!\n");
				return -1;
			}
		}
		#endif	
		else
		{
			printf("Not support this service DomainType Type: %s!\n", DomainType);
			return -1;
		}
	}
	

	//-------------------------------------
	// ɾ���ɵ���־�ļ�
	//-------------------------------------
	if(delete_log == 1 && log_file_name[0] != 0)
	{
		char tmp_name[255] = {0};
		sprintf(tmp_name , "%s%s" , log_file_name , ".receive");
		unlink(tmp_name);
		sprintf(tmp_name , "%s%s" , log_file_name , ".send");
		unlink(tmp_name);
	}

	struct timezone tz;
	struct timeval now;
	char session[100];

	//-------------------------------------
	// FORK ����������CCA�Ľ��ա������Log���
	//-------------------------------------
	if ( (g_childid = fork()) == 0)
	{
		if (signal(SIGTERM, sig_term_receive) == SIG_ERR)
		{
			perror("signal error");
			exit(-1);
		}

		if (signal(SIGINT, sig_term_receive) == SIG_ERR)
		{
			perror("signal error");
			exit(-1);
		}

		if (signal(SIGALRM, sig_alarm_receive) == SIG_ERR)
		{
			perror("signal error");
			exit(-1);
		}
        
        int recv_log = 0;
        RE_RECV:
        int count = 0;    
		// ׼���÷���LOG�ļ������֮�����Ϣ�����д��Log�ļ����������Ļ���
		if(log_file_name[0] != '\0')
		{
		    char buf[64] = {0};
		    snprintf(buf, sizeof(buf), "_%d.receive", recv_log);
		    recv_log++;
			int fd = open_log_file(log_file_name , buf);
			if(fd == -1)
			{
				printf("open log file faild:%s.receive\n" , log_file_name);
				perror("open");
				exit(-1);
			}
			// �ѱ�׼����ض���Log�ļ�

			close(STDOUT_FILENO);
			dup2(fd , STDOUT_FILENO);
			close(fd);
		}
		while(1)
		{
			int n = get_diameter_msg(sockfd, timeout);
			if(n == -1 )
			{
				printf("�ڲ�ת�ⲿ����ʧ��!\n" );
				exit(-1);
			}
			else if (n == -9999)
			{
				printf("OK!\n" );
				break;
			}
			count++;
		/*	
			if(count >= 1500000)
			{
			    fflush(stdout);
			    //close(STDOUT_FILENO);  
			    goto RE_RECV;
			}  
        */    
		}
		close(sockfd);
		exit(0);
	}

	
	//==================================================================
	// CCR������ͷ���
int send_log = 0;	
RE_SEND:
	// ׼���÷���LOG�ļ������֮�����Ϣ�����д��Log�ļ����������Ļ��� 
	if(log_file_name[0] != '\0')
	{
	    char buf[64] = {0};
	    snprintf(buf, sizeof(buf), "_%d.send", send_log);
	    send_log++;
		int fd = open_log_file(log_file_name , buf);
		if(fd == -1)
		{
			printf("open log file faild:%s.send\n" , log_file_name);
			perror("open");
			exit(-1);
		}

		// �ѱ�׼����ض���Log�ļ� 

		close(STDOUT_FILENO);
		dup2(fd , STDOUT_FILENO);
		close(fd);
	}

	// ��������˷���ʱ��������Alarm����ʱǿ����ֹCCR�ķ���
	// һ������£��������û��ʲô�ã�����ֻ���ϴ���ʱ�ڱ����ļ���֮��
	// ������ˣ����Ǳ�����
	if(duration != 0 )
	{
		//signal(SIGALRM , sig_alarm_send);
		//alarm(duration);
	}  


	// read case list file <subno+seq_type+seq_no>
	// loop to file the avps and send 
	AVPGroup *pTopGroup;
	AVPGroup *p_subscribe_id;

	SunriseOCP *ocp_x;

	//-------------------------------------
	// ���嵥�ļ�
	//-------------------------------------
	FILE *list_fp = NULL;
	FILE *cap_fp  = NULL;
	if (!bUseCapFile)
	{		
		list_fp = fopen(case_file_name, "r");
		if (list_fp == NULL)
		{
			perror("Open list file faild\n");
			exit(-1);
		}
		else
		{
			printf("Open list file [%s] OK\n", case_file_name);
		}
	}
	else
	{
    	cap_fp = fopen(cap_file_name, "rb");
		if (cap_fp == NULL)
		{
			perror("Open cap file faild\n");
			exit(-1);
		}
		else
		{
			printf("Open cap file [%s] OK\n", cap_file_name);
		}

	}	

	sleep(2);

	//-------------------------------------
	// ��ʼ�������ͻ�����
	// ע�⣺����ʱ��ÿ��Ϊ������λ����󷢱���Ϊ2048/Sec
	//-------------------------------------
	
	CALLINFO CIList[10240];	

	char line[1024];
	int CountOfCI;
	long TS = 0;
	
	bool TSFirst = true;

	// �嵥��¼�ṹ�����
	CALLINFO *CallInfo = (CALLINFO *) malloc(sizeof(CALLINFO));
	if (CallInfo == NULL)
	{
		printf("Malloc CallInfo Faild, Exit -1 \n");
		exit(-1);
	}

	// Hop-by-Hopֵ
	gettimeofday(&now, &tz);
	unsigned int hopbyhop = now.tv_sec * 10000 + now.tv_usec / 10000;
	unsigned int INIT_HOP = hopbyhop;

	//-------------------------------------
	// ��ӡ������ʼʱ��
	//-------------------------------------
	printf("[%ld.%06ld] Begin ... \n", now.tv_sec, now.tv_usec);

	//-------------------------------------
	// ˳��������л�����������ʱ��˳�򣬽�ͬ1��ı����ȶ���
	// Ȼ����ݱ���������̬���������ٶ�
	//-------------------------------------
	if (!bUseCapFile)
	{
		CountOfCI = 0;
		while(1)
		{  	
			memset(line, 0, sizeof(line));

			// ���嵥�ļ���˳������¼
			if (fgets(line, sizeof(line), list_fp) == NULL)
			{    
				break;
			}

			// ����ע��
			if (line[0] == '#')
			{
				continue;
			}		

			// ������¼������ṹ����		
			// ע�⣺����ʹ��INIT_HOP������hopbyhop, ��Ϊhopbyhop����SendOCP�б��ۼ�, �����ᵼ��SessionID�����
			// TODO������µ�ҵ������
			if (strcmp(DomainType, "IN") == 0)
			{
				// ��¼��ʽ "Session_ID, CCRType, CallType, ANO, BNO, VLR, LAI, SAI, USU, TIMESTAMP"
				if (FillCallInfo(CallInfo, line, INIT_HOP) != 0)
				{
					break;
				}
			}
			else if (strcmp(DomainType, "PS") == 0)
			{ 
				if (FillPSInfo(CallInfo, line, INIT_HOP) != 0)
				{
					break;
				}
			}
			else if (strcmp(DomainType, "VASP") == 0)
			{
				if(FillVASPInfo(CallInfo, line, INIT_HOP) != 0)
				{
					break;
				}
			}
			else if (strcmp(DomainType, "VAC_E") == 0)
			{
				if(FillVACEInfo(CallInfo, line, INIT_HOP) != 0)
				{
					break;
				}
			}
			else if (strcmp(DomainType, "VAC_S") == 0)
			{
				if(FillVACSInfo(CallInfo, line, INIT_HOP) != 0)
				{
					break;
				}
			}

			// DEBUG
			// printf("Readed: %s, %c, %c, %s, %s, %s, %s, %s, %u, %d\n", CallInfo->SessionId,
			//	CallInfo->CCRType, CallInfo->CallType, CallInfo->ANO, CallInfo->BNO,
			//	CallInfo->VLR, CallInfo->SAI, CallInfo->LAI, CallInfo->TimeStamp, CallInfo->USU);

			// ����ǵ�1����¼���������ҵ����ʱ��
			if (TSFirst == true)
			{
				TS = CallInfo->TimeStamp;
				TSFirst = false;
			}

			/* Ϊ֧��HPϵͳ�����ú��ٷ����������ÿ��2000������ 	*/
			/* ��ע������ı���ʵ�� 								*/
			/*		
			if (CountOfCI <= 20)
			{
			memcpy(&(CIList[CountOfCI]), CallInfo, sizeof(CALLINFO));
			CountOfCI++;	
			}
			else
			{
			SendCCR(CIList, CountOfCI, hopbyhop, sockfd, 0, DomainType, ocp_i, ocp_u1, ocp_ux, ocp_t);
			usleep(100000/SpeedX);

			CountOfCI = 0;
			memset(CIList, 0, sizeof(CIList));
			}
			*/

			// ���ͬһ���ڣ���Ҫ�����ĸ�������2048�����Ͼ����2048��������
			// Ȼ��������룬��ʱ�п��ܻ��Ǹ��ϴ�ͬһ���ʱ��
			if (CountOfCI >= 10240)
			{
				// ����¼��������CCRȻ����
				// ע�⣺hopbyhop����SendOCP()�б��ۼ�
				// TODO������µ�ҵ������
				SendCCR(CIList, CountOfCI, hopbyhop, sockfd, 1000000/CountOfCI/SpeedX, DomainType, ocp_i, ocp_u1, ocp_ux, ocp_t, ocp_e);

				memset(CIList, 0, sizeof(CIList));

				// ���ֵ�1����¼�Ĵ���
				CountOfCI = 0;			
				memcpy(&(CIList[CountOfCI]), CallInfo, sizeof(CALLINFO));

				// �ۼ��Ѵ�����¼
				CountOfCI ++;
			}
			else
			{
				// ����ü�¼��ҵ����ʱ��С�ڵ��ڱ��ֵ�1����¼�ģ�
				// ���ʾ����¼Ҳ��Ҫ�ڱ��ַ����������ռ�����
				if (TS >= CallInfo->TimeStamp)
				{
					memcpy(&(CIList[CountOfCI]), CallInfo, sizeof(CALLINFO));
					CountOfCI ++;	
				}
				// ����ü�¼��ҵ����ʱ����ڱ��ֵ�1����¼�ģ�
				// �򽫱����ռ������м�¼��������
				else	
				{
					// ����¼��������CCRȻ����
					// TODO������µ�ҵ������
					SendCCR(CIList, CountOfCI, hopbyhop, sockfd, 1000000/CountOfCI/SpeedX, DomainType, ocp_i, ocp_u1, ocp_ux, ocp_t, ocp_e);

					memset(CIList, 0, sizeof(CIList));

					// ������¼��Ϊ��һ�ֵĵ�1����¼
					CountOfCI = 0;
					memcpy(&(CIList[CountOfCI]), CallInfo, sizeof(CALLINFO));

					// �ۼ��Ѵ�����¼
					CountOfCI++;		

					// ���µ�1����¼��ҵ����ʱ��
					// �������ʱ���ϵͳʱ���ǵ�󣬱�ʾ�����г��ֵ�ʱ����Խ
					// ��Ҫ��ͣ�����Ķ��룬��ѹ������������TS��׷�ϻ���ʱ��
					TS++;			
					while(TS < CallInfo->TimeStamp)
					{
						// ��������ԭ������������£�1��϶�����һ�������
						// �������������������϶��ǻ����ļ����ռ�����
						// printf("TS[%u] < TimeStamp[%u], uSleep(%d), TS ++\n", TS, CallInfo->TimeStamp, 1000000/SpeedX);
						// usleep(1000000/SpeedX);	// �������һ�����ʲ������ı��ٶ�
						TS ++;				
					}				
				}
			}

		}	// end while

		// �嵥�ļ��������Ҫ��ʣ�౨�ķ���
		if(CountOfCI > 0)
		{	
			// TODO������µ�ҵ������
			SendCCR(CIList, CountOfCI, hopbyhop, sockfd, 1000000/CountOfCI/SpeedX, DomainType, ocp_i, ocp_u1, ocp_ux, ocp_t, ocp_e);
		}
		
		//****************���ܲ���ר��
		/*
        fclose(list_fp);
	    fflush(stdout);
	    //close(STDOUT_FILENO);
	    free(CallInfo);
	    goto RE_SEND;
        */
		//***********************
	} 
	else
	{
		int  nSharkLen   = 40;
		//int  nEIILen     = 14;
		//int  nIPLen      = 20;
		//int  nTCPLen     = 32;
		//int  nIgnoreLen  = nSharkLen + nEIILen + nIPLen + nTCPLen;
		int  nIgnoreLen  = skip_len + nSharkLen;
		long lOffset     = nIgnoreLen;

		char szCCR[10240];
		char szDump[1024];
		memset(szCCR,  0, sizeof(szCCR));
		memset(szDump, 0, sizeof(szDump));

		SunriseOCP::CmdHeader *pHeader = NULL;

		
		size_t nMsgLen           = 0; // CCR��Ϣ����		
		size_t nMsgHeaderLen     = sizeof(SunriseOCP::CmdHeader); // CCR��Ϣͷ����		
		size_t nMsgBodyLen       = 0; // CCR��Ϣ�峤��		
		size_t nHandledLen       = 0; // �Ѿ��������ֽ���		
		size_t nWriteLen         = 0; // ���͵��ֽ���
		

		// ��ȡ�ļ�����
		fseek(cap_fp, 0, SEEK_END);
		size_t nFileLen = ftell(cap_fp);

		fseek(cap_fp, 0, SEEK_SET);
		int nHandledMsgCount  = 0;   // �Ѵ�������Ϣ��
		while (1)
		{
			// �������õ�ͷ��
			fseek(cap_fp, lOffset, SEEK_SET);
			nHandledLen += nIgnoreLen;

			// ��ȡ��Ϣͷ
			if (fread(szCCR, 1, nMsgHeaderLen, cap_fp) < nMsgHeaderLen)
			{
				printf("Read cap diameter msg header failed! \n");
				exit(-1);
			}
			nHandledLen += nMsgHeaderLen;

			if (g_debug)
			{
				MemDump(szCCR, nMsgHeaderLen, szDump);
				printf("Dump ccr head...\n%s\n", szDump);
			}			

			// ��ȡ��Ϣ����
			pHeader = (SunriseOCP::CmdHeader*)szCCR;
            nMsgLen = htonl(pHeader->MsgLen);

			// ��ȡ��Ϣ��			
			nMsgBodyLen = nMsgLen - nMsgHeaderLen;			
			if (fread(szCCR+nMsgHeaderLen,1, nMsgBodyLen, cap_fp) != nMsgBodyLen)
			{
				printf("Read cap diameter msg body failed! \n");
				exit(-1);
			}	
			nHandledLen += nMsgBodyLen;

			if (g_debug)
			{
				MemDump(szCCR+nMsgHeaderLen, nMsgBodyLen, szDump);
				printf("Dump ccr body...\n%s\n", szDump);
			}	

			// ������Ϣ
			nWriteLen = write(sockfd, szCCR, nMsgLen);
			if(nWriteLen <= 0)
			{
				perror("write");
				exit(-1);
			}	
			nHandledMsgCount++;

			gettimeofday(&now, &tz);
			printf("[%ld.%06ld] SEND: msg number[%06d], hop_by_hop_id[%u] \n", now.tv_sec, now.tv_usec, nHandledMsgCount, pHeader->hop_by_hop_id);
			
			// �ж��Ƿ�����ļ�
			if (nHandledLen >= nFileLen)
			{
				break;
			}			

			// �������õļ��˯��
			uDelay(1000000/nHandledMsgCount/SpeedX);
		}		
	}	

	//-------------------------------------
	// ��ӡ��������ʱ��
	//-------------------------------------
	gettimeofday(&now, &tz);
	printf("[%ld.%06ld] End ... \n", now.tv_sec, now.tv_usec);	

	//  CCR������ͷ��ͣ����
	//==================================================================

	//-------------------------------------
	// �ͷ���Դ
	//-------------------------------------
	delete CallInfo;

	if (!bUseCapFile)
	{
		fclose(list_fp);
	}
	else
	{
		fclose(cap_fp);
	}	
	
	fflush(stdout);
	close(sockfd);

	int nstatus;
	if(wait(&nstatus) != g_childid )
	{
		printf("wait failed\n");
	}
	pr_exit(nstatus);
	fflush(stdout);
	close(STDOUT_FILENO);
}
