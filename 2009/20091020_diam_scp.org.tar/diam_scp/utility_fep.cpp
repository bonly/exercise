#include "sfep_config.h"
//#include "utility.h"
#include "r5api.h"

int g_sig_term;
using namespace std;

//��õ�ǰʱ��
char *getcurtime(int nFormat /*=3*/)
{
	static char curtime[30];
	struct tm *lt;
	struct timezone tz;
	struct timeval now;
	gettimeofday(&now, &tz);
	lt = localtime(&now.tv_sec);

	memset(curtime , 0 ,sizeof(curtime));

	if(nFormat==0 || nFormat > 2 || nFormat < 0)
		sprintf(curtime, "%4d-%02d-%02d %02d:%02d:%02d",lt->tm_year+1900,lt->tm_mon+1,lt->tm_mday,lt->tm_hour,lt->tm_min,lt->tm_sec);
	else if(nFormat ==1)
		sprintf(curtime, "%4d%02d%02d%02d%02d%02d",lt->tm_year+1900,lt->tm_mon+1,lt->tm_mday,lt->tm_hour,lt->tm_min,lt->tm_sec);
	else if(nFormat ==2)
		sprintf(curtime, "%4d-%02d-%02d %02d:%02d:%02d.%06ld",lt->tm_year+1900,lt->tm_mon+1,lt->tm_mday,lt->tm_hour,lt->tm_min,lt->tm_sec,now.tv_usec);
	else if(nFormat == 3 )
		sprintf(curtime , "%ld" , now.tv_sec * 1000 + now.tv_usec / 1000);
	return curtime;
}


unsigned long getlongtime()
{
	//struct tm *lt;
	struct timezone tz;
	struct timeval now;
	gettimeofday(&now, &tz);
	//lt = localtime(&now.tv_sec);
	return now.tv_sec * 1000 + now.tv_usec / 1000;
}

//��socket �ж���ָ�����ȣ�������Ȳ�������ѭ������
// >0 �ɹ�
// =0 ����Ͽ�
// -1 ��ȡ����ʧ��
// -2 sellectʧ��
// -3 ��ʱ
int my_read(int fd,char *p, int total_len, int timeo)
{

	if(timeo>0) /* timeo>0ʱ������ʱ���� */
	{
		fd_set rset;
		FD_ZERO(&rset);
		FD_SET(fd, &rset);
		struct timeval timeout;
		timeout.tv_sec = timeo;
		timeout.tv_usec = 0;
		int slet_ret = select(fd+1, &rset, NULL, NULL, &timeout);

		if(slet_ret == -1)
		{
			perror("select failed");
			return -2;
		}
		else if(slet_ret == 0)
		{
			return -3;
		}
	}

	int get_len = 0;
	int n;

	while(get_len < total_len)
	{
		n = read(fd , p + get_len , total_len - get_len);
		if(n == 0)
			return 0;
		else if(n < 0)
		{
			if (errno == EINTR)
			{
				if(g_sig_term == 1)
				{                   
					return -1;
				}
				else 
					continue;
			}

			//FEP_R5_ERROR("read failed:%s\n", strerror(errno));
			return -1;
		}

		get_len += n;
	}

	return get_len;

	/*int get_len = 0;
	int n;

	while(get_len < total_len)
	{
	printf("total-get=%d\n" , total_len - get_len);
	n = read(fd , p + get_len , total_len - get_len);
	if(n == 0)
	return 0;
	else if(n < 0)
	{
	perror("network failed\n");
	return n;
	}

	get_len += n;
	}

	return get_len;
	*/
}

int log_printf(char *format , ...)
{
	va_list args;
	va_start(args, format);
	char tmp[1024] ;
	memset(tmp , 0 , sizeof(tmp));
	vsnprintf(tmp , 1024 , format , args);
	va_end(args);
	return printf("%ld|%s" , getlongtime() , tmp);
}

int open_log_file(char *log_file_name , char *appendix )
{
	char log_file[255] = {0};
	if(appendix)
		sprintf(log_file , "%s%s.%d" , log_file_name , appendix , getpid());
	else
		sprintf(log_file , "%s.%d" , log_file_name , getpid());
	int flags =  O_WRONLY|O_CREAT|O_APPEND;
	int fd = open(log_file , flags , S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH);
	return fd;
}

void pr_exit(int status)
{
	if (WIFEXITED(status))
		log_printf("normal termination, exit status = %d\n",
		WEXITSTATUS(status));
	else if (WIFSIGNALED(status))
		log_printf("abnormal termination, signal number = %d\n",
		WTERMSIG(status));
	else if (WIFSTOPPED(status))
		log_printf("child stopped, signal number = %d\n",
		WSTOPSIG(status));
}
