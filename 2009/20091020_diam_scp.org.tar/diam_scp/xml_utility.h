#ifndef XML_UTILITY_H
#define XML_UTILITY_H

#include "sfep_config.h"

/*
#define AVP_ADDRESS_BUF_LENGTH 128

typedef struct _AVP_ADDRESS_TYPE
{
	short sType;
	char  cBuf[AVP_ADDRESS_BUF_LENGTH];
}avp_addressType;
*/

SunriseOCP * process_xml2diam(char *filename, int app_id, char* buf);

SunriseOCP* process_xml2diam_helper(DOMNode *n , char *p , int buf_len, char* buf);

//int process_xml2diam_helper(DOMNode *n , char *p , int buf_len);
//int process_xml2diam(char *filename , char *p , int buf_len );
int fill_group(AVPGroup *pGroup , DOMNode *avp);
AVPGroup* getSubGroup(SunriseOCP *parents, long nAVPCode, AVPGroup *avpGroup=NULL);

#endif
