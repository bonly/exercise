#ifndef DIAM_CLI_H
#define DIAM_CLI_H

//this program is temporarily for Beijing performance test
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <set>
#include <string>
#include <vector>
#include <sys/msg.h>
#include <dlfcn.h>
//#include "utility.h"
#include "DiamUtil.h"
#include "DictionaryManager.h"
#include "avp_code.h"
#include "r5api.h"

//#define PROGRAM_VERSION           1.0

char *getcurtime(int nFormat /*=3*/);
static void sig_int(int);
int  g_childid = 0;
int  g_stop = 0;

#endif
