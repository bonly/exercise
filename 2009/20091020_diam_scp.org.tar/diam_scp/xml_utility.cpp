#include "xml.h"
#include "xml_errorreporter.h"
#include "xml_utility.h"
#include <math.h>
#define DIAMETER_PACKET_MAX_SIZE  10240
//SunriseOCP* process_xml2diam_helper(DOMNode *n , char *p , int buf_len)
SunriseOCP* process_xml2diam_helper(DOMNode *n , char *p , int buf_len, int app_id, char* buf)
{
    if (!UtilXML::matchNode(n, "ocp_test_data"))
    {
        cout <<  "No ocp_test_data found in xml!Bad diameter xml format.\n"  << endl;
        return  NULL;
    }

    DOMNode *head = n->getFirstChild() ;
    head = UtilXML::getNextElementNode(head);
    if(!UtilXML::matchNode(head, "head"))
    {
        cout <<  "No head found in xml!Bad diameter xml format.\n"  << endl;
        return NULL;
    }

    string version;
    string msglen;
    string cmdflg;
    string cmdcode;
    string appid;
    string hopbyhop;
    string endbyend;
    DOMNode *head_field = head->getFirstChild() ;
    for (head_field = UtilXML::getNextElementNode(head_field);
         head_field != NULL; head_field = UtilXML::getNextElementNode(head_field))
    {


        if(UtilXML::matchNode(head_field, "version"))
            version = UtilXML::getProp(head_field, "data");
        else if(UtilXML::matchNode(head_field, "msglen"))
            msglen = UtilXML::getProp(head_field, "data");
        else if(UtilXML::matchNode(head_field, "cmdflg"))
            cmdflg = UtilXML::getProp(head_field, "data");
        else if(UtilXML::matchNode(head_field, "cmdcode"))
            cmdcode = UtilXML::getProp(head_field, "data");
        else if(UtilXML::matchNode(head_field, "appid"))
            appid = UtilXML::getProp(head_field, "data");
        else if(UtilXML::matchNode(head_field, "hopbyhop"))
            hopbyhop = UtilXML::getProp(head_field, "data");
        else if(UtilXML::matchNode(head_field, "endbyend"))
            endbyend = UtilXML::getProp(head_field, "data");

    }
    //char msg_buf[DIAMETER_PACKET_MAX_SIZE];

    SunriseOCP* ocp = new SunriseOCP(buf ,DIAMETER_PACKET_MAX_SIZE, 0, true, app_id, atoi(cmdcode.c_str()));
    ocp->cmdHeader.Version = atoi(version.c_str());
    ocp->cmdHeader.MsgLen = atoi(msglen.c_str());

    long l = strtol(cmdflg.c_str() , NULL ,2);
    
    ocp->cmdHeader.reqFlag = ntohl(htonl(l) >> 7);
    
    
    ocp->cmdHeader.proxFlag = ntohl(htonl(l) >> 6);
    ocp->cmdHeader.errFlag = ntohl(htonl(l) >> 5);
    ocp->cmdHeader.potenFlag = ntohl(htonl(l) >> 4);

    ocp->cmdHeader.hop_by_hop_id = atoi(hopbyhop.c_str());
    ocp->cmdHeader.end_to_end_id = atoi(endbyend.c_str());

    DOMNode *avps = UtilXML::getNextElementNode(head) ;
    if(!UtilXML::matchNode(avps, "avps"))
    {
        cout <<  "No avps found!Bad diameter xml format.\n"  << endl;
        return NULL;
    }

    AVPGroup *pGroup = ocp->getTopmostGroup();
    DOMNode *avp = avps->getFirstChild();
    fill_group(pGroup , avp);
    
    //string sun_in_s;
    //ocp->dump(sun_in_s);
    //printf("CCR is:\n %s \n" , sun_in_s.c_str());
    
    //int len = ocp.getBuffer(p , buf_len) ;
    return ocp ;
}

//transfer a xml file to diameter binary file
//filename - the xml file
//p        - the binary buffer
//buf_len  - the length of input buffer
SunriseOCP * process_xml2diam(char *filename,  int app_id, char * buf)
{
	
    char buff[1024] = {0};
    char *p = buff;	
    int buf_len = sizeof(buff);	
    try
    {
        XMLPlatformUtils::Initialize();
    }
    catch (const XMLException& toCatch)
    {
        cout <<   "Error during initialization! Message:"  << endl;
        XMLPlatformUtils::Terminate();
        throw;
    }

    int errorCount = 0;
    XercesDOMParser::ValSchemes        valScheme = XercesDOMParser::Val_Auto;
    auto_ptr<XercesDOMParser>          parser(new XercesDOMParser);
    auto_ptr<myDOMTreeErrorReporter>   errReporter(new myDOMTreeErrorReporter());

    parser->setErrorHandler(errReporter.get());

    bool errorsOccured = false;

    parser->setValidationScheme(valScheme);

    try
    {
        parser->parse(filename);
        errorCount = parser->getErrorCount();

        if (errorCount > 0)
        {
            cout <<  "Error while parsing input xml file.\n"  << endl;
            errorsOccured = true;
            return NULL;
        }
    }
    catch (const DOMException& e)
    {
        cout <<   "DOM error.\n"  << endl;
        errorCount = parser->getErrorCount();
        errorsOccured = true;
    }
    catch (const XMLException& e)
    {
        cout <<  "XML error.\n"  << endl;
        errorsOccured = true;
    }

    if (errorsOccured)
    {
        //  delete errReporter;
        //  delete parser;
        XMLPlatformUtils::Terminate();
        throw (1);
    }

    DOMNode *doc = parser->getDocument();
    //return  process_xml2diam_helper(doc->getFirstChild() , p , buf_len);
	return  process_xml2diam_helper(doc->getFirstChild() , p , buf_len, app_id, buf);
    

}

int GetValue(const char* szData)
{
	int  nValue = 0;
    int  nFinalValue = 0;
    bool flag = true;
             
	for (int i = 0; i < 2 && flag; ++i)
    {
    	// get first number
    	switch (szData[i])
    	{
    		case '0':
    			nValue = 0;
    			break;
    		case '1':
    			nValue = 1;
    			break;
    		case '2':
    			nValue = 2;
    			break;
    		case '3':
    			nValue = 3;
    			break;
    		case '4':
    			nValue = 4;
    			break;
    		case '5':
    			nValue = 5;
    			break;
    		case '6':
    			nValue = 6;
    			break;
    		case '7':
    			nValue = 7;
    			break;
    		case '8':
    			nValue = 8;
    			break;
    		case '9':
    			nValue = 9;
    			break;
    		case 'A':
    		case 'a':	
    			nValue = 10;
    			break;
    		case 'B':
    		case 'b':	
    			nValue = 11;
    			break;
    		case 'C':
    		case 'c':	
    			nValue = 12;
    			break;
    		case 'D':
    		case 'd':	
    			nValue = 13;
    			break;
    		case 'E':
    		case 'e':	
    			nValue = 14;
    			break;
    		case 'F':
    		case 'f':
    			nValue = 15;
    			break;
    		default:
    			nValue = 0;
    			flag = false;
    			break;		
    	}
    	double tmp = nValue;
    	nValue = (int)ldexp(tmp,(1-i)*4);
    	nFinalValue += nValue;
    }
	
    return nFinalValue;
}

int fill_group(AVPGroup *pGroup , DOMNode *avp)
{
    for (avp = UtilXML::getNextElementNode(avp);
         avp != NULL; avp = UtilXML::getNextElementNode(avp))
    {
        string name = UtilXML::getName(avp);

        AAADictionaryEntry *pCurrentAvpEntry = 0;

        //find the avp type from dictionary
        if ((pCurrentAvpEntry = pGroup->m_pDictionary->getDictionaryEntry(name)) == 0)
        {
            cout <<  "Can not find avp in diameter dictionary: " << name  << endl;
            pGroup->getParent()->setErrCode(-1);
            return -1;
        }

        AVPDataType type = pCurrentAvpEntry->avpType;

        switch(type)
        {
        case AAA_AVP_STRING_TYPE:
        {
        	string  data = UtilXML::getProp(avp, "data");    	
            //--------------------------------------------
            //add by chenliang, on 20091117
            //--------------------------------------------
            // byte order
            int mobile = 0;
            int n = 1; int t = 0;
            char* p = (char*)&n;
            memcpy(&t, p+3, 1); memcpy(&t+1, p+2, 1);
            if (t>0)
            {
            	mobile = 3;
            }	
            
            //Ox format
            int nLen = (data.size()+1)/2;
            char szBuffer[128];
            memset(szBuffer, 0, 128);
            
            int nFinalValue = 0; 
            char* bytePos = (char*)(&nFinalValue);
            const char* pos = data.c_str();
            for (int i = 0; i < nLen; ++i)
            {
        		nFinalValue = GetValue(pos + i*2);
        		memcpy(szBuffer + i, bytePos+mobile, 1);
            }
            
            pGroup->addField(pCurrentAvpEntry->avpCode, szBuffer, nLen);
            printf("code = %d, len = %d\n",pCurrentAvpEntry->avpCode,nLen);
            break;
        }
        
        case AAA_AVP_UTF8_STRING_TYPE:
        case AAA_AVP_DIAMID_TYPE:
        case AAA_AVP_DIAMURI_TYPE:
            {
                string  data = UtilXML::getProp(avp, "data");
                pGroup->addField(pCurrentAvpEntry->avpCode, data.c_str(), data.size());
                break;
            }
	
	case AAA_AVP_ADDRESS_TYPE: //add by lqb for "SGSN-Address"
	    {
		string  data = UtilXML::getProp(avp, "data");
		
		string::size_type pos = data.find(":");
		
		avp_addressType addr;

		memset(&addr, 0, sizeof(addr) );		
	
		if(pos != string::npos)
		{
			string type = data.substr(0, pos);
			addr.sType = htons(atoi(type.c_str()));
		}	
	
		data = data.substr(pos + 1);

		unsigned int ip =  inet_addr(data.c_str());

		memcpy(addr.cBuf, &ip, sizeof(unsigned int) );			


		pGroup->addField(pCurrentAvpEntry->avpCode, &addr, 6);	

		break;	
	    }	
	
        case AAA_AVP_INTEGER32_TYPE:
        case AAA_AVP_UINTEGER32_TYPE:
        case AAA_AVP_ENUM_TYPE:
        case AAA_AVP_TIME_TYPE:
            {
                string data = UtilXML::getProp(avp, "data");
                int n = atol(data.c_str());
                pGroup->addField(pCurrentAvpEntry->avpCode, n);
                break;
            }

        case AAA_AVP_INTEGER64_TYPE:
        case AAA_AVP_UINTEGER64_TYPE:
            {
                string data = UtilXML::getProp(avp, "data");
                OCP_INT64 l = atol(data.c_str());
                pGroup->addField(pCurrentAvpEntry->avpCode, l);
                break;
            }

        case AAA_AVP_GROUPED_TYPE:
            {
                DOMNode *child_avp = avp->getFirstChild();
                if(!pCurrentAvpEntry->pSubDictionary)
                {
                    cout <<  "No sub directory found ! avp: " << name << endl;
                    return -1;
                }
                //AVPGroup *child_group = new AVPGroup(pGroup->getParent() , pCurrentAvpEntry->pSubDictionary);
                AVPGroup *child_group = DiamUtil::creatSubGroup(pGroup->getParent(), pCurrentAvpEntry->avpCode, pGroup);
                pGroup->addField(pCurrentAvpEntry->avpCode, child_group);
                fill_group(child_group , child_avp);                
                break;
            }
        default:
            {
                cout << "Unrecognized avp type: avp: " << name <<", type :" << type  << endl;
                break;
            }
        }//end switch
    }//end for

    return 0;
}
//add by jiangyan 2007/12/15

AVPGroup* getSubGroup(SunriseOCP *parents, long nAVPCode, AVPGroup *avpGroup/*=NULL*/)
{
	AAADictionaryEntry *pCurrentAvpEntry = NULL;    
    AVPGroup *parentAvpGroup = parents->getTopmostGroup();
    if (avpGroup == NULL)
    {
        if ((pCurrentAvpEntry = parentAvpGroup->m_pDictionary->getDictionaryEntry(nAVPCode)) == 0)
        {
          printf("getSubGroup \"%s\" line %d: Can not find avp in diameter dictionary:...\n", __FILE__, __LINE__);
          parents->setErrCode(-1);
          return 0;
        }
    }
    else
    {
        if ((pCurrentAvpEntry = avpGroup->m_pDictionary->getDictionaryEntry(nAVPCode)) == 0)
        {
          printf("getSubGroup \"%s\" line %d: Can not find avp  in diameter dictionary:...\n", __FILE__, __LINE__);
          parents->setErrCode(-1);
          return 0;
        }
    }
 
    AVPGroup *subAvpGroup = new AVPGroup(parents, pCurrentAvpEntry->pSubDictionary);
    return subAvpGroup;
}
