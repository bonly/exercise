#include "bonly_chap_Native.h"

/**
 * Class:     bonly_chap_Native
 * Method:    LibMain
 * Signature: ([Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_bonly_chap_Native_LibMain
  (JNIEnv * env, jclass jc, jobjectArray name)
{
	jboolean iscopy;
	//const char *from_java = (*env)->GetStringUTFChars(env, name, &iscopy);
	
	//jsize clen = getArrayLen(env, name);///这个函数有链接问题,未明
	jsize clen = (*env)->GetArrayLength(env, name);
	
	jstring jrow = (jstring)(*env)->GetObjectArrayElement (env,name,0); ///取string[i]
	const char *from_java = (*env)->GetStringUTFChars(env, jrow, 0);///转换为char*
	//const char *from_java = "this is a test ";
	
	static JavaVM *g_vm;
	(*env)->GetJavaVM(env, &g_vm);
	
	if (!g_vm)
	{
		printf("I_JNI_NOVM\n");
	    return -1;
	}
	
    //(*g_vm)->AttahCurrentThread(g_vm, (void **)&env,NULL);
	
	//static jclass jc;
	//jc = (*env)->FindClass(env,"bonly/chap/Native");  ///先找到类
	
	jmethodID mSendStr=(*env)->GetStaticMethodID(env, jc, "OnMessage", "(Ljava/lang/String;I)V");  ///找静态函数的方法ID
	if(mSendStr)
	{
		(*env)->CallStaticVoidMethod(env, jc,mSendStr, 
				(*env)->NewStringUTF(env, from_java),(jint)1);
		printf("user print with c\n");
	}
	
	return 0;
}

void myFun(int i, char* disp)
{
	return ;
}

void getCharArry(JNIEnv * env, jobjectArray jargv)
{
	jsize clen = (*env)->GetArrayLength(env, jargv);
	
	//char * args[(int)clen];
	
	int i;
	jstring jrow;
	for (i=0; i<clen; ++i)
	{
		jrow = (jstring)(*env)->GetObjectArrayElement
		  (env,jargv,i); ///Get String[i]
		
		/// convert string[i] to char*
		const char *row = (*env)->GetStringUTFChars
		   (env, jrow, 0);
		
		//args[i]=malloc(strlen(row)+1);
		
		
		//strcpy(args[i],row);
		(*env)->ReleaseStringUTFChars(env,jrow,row);
	}
}


/**
生成的libmy.so:
agcc -c lib.c -o my.o
ald -shared -o libmy.so my.o
eclipse的项目下创建目录libs/armeabi(如果是mips编译器编译的,则是libs/mips);
项目生成时会自动打包so文件,并在安装时在/data/data/$packagename/lib/目录中放入so文件;
经测试,手工创建/data/data/$packagename/lib/及so文件却运行不成功.
问题:
getCharArry函数要连接其它库.待查
*/