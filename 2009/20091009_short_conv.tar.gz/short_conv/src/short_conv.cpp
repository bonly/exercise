//============================================================================
// Name        : short_conv.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <cstdio>
#include <sstream>
#include <string.h>
#include <fstream>
using namespace std;

void test1()
{
  fprintf(stderr, "int: %d short: %d\n", sizeof(int), sizeof(short));
  unsigned int k = 20501020;
  unsigned short tmp = (k >> 9)+1980;
  unsigned short tmpm = (k & 0x1FF)>>5;
  unsigned short tmpd = (k & 0x1F) +1;

  char date[9];
  sprintf(date, "%04d%02d%02d",tmp, tmpm, tmpd);
  fprintf (stderr,"%s\n", date);


  unsigned short scpid=1;
  char mycp[1];
  memset(mycp,0,8);
  mycp[0]=scpid+30;
}

void test2()
{
  ofstream  fs("test.txt");
  fs << "test line\n";
  fs.clear();
  fs.close();
}
int main()
{
  test2();
	return 0;
}
