/*
 * GameException.cpp
 *
 *  Created on: 2010-5-14
 *      Author: bonly
 */


#include "GameException.h"

GameException::GameException(const string& message)
        : runtime_error(message) {
}

GameException::~GameException() throw() {
}
