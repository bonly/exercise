/*
 * Position.h
 *
 *  Created on: 2010-5-14
 *      Author: bonly
 */


#ifndef POSITION_H_
#define POSITION_H_

struct Position {
        int x;
        int y;
};

#endif /* POSITION_H_ */
