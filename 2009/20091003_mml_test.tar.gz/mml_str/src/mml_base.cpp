/*
 * mml_base.cpp
 *
 *  Created on: 2009-9-7
 *      Author: bonly
 */
#include "mml_base.hpp"
void _hex(unsigned char c, char* s)
{
  sprintf(s, "%02X", c);
  s[2] = ' ';
}

char* _hexdump16bytes(char* p, size_t& nBegin, size_t& nLeft)
{
  if(nLeft <= 0)
  {
    return NULL;
  }

  enum{line_size = 67};
  static char s[line_size + 1];
  s[line_size] = '\0';

  char* p2 = p + nBegin;
  for(size_t i=0; i<16; ++i)
  {
    if(nLeft > 0)
    {
      unsigned char c = p2[i];
      _hex(c, s+i*3);

      s[51+i] = isprint(c) ? c : '.';
      --nLeft;
    }
    else
    {
      size_t j=i*3;
      s[j] = ' ';
      s[j+1] = ' ';
      s[j+2] = ' ';
      s[51+i] = ' ';
    }
  }

  s[48] = ' ';
  s[49] = ';';
  s[50] = ' ';

  nBegin += 16;

  return s;
}

void hexdump(char* buf, const size_t len)
{
  size_t i=0;
  size_t j=len;

  char* s = 0;
  while((s=_hexdump16bytes(buf,i,j))!=0)
  {
    //clog << s << "\n";
    //clog.write(p, sizeof(mml::MML));
    printf("%s\n", s);
  }
}
namespace mml
{
MML_base::MML_base()
{
  bzero(this,sizeof(MML_base));
  strncpy (SC,"`SC`",4);
  strncpy (VERSION,"1.00",4);
}

MML_CRC::MML_CRC()
{
  bzero(&CRC,sizeof(CRC));
}

int //��"��Ϣͷ���Ựͷ������ͷ��������Ϣ"��32λ��򣬶������ȡ�����ֵΪУ���.
MML_CRC::crc(const char *tt, const size_t length)
{
  unsigned char souce[MAXMEGLENG],buf[4];
  int  bnum;
  int  i,j;
  char tmp[100];

  if ( length%4 )
  {
    printf ("Length Error:%d:",length);
    return ( -1 );
  }

  memcpy(souce,tt,length);
  bnum = length/4;

  memset(buf,0,4);
  for(i=0;i<bnum; i++)
  {
    j = i * 4;
    rh_BlockXor(souce+j,buf,4);
  }

  rh_BlockOpp(buf,4);

  for ( i=0;i<4;i++ )
  {
    sprintf(tmp,"%X",(buf[i]>>4)&0XF);
    strcat(CRC,tmp);
    sprintf(tmp,"%X",(buf[i])&0XF);
    strcat(CRC,tmp);
  }

  return 0;
}

void
MML_CRC::rh_BlockXor(unsigned char *a, unsigned char *b, int num)
{
  while(num--){ *(b++)^=*(a++);}
}

void
MML_CRC::rh_BlockOpp(unsigned char *a, int num)
{
  while ( num-- )
  {
    *a = ~(*a); a++;
  }
}

int //���㳤��,��д��CRC
CMD::encode(MML_base &base, const char *cmd, const size_t clen, char *buf, const size_t blen)
{
  size_t   base_len  = sizeof(mml::MML_base); 
  size_t   patch    = 4 - (clen % 4);  //��������Ҫ���Ŀո�
  if (blen < base_len + clen + patch + 8) //buffer is to small
    return -2;

  char strLen[5]; //�������泤��
  sprintf (strLen, "%04X", base_len - sizeof(mml::MML_BEGIN) + clen + patch);  //�Ӱ汾��ʼ����CRCǰ����ĳ���
  strncpy (base.LEN, strLen, 4);  //д�뵽���������

  memcpy (buf, &base, base_len);  //д�̶���
  memcpy (buf+base_len, cmd, clen);  //д��������
  memset (buf+base_len+clen,' ',patch); //���ո�

  {//����CRC,�Ӱ汾�ſ�ʼ��CRCǰ����
  MML_CRC  crc;
  if (0!=crc.crc(buf+sizeof(mml::MML_BEGIN),base_len+clen+patch-sizeof(mml::MML_BEGIN)))
    return -1;
  memcpy  (buf+(base_len+clen+patch), crc.CRC, 8); //д��CRC
  }
  return base_len + clen + patch + 8;
}

#ifdef __ZX__   //����
int
CMD::login(const char* terminal, const char* service, const char *cmd, const size_t clen,
           char *buf, const size_t blen)
{
   MML_base base;

   strncpy (base.TERMINAL,terminal,sizeof(base.TERMINAL));
   strncpy (base.SERVICE, service, sizeof(base.SERVICE));
   strncpy (base.SESSION, "00000000", 8);
   strncpy (base.SES_CTRL, "DLGLGN", 6);
   strncpy (base.SES_BACKUP, "FFFF", 4);
   {
   int tran_id=1;
   sprintf (base.TRANSACTION, "%08X", tran_id);
   }
   strncpy (base.TRAN_CTRL, " TXBEG", 6);
   strncpy (base.SCOPE, "00", 2);
   strncpy (base.TRAN_BACKUP, "FF", 2);

   return CMD::encode(base, cmd, clen, buf, blen);
}
#else  //��Ϊ
int
CMD::login(const char* terminal, const char* service, const char *cmd, const size_t clen,
           char *buf, const size_t blen)
{
   MML_base base;

   strncpy (base.TERMINAL,terminal,sizeof(base.TERMINAL));
   strncpy (base.SERVICE, service, sizeof(base.SERVICE));
   strncpy (base.SESSION, "00000000", 8);
   strncpy (base.SES_CTRL, "DlgLgn", 6);
   strncpy (base.SES_BACKUP, "    ", 4);
   {
   int tran_id=1;
   sprintf (base.TRANSACTION, "%08X", tran_id);
   }
   strncpy (base.TRAN_CTRL, " TxBeg", 6);
   strncpy (base.SCOPE, "  ", 2);
   strncpy (base.TRAN_BACKUP, "  ", 2);

   return CMD::encode(base, cmd, clen, buf, blen);
}
#endif

int
CMD::login_ack(const char* terminal, const char* service, const char* session, const int tran_id, const char *cmd,
                 const size_t clen, char *buf, const size_t blen)
{
  MML_base base;

  strncpy (base.TERMINAL,terminal,sizeof(base.TERMINAL));
  strncpy (base.SERVICE, service, sizeof(base.SERVICE));
  strncpy (base.SESSION, session, 8);
  strncpy (base.SES_CTRL, "DLGLON", 6);
  strncpy (base.SES_BACKUP, "FFFF", 4);
  sprintf (base.TRANSACTION, "%08X", tran_id);
  strncpy (base.TRAN_CTRL, " TXEND", 6);
  strncpy (base.SCOPE, "00", 2);
  strncpy (base.TRAN_BACKUP, "FF", 2);

  return CMD::encode(base, cmd, clen, buf, blen);
}

int
CMD::logout(const char* terminal, const char* service, const char* session_id, const int tran_id,
                   char * buf, const size_t blen)
{
  MML_base base;
  strncpy (base.TERMINAL,terminal,sizeof(base.TERMINAL));
  strncpy (base.SERVICE, service, sizeof(base.SERVICE));
  strncpy (base.SESSION, session_id, 8);
  strncpy (base.SES_CTRL, "DLGCON", 6);
  strncpy (base.SES_BACKUP, "FFFF", 4);
  sprintf (base.TRANSACTION, "%08X", tran_id);
  strncpy (base.TRAN_CTRL, " TXBEG", 6);
  strncpy (base.SCOPE, "00", 2);
  strncpy (base.TRAN_BACKUP, "FF", 2);

  char cmd_logout[]="LOGOUT";
  return CMD::encode(base, cmd_logout, strlen(cmd_logout), buf, blen);
}

int
CMD::logout_ack(const char* terminal, const char* service, const char* session_id, const int tran_id,
                const char* cmd, const size_t clen, char * buf, const size_t blen)
{
  MML_base base;
  strncpy (base.TERMINAL,terminal,sizeof(base.TERMINAL));
  strncpy (base.SERVICE, service, sizeof(base.SERVICE));
  strncpy (base.SESSION, session_id, 8);
  strncpy (base.SES_CTRL, "DLGEND", 6);
  strncpy (base.SES_BACKUP, "FFFF", 4);
  sprintf (base.TRANSACTION, "%08X", tran_id);
  strncpy (base.TRAN_CTRL, " TXEND", 6);
  strncpy (base.SCOPE, "00", 2);
  strncpy (base.TRAN_BACKUP, "FF", 2);

  return CMD::encode(base, cmd, clen, buf, blen);
}

#ifdef __ZX__ //����
int
CMD::business(const char* terminal, const char* service, const char* session_id, const int tran_id,
              const char* cmd, const size_t clen, char* buf, const size_t blen)
{
  MML_base base;
  strncpy (base.TERMINAL,terminal,sizeof(base.TERMINAL));
  strncpy (base.SERVICE, service, sizeof(base.SERVICE));
  strncpy (base.SESSION, session_id, 8);
  strncpy (base.SES_CTRL, "DLGCON", 6);
  strncpy (base.SES_BACKUP, "FFFF", 4);
  sprintf (base.TRANSACTION, "%08X", tran_id);
  strncpy (base.TRAN_CTRL, " TXBEG", 6);
  strncpy (base.SCOPE, "00", 2);
  strncpy (base.TRAN_BACKUP, "FF", 2);

  return CMD::encode(base, cmd, clen, buf, blen);
}
#else
int
CMD::business(const char* terminal, const char* service, const char* session_id, const int tran_id,
              const char* cmd, const size_t clen, char* buf, const size_t blen)
{
  MML_base base;
  strncpy (base.TERMINAL,terminal,sizeof(base.TERMINAL));
  strncpy (base.SERVICE, service, sizeof(base.SERVICE));
  strncpy (base.SESSION, session_id, 8);
  strncpy (base.SES_CTRL, "DlgCon", 6);
  strncpy (base.SES_BACKUP, "    ", 4);
  sprintf (base.TRANSACTION, "%08X", tran_id);
  strncpy (base.TRAN_CTRL, " TxBeg", 6);
  strncpy (base.SCOPE, "  ", 2);
  strncpy (base.TRAN_BACKUP, "  ", 2);

  return CMD::encode(base, cmd, clen, buf, blen);
}
#endif

int
CMD::business_ack(const char* terminal, const char* service, const char* session_id, const int tran_id,
              const char* cmd, const size_t clen, char* buf, const size_t blen)
{
  MML_base base;
  strncpy (base.TERMINAL,terminal,sizeof(base.TERMINAL));
  strncpy (base.SERVICE, service, sizeof(base.SERVICE));
  strncpy (base.SESSION, session_id, 8);
  strncpy (base.SES_CTRL, "DLGCON", 6);
  strncpy (base.SES_BACKUP, "FFFF", 4);
  sprintf (base.TRANSACTION, "%08X", tran_id);
  strncpy (base.TRAN_CTRL, " TXEND", 6);
  strncpy (base.SCOPE, "00", 2);
  strncpy (base.TRAN_BACKUP, "FF", 2);

  return CMD::encode(base, cmd, clen, buf, blen);
}
}


/*
void MakeCheckSumValue(CHAR *pMsg,WORD msgLen,CHAR pCheckNum[8])
{
  UINT8   cTempVal[5],cTempCheckNum[9];
  dword   i, j;

	memset(cTempVal,0x00,5);
	memset(cTempCheckNum,0x00,9);

	for (i = 0; i < msgLen / 4; i ++)
	{
     for (j = 0; j < 4; j ++)
		   cTempVal[j] ^= pMsg[i * 4 + j];
	}

	for (j = 0; j < msgLen % 4; j ++)
	{
	    cTempVal[j] ^= pMsg[i * 4 + j];
	}

	for (i = 0; i < 4; i++)
		cTempVal[i] = ~cTempVal[i];

	sprintf(cTempCheckNum, "%02X%02X%02X%02X", cTempVal[0],  cTempVal[1],
  cTempVal[2], cTempVal[3]);
	memcpy(pCheckNum, cTempCheckNum, 8);
    return;
}
*/
