/*
 * test_case.cpp
 *
 *  Created on: 2009-9-7
 *      Author: bonly
 */


/*
server ip:138.1.1.10:29999
130.51.33.16:29999

只能从130.51.12.14连过去
138.1.1.10对应130.51.33.16
140.1.1.20对应130.51.33.24
*/
#define BOOST_TEST_MODULE MML_TEST
#include <boost/test/included/unit_test.hpp>

#include <iostream>
using namespace std;

#include "mml_base.hpp"
using namespace mml;

BOOST_AUTO_TEST_SUITE( MML_SUITE )

BOOST_AUTO_TEST_CASE( MML_Login )
{
  clog << "Login cmd length are not dobule of 4:\n";
  char buf[1024*8];
  bzero(buf,1024*8);
#ifdef __ZX__
  char login[]="LOGIN: USER=cxtest, PSWD=123, NotifyServer=0";
  int ret = mml::CMD::login("ZXWN1000","HLRAGENT",login,strlen((char*)login),buf,size_t(1024*8));
  BOOST_CHECK_EQUAL( ret, 120);
#else
  char login[]="LOGIN: USER=cxtest,PSWD=123";
  int ret = mml::CMD::login("internal","    SRVM",login,strlen((char*)login),buf,size_t(1024*8));
  BOOST_CHECK_EQUAL( ret, 120);
#endif

  hexdump (buf, ret);
}

BOOST_AUTO_TEST_CASE( MML_LOGIN_ACK )
{
  //`SC`00541.00congxing    SRVM4b6a3739DlgLgn    0000235e TxBeg    LOGIN: USER=cxtest,PSWD=
  char buf[255];
  char login_ack[]="ACK:LOGIN:RETN=000000,DESC=SUCCESS";
  int len = mml::CMD::login_ack("congxing","    SRVM","4b6a3739",0,
                                login_ack,strlen((char*)login_ack),buf,255);
  clog << "Login ACK:\n";
  printf(buf);
  hexdump(buf,len);
}

BOOST_AUTO_TEST_CASE( MML_Login_1 )
{
  clog << "Login cmd length are dobule of 4:\n";
  char buf[1024*8];
  bzero(buf,1024*8);
  char login[]="LOGIN: USER=test, PSWD=test, NotifyServer=0;";
  int ret = mml::CMD::login("ZXWN1000","HLRAGENT",login,strlen((char*)login),buf,size_t(1024*8));
  BOOST_CHECK_EQUAL( ret, 120);

  //hexdump (buf, ret);
}

BOOST_AUTO_TEST_CASE( MML_Logout )
{
  clog << "logout package:\n";
  char buf[1024*8];
  bzero(buf,1024*8);
  int ret = mml::CMD::logout((const char*)"ZXWN1000",(const char*)"HLRAGENT",
                             (const char*)"sessioid",245,(char*)buf,(const size_t)(1024*8));
  BOOST_CHECK_EQUAL( ret, 80);

  //hexdump (buf, ret);
}

BOOST_AUTO_TEST_CASE( MML_PPS_DISP )
{
  clog << "DISP PPS userinfo:\n";
  char buf[1024*8];
  bzero(buf,1024*8);
  char disp[]="DISP PPS ACNTINFO: MSISDN=13719360007";
  int ret = mml::CMD::business("ZXWN1000","HLRAGENT","sessiond",83911,disp,strlen(disp),buf,size_t(1024*8));
  BOOST_CHECK_EQUAL( ret, 112);

  //hexdump (buf, ret);
}

BOOST_AUTO_TEST_CASE( MML_H)
{
  clog << "HB info:\n";
  size_t len = sizeof(mml::MML_HB);
  char hb[20];
  len = mml::MML_HB::create_heartbeat(hb,len);
  BOOST_CHECK_EQUAL(len,20);
  //hexdump(hb, len);
}

BOOST_AUTO_TEST_SUITE_END()

/*
drop sequence bf_sub_seq;
create sequence bf_sub_seq increment by 1 minvalue 0 maxvalue 99999999999999999;
drop table bf_subscriber_qry;
create table bf_subscriber_qry(
  pk_id integer not null  primary key ,
  MSISDN TT_BIGINT,
  SCPID  VARCHAR2(8)
);


*/

