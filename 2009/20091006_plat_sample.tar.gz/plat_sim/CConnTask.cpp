#include "CConnTask.h"

CConnTask::CConnTask():ACE_Task_Base()
{
	m_flag = -1;
	m_ppeer = 0;
}

CConnTask::~CConnTask()
{
	cleanup();
}

int CConnTask::initilize(ACE_SOCK_Stream& peer, int flag)
{
	m_ppeer = &peer;       
	m_flag = flag;

	return 1;
}

int CConnTask::cleanup(void)
{
	if (m_ppeer > 0) 
	{
		m_ppeer->close();
		delete m_ppeer;
	}
	m_flag = -1;
	m_ppeer = 0;
	return 1;
}

int CConnTask::svc(void)
{              
	if (m_ppeer == 0)
	{
		return -1;
	}
	
	char buffer[4096];    
	char szTmp[4096];     
	ssize_t bytes_recived;
	memset(buffer, 0, 4096);
	memset(szTmp, 0, 4096);
	
	// registe cmd
	printf("Platform: -> wating recv a msg!...\n");
	if ((bytes_recived = m_ppeer->recv(buffer, sizeof(buffer))) > 0)
	{
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: -> recv a msg[%s]!\n"), buffer));
		sprintf(szTmp, "SCIP00000024ACK REGIST_NODE:RESULT=00000");
		m_ppeer->send_n(szTmp, strlen(szTmp));
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: send a msg[%s] -> NODE!\n"), szTmp));
	}
	else
	{
		m_ppeer->close();
		return -2;
	}

	// service node	
	if (m_flag == 0)
	{
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: waiting node send msg...!\n"))); 
		while ((bytes_recived = m_ppeer->recv(buffer, sizeof(buffer))) > 0)
		{
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: ->recv a msg[%s]!\n"), buffer));
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: please input ACK msg...!\n")));    	
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("    eg1:ACK HELLO:RESULT=0\n")));
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("    eg2:ACK REQUEST_FLOW:SESSION=123213,FLOW=CREATECUSTOMER,PARAMS=<PARAM1=a><PARAM2=b><PARAM3=C>,RESULT=0\n")));	
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("    Cmd: exit or quit.\n")));  
			
			char c;int ix = 0;
			for (;true;)
			{
				scanf("%c", &c);
				if (c == '\n')
				{
					if (ix == 0) continue;
					break;
				}
				buffer[ix++]=c; 
			}buffer[ix]='\0';
			if ((strcmp(buffer, "exit") == 0) || (strcmp(buffer, "quit") == 0))
			{
				break;
			}
			
			sprintf(szTmp, "SCIP%08d%s0000", strlen(buffer), buffer);
			m_ppeer->send_n(szTmp, strlen(szTmp));
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: send a msg[%s][%d] -> NODE! waiting ACK...\n"), szTmp,strlen(szTmp)));
			memset(buffer, 0, sizeof(buffer));
		}
	}
	else  // call node
	{
		do
		{
//			ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: please input SEND msg -> NODE!\n")));
//			ACE_DEBUG((LM_DEBUG, ACE_TEXT("    eg1:ACK HELLO:RESULT=0\n")));
//			ACE_DEBUG((LM_DEBUG, ACE_TEXT("    eg2:CALL_FUNC:SESSION=123213,FUNC=LOCAL_CREATECUSTOMER,PARAMS=<PARAM1=a><PARAM2=b><PARAM3=C>\n")));
//			ACE_DEBUG((LM_DEBUG, ACE_TEXT("    Cmd: exit or quit.\n")));
			
			char c;int ix = 0;
			for (;true;)
			{
				scanf("%c", &c);
				if (c == '\n')
				{
					if (ix == 0) continue;
					break;
				}
				buffer[ix++]=c; 
			}buffer[ix]='\0';
			if ((strcmp(buffer, "exit") == 0) || (strcmp(buffer, "quit") == 0))
			{
				break;
			}
			
			sprintf(szTmp, "SCIP%08d%s0000", strlen(buffer), buffer);
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("start send...\n")));
			m_ppeer->send_n(szTmp, strlen(szTmp));
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: send a msg[%s] -> NODE! waiting ACK...\n"), szTmp));
			
			memset(buffer, 0, sizeof(buffer));
			if ((bytes_recived = m_ppeer->recv(buffer, sizeof(buffer))) <= 0)
			{
				break;
			}
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: ->recv a msg[%s]!\n"), buffer));
		} while (true);
	} // ~else()
	m_ppeer->close();
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform simulator: close clint connection!\n")));
	
	return 0;
}




