/********************************************
 *
 *
 *******************************************/
#include "ace/INET_Addr.h"
#include "ace/SOCK_Stream.h"
#include "ace/SOCK_Connector.h"
#include "ace/Log_Msg.h"
#include "string.h"

int ACE_TMAIN(int argc, ACE_TCHAR* args[])
{
	ACE_INET_Addr      addr(5100, ACE_LOCALHOST);
	ACE_SOCK_Connector connector;
	ACE_SOCK_Stream    peer;
	
	if (connector.connect(peer, addr) == -1)
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("%p\n"),ACE_TEXT("connect")), 1);
	}
	
	int nBc = 0;
	char szBuff[4096];
	char szTmp[4096];
	
	while (true)
	{
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("Node: please input SEND msg!\n")));
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("    eg1:REGIST_NODE:NODE_ID=[FEP_BUSINESS]\n")));
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("    eg2:REQUEST_FLOW:SESSION=123213,FLOW=CREATECUSTOMER,PARAMS=<PARAM1=a><PARAM2=b><PARAM3=C>\n")));	
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("    Cmd: exit or quit.\n")));
		
		char c;int ix = 0;
		for (;true;)
		{
			scanf("%c", &c);
			if (c == '\n')
			{
				break;
			}
			szBuff[ix++]=c; 
		}szBuff[ix]='\0';
		if ((strcmp(szBuff, "exit") == 0) || (strcmp(szBuff, "quit") == 0))
		{
			break;
		}
		sprintf(szTmp, "SCIP%08d%s0000", strlen(szBuff), szBuff);
		
		peer.send_n(szTmp, strlen(szTmp));
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("Node: send msg[%s] -> platform! waiting ACK...\n"), szTmp));
		nBc = peer.recv(szBuff, sizeof(szBuff));
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("Node: recv msg[%s][%d]!\n"), szBuff,strlen(szBuff)));
	}
	
	peer.close();
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("Node: close connection! exit program...\n")));
	
	return 0;
}






