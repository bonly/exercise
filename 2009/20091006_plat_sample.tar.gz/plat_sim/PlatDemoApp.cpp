/********************************************
 *
 *
 *******************************************/
#include "ace/INET_Addr.h"
#include "ace/SOCK_Stream.h"
#include "ace/SOCK_Acceptor.h"
#include "ace/Log_Msg.h"
#include "ace/Time_Value.h"
#include "CConnTask.h"

int ACE_TMAIN(int argc, ACE_TCHAR* args[])
{
	//ACE_INET_Addr      listenAddr(5100, ACE_LOCALHOST);
  ACE_INET_Addr      listenAddr(atoi(args[2]), args[1]);
	ACE_SOCK_Acceptor  acceptor;
	
	if (acceptor.open(listenAddr, 1) == -1)
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("%p\n"), ACE_TEXT("acceptor.open")), 100);
	}
	
	int i = 0;
	CConnTask* pTask[2000] = {0};
	while (i < 2000)
	{
		ACE_SOCK_Stream* peer = new ACE_SOCK_Stream();
		ACE_INET_Addr   addr;
		ACE_Time_Value  timeout(3000);// += 10;
		
	#if 0
		if (acceptor.accept(*peer) == -1)
		{
			ACE_ERROR_RETERN((LM_ERROR, ACE_TEXT("(%P|%t)Failed to accept"),
			                  ACE_TEXT("client connection\n")), 100);
	    }
	#endif /* ~0 */
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform simulator:waiting for connection...!\n")));
	    if (acceptor.accept(*peer, &addr, &timeout, 0) == -1)
	    {
	    	if (ACE_OS::last_error() == EINTR)
	    	{
	    		ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%P|%t)interruppt while"),
	    		                    ACE_TEXT("waiting for connection\n")));
	    	}
	    	else if (ACE_OS::last_error() == ETIMEDOUT)
	    	{
	    		ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%P|%t)timeout while"),
	    		                    ACE_TEXT("waiting for connection\n")));
	    		break;
	    	}
	    	ACE_DEBUG((LM_DEBUG, ACE_TEXT("Exit ServerApp:accept().waiting for connection error!\n")));
	    	sleep(5);
	    }
	    else
	    {
	    	ACE_TCHAR peer_name[MAXHOSTNAMELEN];
	    	addr.addr_to_string(peer_name, MAXHOSTNAMELEN);
	    	ACE_DEBUG((LM_DEBUG, ACE_TEXT("Platform: recv a connection form [%s]\n"), peer_name));
	    	
	    	int flag = -1;

	    	printf("choose client type: \n");
            printf("0: FILE_NODE || H2_NODE || scp_real_msg_NODE || PDSCP_SMS_NODE\n");
            printf("1: FEP_BUSINESS_NODE || SCP_MML_NODE || SCP_GFEP_NODE || SMSC_NODE\n");
            if(strcmp(args[3],"")==0)
              scanf("%d", &flag);
            else
              flag=atoi(args[3]);
            
            pTask[i] = new CConnTask();
            pTask[i]->initilize(*peer, flag);
            if (pTask[i]->activate() != 0)	  
            {
            	ACE_DEBUG((LM_DEBUG, ACE_TEXT("SPAWN a thread faild! close soacket and continue accepting()...\n")));
            	peer->close();
            	pTask[i]->cleanup();
            	pTask[i] = 0;
            }  	
         }  
         i++; 
 	}/* ~while (true) */
	int j = 0;
	while (j < i && pTask[j] > 0) 
	{
		j++;
		pTask[0]->wait();
	 	delete pTask[0];
	}
	
	return 0;
}

