#ifndef __CCONNTASK__
#define __CCONNTASK__

#include "ace/Task.h"
#include "ace/INET_Addr.h"     
#include "ace/SOCK_Stream.h"   
#include "ace/SOCK_Acceptor.h" 
#include "ace/Log_Msg.h"       
#include "ace/Time_Value.h"    

class CConnTask: public ACE_Task_Base
{
public:
	CConnTask();
	~CConnTask();
	int initilize(ACE_SOCK_Stream& peer, int flag);
	int cleanup(void);
	
	int svc(void);

protected:
	
private:
	ACE_SOCK_Stream* m_ppeer;
	int m_flag;	
};

#endif


