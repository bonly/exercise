#include "cbe_pack.h"

void CBE_Pack::setFileNameHead(const char *nm)
{
  //文件名规则：cbe_时间_进程ID_日志计数.data
  int len = strlen(nm);
  if (len != 0 && memcmp(prefix, nm, len) != 0)
  {
    strcpy(prefix, nm);
    file_count = 0;
    fileClose(true);
  }
}

int CBE_Pack::setDir(const char *dir)
{
  int len = strlen(dir);
  if (len != 0 && memcmp(fulldir, dir, len) != 0)
  {
    if (!checkPath(dir))
      return -1;

    strcpy(fulldir, dir);
    file_count = 0;
    fileClose(true);
  }
  return 0;
}

FILE *CBE_Pack::fileOpen()
{
  fileClose(true);

  time_t t;
  struct tm tt;
  time(&t);

#ifdef SunOS
  memcpy(&tt, localtime(&t), sizeof(struct tm));
#else
  localtime_r(&t, &tt);
#endif

  if (date.tm_mday != tt.tm_mday || date.tm_mon != tt.tm_mon || date.tm_year
        != tt.tm_year)
  {
    // 日期改变，重新计数
    file_count = 0;
    memcpy(&date, &tt, sizeof(date));
  }

  char dirpath[PATH_MAX];
  memset(dirpath, 0, PATH_MAX);
  if (fulldir[0] == 0)
    sprintf(dirpath, "%s", "./");
  else
    sprintf(dirpath, "%s", fulldir);

  snprintf(name, PATH_MAX, "%s%s%s_%d_%04d%02d%02d_%d.data", dirpath, "/",
        prefix, getpid(), date.tm_year + 1900, date.tm_mon + 1, date.tm_mday,
        file_count);

  char name2[PATH_MAX] =
  { 0 };
  snprintf(name2, PATH_MAX, "%s.tmp", name);

  fileOpen(name2);
  file_count++;

  return os_stream;
}

FILE *CBE_Pack::fileOpen(const char *name)
{
  os_stream = fopen(name, "w");

  if (os_stream == NULL)
    fprintf(stderr, "ERROR init [%s] log file\n", name);
  else if (buf_size > 0)
    setvbuf(os_stream, NULL, _IOFBF, buf_size); // NULL mean: file system automatically allocated buffer, size specifies the size of the buffer to be used

  return os_stream;
}

void CBE_Pack::fileClose(bool bRename)
{
  if (os_stream != NULL)
  {
    fclose(os_stream);
    os_stream = NULL;

    if (bRename)
    {
      char name2[PATH_MAX] =
      { 0 };
      snprintf(name2, PATH_MAX, "%s.tmp", name);

      rename(name2, name);
    }
  }
}

void CBE_Pack::fileOnlyClose()
{
  fileClose(false);
}

void CBE_Pack::output(const unsigned char *data, const int len)
{
  struct timeval now;
  struct tm ts;

  gettimeofday(&now, 0);
  memset(&ts, 0, sizeof(ts));
  localtime_r(&now.tv_sec, &ts);

  if (os_stream == NULL || line >= max_line || (date.tm_mday != ts.tm_mday
        || date.tm_mon != ts.tm_mon || date.tm_year != ts.tm_year))
  {
    if (fileOpen() == NULL)
      return;

    line = 0;
  }
  /*
   char dateinfo[64];
   memset(dateinfo, 0 ,sizeof(dateinfo));

   sprintf(dateinfo, "%04d%02d%02d%02d%02d%02d", ts.tm_year+1900, ts.tm_mon + 1,ts.tm_mday,ts.tm_hour,ts.tm_min,ts.tm_sec);

   if (level>=CBE_Pack_trace&&level<=CBE_Pack_error)
   fprintf(os_stream, LOG_HEAD[level/20]);
   else
   fprintf(os_stream, "%06d", level);

   fprintf(os_stream, "[%s:%06ld]", dateinfo, now.tv_usec);
   */

  //    int fd = fileno(os_stream);
  //    write(fd, data, len);

  fwrite(data, 1, len, os_stream);

  line++;
}

bool CBE_Pack::checkPath(const char *path)
{
  DIR *dir = NULL;
  if ((dir = opendir(path)) == NULL) //��Ŀ¼�����ڣ��򴴽�
  {
    //if( mkdir(dirpath, 0755) == -1)
    //{
    fprintf(stderr, "Directory: %s is not exist\n", path);
    return false;
    //}
  }
  if (dir != NULL)
  {
    if (closedir(dir) < 0)
    {
      fprintf(stderr, "Unable to close directory %s\n", path);
      return false;
    }
    dir = NULL;
  }
  if (access(path, W_OK) < 0)
  {
    fprintf(stderr, "The dir access permissions do not allow!path=%s\n", path);
    return false;
  }
  return true;
}

// example:

//    R5_TRACE("main");

// ע�⣺�������־����ʹ�õ�ʱ��һ��Ҫ���һ��С���Ž���־��Ϣ������

//     R5_INFO(("INFO\n"));
//    R5_DEBUG(("DEBUG\n"));
//    R5_WARN(("WARN\n"));
//    R5_ERROR(("ERROR\n"));

//    struct tm *lt;
//    struct timezone tz;
//    struct timeval now;
//    gettimeofday(&now, &tz);
//    lt = localtime(&now.tv_sec);
//    R5_ERROR(("%02d:%02d:%02d:%06d\n",
//    lt->tm_hour, lt->tm_min, lt->tm_sec, now.tv_usec));
