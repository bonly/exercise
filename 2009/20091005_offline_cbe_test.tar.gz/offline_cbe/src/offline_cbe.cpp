//============================================================================
// Name        : offline_cbe.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include "cbe_pack.h"
#include <iostream>
using namespace std;

CBE_Pack g_r5_log;

//默认为8个字节对齐，机器会自动补满8位
#pragma pack(1)  //按1个字节对齐，则不会补位，按2个字节对齐，则有可能补1位
struct package
{
  unsigned int begin;
  char bflag[6];   //没有pack(1)，将按计算机打包补满8位
  unsigned int len;
  char realdata[11];
};
#pragma pack() //恢复默认对齐

int main()
{
  g_r5_log.setDir("log/");
  g_r5_log.setFileNameHead("cbe");
  package pk={0,"begin",0,"0123456789"};
  //package pk;pk.begin=0;strcpy(pk.bflag,"begin");pk.len=0;strcpy(pk.realdata,"0123456789");

  unsigned char *c=(unsigned char*)&pk;
  for(unsigned int i=0; i<sizeof(package); ++i,++c)
  {
    fprintf(stderr, "%02X ",*c);
  }

  g_r5_log.output((const unsigned char* )(&pk),sizeof(package));
  g_r5_log.flush();
	return 0;
}
