//============================================================================
// Name        : stream_pack.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
// This is the main project file for VC++ application project
// generated using an Application Wizard.
#include <cstdlib>
#include <cstring>
#include <string>
#include <fstream>
#include <iostream>
#include <boost/lexical_cast.hpp>
using namespace boost;
using namespace std;

class BufferEncoder: public streambuf {
private:
string buffer; //encoded string
int numCar; //chars number of encoded string
public:

BufferEncoder() : streambuf(), numCar(0) {}
~BufferEncoder() {}

//encode a string and put it into BufferEncoder buffer
void Encode(const string& s){
    char tmp[10];
    for (unsigned int i=0; i< s.length(); ++i){
//        itoa(s[i],tmp,10);
        sprintf(tmp,"%d",s[i]);
        buffer+= (string)tmp + (string)" "; //encode in an ASCII value
        numCar +=strlen(tmp)+1;
    }
}

//decode BufferEncoder buffer and return it into s
void Decode(string& s){
    string decodeStr;
    for (int i=0; i< numCar;++i){
        string tokenStr;
        while ((buffer.at(i) != ' ')&& (buffer.at(i)!='\n') && (i< numCar)){
            tokenStr += buffer.at(i);
            i++;
        }
        int v = atoi(tokenStr.c_str());
        decodeStr += (char) v; //decoded char
    }
    s = decodeStr;
}

//add and end of line into buffer
void EndOfLine() {
    buffer += '\n';
    numCar ++;
}

//return buffer pointer
char* GetBuffer() {return ((char*) buffer.c_str());}
};



class Encoder : public ostream {
private:
    BufferEncoder myStrBuf;
public:
    //constructors
    Encoder(filebuf* fb) : ostream(fb),ios(0) {}
    Encoder() : ostream(&myStrBuf),ios(0) {}

    //endl manipulator serialization
//    _Myt& operator<<(_Myt&(__cdecl *_Pfn )(_Myt&) ){    // call basic_ostream manipulator
//            //... no others manipulators than endl
//            myStrBuf.EndOfLine();
//            return ((*_Pfn)(*this));
//        }

    //from Encoder to ostream serialization
    friend ostream& operator<<(ostream & s, Encoder& c) {
        s << c.myStrBuf.GetBuffer();
        return s;
    }

    //from const char* to Encoder serialization
    Encoder& operator<<(const char * s) {
        myStrBuf.Encode(s);
        return *this;
    }

    //from Encoder to string serialization
    Encoder& operator>>(string& s) {
        myStrBuf.Decode(s);
        return *this;
    }
};



int main ()
{

    Encoder y;

    //encoding
    y <<"Hello World!";
    cout <<"ENCODED: "<< y << endl;

    //decoding
    string s ;
    y >> s;
    cout << "DECODED: " << s << endl;
    getchar();
    return 0;
}
