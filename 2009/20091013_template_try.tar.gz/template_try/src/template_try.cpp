template<typename T>
struct OpNewCreator
{
    static T* Create()
    {
      return new T;
    }
};

class Widget
{

};

template< template<typename Created> class CreationPolicy>
class WidgetManager : public CreationPolicy<Widget>
{

};


#define STATIC_CHECK(expr) {char unnamed[(expr)?1:0];}

template <class To, class From>
To safe_reinterpret_cast(From from)
{
    STATIC_CHECK(sizeof(From)<=sizeof(To));
    return reinterpret_cast<To>(from);
}

template<bool> struct CompileTimeError;
template<> struct CompileTimeError<true>{};

int main(int argc, char* argv[])
{
  CompileTimeError<(3>2)>();
  return 0;
}
