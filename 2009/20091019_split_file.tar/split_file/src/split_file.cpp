//============================================================================
// Name        : split_file.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include "pre.h"
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

#include "rapidxml.hpp"
#include "rapidxml_print.hpp"
using namespace rapidxml;

#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "profile_config.h"

int parse_xml_file(const char* filename, xml_document<> &doc, xml_node<> **root, vector<char> &xmlData)
{
  ifstream xmlFile(filename, ios::binary);
  if (!xmlFile)
  {
    return -1;
  }

  xmlFile.unsetf(ios::skipws); //读出不跳过空白字符
  xmlFile.seekg(0, ios::end);
  size_t size = xmlFile.tellg();
  xmlFile.seekg(0);

  //预定义存放区大小
  //vector<char> xmlData(size + 1);
  xmlData.reserve(size + 1);
  xmlData[size] = 0;

  xmlFile.read(&xmlData.front(), static_cast<streamsize> (size));

  try
  {
    doc.clear();

    //解释
    doc.parse<0> (&xmlData.front());

    //取得root
    *root = doc.first_node();
  }
  catch (rapidxml::parse_error &e)
  {
    clog << "parse xml file eror: " << e.what() << endl;
    return -2;
  }
  xmlFile.close();
  return 0;
}

class NumberRangeFilter
{
  public:
    struct NumberRange
    {
        long long start;
        long long end;
        long long count;
    };

  public:
    bool inNumberRange(long long number);

  public:
    vector<NumberRange>    m_numberList;
};

bool NumberRangeFilter::inNumberRange(long long number)
{
    int cnt = (int)m_numberList.size();

    if(0 == cnt)
    {
        return true;
    }

    for(int i = 0; i < cnt; ++i)
    {
        if(number >= m_numberList[i].start && number <= m_numberList[i].end)
        {
            ++m_numberList[i].count;
            return true;
        }
    }

    return false;
}

NumberRangeFilter num_filter;

int main(int argc, char *argv[])
{
  clog << "Application begin\n";

  //读入配置文件
  Config::instance().parse(argc,argv);

  string ofile_dir = Config::instance().get<string>("ofile");
  string rfile_dir = Config::instance().get<string>("rfile");

  if(ofile_dir.compare(rfile_dir)==0)
  {
    cerr << "ofile and rfile are the same dir!\n";
    return -1;
  }

  //todo: 检查输入是否是文件而不是目录
  string ifile_name = Config::instance().get<string>("ifile");
  if(-1==access(ifile_name.c_str(),04)||
      -1==access(ofile_dir.c_str(),04)||
      -1==access(rfile_dir.c_str(),04)||
      -1==access(Config::instance().get<string>("range").c_str(),04)
  )
  {
    cerr << "input file or range file or output dir can not access!\n";
    return -1;
  }


  string file_name = basename(ifile_name.c_str());

  {//设置号码段
    //读入号码段文件
    vector<char>  num_range;
    xml_document<> doc;
    xml_node<>   *root;
    if (0 != parse_xml_file(Config::instance().get<string>("range").c_str(),
                            doc, &root, num_range))
    {
      return -1;
    }

    //解释出号码
    xml_node<char> *node = 0;
    xml_node<char> *tmp_node = 0;
    if(0 != (node = root->first_node("RANGE")))
    {
      char begin[12];
      char end[12];
      bzero(begin,12);
      bzero(end,12);
      do
      {
        if(0 == (tmp_node = node->first_node("BEGIN")))
            return -1;
        strncpy(begin, tmp_node->value(), 12);

        if(0 == (tmp_node = node->first_node("END")))
            return -1;
        strncpy(end, tmp_node->value(), 12);

        NumberRangeFilter::NumberRange nr;
        nr.start = atoll(begin);
        nr.end   = atoll(end);
        nr.count = 0;

        num_filter.m_numberList.push_back(nr);
        node     = node->next_sibling("RANGE");
      }while(0 != node);
    }
  }

  //打开相关输出文件
  ofstream ofile((ofile_dir + file_name).c_str());
  ofstream rfile((rfile_dir + file_name).c_str());
  ofile << "<?xml version=\"1.0\" encoding=\"gb2312\"?>\n<BIZ>\n";
  rfile << "<?xml version=\"1.0\" encoding=\"gb2312\"?>\n<BIZ>\n";

  //读入数据文件,解释出号码
  vector<char>  data;
  xml_document<> doc;
  xml_node<>   *root;
  if (0 != parse_xml_file(ifile_name.c_str(), doc, &root, data))
  {
    return -1;
  }

  //过滤号码,分文件输出
  string key = Config::instance().get<string>("key");
  char buf[4086];
  for(xml_node<> *child = root->first_node(); child; child = child->next_sibling())
  {
    print(buf,*child);

    xml_node<>   *node = 0;
    if (0 == (node = child->first_node(key.c_str())))
    {
      clog << "lack MSISDN field in xml\n";
      ofile << buf;
      continue;
    }

    long long acc_nbr = atoll(node->value());

    if(num_filter.inNumberRange(acc_nbr)==true)
    {
      rfile << buf ;
    }
    else
    {
      ofile << buf;
    }
  }

  ofile << "</BIZ>\n";
  rfile << "</BIZ>\n";
  ofile.close();
  rfile.close();

  clog << "Application end.\n";
	return 0;
}
