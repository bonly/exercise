#include <string.h>

#include "smpp_encoder.h"
#include <iostream>

namespace smpp
{

//CSmppEncoder::CSmppEncoder()
//{
//}
//
//CSmppEncoder::~CSmppEncoder()
//{
//}

void CSmppEncoder::fillReqSmppHead(SSmppHead& sh, unsigned int nMsgLength,
	unsigned int srcFE, unsigned int dstFE,	unsigned int srcFSM,
	unsigned int nServiceMsgType)
{
	sh.msgLength = nMsgLength;
	sh.msgType = E_MSGTYPE_REQ;
	sh.msgID = E_MSGID_REQ;
	sh.srcFE = srcFE;
	sh.dstFE = dstFE;
	sh.srcFSM = srcFSM;
	sh.dstFSM = 0;
	sh.nodeNo = 0;
	sh.serviceKey = 1;
	sh.ServiceMsgType = nServiceMsgType;
}

void CSmppEncoder::fillRespSmppHead(SSmppHead& sh, unsigned int nMsgLength,
	unsigned int dstFE,	unsigned int dstFSM,
	unsigned int nServiceMsgType)
{
	sh.msgLength = nMsgLength;
	sh.msgType = E_MSGTYPE_RESP;
	sh.msgID = E_MSGID_RESP;
	sh.srcFE = 0;
	sh.dstFE = dstFE;
	sh.srcFSM = 0;
	sh.dstFSM = dstFSM;
	sh.nodeNo = 0;
	sh.serviceKey = 1;
	sh.ServiceMsgType = nServiceMsgType;
}

//���smpp��ͷ
CSmppData& CSmppEncoder::fillHead(CSmppData& sd, SSmppHead& sh)
{
	sd.alloc_data(sh.msgLength + ESmppHeadSize);
	sd << sh.msgLength						//
		<< sh.msgType						//
		<< sh.msgID							//
		<< sh.srcFE							//
		<< sh.dstFE					    	//
		<< sh.srcFSM						//
		<< sh.dstFSM						//
		<< sh.nodeNo						//
		<< sh.serviceKey					//
		<< sh.ServiceMsgType;				//
	return sd;
}

bool CSmppEncoder::reqCheckup(CSmppData& sd, 
	unsigned int srcFE, unsigned int dstFE,	unsigned int srcFSM,
	const char* pszMsIsdn, const char* pszPin, const char* pszReqSeq,
	int nAmount, int nActiveDays, const char* pszCardNumber)
{
	//enum {e_checkup_req_size = ESmppHeadSize + 11 + 8 + 24 + 4 + 4 + 36 };
	SSmppHead sh;
	fillReqSmppHead(sh, e_checkup_req_size, srcFE, dstFE, srcFSM, E_CMD_CHECKUP_REQ);
	fillHead(sd, sh);
	sd << CSmppData::CFixedBuffer(pszMsIsdn, 11)
		<< CSmppData::CFixedBuffer(pszPin, 8)
		<< CSmppData::CFixedBuffer(pszReqSeq, 24)
		<< (unsigned int)nAmount
		<< (unsigned int)nActiveDays
		<< CSmppData::CFixedBuffer(pszCardNumber, 36)
		<< endSmpp;
	return sd.getStatus()==EInputSuc;
}


//��ֵ�����
bool CSmppEncoder::reqTopup(CSmppData& sd, 
	 unsigned int srcFE, unsigned int dstFE,	unsigned int srcFSM,
	 const char* pszMsIsdn, const char* pszPin, const char* pszReqSeq,
	 int nAmount, int nActiveDays, const char* pszCardNumber)
{
	//enum {e_topup_req_size = ESmppHeadSize + 11 + 8 + 24 + 4 + 4 + 36 };
	SSmppHead sh;
	fillReqSmppHead(sh, e_topup_req_size, srcFE, dstFE, srcFSM, E_CMD_TOPUP_REQ);
	fillHead(sd, sh);
	sd << CSmppData::CFixedBuffer(pszMsIsdn, 11)
		<< CSmppData::CFixedBuffer(pszPin, 8)
		<< CSmppData::CFixedBuffer(pszReqSeq, 24)
		<< (unsigned int)nAmount
		<< (unsigned int)nActiveDays
		<< CSmppData::CFixedBuffer(pszCardNumber, 36)
		<< endSmpp;
	return sd.getStatus()==EInputSuc;
}

//�ع������
bool CSmppEncoder::reqRollback(CSmppData& sd, 
	unsigned int srcFE, unsigned int dstFE,	unsigned int srcFSM,
	const char* pszMsIsdn, const char* pszReqSeq,
	const char* pszTradeSeq, const char* pszCardNumber)
{
	//enum {e_rollback_req_size = ESmppHeadSize + 11 + 24 + 24 + 36 };
	SSmppHead sh;
	fillReqSmppHead(sh, e_rollback_req_size, srcFE, dstFE, srcFSM, E_CMD_ROLLBACK_REQ);
	fillHead(sd, sh);
	sd << CSmppData::CFixedBuffer(pszMsIsdn, 11)
		<< CSmppData::CFixedBuffer(pszReqSeq, 24)
		<< CSmppData::CFixedBuffer(pszTradeSeq, 24)
		<< CSmppData::CFixedBuffer(pszCardNumber, 36)
		<< endSmpp;
	return sd.getStatus()==EInputSuc;
}


//��ȨӦ���
bool CSmppEncoder::respCheckup(CSmppData& sd, 
				 unsigned int dstFE,	unsigned int dstFSM,
				 const char* pszRetCode, const char* pszAckReq,
				 int nAccountLeft, const char* pszEffDate, const char* pszAreaNo)
{
	//enum {e_checkup_resp_size = ESmppHeadSize + 4 + 24 + 4 + 8 + 36 };
	SSmppHead sh;
	fillRespSmppHead(sh, e_checkup_resp_size, dstFE, dstFSM, E_CMD_CHECKUP_RESP);
	fillHead(sd, sh);
	sd << CSmppData::CFixedBuffer(pszRetCode, 4)
		<< CSmppData::CFixedBuffer(pszAckReq, 24)
		<< (unsigned int)nAccountLeft
		<< CSmppData::CFixedBuffer(pszEffDate, 8)
		<< CSmppData::CFixedBuffer(pszAreaNo, 36)
		<< endSmpp;
	return sd.getStatus()==EInputSuc;
}

//��ֵӦ���
bool CSmppEncoder::respTopup(CSmppData& sd, 
	  unsigned int dstFE, unsigned int dstFSM,
	  const char* pszRetCode, const char* pszAckReq,
	  int nAccountLeft, const char* pszEffDate, const char* pszCardNumber)
{
	//enum {e_topup_resp_size = ESmppHeadSize + 4 + 24 + 4 + 8 + 36 };
	SSmppHead sh;
std::cerr << "smpp date: " << 	pszEffDate << std::endl;
	fillRespSmppHead(sh, e_topup_resp_size, dstFE, dstFSM, E_CMD_TOPUP_RESP);
	fillHead(sd, sh);
	sd << CSmppData::CFixedBuffer(pszRetCode, 4)
		<< CSmppData::CFixedBuffer(pszAckReq, 24)
		<< (unsigned int)nAccountLeft
		<< CSmppData::CFixedBuffer(pszEffDate, 8)
		<< CSmppData::CFixedBuffer(pszCardNumber, 36)
		<< endSmpp;

	return sd.getStatus()==EInputSuc;
}

//�ع�Ӧ���
bool CSmppEncoder::respRollback(CSmppData& sd, 
	 unsigned int dstFE, unsigned int dstFSM,
	 const char* pszRetCode, const char* pszAckReq,
	 int nAccountLeft, const char* pszEffDate, const char* pszCardNumber)
{
	//enum {e_rollback_resp_size = ESmppHeadSize + 4 + 24 + 4 + 8 + 36 };
	SSmppHead sh;
	fillRespSmppHead(sh, e_rollback_resp_size, dstFE, dstFSM, E_CMD_ROLLBACK_RESP);
	fillHead(sd, sh);
	sd << CSmppData::CFixedBuffer(pszRetCode, 4)
		<< CSmppData::CFixedBuffer(pszAckReq, 24)
		<< (unsigned int)nAccountLeft
		<< CSmppData::CFixedBuffer(pszEffDate, 8)
		<< CSmppData::CFixedBuffer(pszCardNumber, 36)
		<< endSmpp;
	return sd.getStatus()==EInputSuc;
}

bool CSmppEncoder::heartbeat(CSmppData& sd)
{
	sd.alloc_data(e_beatheart_size);
	sd << (unsigned int)0x01 << (unsigned char)0x03;
	return true;
}

};

