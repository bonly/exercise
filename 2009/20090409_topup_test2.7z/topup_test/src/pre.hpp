#ifndef __PRE_HPP__
#define __PRE_HPP__

#include <iostream>
using namespace std;

#include <boost/format.hpp>
using namespace boost;


template <typename T> void print_var(const char* k, T v)
{
  cout << format("%1% : %2% \n")%k%v;
}
#define PRINT_VAR(k) print_var(#k, k)

#endif
