#ifndef __SMPP_DECODER_HEAD__
#define __SMPP_DECODER_HEAD__
#include "pre.hpp"
#include <ctype.h>

#include "smpp_code.h"
#include "smpp_encoder.h"

namespace smpp
{
	struct RTS
	{
		SSmppHead Head;
		char RetCode[4+1];
		char AckReq[24+1];
		char AccountLeft[4+1];
		char CallServiceStop[8+1];
		char AccountNumber[36];
		void print();
		RTS(){memset(this,0,sizeof(RTS));}
	};

	struct TAS
	{
		SSmppHead Head;
		char RetCode[4+1];
		char AckReq[24+1];
		char AccountLeft[4+1];
		char CallServiceStop[8+1];
		char AccountNumber[36];
		void print();
		TAS(){memset(this,0,sizeof(TAS));}
	};

	struct TUS
	{
		SSmppHead Head;
		char RetCode[4+1];
		char AckReq[24+1];
		char AccountLeft[4+1];
		char CallServiceStop[8+1];
		char AccountNumber[36];
		void print();
		TUS(){memset(this,0,sizeof(TUS));}
	};

	class CSmppDecoder
	{
	public:
		//��4byteת��Ϊ����(sizeof(int)==4)
		static unsigned int FourByteToInt(const char* pszInput);
    static unsigned long long ch2uLL(const char* pszInput,const int bp,const int size);

	public:
		static ECommandId getServiceMsgType(const char* p);

	public:
		//��Ȩ����
		static bool reqCheckup(const char* p, unsigned int& srcFE,
			unsigned int& dstFE, unsigned int& srcFSM,
			unsigned long long& pszMsIsdn, char* pszPin, char* pszReqSeq,
			int& nAmount, int& nActiveDays, char* pszCardNumber);

		//��ֵ����
		static bool reqTopup(const  char* p, unsigned int& srcFE,
			unsigned int& dstFE, unsigned int& srcFSM,
			unsigned long long& pszMsIsdn, char* pszPin, char* pszReqSeq,
			int& nAmount, int& nActiveDays, char* pszCardNumber);

		//�ع�����
		static bool reqRollback(const char* p, unsigned int& srcFE,
			unsigned int& dstFE, unsigned int& srcFSM,
			unsigned long long& pszMsIsdn, char* pszReqSeq,
			char* pszTradeSeq, char* pszCardNumber);

		//�ع�Ӧ��
		static bool respRollback(const char* p,RTS &rts);
		static bool respTopup(const char* p,TUS &tus);
		static bool respCheckup(const char* p,TAS &tas);
	};

};


#endif

