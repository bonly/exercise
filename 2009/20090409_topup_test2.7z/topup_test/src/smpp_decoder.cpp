#include <cstring>
#include <cstdlib>
#include "smpp_decoder.h"
#include <boost/lexical_cast.hpp>
#include <boost/format.hpp>
#include <boost/algorithm/string.hpp>
#include <netinet/in.h>
#include <iostream>
namespace smpp
{

//��4byteת��Ϊ����(sizeof(int)==4)
unsigned int CSmppDecoder::FourByteToInt(const char* pszInput)
{
  unsigned char* psz = (unsigned char*)pszInput;
  unsigned int nLen = (psz[0] << 24) + (psz[1] << 16) + (psz[2] << 8) + psz[3];
  return nLen;
}

ECommandId CSmppDecoder::getServiceMsgType(const char* p)
{
  //��ȡ����,�������Ϊ1,��Ϊ������
  unsigned int unLen = FourByteToInt(p);
  if(unLen == 1)
  {
    return E_CMD_HEARTBEAT;
  }

  enum{e_pos = 36, min_msg_size = 41};
  if(unLen < min_msg_size)
  {
    return E_CMD_UNKNOWN;
  }

  return static_cast<ECommandId>(FourByteToInt(p + e_pos));
}

unsigned long long CSmppDecoder::ch2uLL(const char* pszInput,const int bp, const int size)
{
  char tmp[11+1];
  memset(tmp,0,sizeof(tmp));
  strncpy(tmp, pszInput + bp, 11);
  unsigned long long result=0ull;
  try
  {
    result = boost::lexical_cast<unsigned long long>(tmp);
  }
  catch(boost::bad_lexical_cast &e)
  {
    std::cerr << "phone"<<tmp<<e.what()<<"\n";
  }
  return result;
}

bool CSmppDecoder::reqCheckup(const char* p, unsigned int& srcFE,
      unsigned int& dstFE, unsigned int& srcFSM,
      unsigned long long& pszMsIsdn, char* pszPin, char* pszReqSeq,
      int& nAmount, int& nActiveDays, char* pszCardNumber)
{
  if(FourByteToInt(p) != e_checkup_req_size)
  {
    return false;
  }

  srcFE = FourByteToInt(p + 12);
  dstFE = FourByteToInt(p + 16);
  srcFSM = FourByteToInt(p + 20);
  pszMsIsdn = ch2uLL(p, 40, 11);
  strncpy(pszPin, p + 51, 8);
  pszPin[8] = '\0';
  strncpy(pszReqSeq, p + 59, 24);
  pszReqSeq[24] = '\0';
  nAmount = FourByteToInt(p + 83);
  nActiveDays = FourByteToInt(p + 87);
  strncpy(pszCardNumber, p + 91, 36);
  pszCardNumber[36] = '\0';

  return true;
}

//��ֵ����
bool CSmppDecoder::reqTopup(const char* p, unsigned int& srcFE,
       unsigned int& dstFE, unsigned int& srcFSM,
       unsigned long long& pszMsIsdn, char* pszPin, char* pszReqSeq,
       int& nAmount, int& nActiveDays, char* pszCardNumber)
{
  if(FourByteToInt(p) != e_topup_req_size)
  {
    return false;
  }

  srcFE = FourByteToInt(p + 12);
  dstFE = FourByteToInt(p + 16);
  srcFSM = FourByteToInt(p + 20);
  //TODO:ȷ���ֻ��������ʼλ��
  pszMsIsdn = ch2uLL(p, 40, 11);
  strncpy(pszPin, p + 51, 8);
  pszPin[8] = '\0';
  strncpy(pszReqSeq, p + 59, 24);
  pszReqSeq[24] = '\0';
  nAmount = FourByteToInt(p + 83);
std::cout<<boost::format("smpp's Amount is: %u\t%d\t%x\n")%nAmount%nAmount%nAmount;
  nActiveDays = FourByteToInt(p + 87);
  strncpy(pszCardNumber, p + 91, 36);
  pszCardNumber[36] = '\0';

  return true;
}

//�ع�����
bool CSmppDecoder::reqRollback(const char* p, unsigned int& srcFE,
      unsigned int& dstFE, unsigned int& srcFSM,
      unsigned long long& pszMsIsdn, char* pszReqSeq,
      char* pszTradeSeq, char* pszCardNumber)
{
  //unsigned int *pMsgLen = reinterpret_cast<unsigned int*>(const_cast<char*>(p));
  //HP���ô˽�ͷ����������
  //if(FourByteToInt(p) != e_rollback_req_size)
	int *pMsgLen = reinterpret_cast<int*>(const_cast<char*>(p));
	int nMsgLen = ntohl(*pMsgLen);
  if (nMsgLen != e_rollback_req_size)
  {
  	std::cout << "Rollback size is: "<<e_rollback_req_size<<std::endl;
    //return false;
  }

  srcFE = FourByteToInt(p + 12);
  dstFE = FourByteToInt(p + 16);
  srcFSM = FourByteToInt(p + 20);
  srcFSM = FourByteToInt(p + 40);
  //TODO:ȷ���ֻ��������ʼλ��
  pszMsIsdn = ch2uLL(p, 40, 11);
  strncpy(pszReqSeq, p + 51, 24);
  pszReqSeq[24] = '\0';
  strncpy(pszTradeSeq, p + 75, 24);
  pszTradeSeq[24] = '\0';
  strncpy(pszCardNumber, p + 99, 36);
  pszCardNumber[36] = '\0';

  return true;
}

//�ع�Ӧ��
bool CSmppDecoder::respRollback(const char* p,RTS &rts)
{
	rts.Head.msgLength = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 0))));
	rts.Head.msgType   = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 4))));
	rts.Head.msgID     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 8))));
	rts.Head.srcFE     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 12))));

	rts.Head.dstFE     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 16))));
	rts.Head.srcFSM    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 20))));
	rts.Head.dstFSM    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 24))));
  //rts.Head.nodeNo  = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 28))));

  //rts.Head.serkey  = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 32))));
  //rts.Head.sermtpe = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 36))));

  strncpy(rts.RetCode, p + 40, 4);//RetCode
  strncpy(rts.AckReq, p + 44, 24);//ReqSeq
  //rts.AccountLeft    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 68)))); //�ع���Ԥ�����ʻ����
  strncpy(rts.CallServiceStop,p + 72,8);//�ع���Ԥ�����ʻ���Ч��
  strncpy(rts.AccountNumber, p + 80, 36);//AccountNumber

  return true;
}

//��ֵӦ��
bool CSmppDecoder::respTopup(const char* p,TUS &tus)
{
	tus.Head.msgLength = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 0))));
	tus.Head.msgType   = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 4))));
	tus.Head.msgID     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 8))));
	tus.Head.srcFE     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 12))));

	tus.Head.dstFE     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 16))));
	tus.Head.srcFSM    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 20))));
	tus.Head.dstFSM    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 24))));
  //tus.Head.nodeNo  = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 28))));

  //tus.Head.serkey  = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 32))));
  //tus.Head.sermtpe = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 36))));

  strncpy(tus.RetCode, p + 40, 4);//RetCode
  strncpy(tus.AckReq, p + 44, 24);//ReqSeq
  //tus.AccountLeft    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 68)))); //�ع���Ԥ�����ʻ����
  strncpy(tus.CallServiceStop,p + 72,8);//�ع���Ԥ�����ʻ���Ч��
  strncpy(tus.AccountNumber, p + 80, 36);//AccountNumber

  return true;
}

//��ȨӦ��
bool CSmppDecoder::respCheckup(const char* p,TAS &tas)
{
	tas.Head.msgLength = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 0))));
	tas.Head.msgType   = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 4))));
	tas.Head.msgID     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 8))));
	tas.Head.srcFE     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 12))));

	tas.Head.dstFE     = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 16))));
	tas.Head.srcFSM    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 20))));
	tas.Head.dstFSM    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 24))));
  //tas.Head.nodeNo  = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 28))));

  //tas.Head.serkey  = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 32))));
  //tas.Head.sermtpe = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 36))));

  strncpy(tas.RetCode, p + 40, 4);//RetCode
  strncpy(tas.AckReq, p + 44, 24);//ReqSeq
  //tas.AccountLeft    = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 68)))); //�ع���Ԥ�����ʻ����
  strncpy(tas.CallServiceStop,p + 72,8);//�ع���Ԥ�����ʻ���Ч��
  strncpy(tas.AccountNumber, p + 80, 36);//AccountNumber

  return true;
}

void RTS::print()
{
	PRINT_VAR(RetCode);
	PRINT_VAR(AckReq);
	PRINT_VAR(AccountLeft);
	PRINT_VAR(CallServiceStop);
	PRINT_VAR(AccountNumber);
}

void TUS::print()
{
	PRINT_VAR(RetCode);
	PRINT_VAR(AckReq);
	PRINT_VAR(AccountLeft);
	PRINT_VAR(CallServiceStop);
	PRINT_VAR(AccountNumber);
}

void TAS::print()
{
	PRINT_VAR(RetCode);
	PRINT_VAR(AckReq);
	PRINT_VAR(AccountLeft);
	PRINT_VAR(CallServiceStop);
	PRINT_VAR(AccountNumber);
}
};

