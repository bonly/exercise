/*
 * pre.h
 *
 *  Created on: 2010-4-22
 *      Author: bonly
 */

#ifndef PRE_H_
#define PRE_H_
#include <boost/shared_ptr.hpp>
#include <boost/program_options.hpp>
#include <boost/format.hpp>
#include <boost/foreach.hpp>
using namespace boost;

#include <iostream>
using namespace std;

#endif /* PRE_H_ */
