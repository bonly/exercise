//============================================================================
// Name        : split_file.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include "pre.h"
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

#include "rapidxml.hpp"
#include "rapidxml_print.hpp"
using namespace rapidxml;

#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <libgen.h>
#include <dirent.h>


#include "profile_config.h"

struct file_info
{
    string ifile; //输入文件
    string bfile; //备份文件
    string efile; //错误文件
    string ofile; //IBS输出文件
    string tofile; //IBS输出文件临时文件
    string rfile; //EPDSCP输出文件
    string trfile; //EPDSCP输出文件临时文件

};

struct BSS_REC
{
    char  COMMSERIAL[40];
    char  OperID[20];
    char  OrgID[10];
    char  SubID[40];
    char  MSISDN[15];
    char  CallType[10];
    char  CardNo[5];
    char  IMSI[5];
    char  AcctLimit[40];

    struct PROD
    {
      char  COMMSERIAL[40];
      char  OPType[5];
      char  Brand[10];
      char  ProdID[20];
      char  ProdDef[20];
      char  ProdType[5];
      char  PlanID[20];
      char  EffType[5];
      char  BegDate[40];
      char  EndDate[40];
    };
};
int scan_dir(const char* pdir, const char* ofile_dir, const char* tfile_dir,
             const char* bfile_dir, const char* rfile_dir, vector<file_info> &vfile)
{
  DIR* pDir = NULL;

  struct dirent* pDirent;
  struct stat statinfo;

  if (access(pdir, F_OK)==0)
    pDir = opendir(pdir);
  else
  {
    return -1;
  }
  if (pDir == NULL)
  {
    return -2;
  }

  char szFullName[256];
  while ((pDirent = readdir(pDir)) != NULL)
  {
    if ((strcmp(pDirent->d_name, ".") == 0) || (strcmp(pDirent->d_name, "..")
          == 0))
      continue;

    memset(szFullName, 0, sizeof(szFullName));
    strcpy(szFullName, pdir);
    strcat(szFullName, "/");
    strcat(szFullName, pDirent->d_name);
    if (stat(szFullName, &statinfo) == -1)
      continue;

    /* is directory */
    if (S_ISDIR( statinfo.st_mode ))
      continue;

    file_info finfo;
    finfo.ifile   = szFullName;
    (finfo.bfile  = bfile_dir).append("/").append(pDirent->d_name);
    (finfo.efile  = bfile_dir).append("/").append(pDirent->d_name).append(".err");
    (finfo.ofile  = ofile_dir).append("/").append(pDirent->d_name);
    (finfo.rfile  = rfile_dir).append("/").append(pDirent->d_name);
    (finfo.tofile = tfile_dir).append("/").append(pDirent->d_name).append(".o");
    (finfo.trfile = tfile_dir).append("/").append(pDirent->d_name).append(".r");

    vfile.push_back(finfo);
  }
  return 0;
}

int parse_xml_file(const char* filename, xml_document<> &doc,
      xml_node<> **root, vector<char> &xmlData)
{
  ifstream xmlFile(filename, ios::binary);
  if (!xmlFile)
  {
    return -1;
  }

  xmlFile.unsetf(ios::skipws); //读出不跳过空白字符
  xmlFile.seekg(0, ios::end);
  size_t size = xmlFile.tellg();
  xmlFile.seekg(0);

  //预定义存放区大小
  //vector<char> xmlData(size + 1);
  xmlData.reserve(size + 1);
  xmlData[size] = 0;

  xmlFile.read(&xmlData.front(), static_cast<streamsize> (size));

  try
  {
    doc.clear();

    //解释
    doc.parse<0> (&xmlData.front());

    //取得root
    *root = doc.first_node();
  }
  catch (rapidxml::parse_error &e)
  {
    xmlFile.close();
    clog << "parse xml file eror: " << e.what() << endl;
    return -2;
  }
  xmlFile.close();
  return 0;
}

class NumberRangeFilter
{
  public:
    struct NumberRange
    {
        long long start;
        long long end;
        long long count;
    };

  public:
    bool inNumberRange(long long number);

  public:
    vector<NumberRange> m_numberList;
};

bool NumberRangeFilter::inNumberRange(long long number)
{
  int cnt = (int) m_numberList.size();

  if (0 == cnt)
  {
    return true;
  }

  for (int i = 0; i < cnt; ++i)
  {
    //fprintf(stderr, "begin: %lld end: %lld\n",m_numberList[i].start,m_numberList[i].end);
    if (number >= m_numberList[i].start && number <= m_numberList[i].end)
    {
      ++m_numberList[i].count;
      return true;
    }
  }

  return false;
}


int process_file(file_info &finfo, NumberRangeFilter &num_filter, bool &empty_for_rfile, bool &split)
{
  //打开相关输出文件
  ofstream ofile(finfo.tofile.c_str());
  ofstream rfile(finfo.trfile.c_str());
  ofile << "<?xml version=\"1.0\" encoding=\"gb2312\"?>\n<BIZ>\n";
  rfile << "<?xml version=\"1.0\" encoding=\"gb2312\"?>\n<BIZ>\n";

  //读入数据文件,解释出号码
  vector<char> data;
  xml_document<> doc;
  xml_node<> *root;
  if (0 != parse_xml_file(finfo.ifile.c_str(), doc, &root, data))
  {
    ofile.close();
    rfile.close();
    return -1;
  }

  //过滤号码,分文件输出
  string key = Config::instance().get<string> ("key");
  char buf[4086];
  for (xml_node<> *child = root->first_node(); child;
        child = child->next_sibling())
  {
    memset(buf, 0, 4086);
    print(buf, *child);

    xml_node<> *node = 0;
    if (0 == (node = child->first_node(key.c_str())))
    {
      clog << "lack MSISDN field in xml\n";
      ofile << buf;
      continue;
    }

    long long acc_nbr = strtoll(node->value(), NULL, 10);

    if (num_filter.inNumberRange(acc_nbr) == true)
    {
      empty_for_rfile = false;
      if(split)
      {
        BSS_REC  rec;
        memset(&rec,0,sizeof(BSS_REC));

#define GET_NODE(field,NODE,pre) {\
  xml_node<> *tmp_node = NODE->first_node(#field + pre); \
  if(0!=tmp_node) {\
    if(strlen(tmp_node->value())>sizeof(field)) {\
      clog << format("Field [%s]:%s is bigger then define %d\n")%(#field+pre)%tmp_node->value()%sizeof(field); \
      strncpy(field,tmp_node->value(),sizeof(field)); \
     } \
    strcpy(field,tmp_node->value()); \
  } \
  else strcpy(field,""); \
}
        GET_NODE(rec.COMMSERIAL,child,4);
        GET_NODE(rec.OperID,child,4);
        GET_NODE(rec.OrgID,child,4);
        GET_NODE(rec.SubID,child,4);
        GET_NODE(rec.MSISDN,child,4);
        GET_NODE(rec.CallType,child,4);
        GET_NODE(rec.CardNo,child,4);
        GET_NODE(rec.IMSI,child,4);
        GET_NODE(rec.AcctLimit,child,4);

        xml_node<> *prodlist = child->first_node("ProdList");
        xml_node<> *prodfile = prodlist->first_node("Prod");
        int prod_num=0;
        do
         {
            xml_document<> ndoc;
            xml_node<> *rec_node = ndoc.allocate_node(node_element,"REC");
            ndoc.append_node(rec_node);

#define SET_NODE(field,NODE,pre) {\
            NODE->append_node( \
                  ndoc.allocate_node(node_element, \
                        doc.allocate_string(#field+pre), \
                        field)); \
}
            char COMMSERIAL[40];
            strncpy(COMMSERIAL,rec.COMMSERIAL,40);
            char num[4];
            sprintf(num, "%d", prod_num);
            strcat(COMMSERIAL,num);

            SET_NODE(COMMSERIAL,rec_node,0);
            SET_NODE(rec.OperID,rec_node,4);
            SET_NODE(rec.OrgID,rec_node,4);
            SET_NODE(rec.SubID,rec_node,4);
            SET_NODE(rec.MSISDN,rec_node,4);
            SET_NODE(rec.CallType,rec_node,4);
            SET_NODE(rec.CardNo,rec_node,4);
            SET_NODE(rec.IMSI,rec_node,4);
            SET_NODE(rec.AcctLimit,rec_node,4);
            xml_node<> *prodlist_node = doc.allocate_node(node_element,
                                       doc.allocate_string("ProdList"));
            rec_node->append_node(prodlist_node);

            xml_node<> *prod_node = doc.allocate_node(node_element,
                                    doc.allocate_string("Prod"));

            prodlist_node->append_node(prod_node);

            BSS_REC::PROD prod;
            memset(&prod,0,sizeof(BSS_REC::PROD));

            GET_NODE(prod.OPType,prodfile,5);
            SET_NODE(prod.OPType,prod_node,5);

            GET_NODE(prod.Brand,prodfile,5);
            SET_NODE(prod.Brand,prod_node,5);

            GET_NODE(prod.ProdID,prodfile,5);
            SET_NODE(prod.ProdID,prod_node,5);

            GET_NODE(prod.ProdDef,prodfile,5);
            SET_NODE(prod.ProdDef,prod_node,5);

            GET_NODE(prod.ProdType,prodfile,5);
            SET_NODE(prod.ProdType,prod_node,5);

            GET_NODE(prod.PlanID,prodfile,5);
            SET_NODE(prod.PlanID,prod_node,5);

            GET_NODE(prod.EffType,prodfile,5);
            SET_NODE(prod.EffType,prod_node,5);

            GET_NODE(prod.BegDate,prodfile,5);
            SET_NODE(prod.BegDate,prod_node,5);

            GET_NODE(prod.EndDate,prodfile,5);
            SET_NODE(prod.EndDate,prod_node,5);
            rfile << ndoc;
#undef GET_NODE
#undef SET_NODE

            prodfile = prodfile->next_sibling();
            ++prod_num;
        }while(prodfile); //当下一个Prod为空
      }
      else
      {
        rfile << buf;
      }
    }
    else
    {
      ofile << buf;
    }
  }

  ofile << "</BIZ>\n";
  rfile << "</BIZ>\n";
  ofile.close();
  rfile.close();

  return 0;
}

int split()
{

}

NumberRangeFilter num_filter;

int main(int argc, char *argv[])
{
  clog << "Split file begin\n";

  //读入配置文件
  Config::instance().parse(argc, argv);

  string ifile_dir = Config::instance().get<string> ("ifile");
  string bfile_dir = Config::instance().get<string> ("bfile");
  string ofile_dir = Config::instance().get<string> ("ofile");
  string rfile_dir = Config::instance().get<string> ("rfile");
  string tfile_dir = Config::instance().get<string> ("tfile");
  bool   split_prod = Config::instance().get<bool>("split");
  if (ofile_dir.compare(rfile_dir) == 0)
  {
    cerr << "ofile and rfile are the same dir!\n";
    return -1;
  }

  if (bfile_dir.compare(ifile_dir) == 0)
  {
    cerr << "bfile and ifile are the same dir!\n";
    return -1;
  }

  //检查输入是否存在,不存在的创建
  if (-1 == access(ifile_dir.c_str(), 04))
  {
    if (0 != mkdir(ifile_dir.c_str(),0777))
    {
      cerr << "can not create input dir: " << ifile_dir << strerror(errno)
            << endl;
      return -1;
    }
  }

  //检查备份是否存在,不存在的创建
  if (-1 == access(bfile_dir.c_str(), 04))
  {
    if (0 != mkdir(bfile_dir.c_str(),0777))
    {
      cerr << "can not create backup dir: " << bfile_dir << strerror(errno)
            << endl;
      return -1;
    }
  }

  //检查临时目录是否存在,不存在的创建
  if (-1 == access(tfile_dir.c_str(), 04))
  {
    if (0 != mkdir(tfile_dir.c_str(),0777))
    {
      cerr << "can not create temp dir: " << tfile_dir << strerror(errno)
            << endl;
      return -1;
    }
  }

  //检查号段内的输出目录
  if (-1 == access(rfile_dir.c_str(), 04))
  {
    if (0 != mkdir(rfile_dir.c_str(),0777))
    {
      cerr << "can not create in range dir: " << rfile_dir << strerror(errno)
            << endl;
      return -1;
    }
  }

  //检查号段外的输出目录
  if (-1 == access(ofile_dir.c_str(), 04))
  {
    if (0 != mkdir(ofile_dir.c_str(),0777))
    {
      cerr << "can not create out of range dir: " << ofile_dir << strerror(
            errno) << endl;
      return -1;
    }
  }

  //检查各个目录是否能访问
  if ( -1 == access(ifile_dir.c_str(), 04) ||
       -1 == access(ofile_dir.c_str(), 04) ||
       -1 == access(rfile_dir.c_str(), 04) ||
       -1 == access(tfile_dir.c_str(), 04) ||
       -1 == access(Config::instance().get<string> ("range").c_str(), 04))
  {
    cerr
          << "input dir or range file or output dir or tmp dir can not access!\n";
    return -1;
  }

  {//设置号码段
    //读入号码段文件
    vector<char> num_range;
    xml_document<> doc;
    xml_node<> *root;
    if (0 != parse_xml_file(Config::instance().get<string> ("range").c_str(),
          doc, &root, num_range))
    {
      return -1;
    }

    //解释出号码
    xml_node<char> *node = 0;
    xml_node<char> *tmp_node = 0;
    if (0 != (node = root->first_node("RANGE")))
    {
      char begin[12];
      char end[12];
      memset(begin, 0, 12);
      memset(end, 0, 12);
      do
      {
        if (0 == (tmp_node = node->first_node("BEGIN")))
          return -1;
        strncpy(begin, tmp_node->value(), 12);

        if (0 == (tmp_node = node->first_node("END")))
          return -1;
        strncpy(end, tmp_node->value(), 12);

        NumberRangeFilter::NumberRange nr;
        nr.start = strtoll(begin, NULL, 10);
        nr.end = strtoll(end, NULL, 10);
        nr.count = 0;

        num_filter.m_numberList.push_back(nr);
        node = node->next_sibling("RANGE");
      } while (0 != node);
    }
    else
    {
      fprintf(stderr, "file is empty!\n");
      return 0;
    }
  }
  //BOOST_FOREACH(NumberRangeFilter::NumberRange n, num_filter.m_numberList)
  //{
  //  fprintf(stderr,"%lld -- %lld\n", n.start , n.end);
  //}

  vector<file_info> vfile;
  if (0 != scan_dir(ifile_dir.c_str(), ofile_dir.c_str(), tfile_dir.c_str(),
        bfile_dir.c_str(),rfile_dir.c_str(), vfile))
  {
    clog << "can not get file from " << ifile_dir << endl;
    return 0;
  }

  BOOST_FOREACH(file_info finfo, vfile)
  {
    bool empty_for_rfile = true;
    bool split = Config::instance().get<bool>("split");
    if(0 == process_file(finfo, num_filter, empty_for_rfile, split))
    {
      rename(finfo.ifile.c_str(), finfo.bfile.c_str()); //备份原文件
      rename(finfo.tofile.c_str(), finfo.ofile.c_str()); //IBS的文件
      if (empty_for_rfile == false)
        rename(finfo.trfile.c_str(), finfo.rfile.c_str()); //EPDSCP的文件
      remove(finfo.trfile.c_str()); //删除EPDSCP临时文件
      remove(finfo.tofile.c_str()); //删除IBS临时文件
    }
    else
    {
      rename(finfo.ifile.c_str(), finfo.efile.c_str()); //备份原文件
      remove(finfo.trfile.c_str()); //删除EPDSCP临时文件
      remove(finfo.tofile.c_str()); //删除IBS临时文件
    }
  }
  clog << "Application end.\n";
  return 0;
}
