//============================================================================
// Name        : profile_config.hpp
// Author      : bonly
// Version     : 2009-4-10
// Copyright   :
// Description : 启动参数管理
//============================================================================
#ifndef __PROFILE_CONFIG_H__
#define __PROFILE_CONFIG_H__
#include "pre.h"

class Config
{
  public:
    int parse(int argc=0, char* argv[]=0);
    static Config& instance();
    int count(const char* key){return (*_cfg).count(key);}
    void help();

    template<typename RET>
    RET get(const char* key){return (*_cfg)[key].as<RET>();}

  private:
    shared_ptr<program_options::variables_map>         _cfg;
    program_options::options_description               _desc_cfg;
    int argc;char** argv;
    int clear();

  public:
    static Config* _config;
};

#endif //__PROFILE_CONFIG_H__


