/*
 * profile_config.cpp
 *
 *  Created on: 2009-4-10
 *      Author: Bonly
 */

#include <fstream>
#include <iostream>
#include "profile_config.h"

Config* Config::_config = 0;
void Config::help()
{
  cout << _desc_cfg;
}
int Config::clear()
{
  _cfg.reset();
  _cfg = shared_ptr<program_options::variables_map>(new program_options::variables_map);
  return 0;
}

int Config::parse(int argc, char* argv[])
{
  try
  {
    clear();
    if(argc!=0 || argv!=0)
    {
      this->argc=argc;
      this->argv=argv;
    }

    string rule(
     "Note: ifile must be a file"
    );

    _desc_cfg.add_options ()
      ("help,h", rule.c_str())
      ("config-file,c", program_options::value<std::string>(),"use config file")
      ("ifile,i", program_options::value<std::string>()->default_value("ifile"),"input dir")
      ("bfile,b", program_options::value<std::string>()->default_value("bfile"),"backup dir")
      ("tfile,t", program_options::value<std::string>()->default_value("tfile"),"temp dir")
      ("ofile,o", program_options::value<std::string>()->default_value("ofile"),"output File's dir not in range")
      ("rfile,r", program_options::value<std::string>()->default_value("rfile"),"output File's dir in range")
      ("range,a", program_options::value<std::string>()->default_value("./num_range.xml"),"num range defind")
      ("key,k",program_options::value<string>()->default_value("MSISDN"),"MSISDN field name in file")
      ("split,s",program_options::value<bool>()->default_value(false),"split prod to mult task")
       ;

    program_options::positional_options_description p;
    p.add("config-file", -1);
    store (
        program_options::command_line_parser(this->argc,this->argv).options(_desc_cfg).positional(p).run(),
        *_cfg);

    notify(*_cfg);

    if ((*_cfg).count("help")||(*_cfg).count("version"))
    {
      cout << _desc_cfg;
      exit(0);
    }

    if (!(*_cfg).count("config-file"))
    {
      cerr << "usage: " << argv[0] << " <config-file> \n";
      exit(EXIT_FAILURE);
    }

    ifstream ifs((*_cfg)["config-file"].as<std::string>().c_str());
    store(parse_config_file(ifs,_desc_cfg),*_cfg );
    ifs.close();
    notify(*_cfg);
  }
  catch(std::exception& e)
  {
    cout << e.what() << "\n";
    exit(EXIT_FAILURE);
  }
  return 0;
}

Config& Config::instance()
{
  if (Config::_config == 0)
  {
    Config::_config = new Config;
  }
  return *Config::_config;
}


