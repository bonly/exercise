#include "bonly_chap_Native.h"

/**
 * Class:     bonly_chap_Native
 * Method:    LibMain
 * Signature: ([Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_bonly_chap_Native_LibMain
  (JNIEnv * env, jclass jc, jobjectArray name)
{
	jboolean iscopy;
	const char *from_java = (*env)->GetStringUTFChars(env, name, &iscopy);
	printf("string from java is: %s\n",from_java);
	return 0;
}

int lib_main(int argc, char **argv)
{
    int i;

    printf("Entering LIB MAIN");
    return 0;
}

/**
生成的libmy.so:
agcc -c lib.c -o my.o
ald -shared -o libmy.so my.o
eclipse的项目下创建目录libs/armeabi(如果是mips编译器编译的,则是libs/mips);
项目生成时会自动打包so文件,并在安装时在/data/data/$packagename/lib/目录中放入so文件;
经测试,手工创建/data/data/$packagename/lib/及so文件却运行不成功.
*/