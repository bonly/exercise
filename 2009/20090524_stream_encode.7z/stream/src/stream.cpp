//============================================================================
// Name        : stream_pack.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
// This is the main project file for VC++ application project
// generated using an Application Wizard.
#include <cstdlib>
#include <cstring>
#include <string>
#include <fstream>
#include <iostream>
#include <boost/lexical_cast.hpp>
using namespace boost;
using namespace std;

class BufferEncoder: public streambuf
{
    private:
        string buffer; //ѹ��������
        int    numCar; //ѹ���ַ�����
        bool   begin;
    public:
        enum oper{ending};

        BufferEncoder() : streambuf(), numCar(0),begin(true) {}
        ~BufferEncoder() {}

        //ѹ�������buffer��
        void Encode(const string& s)
        {
           if(!begin)
           {
              buffer.append(",");
              begin=false;
           }
           buffer+= s; //encode in an ASCII value
        }

        //��ѹ���ݷ��������
        void Decode(string& s)
        {
            string decodeStr;
            for (int i=0; i< numCar;++i)
            {
                string tokenStr;
                while ((buffer.at(i) != ' ')&& (buffer.at(i)!='\n') && (i< numCar)){
                    tokenStr += buffer.at(i);
                    i++;
                }
                int v = atoi(tokenStr.c_str());
                decodeStr += (char) v; //decoded char
            }
            s = decodeStr;
        }

        //�������������β
        void EndOfLine()
        {
            buffer.insert(0,"ACK:");
            buffer += ';';
            numCar = buffer.length();
        }

        //ȡ��buffer����
        char* GetBuffer() {return ((char*) buffer.c_str());}
};



class Encoder : public ostream {
private:
    BufferEncoder myStrBuf;
public:
    //constructors
    Encoder(filebuf* fb) : ostream(fb),ios(0) {}
    Encoder() : ostream(&myStrBuf),ios(0) {}

    //���ѹ������
    friend ostream& operator<<(ostream & s, Encoder& c)
    {
        s << c.myStrBuf.GetBuffer();
        return s;
    }

    //ѹ��
    Encoder& operator<<(const char * s)
    {
        myStrBuf.Encode(s);
        return *this;
    }
    Encoder& operator<<(BufferEncoder::oper)
    {
        myStrBuf.EndOfLine();
        return *this;
    }

    //���
    Encoder& operator>>(string& s)
    {
        myStrBuf.Decode(s);
        return *this;
    }
};



int main ()
{

    Encoder y;

    //ѹ��
    y <<"USERIDENTIFIER=N'02099119911" << BufferEncoder::ending;
    cout <<"ENCODED: "<< y << endl;  //���ѹ������

    //���
    string s ;
    y >> s;
    cout << "DECODED: " << s << endl;
    getchar();
    return 0;
}
