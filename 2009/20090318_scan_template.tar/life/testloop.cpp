#include <cstdio>
#include <unistd.h>
int main(int argc, char* argv[])
{
  while(true)
  {
    printf("loop\n");
    sleep(6);
  }
  return 0;
}
