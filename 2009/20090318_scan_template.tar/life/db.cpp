#include "db.hpp"
namespace bonly{

int
CCommand::RePrepare()
{
  _ttcmd.RePrepare(&_db->Connect(),_status);
  if(_status.rc)
  {
    printf("TTCmd::RePrepare Failed: %s\n", _status.err_msg);
    return -1;
  }
  return 0;
}
int
CCommand::Close()
{
  _ttcmd.Close(_status);
  if(_status.rc)
  {
    printf("TTCmd::Close failed: %s\n", _status.err_msg);
    return -1;
  }
  return _db->Commit();
}
int
CCommand::Drop()
{
  _ttcmd.Drop(_status);
  if (_status.rc)
  {
    printf("TTCmd::Drop failed: %s\n", _status.err_msg);
    return -1;
  }
  return _db->Commit();
}
int
CCommand::Execute()
{
  _ttcmd.Execute(_status);
  if(_status.rc)
  {
    printf("TTCmd::Execute Failed: %s\n", _status.err_msg);
    return -1;
  }
  return 0;
}
int
CCommand::FetchNext()
{
  int result = _ttcmd.FetchNext(_status);
  if ( !(result==0||result==1) && _status.rc)
  {
    printf("TTCmd:: FetchNext Failed: %s\n", _status.err_msg);
  }
  return result;
}

//===========================================================================================
#ifndef WIN32
void CDB::Log(ofstream& log_file, TTLog::TTLOG_LEVEL level)
{
  TTGlobal::setLogStream (log_file);
  TTGlobal::setLogLevel (level);
}
void CDB::Debug(const char* logfile,TTLog::TTLOG_LEVEL level)
{
  _log_file.open(logfile);
  Log(_log_file,level);
}
#endif
void CDB::disableLogging()
{
  TTGlobal::disableLogging();
  TTGlobal::setLogLevel (TTLog::TTLOG_NIL);
}
int CDB::Connect(const char* szDSN)
{
  _connect.Connect(szDSN, _status);
  if (_status.rc)
  {
    printf("Connect to [%s] Failed::%s\n", szDSN, _status.err_msg);
    return -1;
  }
  _connect.SetAutoCommitOff(_status);
  if (_status.rc)
  {
    printf("Set autocommit = 0 Failed\n");
    return -1;
  }
  return 0;
}

int CDB::Commit()
{
  _connect.Commit(_status);
  if (_status.rc)
  {
    printf("CDB::Commit failed: %s\n", _status.err_msg);
    return -1;
  }
  return 0;
}
int CDB::Rollback()
{
  _connect.Rollback(_status);
  if (_status.rc)
  {
    printf("CDB::Rollback failed: %s\n", _status.err_msg);
    return -1;
  }
  return 0;
}
int CDB::Disconnect()
{
  _connect.Disconnect(_status);
  if (_status.rc)
  {
    printf("CDB::Disconnect failed: %s\n", _status.err_msg);
    return -1;
  }
  return 0;
}
PCmd CDB::Prepare (const char* sql)
{
  PCmd cmd (new CCommand);
  cmd->db(this);
  cmd->ttcmd().Prepare(&_connect, sql, cmd->status());
  if(cmd->status().rc)
  {
    printf("CDB::Prepare sql failed: %s\n", cmd->status().err_msg);
    //todo: return NULL;
  }
  Commit();
  return cmd;
}
}



