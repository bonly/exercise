#ifndef __UTC_HPP__
#define __UTC_HPP__
#include "pre.hpp"
#include <ctime>

/*
 * ������ʱ���๤��
 */
class CUtcTime
{
public:
  CUtcTime(){};
  ~CUtcTime(){};

  static time_t Time(time_t tTime=0);
  static time_t MakeTime(int nYear, int nMonth, int nDay, int nHour=0, int nMinute=0, int nSecond=0);
  static char *ToString(char *szTime, const char *szFormat, time_t tUtcTime);
  static char *Format(char *szTime, const char *szFormat, const struct tm *ptm);
  static int  IsLeapYear(int nYear);
};

#endif


