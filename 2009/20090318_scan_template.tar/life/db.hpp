/****************************************************************
Author: Bonly
Create Date: 20090217
*****************************************************************/
#ifndef __BONLY_DB_HPP__
#define __BONLY_DB_HPP__

#include <boost/shared_ptr.hpp>
#include <ttclasses/TTInclude.h>
#include <iosfwd>

namespace bonly{
using namespace boost;

class CDB;

class CCommand
{
public:
  template<typename field>
  void setParam(int i, field key)
  {
    _ttcmd.setParam(i,key);
  }
  template<typename field>
  void setParam(int cno, field* binP, int len)
  {_ttcmd.setParam(cno,binP,len);}

  template<typename field>
  void getColumnNullable(int i, field value)
  {
    _ttcmd.getColumnNullable(i,value);
  }
  void getColumnNullable(int cno, void** binPP, int* lenP)
  {_ttcmd.getColumnNullable(cno,binPP,lenP);}

  int  Execute();
  int  FetchNext();
  int  Close();
  int  Drop();
  int  RePrepare();

  TTStatus& status(){return _status;}
  TTCmd&    ttcmd(){return _ttcmd;}
  void      db(CDB* d){_db=d;}
private:
  TTCmd      _ttcmd;
  TTStatus   _status;
  CDB*       _db;
};

typedef shared_ptr<CCommand> PCmd;

class CDB
{
public:
  CDB (){}
  CDB (const char* szDSN){Connect(szDSN);}
  int  Connect(const char* szDSN);
  int  Commit();
  int  Rollback();
  int  Disconnect();
  bool isConnected(){return _connect.isConnected();}
  PCmd Prepare (const char* sql);

  void disableLogging();
#ifndef WIN32
  static void Log(ofstream& log_file,
               TTLog::TTLOG_LEVEL level=TTLog::TTLOG_WARN);
  void Debug(const char* logfile,
               TTLog::TTLOG_LEVEL level=TTLog::TTLOG_WARN);
#endif
  //TTLOG_NIL
  //TTLOG_FATAL_ERR
  //TTLOG_ERR
  //TTLOG_WARN
  //TTLOG_INFO
  //TTLOG_DEBUG


  TTConnection& Connect(){return _connect;}
private:
  TTConnection _connect;
  TTStatus     _status;
#ifndef WIN32
  ofstream     _log_file;
#endif
};
}
#endif // __BONLY_DB_HPP__


