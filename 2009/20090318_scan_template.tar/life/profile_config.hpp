/*
 * profile_config.hpp
 *
 *  Created on: 2009-4-10
 *      Author: Bonly
 */

#ifndef __PROFILE_CONFIG_H__
#define __PROFILE_CONFIG_H__
#include "pre.hpp"

class Config
{
  public:
    int parse(int argc=0, char* argv[]=0);
    static Config& instance();
    int count(const char* key){return (*_cfg).count(key);}
    void help();

    template<typename RET>
    RET get(const char* key){return (*_cfg)[key].as<RET>();}

  private:
    shared_ptr<program_options::variables_map>         _cfg;
    program_options::options_description               _desc_cfg;
    int argc;char** argv;
    int clear();

  public:
    static Config* _config;
};

#endif //__PROFILE_CONFIG_H__


