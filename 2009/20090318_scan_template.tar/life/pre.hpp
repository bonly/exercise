#ifndef __PRE_HPP__
#define __PRE_HPP__

#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
using namespace boost;
#include <boost/program_options.hpp>
namespace op=boost::program_options;


#include <string>
using namespace std;


#endif  //__PRE_HPP__
