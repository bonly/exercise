#include "application.hpp"

int Scan::run()
{
  while(true)
  {
    cerr << "Scan running\n";
    sleep(2);
  }
  return 0;
}

int 
Application::create_jobs()
{
  for(int i=0; i<3; ++i)
    _tscan.create_thread (bind(&Application::run_job,ref(*this)));
  return 0;
}  

int 
Application::run_job()
{
  //while(true)//ɱ�˺��Զ�����
  {
    pid_t pid;
    if((pid=vfork())==0)
    {
       execlp("process","process",(char*)NULL);
       perror("start child process");
       return -1;
    }
    waitpid(pid,NULL,NULL);
  }
  return 0;
}  

int
Application::run()
{
  _tscan.create_thread (bind(&Scan::run,ref(_scan)));
  create_jobs();
  _tscan.join_all();
  return 0;
}

int
main (int argc, char* argv[])
{
 Application app;
 //app.init()
 app.run();
 return 0;
}

