#ifndef __CBE_PACK__
#define __CBE_PACK__

#include <stdio.h>
#include <stdarg.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <string>
#include <assert.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
using std::string;

#define MAX_LINE 10000
//-----------------------------------------------------------------------------
class CBE_Pack
{
   public:
      CBE_Pack() :
         file(0), os_stream(NULL), line(0), file_count(0), max_line(MAX_LINE),
         buf_size(0)
   {
      memset(name, 0, PATH_MAX);
      memset(&date, 0, sizeof(date));
      memset(prefix, 0, sizeof(prefix));
      memset(fulldir, 0, sizeof(fulldir));
   }

      ~CBE_Pack()
      {
         if (os_stream != NULL)
         {
            fclose(os_stream);
            char name2[PATH_MAX] =
            { 0 };
            snprintf(name2, PATH_MAX, "%s.tmp", name);

            rename(name2, name);
         }
      }

   public:
      int setDir(const char *dir);
      void setFileNameHead(const char *nm);
      FILE *fileOpen();
      FILE *fileOpen(const char *name);
      void fileOnlyClose();
      void fileClose(bool bRename);

      size_t output(const unsigned char *data, const int len);

      void flush()
      {
         if (os_stream != NULL)
         {
            fflush(os_stream);
         }
      }

      void setFileSize(unsigned int size)
      {
         assert(size>0);
         if (size > 0)
            max_line = size;
      }

      void setBufSize(unsigned int size)
      {
         assert(size>0);
         if (size > 0)
            buf_size = size;
      }

      bool checkPath(const char *path);
   private:
      const char* file;

      FILE *os_stream;

      unsigned int line; 
      unsigned int file_count; 
      char name[PATH_MAX];
      char prefix[128];
      char fulldir[PATH_MAX];
      struct tm date;

      unsigned int buf_size; // setvbuf size
      unsigned int max_line; // max line count before seplit file, for line
};

#endif //__CBE_PACK__

