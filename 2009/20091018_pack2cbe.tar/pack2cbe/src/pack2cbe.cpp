//============================================================================
// Name        : pack2cbe.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <arpa/inet.h>
#include <cstdlib>
#include <cassert>
#include <iostream>
#include <fstream>
#include <string>
#include <errno.h>
using namespace std;

#include "r5log.h"
#include "r5api.h"
#include "DictionaryManager.h"
#include "DiamUtil.h"
#include "tools.h"
#include "pack2cbe.hpp"
#include "cbe_pack.h"
#include "avp_code.h"

#define SUNRISE_CMDHEADER_LEN 20
typedef unsigned int OCP_UINT32;

CBE_Conv g_conv;
R5_Log g_r5_log;
CBE_Pack g_pack;
struct _stConf g_conf;
int g_deamon = 1;
int g_sockfd = 0;
int g_exit = 0;

char addTmp[8], getTmp[8];
int addLen = 0, getLen = 0;

char g_confFile[256] = { 0 };
char *g_path;
char *g_line_path;
char *g_ifile;
char *g_ofile;
char *g_ifile_bak;
char *g_ofile_tmp;

extern int scandir();
extern int alphasort();

int main(int argc, char* argv[])
{
  if (ReadArg(argc, argv) != RE_SUCCESS)
  {
    //LOG_WARN("Parameter error, program exit.\n");
    return -1;
  }

  if (!LoadConfig())
  {
    LOG_WARN("LoadConfig error, program exit.\n");
    return -1;
  }

  while (true)
  {
    processLoop();
  }
  return 0;
}

namespace CS
{
  int ParseDiameter(const char* buff, const int nLen)
  {
    int result = 1; //返回为值1,是不需要输出到文件的,只有为0才写到文件中

    //解释DCC对象
    SunriseOCP dcc((char*) buff, nLen, nLen);
    if (!dcc || dcc.error() != 0)
    {
      return RE_FAILED;
    }
    string tmpbuf;
    dcc.dump(tmpbuf);
    clog << tmpbuf << endl;

    //取顶层项
    AVPGroup *tg = dcc.getTopmostGroup();
    if (tg == NULL)
      return RE_FAILED;

    int cmdCode = dcc.cmdHeader.cmdCode;
    int reqFlag = dcc.cmdHeader.reqFlag; //1:请求包 0:应答包
    //检查消息类型
    if (reqFlag == 0)
      return 1; //不记录应答包

    switch (cmdCode)
    {
      case CCR_CMD_CODE:
      {
        OCP_UINT32 itmp = 0;
        OCP_UINT64 ltmp = 0;
        char ctmp[255] = { 0 };
        int request_type = 1; //请求类型,1表示初始包,2表示更新包,3表示终止包,4表示事件包
        GETAVP(tg, AVPCODE_CC_REQUEST_TYPE, request_type, 0);

        strncpy(g_conv.CBEFileType, "01", sizeof(g_conv.CBEFileType)); //CBE格式类型:固定01
        //strncpy(FieldId) //文件Id,空

        //取用户子项
        AVPGroup *subscription_id = 0;
        tg->getGroup(AVPCODE_SUBSCRIPTION_ID, subscription_id, 0);
        if (subscription_id != NULL)//计费主号码
          GETAVPSTR(subscription_id, AVPCODE_SUBSCRIPTION_ID_DATA, g_conv.MsisdnA, sizeof(g_conv.MsisdnA),0);

        //通话时间:utc转换为字符串
        OCP_UINT32 stime = 0;
        if (readAVP(tg, AVPCODE_EVENT_TIMESTAMP, stime, 0) == 0)
          CTimeUtil::ToString(g_conv.StartTime, "%Y%m%d%H%M%S", stime);

        AVPGroup *Used_Service_Unit = 0;
        tg->getGroup(AVPCODE_USED_SERVICE_UNIT, Used_Service_Unit, 0);
        if (Used_Service_Unit != NULL)
        {
          //通话时长,I包写空
          if (request_type == 1)
            strcpy(g_conv.Usage, "");
          else
          {
            //todo:检查以下两个返回值或异常
            readAVP(Used_Service_Unit, AVPCODE_CC_TIME, itmp, 0);
            snprintf(g_conv.Usage, sizeof(g_conv.Usage), "%d", itmp);
          }
        }

        //strncpy(g_conv.NetType) //未定
        //strncpy(g_conv.MultiCall) //未定
        AVPGroup *Service_Information = 0;
        AVPGroup *In_Information = 0;
        tg->getGroup(AVPCODE_SERVICE_INFORMATION, Service_Information, 0);
        if (Service_Information != NULL)
        {
          Service_Information->getGroup(AVPCODE_IN_INFORMATION, In_Information,
                0);
        }
        if (Service_Information != NULL && In_Information != NULL)
        {
          //话单呼叫类型
          readAVP(In_Information, AVPCODE_CHARGE_FLOW_TYPE, itmp, 0);
          snprintf(g_conv.CallType, sizeof(g_conv.CallType), "%d", itmp);

          //计费方IMSI号
          GETAVPSTR(In_Information,AVPCODE_IMSI,g_conv.IMSI,sizeof(g_conv.IMSI),0);

          //主叫号码
          GETAVPSTR(In_Information,AVPCODE_CALLING_PARTY_NUMBER,g_conv.Calling_Party_Number,sizeof(g_conv.Calling_Party_Number),0);

          //对方号码//被叫号码
          GETAVPSTR(In_Information,AVPCODE_CALLED_PARTY_NUMBER,g_conv.Called_Party_Number,sizeof(g_conv.Called_Party_Number),0);
          //GETAVPSTR(In_Information,AVPCODE_CALLED_PARTY_NUMBER,g_conv.MsisdnB,sizeof(g_conv.MsisdnB),0);
          strcpy(g_conv.MsisdnB, g_conv.Called_Party_Number);

          //第三方号码
          GETAVPSTR(In_Information,AVPCODE_REDIRECTING_PARTY_ID,g_conv.MsisdnC,sizeof(g_conv.MsisdnC),0);

          //计费方IMEI号
          if (strcmp(g_conv.MsisdnA, g_conv.Calling_Party_Number) == 0)
          {
            GETAVPSTR(In_Information,AVPCODE_CALLING_IMEI,g_conv.IMEI,sizeof(g_conv.IMEI),0);
          }
          else
          {
            GETAVPSTR(In_Information,AVPCODE_CALLED_IMEI,g_conv.IMEI,sizeof(g_conv.IMEI),0);
          }

          //计费方?的位置小区代码 及 蜂窝号/基站代码
          GETAVPSTR(In_Information,AVPCODE_CALLING_CELLID_OR_SAI,ctmp,255,0);
          int len = strlen(ctmp);
          if (len >= 15) //LAC-id与cellid在同一个字段内
          {
            strncpy(g_conv.CallingCellId, ctmp + (len - 5), 5); //最后5位是cellid
            strncpy(g_conv.CallingLAC, ctmp + (len - 15), 10); //最后5位前的10位是lac
          }
          else
          {
            strncpy(g_conv.CallingCellId, ctmp, len);
            GETAVPSTR(In_Information,AVPCODE_CALLING_LAI,g_conv.CallingLAC,10,0);
          }

          //对方的位置小区代码 及 蜂窝号/基站代码
          GETAVPSTR(In_Information,AVPCODE_CALLED_CELLID_OR_SAI,ctmp,255,0);
          len = strlen(ctmp);
          if (len >= 15) //LAC-id与cellid在同一个字段内
          {
            strncpy(g_conv.CalledCellId, ctmp + (len - 5), 5); //最后5位是cellid
            strncpy(g_conv.CalledLAC, ctmp + (len - 15), 10); //最后5位前的10位是lac
          }
          else
          {
            strncpy(g_conv.CalledCellId, ctmp, len);
            GETAVPSTR(In_Information,AVPCODE_CALLED_LAI,g_conv.CalledLAC,10,0);
          }
        }

        //SessionID
        GETAVPSTR(tg, AVPCODE_SESSION_ID, g_conv.SessionId, sizeof(g_conv.SessionId), 0);

        //中间话单序号SessionSi
        if (request_type == 3)//T包
          strcpy(g_conv.SessionSi, "FFF");
        else
        {
          readAVP(tg, AVPCODE_CC_REQUEST_NUMBER, ltmp, 0);
          snprintf(g_conv.SessionSi, sizeof(g_conv.SessionSi), "%00ld", ltmp);
        }

        //话单类型标志
        strncpy(g_conv.SessionType, "T", sizeof(g_conv.SessionType));
        //真实号码  待定
        //strncpy(g_conv.RealMsisdn)

        //拨号类型/来电类型 0:长号呼叫  1:短号呼叫
        if (strlen(g_conv.Called_Party_Number) <= 4)
          strcpy(g_conv.VpnCallType, "1");
        else
          strcpy(g_conv.VpnCallType, "0");

        //FCI标记:空值
        strncpy(g_conv.FCI, "", sizeof(g_conv.FCI));
        //动态漫游号:空值
        strncpy(g_conv.MSRN, "", sizeof(g_conv.MSRN));

      }
        return 0;
    }
    return result;
  }

  int ReadDiameterMsg(FILE* ifile, char *buff, int &nLen)
  {
    assert(ifile != NULL && buff != NULL);
    int nRead;
    nRead = fread(buff, 1, SUNRISE_CMDHEADER_LEN, ifile);
    if (nRead < 0)
    {
      return nRead;
    }

    if (nRead != SUNRISE_CMDHEADER_LEN)
    {
      return RE_FAILED;
    }

    char *pTmp = buff;

    int nMsgLen = ntohl(*((OCP_UINT32*) (pTmp))) & 0x00ffffff;

    if (nMsgLen < SUNRISE_CMDHEADER_LEN || nMsgLen > 10000)
    {
      return RE_FAILED;
    }

    nRead = fread(buff + SUNRISE_CMDHEADER_LEN, 1, nMsgLen
          - SUNRISE_CMDHEADER_LEN, ifile);
    if (nRead < 0)
    {
      return nRead;
    }

    if (nRead != nMsgLen - SUNRISE_CMDHEADER_LEN)
    {
      return RE_FAILED;
    }

    nLen = nMsgLen;

    return RE_SUCCESS;
  }
} //end of CS

int ReadArg(int argc, char **argv)
{
  int optch;
  extern char *optarg;
  const char optstring[] = "hve:t:c:M:s:";

  while ((optch = getopt(argc, argv, optstring)) != -1)
  {
    switch (optch)
    {
      case 'v': //打印版本号
        //ShowVersion();
        return RE_FAILED;

      case 'h': //打印帮助信息
        //usage(argv[0]);
        return RE_FAILED;

      case 'e': //后台方式启动
        //g_deamon = 0;
        break;

      case 'c': //配置文件名
        strcpy(g_confFile, optarg);
        break;

      case 'M':
        strcpy(g_conf.sOperationType, optarg);
        break;

      case 's':
      case 'S':
        g_sockfd = atoi(optarg);

      default:
        break;
    }
  }

  if (strlen(g_confFile) <= 0)
  {
    LOG_ERROR("Param Error. No config file.\n");
    usage(argv[0]);
    return RE_FAILED;
  }

  if (strlen(g_conf.sOperationType) <= 0)
  {
    LOG_ERROR("Param Error. No Operation Type.\n");
    usage(argv[0]);
    return RE_FAILED;
  }

  if (strcmp(g_conf.sOperationType, "CS") != 0 && strcmp(g_conf.sOperationType,
        "VASP") != 0 && strcmp(g_conf.sOperationType, "VAC") != 0 && strcmp(
        g_conf.sOperationType, "SMS") != 0 && strcmp(g_conf.sOperationType,
        "PS") != 0)
  {
    LOG_ERROR("Param Error. %s is not a allowed Operation Type.\n");
    //usage(argv[0]);
    return RE_FAILED;
  }

  return RE_SUCCESS;
}

void usage(char* sProgName)
{
  printf("usage : %s [-c configure filename] [-M type][-e] [-h] [-v]\n",
        sProgName);
  printf("        -h show help, optional\n");
  printf("        -v show version, optional\n");
  printf("        -e do not start the process as a deamon, optional\n");
  printf("        -c configure filename, Must\n");
  printf("        -M bussiness type, Must\n");
  printf("example:\n");
  printf("%s -c ../etc/%s.conf -M CS\n", sProgName, sProgName);
}

bool LoadConfig(bool isReload)
{

  IniConfig config;
  if (config.open(g_confFile) < 0)
  {
    LOG_ERROR("Error: Open %s failed:%s\n", g_confFile, strerror(errno));
    return false;
  }

  const char comm[] = "COMM";

  //日志路径
  char* sLogDir = (char*) config.getValue(comm, "LOG_PATH");
  if (sLogDir)
  {
    if (0 != path_string(sLogDir, g_conf.sLogPath, sizeof(g_conf.sLogPath)))
    {
      LOG_ERROR("read %s->LOG_PATH item failed, configure file: '%s', LOG_PATH: '%s'.\n",
            comm, g_confFile, sLogDir);
      return false;
    }
  }
  else
  {
    LOG_ERROR("Error: Read %s->LOG_PATH item failed, configure file:%s.\n",
          comm, g_confFile);
    return false;
  }

  //日志文件头
  char* sLogHead = (char*) config.getValue(comm, "LOG_HEADER");
  if (sLogHead)
  {
    strcpy(g_conf.sLogHead, sLogHead);
  }
  else
  {
    strcpy(g_conf.sLogHead, "offline_cf");
  }

  //日志文件级别
  char* file_l = (char*) config.getValue(comm, "LOG_LEVEL_FILE");
  if (file_l)
  {
    g_conf.iLogLevel = atoi(file_l);
  }

  //终端输出日志级别
  char* term_l = (char*) config.getValue(comm, "LOG_LEVEL_TERM");
  if (term_l)
  {
    g_conf.iTermLevel = atoi(term_l);
  }

  //初始化日志
  INIT_LOG(g_conf.sLogPath, g_conf.sLogHead,
        g_conf.iLogLevel, g_conf.iTermLevel);

  //字典文件
  const char* szDictionary = config.getValue(comm, "DICT_FILE");
  if (szDictionary == 0)
  {
    LOG_ERROR("Get the path of DICT_FILE failed!\n");
    return false;
  }
  else
  {
    strcpy(g_conf.sDictionary, szDictionary);
  }

  //初始化字典
  if (DictionaryManager::instance()->init(g_conf.sDictionary) < 0)
  {
    LOG_ERROR("Init Dictionary failed!\n");
    return RE_FAILED;
  }

  //OriginHost
  const char* sHost = config.getValue(comm, "HOST");
  if (sHost != NULL)
  {
    strcpy(g_conf.sOriginHost, sHost);
  }
  else
  {
    LOG_ERROR("read %s->HOST item failed\n", comm);
    return false;
  }

  //OriginRealm
  const char* sRealm = config.getValue(comm, "REALM");
  if (sRealm != NULL)
  {
    strcpy(g_conf.sOriginRealm, sRealm);
  }
  else
  {
    LOG_ERROR("read %s->REALM item failed\n", comm);
    return false;
  }

  //CBE输出目录
  const char* szCBEpath = config.getValue(comm, "CBE_DIR");
  if (szCBEpath == 0)
  {
    LOG_ERROR("Get the path of CBE failed!\n");
    return false;
  }
  g_pack.setDir(szCBEpath);

  //CBE输出文件前缀
  g_pack.setFileNameHead("CBE");

  if (strcmp(g_conf.sOperationType, "PS") == 0)
  {
    g_conv.read_pack = CS::ReadDiameterMsg;
    g_conv.parse_pack = CS::ParseDiameter;
  }
  else
  {
    cerr << "not support now\n";
    exit(1);
  }

  //扫描CBE文件目录
  const char* path = config.getValue(comm, "SCAN_DIR");
  if (path != NULL)
  {
    strcpy(g_conf.sScanPath, path);
    g_path = g_conf.sScanPath;
  }
  else
  {
    LOG_ERROR("read %s->SCAN_DIR item failed\n", comm);
    return false;
  }

  //CBE文件输出目录
  const char* opath = config.getValue(comm, "CBE_LINE_DIR");
  if (opath != NULL)
  {
    strcpy(g_conf.sLinePath, opath);
    g_line_path = g_conf.sLinePath;
  }
  else
  {
    LOG_ERROR("read %s->SCAN_DIR item failed\n", comm);
    return false;
  }

  //SET_LOG_DIR("./");
  //SET_LOG_NAME_HEAD("READER");


  return true;
}

int set_file(const char* filename)
{
  assert(filename!=0);
  assert(g_path!=0);
  assert(g_line_path!=0);
  assert(g_ifile!=0);
  assert(g_ifile_bak!=0);
  assert(g_ofile!=0);
  assert(g_ofile_tmp!=0);

  char purefile[MAX_PATH_LENGTH] = { 0 };
  snprintf(purefile, strrchr(filename, '.') - filename + 1, "%s", filename);
  sprintf(g_ifile, "%s/%s", g_path, filename);
  sprintf(g_ifile_bak, "%s/%s.bak", g_path, purefile);
  sprintf(g_ofile, "%s/%s.CBE", g_line_path, purefile);
  sprintf(g_ofile_tmp, "%s/%s.tmp", g_path, purefile);

  return 0;
}

int scan_dir(const char *dir, int(*do_file)(const char*), const char *suffix)
{
  assert(dir!=0 && do_file!=0 );
  char name[MAX_PATH_LENGTH] = { 0 };
  struct stat statinfo;
  int file_count = 0;
  int num_entries = 0;
  int i = 0;
  struct dirent **namelist, **list;

  if ((num_entries = scandir(dir, &namelist, NULL, alphasort)) < 0)
  {
    fprintf(stderr, "Unexpected err when scanning dir: %s", dir);
    return -1;
  }
  if (num_entries)
  {
    for (i = 0, list = namelist; i < num_entries; ++i)
    {
      if (strcmp((*list)->d_name, ".") == 0 || strcmp((*list)->d_name, "..")
            == 0)
      {
        free(*list);
        list++;
        continue;
      }

      memset(name, 0, MAX_PATH_LENGTH);

      if (strlen(dir) + strlen((*list)->d_name) + 2 > MAX_PATH_LENGTH)
      {
        fprintf(stderr, "file's full name %s/%s too long\n", dir,
              (*list)->d_name);
        free(*list);
        list++;
        continue;
      }
      sprintf(name, "%s/%s", dir, (*list)->d_name);
      if (stat(name, &statinfo) == -1)
      {
        fprintf(stderr, "stat file %s/%s fail\n", dir, (*list)->d_name);
        free(*list);
        list++;
        continue;
      }
      if (S_ISDIR(statinfo.st_mode)) //是目录,跳过
      {
        free(*list);
        list++;
        continue;
      }

      if (suffix != 0)
      {
        if ((strstr((*list)->d_name, suffix) - (*list)->d_name) != int(strlen(
              (*list)->d_name) - strlen(suffix)))
        {
          free(*list);
          list++;
          continue; //后缀不正确,取下一个文件
        }
      }

      //处理符合条件的文件
      do_file((*list)->d_name);

      ++file_count;
      break;//只取一个文件
    }
  }
  return file_count;
}

int processLoop()
{
  char name[MAX_PATH_LENGTH] = { 0 };
  g_ifile = name;
  char bak_name[MAX_PATH_LENGTH] = { 0 };
  g_ifile_bak = bak_name;
  char oname[MAX_PATH_LENGTH] = { 0 };
  g_ofile = oname;
  char oname_tmp[MAX_PATH_LENGTH] = { 0 };
  g_ofile_tmp = oname_tmp;
  int (*sfile)(const char*) = set_file;
  int get_file = scan_dir(g_path, sfile, ".data");

  if (get_file < 0)
    cerr << "scan err\n";
  if (get_file == 0)
    return 0;

  FILE* ifile = fopen(g_ifile, "r");
  if (ifile == NULL)
    return -1;

  FILE* ofile = fopen(g_ofile_tmp, "w");
  if (ofile == NULL)
    return -1;

  while (!feof(ifile))
  {
    int len = MAX_BUF;
    char buff[MAX_BUF] = { 0 };
    int ret = 0;

    if (RE_FAILED == g_conv.read_pack(ifile, buff, len))
      continue;
    if (RE_FAILED == (ret = g_conv.parse_pack(buff, len)))
    {
      cerr << "Parse err!\n";
      continue;
    }
    if (ret == 0)
      write_cbe(ofile);
  }
  fclose(ifile);
  fclose(ofile);
  rename_file(g_ifile, g_ifile_bak);
  rename_file(g_ofile_tmp, g_ofile);
  return 0;
}

int write_cbe(FILE* ofile)
{
  assert(ofile!=NULL);
  char buff[MAX_BUF] = { 0 };
  sprintf(buff, "%s|%s|%s|" //1
          "%s|%s|%s|" //2
        "%s|%s|%s|" //3
        "%s|%s|%s|" //4
        "%s|%s|%s|" //5
        "%s|%s|%s|" //6
        "%s|%s|%s|" //7
        "%s|%s|%s\n" //8
      , g_conv.CBEFileType, g_conv.FileId, g_conv.MsisdnA, //1
        g_conv.StartTime, g_conv.Usage, g_conv.NetType, //2
        g_conv.MultiCall, g_conv.CallType, g_conv.IMSI, //3
        g_conv.MsisdnB, g_conv.MscId, g_conv.CallingLAC, //4
        g_conv.CallingCellId, g_conv.CalledLAC, g_conv.CalledCellId,//5
        g_conv.MsisdnC, g_conv.IMEI, g_conv.SessionId, //6
        g_conv.SessionSi, g_conv.SessionType, g_conv.RealMsisdn, //7
        g_conv.VpnCallType, g_conv.FCI, g_conv.MSRN //8
  );
  fwrite(buff, 1, strlen(buff), ofile);
  return 0;
}

int rename_file(const char *oldfile, const char *newfile)
{
  assert(oldfile!=0 && newfile!=0);
  ifstream ifile(oldfile);
  ofstream ofile(newfile);
  char c = 0;
  while (ifile.get(c).good())
  {
    ofile << c;
  }
  ofile.close();
  ifile.close();
  remove(oldfile);
  return 0;
}
