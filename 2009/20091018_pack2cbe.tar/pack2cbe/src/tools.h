#ifndef _TOOLS_H_
#define _TOOLS_H_

#include "r5api.h"

#define __WM_LINUX

enum {RE_FAILED=-1,RE_SUCCESS=0};
//#define RE_SUCCESS 0
//#define RE_FAILED  -1

#define MAX_MSG_LEN 1024
#define SUNRISE_CMDHEADER_LEN 20

#define SMPP_HEAD_LENGTH 16


#define LOG_DEBUG(...)\
   R5_DEBUG((&g_r5_log),("[off_cf] " __VA_ARGS__))
#define LOG_INFO(...)\
   R5_INFO((&g_r5_log),("[off_cf] " __VA_ARGS__))
#define LOG_ERROR(...)\
   R5_ERROR((&g_r5_log),("[off_cf] " __VA_ARGS__))
#define LOG_WARN(...)\
   R5_WARN((&g_r5_log),("[off_cf] " __VA_ARGS__))
#define LOG_TRACE(...)\
   R5_TRACE((&g_r5_log),("[off_cf] " __VA_ARGS__))


#define INIT_LOG(log_path, log_header, file_level, term_level)\
   if(SET_LOG_DIR(log_path) < 0)\
{\
   printf("log path can not access:%s\n", log_path);\
   exit(-1);\
}\
SET_LOG_LEVEL(file_level, term_level);\
SET_LOG_NAME_HEAD(log_header);


#ifdef __WM_HP_UNIX
typedef int SOCKETLEN_T;
#endif

#ifdef __WM_LINUX
#include <sys/socket.h>
typedef socklen_t SOCKETLEN_T;
#endif //__WM_LINUX


#define SMPP_AUTH_ACC	        0X01000001 /** �Ʒ���Ϣ,SMPP+*/
#define SMPP_AUTH_ACC_RESP		0X81000001 /** �Ʒ���ϢӦ��,SMPP+*/
#define SMPP_BIND_RECEIVER      0X00000001 /** bind_receiver command id. */


struct SmppHead
{
   unsigned int  m_commandLength;
   unsigned int  m_commandId;
   unsigned int  m_commandStatus;
   unsigned int  m_sequenceNumber;

};


int MyAccept(int servfd, struct sockaddr *addr, SOCKETLEN_T *addrlen);

int MyRead(int clifd, char *buff, int nTotalLen, int nTimeOut);

int MyWrite(int fd, const void *buf, size_t count);

int ReadPackage(int sockfd, char *buff, int &nLen, int nTimeOut,
                const int HeadLen, const int pLenBegin, const int LenLen);

int ReadSmppMsg(int sockfd, char *buff, int &nLen, int nTimeOut);

int ReadDiameterMsg(int sockfd, char *buff, int &nLen, int nTimeOut);

int UTC2String(time_t time, char *buf, int size);

int UTC2Date(time_t time, char *buf, int size);

static int proc_env(char* env, char* buff, size_t len);


int path_string(const char* envpath, char* path, size_t pathlen);


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SECONDS_1900_1970 2208988800L

/*
 * 基本的时间类工具
 */
class CTimeUtil
{
public:
   CTimeUtil(){};
   ~CTimeUtil(){};

    static time_t Time();
   static time_t MakeTime(int nYear, int nMonth, int nDay, int nHour=0, int nMinute=0, int nSecond=0);

    static char *ToString(char *szTime, const char *szFormat, time_t tSecond);
    static char *Format(char *szTime, const char *szFormat, const struct tm *ptm);

   static int  IsLeapYear(int nYear);
};



/*
 * UTC Time Class
 * Seconds elapsed since 00:00:00 on January 1, 1900
 * Attention: not 1970
 */

class CUtcTime
{
public:
   CUtcTime(){};
   ~CUtcTime(){};

    // 获取系统UTC时间
    static time_t UtcTime();
    static time_t ToUtcTime(time_t tLocalTime);
    static time_t ToLocalTime(time_t tUtcTime);

};

#endif

