#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <unistd.h>

#include "com_date.h"
#include "sysinfo.h"

#include "tools.h"

extern int g_exit;

int MyAccept(int servfd, struct sockaddr *addr, SOCKETLEN_T *addrlen)
{
  while (true)
  {
    int clifd;
    clifd = accept(servfd, addr, addrlen);
    if (clifd < 0)
    {
      if (errno == EINTR)//���ź��ж�
      {
        int nRet;
        //if((nRet = Signal::HandleSignal()) < 0)
        //    return nRet;

        //acceptû���Զ�����������
        //��Ҫ��ʽ��������
        break;
      }
      else//�������
      {
        return RE_FAILED;
      }
    }
    else
    {
      return clifd;
    }
  }

  return RE_FAILED;
}

int MyRead(int clifd, char *buff, int nTotalLen, int nTimeOut)
{
  int nGetLen = 0;
  int nRead;

  while (nGetLen < nTotalLen)
  {
    if (nTimeOut != 0)
    {
      alarm(nTimeOut);
    }

    //read���ź��жϺ���Զ�������
    //Ŀǰ����SIGTERM��SIGALARM�ź���������
    nRead = recv(clifd, buff + nGetLen, nTotalLen - nGetLen, 0);
    alarm(0);
    if (nRead == 0)
    {
      return RE_FAILED;
    }
    else if (nRead < 0)
    {
      if (errno == EINTR)//���ź��ж�
      {
        //int nRet;
        if (g_exit)
          return nRead;

        continue;
        //break;
      }
      else//�������
      {
        return RE_FAILED;
      }
    }
    else
    {
      nGetLen += nRead;
    }

  }

  return nGetLen;
}

int MyWrite(int fd, const void *buf, size_t count)
{
  //if(g_WriteTimeOut != 0)
  //{
  //    alarm(g_WriteTimeOut);
  //}

  //write���ź��жϺ���Զ�������
  //Ŀǰ����SIGTERM��SIGALARM�ź���������
  int nWrite = write(fd, buf, count);
  //alarm(0);
  if (nWrite < 0)
  {
    if (errno == EINTR)//���ź��ж�
    {
      int nRet;
      //if((nRet = Signal::HandleSignal()) < 0)
      //    return nRet;
    }
    else//�������
    {
      return RE_FAILED;
    }
  }

  return RE_SUCCESS;
}

int ReadSmppMsg(int sockfd, char *buff, int &nLen, int nTimeOut)
{
  //���������Ϣͷ
  int nRead;
  nRead = MyRead(sockfd, buff, SMPP_HEAD_LENGTH, nTimeOut);
  if (nRead < 0)
  {
    LOG_DEBUG("RECV SMPP msg Failed [file:%s line:%d] Err = %d \n",__FILE__, __LINE__, nRead);

    return RE_FAILED;
  }
  if (nRead != SMPP_HEAD_LENGTH)
  {
    return RE_FAILED;
  }

  //��ȡ��Ϣͷ���е���Ϣ��
  SmppHead* pHeader = (SmppHead*) buff;

  int nMsgLen = ntohl(pHeader->m_commandLength);

  //����ڰ�ͷ���ȣ�ֱ�ӷ���(�����)
  if (SMPP_HEAD_LENGTH == nMsgLen)
  {
    return RE_SUCCESS;
  }

  //�����Ϣ�����Ƿ�Ϸ�
  if (nMsgLen < SMPP_HEAD_LENGTH || nMsgLen > 10000)
  {
    return RE_FAILED;
  }

  //�������ȡ��Ϣ��
  nRead = MyRead(sockfd, buff + SMPP_HEAD_LENGTH, nMsgLen - SMPP_HEAD_LENGTH,
        nTimeOut);
  if (nRead < 0)
  {
    LOG_DEBUG("RECV SMPP msg Failed [file:%s line:$d]\n",__FILE__, __LINE__);
    return RE_FAILED;
  }

  if (nRead != nMsgLen - SMPP_HEAD_LENGTH)
  {
    return RE_FAILED;
  }

  nLen = nMsgLen;

  return RE_SUCCESS;
}

/*================================
 �������ȡһ������İ�,
 return int : �ɹ�(RE_SUCCESS)��ʧ��(RE_FAILED)
 param(
 sockfd:�����ӵ�socket���
 buff:���ڴ��ȡ�õ���ݰ�
 nLen:����buff�Ĵ�С,�������յõ��İ�
 nTimeOut:��ʱ����
 HeadLen:��ͷ�ĳ���
 pLenBegin:��ͷ�б�ʾȫ��ȵĿ�ʼλ��
 LenLen:��ʾ��ȵ���ݳ�
 )
 =================================*/
int ReadPackage(int sockfd, char *buff, int &nLen, int nTimeOut,
      const int HeadLen, const int pLenBegin, const int LenLen)
{
  memset(buff, 0, nLen);
  //���������Ϣͷ
  int nRead = MyRead(sockfd, buff, HeadLen, nTimeOut);
  if (nRead < 0)
    return nRead;
  if (nRead != HeadLen)
    return RE_FAILED;

  char *pTmp = buff;
  //��ȡ��Ϣͷ���е���Ϣ����
  int nMsgLen = ntohl(*((OCP_UINT32*) (pTmp + pLenBegin))) & 0x00ffffff;

  //�����Ϣ�����Ƿ�Ϸ�
  if (nMsgLen < HeadLen || nMsgLen > nLen)
    return RE_FAILED;

  //�������ȡ��Ϣ��
  nRead = MyRead(sockfd, buff + HeadLen, nMsgLen - HeadLen, nTimeOut);
  if (nRead < 0)
    return nRead;
  if (nRead != nMsgLen - HeadLen)
    return RE_FAILED;
  nLen = nMsgLen;
  return RE_SUCCESS;
}

int ReadDiameterMsg(int sockfd, char *buff, int &nLen, int nTimeOut)
{
  /* ���������Ϣͷ */
  int nRead;
  nRead = MyRead(sockfd, buff, SUNRISE_CMDHEADER_LEN, nTimeOut);
  if (nRead < 0)
  {
    return nRead;
  }

  if (nRead != SUNRISE_CMDHEADER_LEN)
  {
    return RE_FAILED;
  }

  char *pTmp = buff;

  /* ��ȡ��Ϣͷ���е���Ϣ���� */
  int nMsgLen = ntohl(*((OCP_UINT32*) (pTmp))) & 0x00ffffff;

  /* �����Ϣ�����Ƿ�Ϸ� */
  if (nMsgLen < SUNRISE_CMDHEADER_LEN || nMsgLen > 10000)
  {
    return RE_FAILED;
  }

  /* �������ȡ��Ϣ�� */
  nRead = MyRead(sockfd, buff + SUNRISE_CMDHEADER_LEN, nMsgLen
        - SUNRISE_CMDHEADER_LEN, nTimeOut);
  if (nRead < 0)
  {
    return nRead;
  }

  if (nRead != nMsgLen - SUNRISE_CMDHEADER_LEN)
  {
    return RE_FAILED;
  }

  nLen = nMsgLen;

  return RE_SUCCESS;
}

int UTC2String(time_t time, char *buf, int size)
{
  if (time > CONV_1900_1970)
  {
    time -= CONV_1900_1970;
  }
  struct tm timep;
  //timep = localtime((const time_t *)&time);

  localtime_r(&time, &timep);

  snprintf(buf, size, "%04d%02d%02d%02d%02d%02d", timep.tm_year + 1900,
        timep.tm_mon + 1, timep.tm_mday, timep.tm_hour, timep.tm_min,
        timep.tm_sec);

  return 0;
}

int UTC2Date(time_t time, char *buf, int size)
{
  if (time > CONV_1900_1970)
  {
    time -= CONV_1900_1970;
  }
  struct tm timep;

  localtime_r(&time, &timep);

  snprintf(buf, size, "%04d%02d%02d", timep.tm_year + 1900, timep.tm_mon + 1,
        timep.tm_mday);

  return 0;
}

static int proc_env(char* env, char* buff, size_t len)
{
  char* tmpenv = env;
  size_t envlen = strlen(env);

  if (0 == envlen) /* �������Ϊ0 */
  {
    return -1;
  }

  if (1 < envlen) /* ���?���� */
  {
    if ('{' == env[0])
    {
      if ('}' != env[envlen - 1]) /* �����Ų��Գ� */
      {
        return -1;
      }
    }
    else if ('}' == env[envlen - 1]) /* �����Ų��Գ� */
    {
      return -1;
    }

    /* ȥ�������� */
    if ('}' == env[envlen - 1])
    {
      if (0 >= (envlen - 2))
      {
        return -1;
      }

      env[envlen - 1] = '\0';
      tmpenv = env + 1;
    }
  }

  const char* value = getenv(tmpenv);

  if (NULL == value) /* �޷�ȡ�û���������ֵ */
  {
    return -1;
  }

  size_t valuelen = strlen(value);

  if (valuelen > len) /* ������Ȳ��� */
  {
    return -2;
  }

  memcpy(buff, value, valuelen);
  return valuelen;
}

int path_string(const char* envpath, char* path, size_t pathlen)
{
  char c;
  char env[500];
  int i = 0;
  int retval = 0;
  int envidx = 0;
  int envpos = 0;
  uint32_t pathidx = 0;
  bool read_env = false;

  while ('\0' != (c = envpath[i]))
  {
    switch (c)
    {
      case '$':
        if (read_env) /* �����ǰ�Ļ������� */
        {
          env[envidx] = '\0';
          retval = proc_env(env, &path[pathidx], pathlen - pathidx);

          if (0 < retval)
          {
            pathidx += retval;
          }
          else
          {
            if (-2 == retval)
            {
              return -1;
            }

            return envpos + 1;
          }
        }

        read_env = true; /* ����������ʼ */
        envpos = i;
        envidx = 0;
        break;

      case ' ':
      case '/':
        if (read_env)
        {
          read_env = false; /* �����������������ǰ�Ļ������� */
          env[envidx] = '\0';
          envidx = 0;
          retval = proc_env(env, &path[pathidx], pathlen - pathidx);

          if (0 < retval)
          {
            pathidx += retval;
          }
          else
          {
            if (-2 == retval)
            {
              return -1;
            }

            return envpos + 1;
          }
        }

        if (pathlen <= pathidx) /* ������Ȳ��� */
        {
          return -1;
        }

        path[pathidx] = c;
        ++pathidx;
        break;

      default:
        if (read_env) /* ��ǰ���ڶ��������� */
        {
          env[envidx] = c;
          ++envidx;
        }
        else
        {
          if (pathlen <= pathidx) /* ������Ȳ��� */
          {
            return -1;
          }

          path[pathidx] = c;
          ++pathidx;
        }

        break;
    }

    ++i;
  }

  if (read_env)
  {
    env[envidx] = '\0';
    retval = proc_env(env, &path[pathidx], pathlen - pathidx);

    if (0 < retval)
    {
      pathidx += retval;
    }
    else
    {
      if (-2 == retval)
      {
        return -1;
      }

      return envpos + 1;
    }
  }

  path[pathidx] = '\0';
  return 0;
}

//======================  CTimeUtil Class  ========================
//
/*
 * 获取系统当前时间: 从00:00:00 on January 1, 1970开始的秒数
 */
time_t CTimeUtil::Time()
{
  time_t tTime;
  return time(&tTime);
}

/*
 * 闰年判断
 * 能被4整除但不能被100整除，可是却能被400整除的年是闰年
 * 闰年2月份是29日
 */
int CTimeUtil::IsLeapYear(int nYear)
{
  if (((nYear % 4 == 0) && (nYear % 100 != 0)) || (nYear % 400 == 0))
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

/*
 * 日期格式输出
 */
char *CTimeUtil::Format(char *szTime, const char *szFormat,
      const struct tm *ptm)
{
  char chFmt;
  char *pBuf = szTime;

  while ((chFmt = *szFormat++) != '\0')
  {
    if (chFmt == '%')
    {
      switch (chFmt = *szFormat++)
      {
        case '%':
          *pBuf++ = chFmt;
          break;
        case 'y':
          pBuf += sprintf(pBuf, "%2.2d", ptm->tm_year);
          break;
        case 'Y':
          pBuf += sprintf(pBuf, "%4.4d", ptm->tm_year + 1900);
          break;
        case 'm':
          pBuf += sprintf(pBuf, "%2.2d", ptm->tm_mon + 1);
          break;
        case 'd':
          pBuf += sprintf(pBuf, "%2.2d", ptm->tm_mday);
          break;
        case 'H':
          pBuf += sprintf(pBuf, "%2.2d", ptm->tm_hour);
          break;
        case 'M':
          pBuf += sprintf(pBuf, "%2.2d", ptm->tm_min);
          break;
        case 'S':
          pBuf += sprintf(pBuf, "%2.2d", ptm->tm_sec);
          break;
        default:
          perror("Time Format Error:");
          return NULL;
      }
    }
    else
    {
      *pBuf++ = chFmt;
    }
  } // end of while

  *pBuf = '\0';

  return szTime;
}

/*
 *  second 是指从00:00:00 on January 1, 1970开始的秒数
 */
char *CTimeUtil::ToString(char *szTime, const char *szFormat, time_t second)
{
  second = second - SECONDS_1900_1970;
  struct tm *ptm = localtime(&second);

  return CTimeUtil::Format(szTime, szFormat, ptm);
}

/*
 * 由本地时间构造一个time_t时间: seconds elapsed since 00:00:00 on January 1, 1970
 */
time_t CTimeUtil::MakeTime(int nYear, int nMonth, int nDay, int nHour,
      int nMinute, int nSecond)
{
  struct tm tm;

  tm.tm_year = nYear - 1900;
  tm.tm_mon = nMonth - 1;
  tm.tm_mday = nDay;
  tm.tm_hour = nHour;
  tm.tm_min = nMinute;
  tm.tm_sec = nSecond;
  tm.tm_isdst = 0;
  tm.tm_wday = 0;
  tm.tm_yday = 0;

  return mktime(&tm);
}

//================== CUtcTime Class  =======================
//
/*
 * 获取系统当前时间: 从00:00:00 on January 1, 1900开始的秒数
 */
time_t CUtcTime::UtcTime()
{
  time_t tTime;

  time(&tTime);

  // return tTime - timezone + SECONDS_1900_1970;
  return tTime + SECONDS_1900_1970;
}

/*
 * 把tTime转换成1900年的时间
 */
time_t CUtcTime::ToUtcTime(time_t tLocalTime)
{
  // tzset();
  // return tLocalTime - timezone + SECONDS_1900_1970;
  return tLocalTime + SECONDS_1900_1970;
}

/*
 * 把tTime转换成1970年的时间
 * timezone是个系统变量，负数
 */
time_t CUtcTime::ToLocalTime(time_t tUtcTime)
{
  if (tUtcTime < SECONDS_1900_1970)
    return tUtcTime;

  // tzset();
  // return tUtcTime + timezone - SECONDS_1900_1970;
  return tUtcTime - SECONDS_1900_1970;
}

