/*
 * pack2cbe.hpp
 *
 *  Created on: 2010-7-5
 *      Author: bonly
 */

#ifndef PACK2CBE_HPP_
#define PACK2CBE_HPP_

#define PROGRAM_NAME "pack2cbe"
#define PROGRAM_VERSION "1.0"
#define OPENING_TIME __DATE__
#define TEST_TIME  __DATE__

#define   INT_LEN                            sizeof(OCP_UINT32)
#define   LONG_LEN                           sizeof(OCP_UINT64)
#define   RES     0
#define   REQ     1

#define ADDAVP(pGroup, avpcode, value) \
    addLen = sizeof(value);\
    if(addLen == INT_LEN)\
    {\
       *(OCP_UINT32* )addTmp = htonl(value);\
    }else\
    {\
       *(OCP_UINT64* )addTmp = pGroup->htonl64(value);\
    }\
    if (pGroup->addField(avpcode, (void* )addTmp, addLen) < 0) \
    {\
        LOG_WARN("ERROR: ADDAVP..., avpcode[%d]\n", avpcode);\
        return DIA_ADD_AVP_FAILD; \
    }

#define ADDGROUP(pGroup, avpcode, group) \
    if (pGroup->addGroup(avpcode, group) < 0) \
    {\
        LOG_WARN("ERROR: ADDGROUP..., avpcode[%d]\n", avpcode);\
        group->clear(); \
        return DIA_ADD_AVP_FAILD; \
    }

#define ADDAVPSTR(pGroup, avpcode, value, size) \
    if (pGroup->addField(avpcode, (void* )value, size) < 0) \
    {\
        LOG_WARN("ERROR: ADDAVPSTR..., avpcode[%d]\n", avpcode);\
        return DIA_ADD_AVP_FAILD; \
    }

#define GETAVPSTR(pGroup, avpcode, buffer, size, index) \
    if (pGroup->getField(avpcode, buffer, size, index) < 0) \
    {\
        LOG_WARN("ERROR: GETAVPSTR...missing, avpcode[%d]\n", avpcode);\
        return DIA_GET_AVP_FAILD; \
    }
#define GETAVPSTROPT(pGroup, avpcode, buffer, size, index) \
    if (pGroup->getField(avpcode, (void* )buffer, size, index) < 0) \
    {\
        LOG_WARN("WARN: GETAVPSTROPT...missing, avpcode[%d]\n", avpcode);\
        buffer[0]= '\0';\
    }

// get avp
#define GETAVP(pGroup, avpcode, buffer, index) \
    getLen = sizeof(getTmp);\
    if(pGroup->getField(avpcode, (void* )getTmp, (int& )getLen, index) < 0) \
    {\
        LOG_WARN("ERROR: GETAVP...missing, avpcode[%d]\n", avpcode);\
        return DIA_GET_AVP_FAILD; \
    }\
    else\
    {\
        if(getLen == INT_LEN) \
        {\
            buffer = ntohl((*((OCP_UINT32*)(getTmp)))); \
        }\
        else if(getLen == LONG_LEN) \
        {\
            buffer = pGroup->ntohl64((*((OCP_UINT64*)(getTmp)))); \
        }\
    }

#define GETAVPOPT(pGroup, avpcode, buffer, index) \
    getLen = sizeof(getTmp);\
    if(pGroup->getField(avpcode, (void* )getTmp, getLen, index) < 0) \
    {\
        LOG_WARN("WARN: GETAVPOPT...missing, avpcode[%d]\n", avpcode);\
        buffer = 0;\
    }\
    else \
    {\
        if(getLen == INT_LEN) \
        {\
            buffer = ntohl((*((OCP_UINT32*)(getTmp)))); \
        }\
        else if(getLen == LONG_LEN) \
        {\
            buffer = pGroup->ntohl64((*((OCP_UINT64*)(getTmp)))); \
        }\
    }

template<class FT>
int readAVP(AVPGroup* pGroup, long nAVPCode, FT &field, int index)
{
  return pGroup->getField(nAVPCode, field);
}

enum
{
  MAX_PATH_LENGTH = 255,
  MAX_BUF = 1024,
  DIA_SUCCESS_CODE = 2001,
  DIA_ADD_AVP_FAILD = -4002002, //添加AVP失败
  DIA_GET_AVP_FAILD = -5005002
//获取AVP失败
};

struct _stConf
{
    int iPort;
    int iDefaultGsu;
    int iLogLevel;
    int iTermLevel;
    int iDictProtocol;
    char sIp[32];
    char sLogPath[256];
    char sLogHead[256];
    char sScanPath[MAX_PATH_LENGTH];
    char sLinePath[MAX_PATH_LENGTH];
    char sDictionary[256];
    char sTemplet[256];
    char sOperationType[32];
    char sSystemID[32];
    char sPasswd[32];
    char sSystemType[32];
    unsigned char nInVersion;
    char sOriginHost[128];
    char sOriginRealm[128];
};

namespace CS
{
  int ReadDiameterMsg(FILE* ifile, char *buff, int &nLen);
  int ParseDiameter(const char* buff, const int nLen);
}

int write_cbe(FILE *);
int ReadArg(int argc, char **argv);
bool LoadConfig(bool isReload = false);
int scan_dir(const char *dir, int(*do_file)(const char*), const char *suffix);
int set_file(const char* filename);
void usage(char *sProgramName);
int processLoop();
int rename_file(const char *oldfile, const char *newfile);
struct CBE_Conv
{
    int (*read_pack)(FILE*, char*, int&);
    int (*parse_pack)(const char*, const int);
    int output();

    char CBEFileType[2 + 1]; //CBE格式类型
    char FileId[10 + 1]; //文件Id
    char MsisdnA[24 + 1]; //计费主号码
    char StartTime[14 + 1]; //通话时间
    char Usage[6 + 1]; //通话时长
    char NetType[2 + 1]; //网络类型
    char MultiCall[2 + 1]; //视频电话
    char CallType[2 + 1]; //话单呼叫类型
    char IMSI[15 + 1]; //计费方IMSI号
    char MsisdnB[24 + 1]; //对方号码
    char MscId[10 + 1]; //出单的交换机代码
    char CallingLAC[10 + 1]; //计费方的位置小区代码
    char CallingCellId[5 + 1];//计费方的蜂窝号/基站代码
    char CalledLAC[10 + 1]; //对方的位置小区代码
    char CalledCellId[5 + 1]; //对方的蜂窝/基站代码
    char MsisdnC[24 + 1]; //第三方号码
    char IMEI[15 + 1]; //计费方IMEI号
    char SessionId[16 + 1]; //一次通话标志
    char SessionSi[3 + 1]; //中间话单序号
    char SessionType[1 + 1]; //话单类型标志
    char RealMsisdn[24 + 1]; //真实号码
    char VpnCallType[2 + 1]; //拨号类型/来电类型
    char FCI[8 + 1]; //FCI标记
    char MSRN[11 + 1]; //动态漫游号
    char Calling_Party_Number[24 + 1]; //主叫号码 不输出到CBE
    char Called_Party_Number[24 + 1]; //被叫号码 不输出到CBE

};
#endif /* PACK2CBE_HPP_ */
