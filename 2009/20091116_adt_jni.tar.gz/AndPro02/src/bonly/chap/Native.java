package bonly.chap;

public class Native 
{
  public static native int LibMain(String[] argv);
  
  private static void OnMessage(String text, int level)
  {
	  System.out.println("OnMessage test: " + text + " level=" + level);
  }
};

/**
用javah bonly.chap.Native会生成头文件
JNIEXPORT jint JNICALL Java_bonly_chap_Native_LibMain
  (JNIEnv *, jclass, jobjectArray);
其中,如果函数定义为static 生成的声名则会用jclass,否则是用jobject

*/