/*
 * Process.cpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */
#include <iostream>
#include <boost/asio.hpp>
using namespace boost;
using namespace boost::asio;
using namespace std;

int
main (int argc, char* argv[])
{
  cerr << "socket is: " << argv[1] << endl;

  io_service io;
  //ip::tcp::socket::native_type native_socket = atoi(argv[1]);
  int native_socket = atoi (argv[1]);
  ip::tcp::socket stream(io,ip::tcp::v4(),native_socket);
  while (true)
  {
    stream.send(buffer("hello "));
    stream.send(buffer(argv[2]));
    stream.send(buffer("\n"));
    sleep (3);
  }
  stream.close();
  //io.run();
  return 0;
}
