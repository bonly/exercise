//============================================================================
// Name        : stream_pack.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
// This is the main project file for VC++ application project
// generated using an Application Wizard.
#define BOOST_TEST_MODULE
#include <boost/test/included/unit_test.hpp>

#include "smpp_encoder.h"
BOOST_AUTO_TEST_CASE(Test_Encoder)
{
    smpp::CSmppData sd;
    smpp::CSmppEncoder::respCheckup(sd, (const char*)"Reqn1234567890abcdefghij",
            (const char*)"0000", 3000, "20091120", "TELE", "BrandCode", "Pr", "GZ","GD");
    std::clog << "return TAS->SMPP  len: "<< sd.getBufferSize()<<std::endl;
    smpp::hexdump(sd);
}
