/*
 * smpp_encoder.h
 *
 *  Created on: 2009-8-14
 *      Author: Bonly
 */

#ifndef SMPP_ENCODER_H_
#define SMPP_ENCODER_H_

#include "smpp_data.h"


namespace smpp
{

struct SSmppHead
{
    unsigned int msgLength;
    unsigned int msgType;
    unsigned int ServiceMsgType;
    char         Businesstype[2];
    char         SystemID[10];
    char         ReqSeq[24];
};

class CSmppEncoder
{
private:
    CSmppEncoder();
    ~CSmppEncoder();

private:
    CSmppEncoder(const CSmppEncoder&);
    CSmppEncoder& operator=(const CSmppEncoder&);

public:
    //���smpp��ͷ
    static CSmppData& fillHead(CSmppData& sd, SSmppHead& sh);

private:
    static void fillReqSmppHead(SSmppHead& sh, unsigned int nMsgLength,
        unsigned int srcFE, unsigned int dstFE, unsigned int srcFSM,
        unsigned int nServiceMsgType);

    static void fillRespSmppHead(SSmppHead& sh, const unsigned int nMsgLength,
            const char* Businesstype, const char* SystemID, const char* ReqSeq,
            const unsigned int nServiceMsgType);

public:
    //��Ȩ�����
    static bool reqCheckup(CSmppData& sd,
        unsigned int srcFE, unsigned int dstFE, unsigned int srcFSM,
        const char* pszMsIsdn, const char* pszPin, const char* pszReqSeq,
        int nAmount, int nActiveDays, const char* pszCardNumber);

    //��ֵ�����
    static bool reqTopup(CSmppData& sd,
        unsigned int srcFE, unsigned int dstFE, unsigned int srcFSM,
        const char* pszMsIsdn, const char* pszPin, const char* pszReqSeq,
        int nAmount, int nActiveDays, const char* pszCardNumber);

    //�ع������
    static bool reqRollback(CSmppData& sd,
        unsigned int srcFE, unsigned int dstFE, unsigned int srcFSM,
        const char* pszMsIsdn, const char* pszReqSeq,
        const char* pszTradeSeq, const char* pszCardNumber);

public:
    //��ȨӦ���
    static bool respCheckup(CSmppData& sd,
            const char* ReqSeq,const char* RetCode,
            const int AccountLeft, const char* CallServiceStop, const char* BaseType,
            const char* BrandCode, const char* ProvinceID, const char* CityID,
            const char* SystemID);

    //��ֵӦ���
    static bool respTopup(CSmppData& sd,
        unsigned int dstFE, unsigned int dstFSM,
        const char* pszRetCode, const char* pszAckReq,
        int nAccountLeft, const char* pszEffDate, const char* pszCardNumber);

    //�ع�Ӧ���
    static bool respRollback(CSmppData& sd,
        unsigned int dstFE, unsigned int dstFSM,
        const char* pszRetCode, const char* pszAckReq,
        int nAccountLeft, const char* pszEffDate, const char* pszCardNumber);
public:
    //������
    static bool heartbeat(CSmppData& sd);

};


};

#endif /* SMPP_ENCODER_H_ */
