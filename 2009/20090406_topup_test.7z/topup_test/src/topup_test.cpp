//============================================================================
// Name        : topup_test.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#define _WIN32_WINNT 0x0501
#define __USE_W32_SOCKETS
#include <iostream>
#include <fstream>
#include <string>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>
#include <boost/thread.hpp>
#include "smpp_encoder.h"
#include "smpp_decoder.h"
using namespace std;
using namespace boost;
using namespace boost::asio;
using namespace smpp;

template <typename T> void print_var(const char* k, T v)
{
  cout << format("%s : %1% \n")%k%v;
}
#define PRINT_VAR(k) print_var(#k, k)

struct RTS
{
	unsigned int srcFE;
	unsigned int dstFE;
	unsigned int srcFSM;
	unsigned long long pszMsIsdn;
	char pszReqSeq[255];
	char pszTradeSeq[255];
	char pszCardNumber[255];
	char retCode[5];
  void print();
  RTS(){memset(this,0,sizeof(RTS));}
};

void RTS::print()
{
	//PRINT_VAR(srcFE);
	//PRINT_VAR(dstFE);
	//PRINT_VAR(srcFSM);
	//PRINT_VAR(pszMsIsdn);
	PRINT_VAR(pszReqSeq);
	PRINT_VAR(pszTradeSeq);
	//PRINT_VAR(pszCardNumber);
	PRINT_VAR(retCode);
}

shared_ptr<program_options::variables_map> vm;
string help;
class Command;
class Application;

class Connector : public boost::enable_shared_from_this<Connector>
{
	public:
		Connector():_stream(_io),_recv_len(0)
		{
			memset(_buf,0,BUF_SIZE);
		}
		int connect(const char* ip, const int port);

		static int send(Connector* conn, char* buf, int len);

		void as_send(char* buf,int len);
		void recv_smpp(const boost::system::error_code& error);
		void recv_body(const boost::system::error_code& error,std::size_t bytes_transferred);
		void recv_done(const boost::system::error_code& error,std::size_t bytes_transferred);

		ip::tcp::socket& stream(){return _stream;}
    int run(){return _io.run();}
    void close(){_stream.close();}
    const char* buf(){return _buf;}

	private:
		enum {
		 BUF_SIZE = 512,
     SMPP_HEAD_SIZE = 4,
     SMPP_MAX_SIZE = BUF_SIZE - SMPP_HEAD_SIZE,
     SMPP_MIN_SIZE = 1
    };
		io_service      _io;
		ip::tcp::socket _stream;
		char            _buf[BUF_SIZE];
		int             _recv_len;
};

int
Connector::send(Connector* conn, char* buf, int len)
{
   return conn->stream().send(buffer(buf,len));
}

void
Connector::as_send(char* buf,int len)
{
  _stream.async_send(buffer(buf,len),bind(&Connector::recv_smpp,this,placeholders::error));
}

void
Connector::recv_smpp(const boost::system::error_code& error)
{
  _stream.async_receive(buffer(_buf,SMPP_HEAD_SIZE),bind(&Connector::recv_body,
  		                                                    this,
  		                                                    placeholders::error,
  		                                                    placeholders::bytes_transferred));
}

void
Connector::recv_body(const boost::system::error_code& error,std::size_t bytes_transferred)
{
	int *pMsgLen = reinterpret_cast<int*>(_buf);
	int nMsgLen = ntohl(*pMsgLen);
	_recv_len = bytes_transferred;
	cout << format("body len: %d\n")%nMsgLen;
  _stream.async_receive(buffer(_buf+SMPP_HEAD_SIZE,nMsgLen),bind(&Connector::recv_done,this,
  		                                            placeholders::error,
  		                                            placeholders::bytes_transferred));
}

void
Connector::recv_done(const boost::system::error_code& error,std::size_t bytes_transferred)
{
	cout << format("recv smpp done: \n");
	_recv_len += bytes_transferred;
	hexdump(_buf,bytes_transferred);
}

int
Connector::connect(const char* ip, const int port)
{
  ip::tcp::endpoint ep(
  		ip::address::from_string(ip),port
  		);

  boost::system::error_code er;
  _stream.connect(ep,er);
  if (er)
  {
  	std::cerr << "connect error\n";
  	return -1;
  }
  else
  	std::cout << "connect sucess\n";
	return 0;
}

class Worker
{
	public:
		int(Worker::*qry) (shared_ptr<CSmppData>&);
    int init(const char* ip, const int port);
		int RTQ(shared_ptr<CSmppData> &sd);
		int TUQ(shared_ptr<CSmppData> &sd);
		int TAQ(shared_ptr<CSmppData> &sd);
    int DWR(shared_ptr<CSmppData> &sd);

		void pRTS();

		int do_qry();

    Worker(){}
    Worker(const char* ip, const int port)
    {init(ip,port);}
    void finish(){_conn.close();}
    ~Worker(){finish();}


	private:
		Connector _conn;
};

void Worker::pRTS()
{
	RTS rts;
	CSmppDecoder::respRollback(_conn.buf(),
			  rts.srcFE,
	      rts.dstFE, rts.srcFSM,
	      rts.pszMsIsdn, (char*)rts.pszReqSeq,
	      (char*)rts.pszTradeSeq, (char*)rts.pszCardNumber, (char*)rts.retCode);
  //rts.print();
}

int Worker::init(const char* ip, const int port)
{
	return _conn.connect(ip,port);
}

int Worker::do_qry()
{
	shared_ptr<CSmppData> sd;
	(this->*qry)(sd);

	char* s = (char*)((*sd).getBuffer());
  int nLen = (*sd).getBufferSize();

  _conn.as_send(s,nLen);
  return _conn.run();
}

int
Worker::DWR(shared_ptr<CSmppData> &sd)
{
	sd = shared_ptr<CSmppData>(new CSmppData);
	if(CSmppEncoder::heartbeat(*sd))
	{
		hexdump(*sd);
		return 0;
	}
	return -1;
}

int
Worker::RTQ(shared_ptr<CSmppData> &sd)
{
	sd = shared_ptr<CSmppData>(new CSmppData);
	if(CSmppEncoder::reqRollback(*sd, 1, 2, 3,
			(*vm)["RTQ.telno"].as<std::string>().c_str(),
			(*vm)["RTQ.seq"].as<std::string>().c_str(),
			(*vm)["RTQ.tuq_seq"].as<std::string>().c_str(),
			(*vm)["RTQ.cardno"].as<std::string>().c_str()))
	{
		hexdump(*sd);
		return 0;
	}
	return -1;
}

int
Worker::TUQ(shared_ptr<CSmppData> &sd)
{
	sd = shared_ptr<CSmppData>(new CSmppData);
	if(CSmppEncoder::reqTopup(*sd, 1, 2, 3,
			(*vm)["TUQ.telno"].as<std::string>().c_str(),
			(*vm)["TUQ.passwd"].as<std::string>().c_str(),
			(*vm)["TUQ.seq"].as<std::string>().c_str(),
			(*vm)["TUQ.money"].as<int>(),
			(*vm)["TUQ.act_days"].as<int>(),
			(*vm)["TUQ.cardno"].as<std::string>().c_str()))
	{
		hexdump(*sd);
		return 0;
	}
	return -1;
}

int
Worker::TAQ(shared_ptr<CSmppData> &sd)
{
	sd = shared_ptr<CSmppData>(new CSmppData);
	if(CSmppEncoder::reqCheckup(*sd, 1, 2, 3,
			(*vm)["TAQ.telno"].as<std::string>().c_str(),
			(*vm)["TAQ.passwd"].as<std::string>().c_str(),
			(*vm)["TAQ.seq"].as<std::string>().c_str(),
			(*vm)["TAQ.amount"].as<int>(),
		  (*vm)["TAQ.act_days"].as<int>(),
		  (*vm)["TAQ.cardno"].as<std::string>().c_str()))
	{
		hexdump(*sd);
		return 0;
	}
	return -1;
}

class Command
{
	public:
		Command(Application &app):_app(app)
		{}
		void run();
	private:
		Application &_app;
		Worker      _worker;
};

class Application
{
	public:
		Application():_cmd(*this){}
		static int configure(program_options::variables_map &vm, int argc, char* argv[]);
    void run();
	private:
		Command      _cmd;
		thread_group _thread;
};

void Application::run()
{
	if((*vm).count("TAQ")||(*vm).count("TUQ")||(*vm).count("RTQ"))
	{
		Worker worker;
		worker.init((*vm)["ip"].as<string>().c_str(), (*vm)["port"].as<int>());
		if ((*vm).count("TAQ"))
		{
			 worker.qry = (&Worker::TAQ);
			 worker.do_qry();
		}

		if ((*vm).count("TUQ"))
		{
			 worker.qry = (&Worker::TUQ);
			 worker.do_qry();
		}

		if ((*vm).count("RTQ"))
		{
			//�ع�
			 worker.qry = (&Worker::RTQ);
			 worker.do_qry();
		}
	}
	if ((*vm).count("console"))
	{
		_thread.create_thread (bind(&Command::run,ref(_cmd)));
	  _thread.join_all();
	}
}

int
Application::configure(program_options::variables_map &vm, int argc, char* argv[])
{
	program_options::options_description desc ("Allowed options");
	help = argv[0];
	help.append(" config.cfg");
	try
	{
		desc.add_options ()
			("help,h", help.c_str())
			("console,c","work as console")
			("test-file", boost::program_options::value<std::string>()->default_value("default.cfg"),"use file to test")
			("ip",boost::program_options::value<std::string>()->default_value("10.200.2.17"),"server's ip")
			("port",boost::program_options::value<int>()->default_value(18899),"server's port")
			("TAQ","��Ȩ")
			("TAQ.telno",boost::program_options::value<std::string>()->default_value("13001000001"),"telno")
			("TAQ.passwd",boost::program_options::value<std::string>()->default_value("88888888"),"password")
			("TAQ.cardno",boost::program_options::value<std::string>()->default_value("360000000002"),"card no")
			("TAQ.seq",boost::program_options::value<std::string>()->default_value("check00001"),"seq")
			("TAQ.act_days",boost::program_options::value<int>()->default_value(31),"Active Days")
			("TAQ.amount",boost::program_options::value<int>()->default_value(823),"Amount")
			("TUQ","��ֵ")
			("TUQ.telno",boost::program_options::value<std::string>()->default_value("13001000001"),"telno")
			("TUQ.passwd",boost::program_options::value<std::string>()->default_value("88888888"),"password")
			("TUQ.money",boost::program_options::value<int>()->default_value(5000),"money (��λ:��)")
			("TUQ.cardno",boost::program_options::value<std::string>()->default_value("360000000002"),"cardno")
			("TUQ.seq",boost::program_options::value<std::string>()->default_value("topup00001"),"seq")
			("TUQ.act_days",boost::program_options::value<int>()->default_value(30),"Active Days")
			("RTQ","�ع�")
			("RTQ.telno",boost::program_options::value<std::string>()->default_value("13001000001"),"telno")
			("RTQ.cardno",boost::program_options::value<std::string>()->default_value("36000000"),"cardno")
			("RTQ.seq",boost::program_options::value<std::string>()->default_value("roseq00001"),"seq")
			("RTQ.tuq_seq",boost::program_options::value<std::string>()->default_value("topup00001"),"TUQ seq")
			;
		boost::program_options::positional_options_description p;
		p.add("test-file", -1);
		store (
				boost::program_options::command_line_parser(argc,argv).options(desc).positional(p).run(),
				vm);

		notify(vm);
		if (vm.count("help"))
		{
			cout << desc << "\n";
			return 0;
		}

		std::string file_cfg("default.cfg");
		if (vm.count("test-file"))
		{
			file_cfg=vm["test-file"].as<std::string>();
			cout << "use test file " << file_cfg << "\n";
		}
		ifstream ifs(file_cfg.c_str());
		store(parse_config_file(ifs,desc), vm);
		notify(vm);
	}
	catch(std::exception& e)
	{
		cout << e.what() << "\n";
		return -1;
	}
	return 0;
}



void Command::run()
{
	 _worker.init((*vm)["ip"].as<string>().c_str(), (*vm)["port"].as<int>());
   while(true)
   {
  	 cout << format("input command \n\tTUQ\n\tTAQ\n\tRTQ\n\tDWR\n"
  			            "\tRECONNECT\n"
  			            "\tEXIT\n:");
  	 string cmd;
  	 cin >> cmd;
  	 if(cmd.compare("RTQ")==0)
  	 {
  		 _worker.qry = (&Worker::RTQ);
  		 _worker.do_qry();
  		 //_worker.pRTS();
  	 }
  	 if(cmd.compare("TUQ")==0)
  	 {
  		 _worker.qry = &Worker::TUQ;
  		 _worker.do_qry();
  	 }
  	 if(cmd.compare("TAQ")==0)
  	 {
  		 _worker.qry = (&Worker::TAQ);
  		 _worker.do_qry();
  	 }
  	 if(cmd.compare("DWR")==0)
  	 {
  		 _worker.qry = (&Worker::DWR);
  		 _worker.do_qry();
  	 }
  	 if(cmd.compare("RECONNECT")==0)
		 {
  		 _worker.finish();
  		 _worker.init((*vm)["ip"].as<string>().c_str(), (*vm)["port"].as<int>());
		 }
  	 if(cmd.compare("EXIT")==0)
       return;
   }
}

int
main(int argc, char* argv[])
{
	vm = shared_ptr<program_options::variables_map>(new program_options::variables_map);
	Application app;
	app.configure((*vm),argc,argv);
  app.run();
	return 0;
}
