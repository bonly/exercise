#ifndef __SMPP_ENCODER_HEAD__
#define __SMPP_ENCODER_HEAD__

#include "smpp_data.h"


namespace smpp
{

struct SSmppHead
{
	unsigned int msgLength;
	unsigned int msgType;
	unsigned int msgID;
	unsigned int srcFE;
	unsigned int dstFE;
	unsigned int srcFSM;
	unsigned int dstFSM;
	unsigned int nodeNo;
	unsigned int serviceKey;
	unsigned int ServiceMsgType;
};

class CSmppEncoder
{
private:
	CSmppEncoder();
	~CSmppEncoder();

private:
	CSmppEncoder(const CSmppEncoder&);
	CSmppEncoder& operator=(const CSmppEncoder&);

public:
	//���smpp��ͷ
	static CSmppData& fillHead(CSmppData& sd, SSmppHead& sh);

private:
	static void fillReqSmppHead(SSmppHead& sh, unsigned int nMsgLength,
		unsigned int srcFE, unsigned int dstFE,	unsigned int srcFSM,
		unsigned int nServiceMsgType);

	static void fillRespSmppHead(SSmppHead& sh, unsigned int nMsgLength,
		unsigned int dstFE,	unsigned int dstFSM,
		unsigned int nServiceMsgType);

public:
	//��Ȩ�����
	static bool reqCheckup(CSmppData& sd, 
		unsigned int srcFE, unsigned int dstFE,	unsigned int srcFSM,
		const char* pszMsIsdn, const char* pszPin, const char* pszReqSeq,
		int nAmount, int nActiveDays, const char* pszCardNumber);

	//��ֵ�����
	static bool reqTopup(CSmppData& sd, 
		unsigned int srcFE, unsigned int dstFE,	unsigned int srcFSM,
		const char* pszMsIsdn, const char* pszPin, const char* pszReqSeq,
		int nAmount, int nActiveDays, const char* pszCardNumber);

	//�ع������
	static bool reqRollback(CSmppData& sd, 
		unsigned int srcFE, unsigned int dstFE,	unsigned int srcFSM,
		const char* pszMsIsdn, const char* pszReqSeq,
		const char* pszTradeSeq, const char* pszCardNumber);

public:
	//��ȨӦ���
	static bool respCheckup(CSmppData& sd, 
		unsigned int dstFE,	unsigned int dstFSM,
		const char* pszRetCode, const char* pszAckReq,
		int nAccountLeft, const char* pszEffDate, const char* pszAreaNo);

	//��ֵӦ���
	static bool respTopup(CSmppData& sd, 
		unsigned int dstFE,	unsigned int dstFSM,
		const char* pszRetCode, const char* pszAckReq,
		int nAccountLeft, const char* pszEffDate, const char* pszCardNumber);

	//�ع�Ӧ���
	static bool respRollback(CSmppData& sd, 
		unsigned int dstFE,	unsigned int dstFSM,
		const char* pszRetCode, const char* pszAckReq,
		int nAccountLeft, const char* pszEffDate, const char* pszCardNumber);
public:
	//������
	static bool heartbeat(CSmppData& sd);

};


};


#endif

