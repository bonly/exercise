#include <string.h>
#include <stdio.h>
#include <ctype.h>

#include "smpp_data.h"


namespace smpp
{
	//CSmppData
	CSmppData::CSmppData()
		: m_puzData(NULL), m_unLen(0), m_unCur(0), m_usStatus(EInputCont)
	{
	}

	CSmppData::CSmppData(size_t nLen)
	{
		this->alloc_data(nLen);
	}


	CSmppData::~CSmppData()
	{
		delete[] m_puzData;
	}


	void CSmppData::alloc_data(size_t nLen)
	{
		if(m_puzData!=NULL)
		{
			delete[] m_puzData;
		}
		m_puzData = new unsigned char[nLen];
		m_unLen = nLen;
		m_unCur = 0;
		m_usStatus = EInputCont;
	}

	bool CSmppData::checkStatus(size_t nInputLen)
	{
		if(m_usStatus == EInputCont)
		{
			bool b = (m_unCur+nInputLen) <= m_unLen;
			if(!b)
			{
				m_usStatus = EInputErr;
			}
			return b;
		}

		return false;
	}

	//д��int,ת��Ϊ4bypes,��λ��ǰ,��λ�ں�
	CSmppData& CSmppData::operator<< (unsigned int unValue)
	{
		if(checkStatus(4))
		{
			unsigned char* pData = m_puzData+m_unCur;
			*pData = (unValue >> 24) & 0xff;
			*(pData+1) = (unValue >> 16) & 0xff;
			*(pData+2) = (unValue >> 8) & 0xff;
			*(pData+3) = unValue & 0xff;

			m_unCur += 4;
		}

		return *this;
	}


	//д��1λ��int
	CSmppData& CSmppData::operator<< (unsigned char cValue)
	{
		if(checkStatus(1))
		{
			*(m_puzData+m_unCur) = cValue;
			++m_unCur;
		}

		return *this;
	}


	//д���ַ���
	CSmppData& CSmppData::operator<< (const char* pszData)
	{
		size_t nLen = strlen(pszData);
		if(checkStatus(nLen))
		{
			strcpy((char*)(m_puzData+m_unCur), pszData);
			m_unCur += nLen;
		}

		return *this;
	}

	CSmppData& CSmppData::operator<< (const CSmppData::CFixedBuffer& buffer)
	{
		if(checkStatus(buffer.m_l))
		{
			size_t nLen = strlen(buffer.m_s);
			if(nLen > buffer.m_l)
			{
				m_usStatus = EInputErr;
				return *this;
			}

			strcpy((char*)(m_puzData+m_unCur), buffer.m_s);
			memset((char*)(m_puzData+nLen+m_unCur), 0, buffer.m_l-nLen);
			m_unCur += buffer.m_l;
		}

		return *this;
	}

	//���ڽ���һ��smpp��������
	void CSmppData::operator<< (void (*p)(CSmppData&))
	{
		(*p)(*this);
	}

	void endSmpp (CSmppData& d)
	{
		if(d.m_usStatus != EInputErr)
		{
			if (d.m_unCur > d.m_unLen)
			{
				d.m_usStatus = EInputErr;
			}
			else
			{
				d.m_usStatus = EInputSuc;
			}
		}
	}

	void _hex(unsigned char c, char* s)
	{
		sprintf(s, "%02X", c);
		s[2] = ' ';
	}

	char* _hexdump16bytes(char* p, size_t& nBegin, size_t& nLeft)
	{
		if(nLeft <= 0)
		{
			return NULL;
		}
	
		enum{line_size = 67};
		static char s[line_size + 1];
		s[line_size] = '\0';

		char* p2 = p + nBegin;
		for(size_t i=0; i<16; ++i)
		{
			if(nLeft > 0)
			{
				unsigned char c = p2[i];
				_hex(c, s+i*3);

				s[51+i] = isprint(c) ? c : '.';
				--nLeft;
			}
			else
			{
				size_t j=i*3;
				s[j] = ' ';
				s[j+1] = ' ';
				s[j+2] = ' ';
				s[51+i] = ' ';
			}
		}

		s[48] = ' ';
		s[49] = ';';
		s[50] = ' ';

		nBegin += 16;

		return s;
	}

	void hexdump(char* p, size_t n)
	{
		size_t nBegin = 0;
		if(n > 0)
		{
			char* s = NULL;
			while( (s= _hexdump16bytes(p, nBegin, n)) != NULL )
			{
				printf("%s\n", s);
			}
		}
		printf("\n");
	}

	void hexdump(const CSmppData& sd)
	{
		size_t nLeft = sd.getBufferSize();
		char* p = sd.getBuffer();
		hexdump(p, nLeft);
	}

};

