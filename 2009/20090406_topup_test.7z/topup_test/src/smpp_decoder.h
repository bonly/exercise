#ifndef __SMPP_DECODER_HEAD__
#define __SMPP_DECODER_HEAD__

#include <ctype.h>

#include "smpp_code.h"


namespace smpp
{
	class CSmppDecoder
	{
	public:
		//��4byteת��Ϊ����(sizeof(int)==4)
		static unsigned int FourByteToInt(const char* pszInput);
    static unsigned long long ch2uLL(const char* pszInput,const int bp,const int size);

	public:
		static ECommandId getServiceMsgType(const char* p);

	public:
		//��Ȩ����
		static bool reqCheckup(const char* p, unsigned int& srcFE,
			unsigned int& dstFE, unsigned int& srcFSM,
			unsigned long long& pszMsIsdn, char* pszPin, char* pszReqSeq,
			int& nAmount, int& nActiveDays, char* pszCardNumber);

		//��ֵ����
		static bool reqTopup(const  char* p, unsigned int& srcFE,
			unsigned int& dstFE, unsigned int& srcFSM,
			unsigned long long& pszMsIsdn, char* pszPin, char* pszReqSeq,
			int& nAmount, int& nActiveDays, char* pszCardNumber);

		//�ع�����
		static bool reqRollback(const char* p, unsigned int& srcFE,
			unsigned int& dstFE, unsigned int& srcFSM,
			unsigned long long& pszMsIsdn, char* pszReqSeq,
			char* pszTradeSeq, char* pszCardNumber);

		//�ع�Ӧ��
		static bool respRollback(const char* p, unsigned int& srcFE,
		      unsigned int& dstFE, unsigned int& srcFSM,
		      unsigned long long& pszMsIsdn, char* pszReqSeq,
		      char* pszTradeSeq, char* pszCardNumber, char* retCode);
	};

};


#endif

