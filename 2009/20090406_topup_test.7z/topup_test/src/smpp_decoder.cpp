#include <cstring>
#include <cstdlib>
#include "smpp_decoder.h"
#include <boost/lexical_cast.hpp>
#include <boost/format.hpp>
#include <boost/algorithm/string.hpp>
#include <netinet/in.h>
#include <iostream>
namespace smpp
{

//��4byteת��Ϊ����(sizeof(int)==4)
unsigned int CSmppDecoder::FourByteToInt(const char* pszInput)
{
  unsigned char* psz = (unsigned char*)pszInput;
  unsigned int nLen = (psz[0] << 24) + (psz[1] << 16) + (psz[2] << 8) + psz[3];
  return nLen;
}

ECommandId CSmppDecoder::getServiceMsgType(const char* p)
{
  //��ȡ����,�������Ϊ1,��Ϊ������
  unsigned int unLen = FourByteToInt(p);
  if(unLen == 1)
  {
    return E_CMD_HEARTBEAT;
  }

  enum{e_pos = 36, min_msg_size = 41};
  if(unLen < min_msg_size)
  {
    return E_CMD_UNKNOWN;
  }

  return static_cast<ECommandId>(FourByteToInt(p + e_pos));
}

unsigned long long CSmppDecoder::ch2uLL(const char* pszInput,const int bp, const int size)
{
  char tmp[11+1];
  memset(tmp,0,sizeof(tmp));
  strncpy(tmp, pszInput + bp, 11);
  unsigned long long result=0ull;
  try
  {
    result = boost::lexical_cast<unsigned long long>(tmp);
  }
  catch(boost::bad_lexical_cast &e)
  {
    std::cerr << "phone"<<tmp<<e.what()<<"\n";
  }
  return result;
}

bool CSmppDecoder::reqCheckup(const char* p, unsigned int& srcFE,
      unsigned int& dstFE, unsigned int& srcFSM,
      unsigned long long& pszMsIsdn, char* pszPin, char* pszReqSeq,
      int& nAmount, int& nActiveDays, char* pszCardNumber)
{
  if(FourByteToInt(p) != e_checkup_req_size)
  {
    return false;
  }

  srcFE = FourByteToInt(p + 12);
  dstFE = FourByteToInt(p + 16);
  srcFSM = FourByteToInt(p + 20);
  pszMsIsdn = ch2uLL(p, 40, 11);
  strncpy(pszPin, p + 51, 8);
  pszPin[8] = '\0';
  strncpy(pszReqSeq, p + 59, 24);
  pszReqSeq[24] = '\0';
  nAmount = FourByteToInt(p + 83);
  nActiveDays = FourByteToInt(p + 87);
  strncpy(pszCardNumber, p + 91, 36);
  pszCardNumber[36] = '\0';

  return true;
}

//��ֵ����
bool CSmppDecoder::reqTopup(const char* p, unsigned int& srcFE,
       unsigned int& dstFE, unsigned int& srcFSM,
       unsigned long long& pszMsIsdn, char* pszPin, char* pszReqSeq,
       int& nAmount, int& nActiveDays, char* pszCardNumber)
{
  if(FourByteToInt(p) != e_topup_req_size)
  {
    return false;
  }

  srcFE = FourByteToInt(p + 12);
  dstFE = FourByteToInt(p + 16);
  srcFSM = FourByteToInt(p + 20);
  //TODO:ȷ���ֻ��������ʼλ��
  pszMsIsdn = ch2uLL(p, 40, 11);
  strncpy(pszPin, p + 51, 8);
  pszPin[8] = '\0';
  strncpy(pszReqSeq, p + 59, 24);
  pszReqSeq[24] = '\0';
  nAmount = FourByteToInt(p + 83);
std::cout<<boost::format("smpp's Amount is: %u\t%d\t%x\n")%nAmount%nAmount%nAmount;
  nActiveDays = FourByteToInt(p + 87);
  strncpy(pszCardNumber, p + 91, 36);
  pszCardNumber[36] = '\0';

  return true;
}

//�ع�����
bool CSmppDecoder::reqRollback(const char* p, unsigned int& srcFE,
      unsigned int& dstFE, unsigned int& srcFSM,
      unsigned long long& pszMsIsdn, char* pszReqSeq,
      char* pszTradeSeq, char* pszCardNumber)
{
  //unsigned int *pMsgLen = reinterpret_cast<unsigned int*>(const_cast<char*>(p));
  //HP���ô˽�ͷ����������
  //if(FourByteToInt(p) != e_rollback_req_size)
	int *pMsgLen = reinterpret_cast<int*>(const_cast<char*>(p));
	int nMsgLen = ntohl(*pMsgLen);
  if (nMsgLen != e_rollback_req_size)
  {
  	std::cout << "Rollback size is: "<<e_rollback_req_size<<std::endl;
    //return false;
  }

  srcFE = FourByteToInt(p + 12);
  dstFE = FourByteToInt(p + 16);
  srcFSM = FourByteToInt(p + 20);
  srcFSM = FourByteToInt(p + 40);
  //TODO:ȷ���ֻ��������ʼλ��
  pszMsIsdn = ch2uLL(p, 40, 11);
  strncpy(pszReqSeq, p + 51, 24);
  pszReqSeq[24] = '\0';
  strncpy(pszTradeSeq, p + 75, 24);
  pszTradeSeq[24] = '\0';
  strncpy(pszCardNumber, p + 99, 36);
  pszCardNumber[36] = '\0';

  return true;
}

//�ع�Ӧ��
bool CSmppDecoder::respRollback(const char* p,
		  unsigned int& srcFE,
      unsigned int& dstFE, unsigned int& srcFSM,
      unsigned long long& pszMsIsdn, char* pszReqSeq,
      char* pszTradeSeq, char* pszCardNumber, char* retCode)
{
	int *pMsgLen = reinterpret_cast<int*>(const_cast<char*>(p));
	//int nMsgLen = ntohl(*pMsgLen);
//  if (nMsgLen != e_rollback_req_size)
//  {
//  	std::cout << "Rollback size is: "<<e_rollback_req_size<<std::endl;
//    return false;
//  }
  //msgType
	//msgID
  srcFE  = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 12))));
  dstFE  = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 16))));
  srcFSM = ntohl(*(reinterpret_cast<int*>(const_cast<char*>(p + 20))));

  //TODO:ȷ���ֻ��������ʼλ��
  pszMsIsdn = ch2uLL(p, 40, 11);
  strncpy(pszReqSeq, p + 51, 24);
  pszReqSeq[24] = '\0';
  strncpy(pszTradeSeq, p + 75, 24);
  pszTradeSeq[24] = '\0';
  strncpy(pszCardNumber, p + 99, 36);
  pszCardNumber[36] = '\0';
  strncpy(retCode, p + 135, 4);
  retCode[4] ='\0';

  return true;
}

};

