//============================================================================
// Name        : get_data.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include "rapidxml.hpp"
#include "rapidxml_print.hpp"
using namespace rapidxml;

#include <vector>
#include <fstream>
#include <iostream>
using namespace std;

#include <boost/shared_ptr.hpp>
#include <boost/format.hpp>
using namespace boost;

#include <string.h>
int parse_xml_file(const char* filename, xml_document<> &doc, xml_node<> **root, vector<char> &xmlData)
{
  ifstream xmlFile(filename, ios::binary);
  if (!xmlFile)
  {
    return -1;
  }
  xmlFile.unsetf(ios::skipws); //读出不跳过空白字符
  xmlFile.seekg(0, ios::end);
  size_t size = xmlFile.tellg();
  xmlFile.seekg(0);

  //预定义存放区大小
  //vector<char> xmlData(size + 1);
  xmlData.reserve(size + 1);
  xmlData[size] = 0;

  xmlFile.read(&xmlData.front(), static_cast<streamsize> (size));

  try
  {
    doc.clear();

    //解释
    doc.parse<0> (&xmlData.front());

    //取得root
    *root = doc.first_node();
  }
  catch (rapidxml::parse_error &e)
  {
    xmlFile.close();
    clog << "parse xml file eror: " << e.what() << endl;
    return -2;
  }
  return 0;
}
class Bss_bus_data
{
  public:
    struct Prod
    {
      char OPType[10];
      char Brand[20];
      char ProdID[20];
      char ProdDef[20];
      char ProdType[10];
      char PlanID[20];
      char EffType[10];
      char BegDate[30];
      char EndDate[30];
    };
    char COMMSERIAL[20];
    char OperID[10];
    char OrgID[10];
    char SubID[20];
    char MSISDN[12];
    char CallType[10];
    char CardNo[10];
    char IMSI[10];
    char AcctLimit[30];
    vector<Prod> prod;
};
class Bss_bus_xml
{
  public:
    int get_record(shared_ptr<Bss_bus_data> &data);
    void go_next_node(xml_node<char> *node,xml_node<char> *tmp_node);
    int get_data(shared_ptr<Bss_bus_data> &data);
    xml_document<>  _doc;
    xml_node<char> *_root;
    xml_node<char> *_current;
    xml_node<char> *_next_prod;
    vector<char>    _xmlData;
    Bss_bus_xml()
    {
      _root=0;
      _current=0;
      _next_prod=0;
    }
};

void Bss_bus_xml::go_next_node(xml_node<char> *node, xml_node<char> *tmp_node)
{
    _current = node;
    if(_next_prod==0)
    {
      //检查next_sibling下一个兄弟,以标识是否全部读完
      tmp_node = node->next_sibling("REC");
      if(tmp_node==0)
      {
        //read_done = true;
        //ifile.close();
      }
    }
}

int Bss_bus_xml::get_record(shared_ptr<Bss_bus_data> &data)
{
  assert(_root!=0);
  xml_node<char> *node = 0;
  xml_node<char> *tmp_node = 0;
  try
  {
    if (_current == 0)
    {
      node = _root->first_node("REC");
      if(node==0)
      {
        /*
        file->have_error = true;
        file->read_done = true;
        file->write_done = true;
        */
        clog << "No REC node found\n";
        return -1;
      }
    }
    else
    {
      if(_next_prod==0)
      {
        node = _current->next_sibling("REC");
        if(node==0)
        {
          clog << "REC node ending\n";
          return 0;
        }
      }
      else
        node = _current;
    }

    shared_ptr<Bss_bus_data> obj(new Bss_bus_data);

    #define GET_NODE(Node) {\
      tmp_node = node->first_node((#Node+5)); \
      if(0 != tmp_node) \
      { \
        if(strlen(tmp_node->value())>sizeof(Node)) \
        { \
          clog << format("Field [%s]:%d is bigger then define %d\n")%(#Node+5)%tmp_node->value()%sizeof(Node); \
          go_next_node(node,tmp_node);\
          return -1; \
        } \
        strcpy(Node,tmp_node->value()); \
      } \
      else strcpy(Node,""); \
    }

    GET_NODE(obj->COMMSERIAL);
    if(strlen(obj->COMMSERIAL)==0)
    {
      go_next_node(node,tmp_node);
      return -1;
    }
    GET_NODE(obj->OperID);
    GET_NODE(obj->OrgID);
    GET_NODE(obj->SubID);
    GET_NODE(obj->MSISDN);
    GET_NODE(obj->CallType);
    GET_NODE(obj->CardNo);
    GET_NODE(obj->IMSI);
    GET_NODE(obj->AcctLimit);

    xml_node<char> *prodlist_node = node->first_node("ProdList");
    xml_node<char> *prod_node;
    if(_next_prod==0)
    {
      prod_node     = prodlist_node->first_node("Prod");
    }
    else
    {
      prod_node     = _next_prod;
    }

    #undef GET_NODE
    #define GET_NODE(Node,Num) {\
      tmp_node = prod_node->first_node((#Node+Num)); \
      if(0 != tmp_node) \
      { \
        if(strlen(tmp_node->value())>sizeof(Node)) \
        { \
          clog << format("Field [%s]:%d is bigger then define %d\n")%(#Node+Num)%tmp_node->value()%sizeof(Node); \
          go_next_node(node,tmp_node);\
          return -1; \
        } \
        strcpy(Node,tmp_node->value()); \
      } \
      else \
        strcpy(Node,""); \
    }

    //while(prod_node != 0)
    {
      Bss_bus_data::Prod prod;
      GET_NODE(prod.OPType,5);

      GET_NODE(prod.Brand,5);
      GET_NODE(prod.ProdID,5);
      GET_NODE(prod.ProdDef,5);
      GET_NODE(prod.ProdType,5);
      GET_NODE(prod.PlanID,5);
      GET_NODE(prod.EffType,5);
      GET_NODE(prod.BegDate,5);
      GET_NODE(prod.EndDate,5);

      obj->prod.push_back(prod);

      //get next product
      //prod_node = prod_node->next_sibling("Prod");
      _next_prod = prod_node->next_sibling("Prod");
    }

    #undef GET_NODE
    data = obj;
    go_next_node(node,tmp_node);
  }
  catch(...)
  {
    cerr << "xml数据不正确" ;
    return -1;
  }
  return 0;
}

int Bss_bus_xml::get_data(shared_ptr<Bss_bus_data>  &data)
{
  int ret = -1;
  /*
  if(irecord-orecord >= 300) //当已发送记录到达300时暂停发送,待数量降下来
    return -1;
  if(read_done==true)
  {
    if(irecord==orecord) //检查是否已全部完成
      try_finish();
    return -1; //read_done==true当前的文件已经读完,未处理完
  }
  */

  //ACE_Guard<ACE_Thread_Mutex> guard (File::mutex);
  if(_root==0)
  {
    ret = parse_xml_file("temp.xml", _doc, &_root, _xmlData);
    if (ret != 0)
    {
      /*
      //后来加的删除空错误文件功能,为免影响框架,补生成后面要删除的文件
      file->ifile.close();
      rename(file->ifile_name.c_str(), file->efile_name.c_str());

      ofile.open(tfile_name.c_str(),ios::out);
      ofile << "error input file, this file will be delete\n";
      ofile.close();

      ofile.open(ifile_name.c_str(),ios::out);
      ofile << "error input file, this file will be delete\n";
      ofile.close();

      file->have_error = true;
      file->read_done = true;
      file->write_done = true;
      */
      return -1;
    }
    try
    {
      /*
      ofile.open(tfile_name.c_str(),ios::out);
      efile.open(efile_name.c_str(),ios::out); //错误记录文件
      efile << "<?xml version=\"1.0\" encoding=\"gb2312\"?>\n<BIZ>" << endl;
      */
    }
    catch(std::exception &e)
    {
      perror("创建临时文件失败");
      return -1;
    }
  }
  else  //已经打开文件的,继续下一条记录
    ret = 0;

  if(ret < 0)
    return ret;

  return get_record(data);
}
int main()
{
  Bss_bus_xml bus;
  shared_ptr<Bss_bus_data> data;
  bus.get_data(data);
  bus.get_data(data);
}

