/*
 * acceptor.cpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */
#include "acceptor.hpp"
#include "application.hpp"
#include <sys/wait.h>

Acceptor::Acceptor(io_service &io,bool &stop, const char* proc_name,
                   const char* ip, const int port)
  :_io(io),_socket(io),_acceptor(io),_stop(stop)
{
  bzero(_proc_name,255);
  strcpy(_proc_name, proc_name);
  ip::tcp::endpoint ep(
      ip::address::from_string(ip),port);
  _acceptor.open(ep.protocol());
  _acceptor.set_option(ip::tcp::acceptor::reuse_address(true));
  _acceptor.bind(ep);
  _acceptor.listen();
}

int
Acceptor::process()
{
  pid_t pid;
  if((pid=fork())==0)
  {
    _acceptor.close();
    if (execlp(_proc_name,_proc_name,
               lexical_cast<string>(_socket.native()).c_str(),(char*)0)<0)
      cerr << "start process fail\n";
    exit(0);
  }
  else
  {
    _pid.push_back(pid);
    _socket.close();

    _acceptor.async_accept(_socket,
        bind (&Acceptor::on_accepted, this, placeholders::error));
  }
  return 0;
}

int
Acceptor::on_accepted(boost::system::error_code const &e)
{
  if(!e)
  {
    _threads.create_thread(bind(&Acceptor::process,ref(*this)));
  }
  else
  {
    std::cerr << "Accept error: " << e.message() << "\n";
  }
  return 0;
}

int
Acceptor::wait()
{
  while(!_stop||!_pid.empty())
  {
   BOOST_FOREACH(pid_t p, _pid)
   {
     pid_t pid;
     pid = waitpid(p,NULL,WNOHANG);
     if (pid > 0)
     {
       _pid.remove(pid);
       break;
     }
   }
   sleep(3);
  }
  return 0;
}

int
Acceptor::run()
{
  _acceptor.async_accept(_socket,
      bind (&Acceptor::on_accepted, this, placeholders::error));
  _threads.create_thread(bind(&Acceptor::wait,ref(*this)));
  return 0;
}
