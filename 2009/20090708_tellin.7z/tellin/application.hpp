/*
 * application.hpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */

#ifndef APPLICATION_HPP_
#define APPLICATION_HPP_
#include "pre_list.hpp"

class Application
{
  public:
    Application(int c, char **v)
      :worker(io),stop(false),argc(c),argv(v)
    {
    }
    int run();

  private:
    io_service       io;
    io_service::work worker;
    bool             stop;
    int              argc;
    char           **argv;
};

#endif /* APPLICATION_HPP_ */
