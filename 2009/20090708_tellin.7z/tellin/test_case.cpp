/*
 * test_case.cpp
 *
 *  Created on: 2009-9-7
 *      Author: bonly
 */
#define BOOST_TEST_MODULE MML_TEST
#include <boost/test/included/unit_test.hpp>

#include <iostream>
using namespace std;

#include "mml_base.hpp"
using namespace mml;

BOOST_AUTO_TEST_SUITE( MML_SUITE )

BOOST_AUTO_TEST_CASE( MML_Login )
{
  clog << "cmd length are not dobule of 4:\n";
  char buf[1024*8];
  bzero(buf,1024*8);
  char login[]="LOGIN: USER=test, PSWD=test1, NotifyServer=0;";
  int ret = mml::CMD::login("ZXWN1000","HLRAGENT",login,strlen((char*)login),buf,size_t(1024*8));
  BOOST_CHECK_EQUAL( ret, 120);

  hexdump (buf, ret);
}

BOOST_AUTO_TEST_CASE( MML_Login_1 )
{
  clog << "cmd length are dobule of 4:\n";
  char buf[1024*8];
  bzero(buf,1024*8);
  char login[]="LOGIN: USER=test, PSWD=test, NotifyServer=0;";
  int ret = mml::CMD::login("ZXWN1000","HLRAGENT",login,strlen((char*)login),buf,size_t(1024*8));
  BOOST_CHECK_EQUAL( ret, 120);

  hexdump (buf, ret);
}

BOOST_AUTO_TEST_CASE( MML_Logout )
{
  clog << "logout package:\n";
  char buf[1024*8];
  bzero(buf,1024*8);
  int ret = mml::CMD::logout((const char*)"ZXWN1000",(const char*)"HLRAGENT",
                             (const char*)"sessioid",245,(char*)buf,(const size_t)(1024*8));
  BOOST_CHECK_EQUAL( ret, 80);

  hexdump (buf, ret);
}

BOOST_AUTO_TEST_CASE( MML_PPS_DISP )
{
  clog << "DISP PPS userinfo:\n";
  char buf[1024*8];
  bzero(buf,1024*8);
  char disp[]="DISP PPS ACNTINFO: MSISDN=13719360007";
  int ret = mml::CMD::business("ZXWN1000","HLRAGENT","sessiond",83911,disp,strlen(disp),buf,size_t(1024*8));
  BOOST_CHECK_EQUAL( ret, 108);

  hexdump (buf, ret);
}
BOOST_AUTO_TEST_SUITE_END()
