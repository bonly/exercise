/*
 * mml_srv.cpp
 *
 *  Created on: 2009-9-4
 *      Author: bonly
 */

#include "deal.hpp"
#include "mml_base.hpp"

class Deal
{
  public:
    Deal():_mml(_io){}
    int run(int sock);
  private:
    io_service _io;
    MML_Stream _mml;

};

int
Deal::run(int sock)
{
  MML_Stream_Srv mml_srv(sock,_io);
  bool on_line=false;
  char session[8];
  sprintf(session,"%08x",getpid());

  for(int i=0; ; ++i)
  {
    int recv_len=0;
    if(0 >= (recv_len=mml_srv.recv()))
    {
      //todo: close mml if had connect
      clog << "nothing recv from ocs\n";
      return -1; //nothing recv from ocs
    }

    if(on_line==false)
    {
      clog << "recv Login:\n";
      hexdump(mml_srv._buffer,recv_len);
     //MML::parse();

      char buf[512];
      bzero (buf,512);
      char login_ack[]="ACK:LOGIN:RETN=000000,DESC=SUCCESS";
      int len = mml::CMD::login_ack(mml_srv._base.TERMINAL,mml_srv._base.SERVICE,session,atoi(mml_srv._base.TRANSACTION),
                                    login_ack,strlen((char*)login_ack),buf,512);
      mml_srv.send(buf,len);
      clog << "send Login ACK:\n";
      hexdump(buf,len);

      on_line=true;
    }
   else
   {
    //MML::parse();
    if(strstr(mml_srv._business,"LOGOUT")!=NULL)
    {
      clog << "recv Logout:\n";
      hexdump(mml_srv._buffer,recv_len);

      char buf[512];
      bzero (buf,512);
      char logout_ack[]="ACK:LOGOUT:RETN=000000,DESC=SUCCESS";
      int len = mml::CMD::logout_ack(mml_srv._base.TERMINAL,mml_srv._base.SERVICE,session,atoi(mml_srv._base.TRANSACTION),
                                          logout_ack,strlen((char*)logout_ack),buf,512);
      mml_srv.send(buf,len);
      clog << "send Logout ACK:\n";
      hexdump(buf,len);

      break;
    }
    else
    {
      clog << "recv Business:\n";
      hexdump(mml_srv._buffer,recv_len);

       //MML::Business::parse();
      char buf[512];
      bzero (buf,512);
      char bus_ack[]="ACK:DISP PPS ACNTINFO: RETN=000000,DESC=SUCESS,ATTR=,RESULT= ";
      int len = mml::CMD::business_ack(mml_srv._base.TERMINAL,mml_srv._base.SERVICE,session,atoi(mml_srv._base.TRANSACTION),
                                          bus_ack,strlen((char*)bus_ack),buf,512);
      mml_srv.send(buf,len);
      clog << "send Business ACK:\n";
      hexdump(buf,len);
    }

   }
clog << __FILE__ << __LINE__ << "\n";
  }
  return 0;
}

int
main(int argc, char* argv[])
{
  Deal deal;
  try
  {
    deal.run(atoi(argv[1]));
  }
  catch(...)
  {
    cerr << "args or system error\n";
  }
  return 0;
}
