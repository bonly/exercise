/*
 * pre.hpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */

#ifndef PRE_HPP_
#define PRE_HPP_

#include <boost/thread.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/foreach.hpp>
using namespace boost;
#include <boost/asio.hpp>
using namespace boost::asio;


#include <iostream>
#include <list>
using namespace std;


#endif /* PRE_HPP_ */
