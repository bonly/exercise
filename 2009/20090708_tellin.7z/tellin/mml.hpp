/*
 * mml.hpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */

#ifndef MML_HPP_
#define MML_HPP_
#include "pre_ocs.hpp"
#include <iostream>

#define MAXMEGLENG 1024*30
class MML
{
  public:
   MML();
   static int   Login(char* buf, const int len, const char *SmpUser, const char *SmpPass);

  public:
   int  Encode();
   int  FullSpace(char *ss, int len);
   int  CheckOut(char *tt);
   void rh_BlockXor(unsigned char *a, unsigned char *b, int length);
   void rh_BlockOpp(unsigned char *a ,int length);
   int  CheckDigit(char *ss );
   int  GetResult(char *in,char *out);
   int  CheckReqEcho();
   int  convatoA(char *ss);
   int  convXtoD(char *ss);
   int  WriteError(int type,char *desc);


  public:
   char   _MesBuf[MAXMEGLENG];
   char    MesStr[13][MAXMEGLENG];
   char    ConStr[20][500];
   char    WriteBuf[30*1024];
   int     RETN,TXEND;
   char    BeginFlag[10];
   char    DESC[200];
   long    TXId;
   char  *_OptMes;
};




#endif /* MML_HPP_ */
