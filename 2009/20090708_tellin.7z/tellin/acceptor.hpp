/*
 * acceptor.hpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */

#ifndef ACCEPTOR_HPP_
#define ACCEPTOR_HPP_
#include "pre_list.hpp"

class Acceptor
{
  public:
    Acceptor(io_service &io,bool &stop, const char* proc_name,
             const char* ip, const int port);
    int on_accepted(system::error_code const &e);
    int process();
    int run();
    int wait();

  private:
    io_service         &_io;
    ip::tcp::socket     _socket;
    ip::tcp::acceptor   _acceptor;
    thread_group        _threads;
    list<pid_t>         _pid;
    bool               &_stop;
    char                _proc_name[255];
};

#endif /* ACCEPTOR_HPP_ */
