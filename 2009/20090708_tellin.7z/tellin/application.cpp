/*
 * application.cpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */
#include "application.hpp"
#include "acceptor.hpp"


int
Application::run()
{
  Acceptor acc(io,stop,argv[1],argv[2],atoi(argv[3]));
  acc.run();
  while (true)
  {//todo: check signal for exit and reconfig
    io.run();
  }
  return 0;
}


int
main(int argc, char* argv[])
{
  Application app(argc,argv);
  try
  {
    app.run();
  }
  catch(...)
  {
    cerr << "Address already in use or args error\n";
    return -1;
  }
  return 0;
}

