/*
 * deal.hpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */

#ifndef DEAL_HPP_
#define DEAL_HPP_
#include "pre_ocs.hpp"
#include "mml_base.hpp"

class OCS_Stream
{
  public:
    OCS_Stream (ip::tcp::socket::native_type sock, io_service &io)
      :_io(io),_stream(io,ip::tcp::v4(),sock),_timer(io)
    {
    }
    ~OCS_Stream()
    {
      close();
    }

    void close(){ _stream.close();}
    void timeout(const system::error_code& e)
    {
      if (e != asio::error::operation_aborted)
      {cerr << "cecv timeout!\n";_stream.close();}
    }

    int send(const char* buf, const int len)
    {
      system::error_code ec;
      int slen = asio::write(_stream,buffer(buf,len),transfer_at_least(len),ec);
      if(ec)
      {
        cerr << "send fail: " << ec.message();
        return -1;
      }
     return slen;
    }

    void on_recv(const system::error_code &error)
    {
      if(error)
      {
        cerr << "recv error: "<< error.message() << "\n";
        close();
        return;
      }
      else
      {
        std::istream is(&_buf);
        getline(is, _str);
        //clog << _str ;
        _timer.cancel(); //cancel timeout after recveive cmd
      }
      /*
      {
      //tothink: or change timeout delay 3 seconds again? does't need
      async_read_until(_stream,_buf,'\n',
          boost::bind(&OCS_Stream::on_recv,this,placeholders::error));

      _timer.expires_from_now(posix_time::seconds(3));
      _timer.async_wait(bind(&OCS_Stream::timeout,this,placeholders::error));
      }
      */
    }

    int recv()
    {
      _io.reset();
      async_read_until(_stream,_buf,'\n',
          boost::bind(&OCS_Stream::on_recv,this,placeholders::error));

//      _timer.expires_from_now(posix_time::seconds(5));
//      _timer.async_wait(bind(&OCS_Stream::timeout,this,placeholders::error));

      system::error_code ec;
      _io.run(ec);
      if(ec)
       {
        cerr << "recv error: " << ec.message() << endl;
        return -1;
       }
      return _str.length();
    }

    string& str(){return _str;}
  private:
    io_service&      _io;
    ip::tcp::socket  _stream;
    asio::streambuf  _buf;
    deadline_timer   _timer;
    string           _str;
};

class MML_Stream
{
  public:
    MML_Stream (io_service &io)
     :_io(io),_stream(io),_timer(io)
     {
      bzero(_buffer,1024);
     }
    ~MML_Stream(){close();}

    void timeout(const system::error_code& e)
    {
      if (e != asio::error::operation_aborted)
      {cerr << "cecv timeout!\n";_stream.close();}
    }

    int connect(const char* ip, const int port)
    {
      try
      {
        ip::tcp::endpoint ep(
            ip::address::address::from_string(ip),port);


        system::error_code error;
        _stream.connect(ep,error);
        if (error)
        {
          cerr << "connect failure: " << error.message() << "\n";
          return -1;
        }
      }
      catch(...)
      {
       cerr << "address not correct!\n";
       return -1;
      }

      return 0;
    }

    bool is_open(){return _stream.is_open();}
    void close(){ _stream.close();}
    int send(const char* buf, const int len)
    {
      system::error_code ec;
      int slen = asio::write(_stream,buffer(buf,len),transfer_at_least(len),ec);
      if(ec)
      {
        cerr << "send fail: " << ec.message();
        return -1;
      }
     return slen;
    }

    int recv()
    {
      _io.reset();
      _msg_len = 0;
      async_read (_stream,buffer(_buffer,sizeof(mml::MML_BEGIN)),transfer_at_least(sizeof(mml::MML_BEGIN)),
                        boost::bind(&MML_Stream::recv_begin,this,placeholders::error,placeholders::bytes_transferred));

//      _timer.expires_from_now(posix_time::seconds(5));
//      _timer.async_wait(bind(&MML_Stream::timeout,this,placeholders::error));

      system::error_code ec;
      _io.run(ec);
      if(ec)
      {
        cerr << "recv error: " << ec.message() << endl;
        return -1;
      }
     return _msg_len;  //return total length of the package
    }

    void recv_begin(const system::error_code &error,size_t bytes_transferred)
    {
      _timer.cancel();
      size_t msg_begin_len = sizeof(mml::MML_BEGIN);

      if(error||bytes_transferred!=msg_begin_len)
      {
       if(error)
         cerr << "recv the begining of msg error: " << error.message() << endl;
       else
         cerr << "recv " << bytes_transferred << " byte need " << msg_begin_len << " byte, error!\n";
       close();
       return;
      }
      mml::MML_BEGIN begin;
      memcpy(&begin,_buffer,msg_begin_len);
      int len = 0; sscanf (begin.LEN,"%x",&len);

       _msg_len = len + msg_begin_len + sizeof(mml::MML_CRC);    // total_package_len = len + MML_BEGIN + CRC

       int least_len = len+sizeof(mml::MML_CRC);
       async_read (_stream, buffer(_buffer+msg_begin_len, least_len),transfer_at_least(least_len),
                     boost::bind(&MML_Stream::recv_done,this,placeholders::error,placeholders::bytes_transferred));
    }

    void recv_done(const system::error_code &error,size_t bytes_transferred)
    {
       if(error)
       {
         cerr << "recv main msg error: " << error.message() << endl;
         close();
         return ;
       }
      memcpy (&_base,_buffer,sizeof(mml::MML_base));
      int business_len = _msg_len - sizeof(mml::MML_base) - sizeof(mml::MML_CRC);
      memcpy (_business, _buffer+sizeof(mml::MML_base), business_len);
      memcpy (&_crc, _buffer+sizeof(mml::MML_base)+business_len, sizeof(mml::MML_CRC));

      clog << "recv done! total " << _msg_len << " byte\n";

    }

   void dump()
   {
     clog << "MML base: " << sizeof(mml::MML_base) << "\n";
     hexdump((char*)&_base,sizeof(mml::MML_base));
     int business_len = _msg_len - sizeof(mml::MML_base) - sizeof(mml::MML_CRC);
     clog << "Business: " << business_len << "\n";
     hexdump(_business,business_len);
     clog << "CRC:\n";
     hexdump((char*)&_crc,sizeof(mml::MML_CRC));
   }
  protected:
    io_service&      _io;
    ip::tcp::socket  _stream;
    deadline_timer   _timer;


  public:
    char             _buffer[MAXMEGLENG];
    mml::MML_base    _base;
    char             _business[MAXMEGLENG-sizeof(mml::MML_BEGIN)-sizeof(mml::MML_CRC)];
    mml::MML_CRC     _crc;
    size_t           _msg_len;

};

class MML_Stream_Srv : public MML_Stream
{//Simulation service
  public:
    MML_Stream_Srv (ip::tcp::socket::native_type sock, io_service &io)
       :MML_Stream::MML_Stream(io)
    {
      system::error_code ec;
      MML_Stream::_stream.assign(ip::tcp::v4(), sock, ec);
      if(ec)
      {
        cerr << "Init socket error: "<<ec.message() << endl;
      }
    }
    ~MML_Stream_Srv(){close();}
};


#endif /* DEAL_HPP_ */
