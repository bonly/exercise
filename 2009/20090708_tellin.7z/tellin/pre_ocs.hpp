/*
 * head.hpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */

#ifndef HEAD_HPP_
#define HEAD_HPP_
#include <iostream>
using namespace std;

#include <boost/bind.hpp>
using namespace boost;
#include <boost/asio.hpp>
using namespace boost::asio;


#endif /* HEAD_HPP_ */
