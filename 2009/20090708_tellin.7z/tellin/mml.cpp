/*
 * mml.cpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */
#include "mml.hpp"
int
MML::FullSpace(char *ss, int len)
{
  int i,j;
  ss[len] = 0;
  i = strlen(ss);
  if ( i == len )  return ( 0 );
  for( j=0;j<(len-i);j++ ) strcat(ss," ");
  return ( 0 );
}

/*
STSMP 1  10.245.32.81         �Է�IP
STSMP 2  19998                �Է��˿�
STSMP 3  SMP_BOSS_MAN         ���й�����
STSMP 4  BOSS_SMP.LQ          �������
STSMP 5  SMP_BOSS.LQ          Ӧ�����    ���Ӧ����д���Ϣ����ȡ����˴�дnull
STSMP 6  210008               ��ȡ����Corrleid
STSMP 7  30                   MQ��ʱʱ��
STSMP 8  `SC`                 Э�鿪ʼ��־
STSMP 9  1.00                 �汾��
STSMP 10 internal            �ն˱�ʶ
STSMP 11 zstest               ��½����
STSMP 12 15Boss89             ��¼����
STSMp 13 15                   TCP������
STSMP 14 120                  SMP���糬ʱʱ��
STSMP 15 /dev/null            ���Ժ��������ļ�
STSMP 16 180                  MQ��ϢʧЧʱ��
 */
MML::MML()
{
  bzero(_MesBuf,MAXMEGLENG);
  strcpy(MesStr[0],"SC");
}
int
MML::Encode()
{
  int  i,n,j;
  char tmp[2000];
  
  _MesBuf[0] = 0;
  
  strcpy(MesStr[0],ConStr[0]);
  strcpy(MesStr[2],ConStr[2]);
  strcpy(MesStr[3],ConStr[3]);

  FullSpace(MesStr[0],4);   FullSpace(MesStr[2],4);
  FullSpace(MesStr[3],8);   FullSpace(MesStr[4],8);
  FullSpace(MesStr[5],8);   FullSpace(MesStr[6],6);
  FullSpace(MesStr[7],4);   FullSpace(MesStr[8],8);
  FullSpace(MesStr[9],6);   FullSpace(MesStr[10],4);  

  
  n = strlen(MesStr[11]);    j = n%4;
  if ( j ) {
    for (i=0;i<(4-j);i++) strcat(MesStr[11]," ");
  }
  n = strlen(MesStr[11]);
  sprintf(MesStr[1],"%04X",n+56);
  
  tmp[0] = 0; 
  for ( i= 2;i<12;i++ ) strcat(tmp, MesStr[i]);
  tmp[n+56] = 0;  
  if ( CheckOut(tmp) ) {
    cerr << "crc error\n";
    return( -1 );
  } 

  strcpy(MesStr[12],tmp);   FullSpace(MesStr[12],8);
  
  for (i=0;i<13;i++) { 
    //printf("MesStr[%d]=:%s:",i,MesStr[i]);
    strcat(_MesBuf,MesStr[i]);
  }

  //todo: write log with time

  return strlen(_MesBuf);
}

int
MML::CheckOut(char *tt)
{

  unsigned char souce[MAXMEGLENG],buf[4];
  int  len,bnum;
  int  i,j;
  char tmp[100];

  len = strlen(tt);
  if ( len%4 ) {
    cerr <<"Length Error:"<< len;
    return ( -1 );
  }

  memcpy(souce,tt,len);
  bnum = len/4;

  memset(buf,0,4);
  for(i=0;i<bnum; i++) {
    j = i * 4;
    rh_BlockXor(souce+j,buf,4);
  }

  rh_BlockOpp(buf,4);

  tt[0]=0;
  for ( i=0;i<4;i++ ) {
    sprintf(tmp,"%X",(buf[i]>>4)&0XF);
    strcat(tt,tmp);
    sprintf(tmp,"%X",(buf[i])&0XF);
    strcat(tt,tmp);
  }

  tt[8]=0;
  return ( 0 );
}

void
MML::rh_BlockXor(unsigned char *a, unsigned char *b, int length)
{
  while (length--) { *(b++) ^= *(a++); }
}

void
MML::rh_BlockOpp(unsigned char *a ,int length)
{
  while ( length-- ) {
    *a = ~(*a); a++;
  }
}

int
MML::WriteError(int type,char *desc)
{
  sprintf(WriteBuf,"ACK:PROC SMP ERROR:RETN=%i, DESC=%s",type,desc);
  return( 0 );
}

int
MML::CheckReqEcho()
{
  char tmp[MAXMEGLENG];
  char *ss,*ss1;
  int  i;

  RETN = 9999;
  tmp[0] = 0;

  for ( i= 2;i<12;i++ ) strcat(tmp, MesStr[i]);
  if ( CheckOut(tmp) ) {
    clog << "CRC Error 2\n";
    WriteError(9999,"CRC Error 2");
    return( -1 );
  }

  if ( strncmp(MesStr[12],tmp,8) ) {
    clog << "CRC Error";
    WriteError(9999,"CRC Error");
    return( -1 );
  }

  if ( strstr(MesStr[9],"TXCON") )  { TXEND = 0; } else
  if ( strstr(MesStr[9],"TXEND") )  { TXEND = 1; } else{
    WriteError(9999,"Ctrol Field Error");
    printf("Ctrol Field Error:%s:",MesStr[9]);
    return( -1 );
  }

  printf("TXEND=:%d:",TXEND);
  convatoA(MesStr[11]);
  if ( strncmp(MesStr[0],BeginFlag,4) ) {
    printf("ACK Error, begin flag:%s:",MesStr[0]);
    WriteError(9999,"ACK Error");
    return ( -1 );
  }

  if ( strstr(MesStr[11],"ACK")==NULL ) {
    clog << ("ACK Error: not ACK package");
    WriteError(9999,"ACK Error: not ACK package");
    return ( -1 );
  }

  if ( strstr(MesStr[11],"GENERAL") ) {
    GetResult("RETN",tmp);
    printf("General Error:%s:",tmp);
    WriteError(9999,"GENERAL ERROR");
    return ( -1 );
  }

  if ( strstr(MesStr[11],"RETN")==NULL ) {
    clog << ("ACK Error: not RETN package");
    WriteError(9999,"ACK Error: not RETN package");
    return ( -1 );
  }

  if ( GetResult("RETN",tmp) ) {
    clog << ("ACK Error: RETN is NULL");
    WriteError(9999,"ACK Error: RETN is NULL");
    return ( -1 );

  }

  if ( CheckDigit(tmp) ) {
    clog << ("ACK Error: RETN is't NUM");
    WriteError(9999,"ACK Error: RETN is't NUM");
    return ( -1 );
  }

  RETN = atoi (tmp);
  if ( GetResult("DESC",DESC) ) strcpy(DESC," ");
//  DeleteAssistant(DESC);

  strcpy(tmp,MesStr[8]); //DeleteSpace(tmp);
  convatoA(tmp);         convXtoD(tmp);
  if ( atoi(tmp) != TXId ) {
    printf("ACK Error: package ID wrong(%d,%d)",atoi(tmp),TXId);
    WriteError(9999,"ACK Error: package ID wrong");
    return ( -1 );
  }

  return ( 0 );
}

int
MML::convXtoD(char *ss)
{
  int len,i,j;
  char tmp[20];
  long l=0;
  //DeleteSpace(ss);
  len = strlen(ss);
  convatoA(ss);
  for (i=0;i<len;i++) {
    if ( strchr("0123456789",ss[i]) ) {
      sprintf(tmp,"%c",ss[i]);
      l = atoi(tmp)+l*16;
      continue;
    } else if ( strchr("ABCDEF",ss[i]) ) {
      j = 10+ss[i]-'A';
      l = j+l*16;
    } else return ( -1 );
  }

  sprintf(ss,"%d",l);
  return ( 0 );
}

int
MML::convatoA(char *ss)
{
  char len,i;
  len = strlen(ss);
  for (i=0;i<len;i++) {
    ss[i] = islower(ss[i])?toupper(ss[i]):ss[i];
  }

  return ( 0 );
}

int
MML::GetResult(char *in,char *out)
{
  char *ss,*ss1;
  char tmp_in[100],tmp_buf[MAXMEGLENG];
  int  len,i;

  strcpy(out," ");
  strcpy(tmp_in,in);
  strcpy(tmp_buf,_OptMes);
  //DeleteSpace(tmp_in);
  len = strlen(tmp_in);

  if ( (ss=strstr(tmp_buf,tmp_in))==NULL ) {
    //strtmpmeg.assign(tmp_buf);
    //shieldpasswd(strtmpmeg);
    printf("result:%s:does't has:%s:",tmp_buf,tmp_in);
    return ( -1 );
  }

  if ( ss[len] != '=' ) {
    //strtmpmeg.assign(tmp_buf);
    //shieldpasswd(strtmpmeg);
    printf("result:%s:Format,Param:%s:Need=",tmp_buf,tmp_in);
    return ( 1 );
  }

  if ( (ss1=strchr(ss,','))==NULL ) strcpy(out,ss+len+1);
  else { *ss1 = 0; strcpy(out,ss+len+1); }
  return ( 0 );
}

int
MML::CheckDigit(char *ss )
{

  int  len,i;

  //DeleteSpace(ss);
  len = strlen(ss);
  for(i=0;i<len;i++) {
    if ( isdigit(ss[i]) ) continue;
    return ( -1 );
  }

  return ( 0 );
}

int
MML::Login(char* buf, const int len, const char *SmpUser="smpuser", const char *SmpPass="smppass")
{
  MML mml;
  mml.TXId = 1;
  strcpy(mml.MesStr[4],"SRVM");
  strcpy(mml.MesStr[5],"00000000");
  strcpy(mml.MesStr[6],"DLGLGN");
  sprintf(mml.MesStr[8],"%08X",mml.TXId);
  strcpy(mml.MesStr[9],"TXBEG");
  sprintf(mml.MesStr[11],"LOGIN: USER=%s, PSWD=%s",SmpUser,SmpPass);

  int ilen = mml.Encode();
  if(ilen>len) return -1;
  bzero(buf,len);
  memcpy(buf,mml._MesBuf,ilen);

  return ilen;
}
