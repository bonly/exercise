/*
 * deal.cpp
 *
 *  Created on: Aug 31, 2009
 *      Author: bonly
 */
#include "deal.hpp"

class Deal
{
  public:
    Deal():_mml(_io){}
    int run(int sock);
  private:
    io_service _io;
    MML_Stream _mml;

};

int
Deal::run(int sock)
{
  OCS_Stream ocs(sock,_io);
  static char session_id[8];
  static int  tran_id=1;

  for(int i=0; ;++i)
  {
    int recv_len=0;
    if(0 >= (recv_len=ocs.recv()))
    {
      //todo: close mml if had connect
      clog << "nothing recv from ocs\n";
      return -1; //nothing recv from ocs
    }

    clog << __FILE__ << __LINE__ << "\n";
    //OCS::parse();

    //todo: logout and then close _mml?

    if(!_mml.is_open())
    {
      if(0!=_mml.connect("127.0.0.1",9999))
      {
        clog << "connect MML server failure: Connection refused\n";
        string ret("ACK:LOGIN:RETN=999999,DESC=MML SERVICE CONNECTION REFUSED");
        ocs.send(ret.c_str(),ret.length());
        return -1;
      }

     char buf[512];
     bzero (buf,512);
     char login[]="LOGIN: USER=test, PSWD=test1, NotifyServer=0;";
     int len = mml::CMD::login("ZXWN1000","HLRAGENT",login,strlen((char*)login),buf,size_t(1024*8));
     _mml.send(buf,len);
     clog << "send Login:\n";
     hexdump(buf,len);

     if(0>=(recv_len=_mml.recv()))
      {
        clog << "recv Login ACK error\n";
        string ret("ACK:LOGIN:RETN=999999,DESC=RECV LOGIN ACK ERROR");
        ocs.send(ret.c_str(),ret.length());
        return -2;
      }
     strncpy(session_id, _mml._base.SESSION,8);
     tran_id++;
     clog << "recv Login ACK: \n";
     hexdump(_mml._buffer,recv_len);
    }

    //*
   {//check if ocs logout
     if(strncmp(ocs.str().c_str(),"LOGOUT",6)==0)
     {
       char buf[512];
       bzero (buf,512);
       int len = mml::CMD::business("ZXWN1000","HLRAGENT",_mml._base.SESSION,tran_id++,
                              ocs.str().c_str(),ocs.str().length(),buf,512);
       _mml.send(buf,len);
       clog << "send Logout: \n";
       hexdump(buf,len);

       if(0>=(recv_len=_mml.recv()))
        {
         clog << "recv Logout ACK error\n";
         string ret("ACK:LOGOUT:RETN=999999,DESC=RECV LOGOUT ACK ERROR");
         ocs.send(ret.c_str(),ret.length());
         return -3;
        }
       tran_id++;
       clog << "recv LOGOUT ACK: \n";
       hexdump(_mml._buffer,recv_len);
       _mml.close();
       ocs.close();

       return 0;
     }
    }//*/

    {
    //MML::encode();
    char buf[512];
    bzero (buf,512);
    int len = mml::CMD::business("ZXWN1000","HLRAGENT",_mml._base.SESSION,tran_id++,
                           ocs.str().c_str(),ocs.str().length(),buf,512);
    _mml.send(buf,len);
    clog << "send Business: \n";
    hexdump(buf,len);
    }

    {
    if(0>=(recv_len=_mml.recv()))
     {
      clog << "recv Business ACK error\n";
      string ret("ACK:BUSINESS:RETN=999999,DESC=RECV BUSINESS ACK ERROR");
      ocs.send(ret.c_str(),ret.length());
      return -3;
     }
    tran_id++;
    clog << "recv Business ACK: \n";
    hexdump(_mml._buffer,recv_len);
    }
  }
  return 0;
}


int
main(int argc, char* argv[])
{
  Deal deal;
  try
  {
    deal.run(atoi(argv[1]));
  }
  catch(system::error_code &e)
  {
    cerr << "socket error: " << e.message() << endl;
  }
  catch(...)
  {
    cerr << "argv or system error\n" << endl;
  }

  return 0;
}
