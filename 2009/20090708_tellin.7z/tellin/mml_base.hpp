/*
 * mml_base.hpp
 *
 *  Created on: 2009-9-7
 *      Author: bonly
 */

#ifndef MML_BASE_HPP_
#define MML_BASE_HPP_
#include <string>
using namespace std;

void  _hex(unsigned char c, char* s);
char* _hexdump16bytes(char* p, size_t& nBegin, size_t& nLeft);
void   hexdump(char* buf, const size_t len);

#define MAXMEGLENG 8000

namespace mml
{
struct MML_BEGIN
{
    char SC[4];
    char LEN[4]; //message_head + session_head + transaction_head + business_msg
};
struct MML_base :public MML_BEGIN
{
    //message head
    char VERSION[4];
    char TERMINAL[8];
    char SERVICE[8];

    //session head
    char SESSION[8];
    char SES_CTRL[6];
    char SES_BACKUP[4];

    //transaction head
    char TRANSACTION[8];
    char TRAN_CTRL[6];
    char SCOPE[2];
    char TRAN_BACKUP[2];

    MML_base();
};

struct MML_CRC
{
    //CRC
    char CRC[8];

    MML_CRC();
    int    crc(const char *tt,const size_t length);
    void   rh_BlockXor(unsigned char *a, unsigned char *b, int num);
    void   rh_BlockOpp(unsigned char *a, int num);
};

class CMD
{
  public:
    static int encode(MML_base &base, const char *cmd, const size_t clen, char *buf, const size_t blen);

    static int login(const char* terminal, const char* service, const char *cmd, const size_t clen,
                     char *buf, const size_t blen);
    static int login_ack(const char* terminal, const char* service, const char* session, const int tran_id,
                     const char *cmd, const size_t clen, char *buf, const size_t blen);

    static int logout(const char* terminal, const char* service, const char* session_id, const int tran_id,
                      char * buf, const size_t blen);
    static int logout_ack(const char* terminal, const char* service, const char* session_id, const int tran_id,
                      const char *cmd, const size_t clen, char * buf, const size_t blen);

    static int business(const char* terminal, const char* service, const char* session_id, const int tran_id,
                        const char* cmd, const size_t clen, char* buf, const size_t blen);
    static int business_ack(const char* terminal, const char* service, const char* session_id, const int tran_id,
                        const char* cmd, const size_t clen, char* buf, const size_t blen);
};
}
#endif /* MML_BASE_HPP_ */
