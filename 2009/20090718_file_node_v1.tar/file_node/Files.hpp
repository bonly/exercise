/*
 * Files.hpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 */

#ifndef FILES_HPP_
#define FILES_HPP_
#include "pre.hpp"
#include "ace/OS.h"
#include "ace/Mutex.h"
#include "ace/Guard_T.h"
#include "Interface.hpp"

typedef map<string,CRequestFlowObj*> TRecord;
typedef pair<string,CRequestFlowObj*>  Tmp;
class File
{
  public:
    string ifile_name;
    string ofile_name;
    int iline;
    int irecord;
    int orecord;
    time_t recv_time;
    time_t send_time;
    bool read_done;
    bool write_done;
    ifstream ifile;
    ofstream ofile;
    TRecord  record;

  public:
    int //取得一个记录对象
    get_obj (char *buf, int size);
    bool //检查文件是否读取完毕
    chk_read_done();
    void //标记增加一条发送记录
    inc_irecord(Tmp &mp);
    void //标记增加一条结果记录
    inc_orecord();
    int //删除文件
    remove_file();
};

class oper_file_finished
{
  public:
  bool operator()(shared_ptr<File> &f) const
  {
    if(f->read_done==true && f->write_done ==true && f->irecord==f->orecord)
      return true;
    else
      return false;
  }
};

class Files
{
  public:
    bool //检查是否能访问
    is_exists(const char* pfile);
    int //扫描目录
    dir(const char* pdir, const char* namelike);
    int //取工作数据
    get_data(char *buf, int siz);
    void //标识增加完成一条记录
    record_done(pair<string,CRequestFlowObj*>);
    shared_ptr<File> //根据流水号中的文件标识查找源文件
    search_qry(const char*);
    int //清除完成的文件
    remove_done();
    int //标识增加完成一条结果记录
    inc_orecord(shared_ptr<File> &file);

  public:
    list<shared_ptr<File> > files;
    TRecord  record;

  private:
    ACE_Thread_Mutex _mutex;
    shared_ptr<File> _cur_file;

  private:
    shared_ptr<File> //取得要操作的文件对象
    get_not_done_file();
};

#endif /* FILES_HPP_ */
