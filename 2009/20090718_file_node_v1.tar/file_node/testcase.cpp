/*
 * testcase.cpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 */
// build ace in linux:
//g++ -fvisibility=hidden -fvisibility-inlines-hidden -W -Wall -Wpointer-arith
//-O3 -ggdb -pipe -D_REENTRANT -DACE_HAS_AIO_CALLS -D_GNU_SOURCE
//-DACE_HAS_EXCEPTIONS -D__ACE_INLINE__ -DACEXML_PARSER_BUILD_DLL  -c -fPIC

#define BOOST_TEST_MODULE FILE_NODE_TEST
#include "pre.hpp"
#include <boost/test/included/unit_test.hpp>
#include <boost/foreach.hpp>
#include <iostream>
using namespace std;

#include "Files.hpp"

BOOST_AUTO_TEST_SUITE(FILES_SUITE)

BOOST_AUTO_TEST_CASE(CREATE_FILE_OBJ)
{
  clog << "test for create file obj\n";
  Files fi;
  int ret = fi.dir("/tmp","ssh");
  if(fi.files.size() >=1 && ret == 0)
  {
    BOOST_FOREACH(shared_ptr<File>  f, fi.files)
    {
      clog << "get a file: " << f->ifile_name.c_str() << endl;
      //clog << "ptr count: " << f.count() << endl;
    }
    BOOST_CHECK( fi.files.size() == 1 );
  }
}

BOOST_AUTO_TEST_SUITE_END()

BOOST_AUTO_TEST_SUITE(MASTER_SUITE)
//#include "Master.hpp"
/*//不能用以测试
BOOST_AUTO_TEST_CASE(THREAD_TEST)
{
  ACE_DEBUG
    ((LM_DEBUG, ACE_TEXT ("(%t) Main Thread running\n")));

  Master handler;
  int result = handler.activate ();
  ACE_ASSERT (result == 0);

  handler.wait ();
}
//*/
BOOST_AUTO_TEST_SUITE_END()


BOOST_AUTO_TEST_SUITE(RECV_SUITE)
/*//不能用以测试
#include "Receive.hpp"
BOOST_AUTO_TEST_CASE(RECV_THREAD_TEST)
{
  extern CNodeClient NodeClient;
  //bool bRun = true;

  CNodeEventHandlerBase * pEventHandler = new CClientEventHandler();
  NodeClient.SetEventHandler(pEventHandler);

  //启动节点
  if(! NodeClient.Active( "TestClientNode", "10.0.0.23", 12345 ))
  {
    ACE_DEBUG((MY_INFO ACE_TEXT("Deduct node start failed.\n")));
    return;
  };
  ACE_Thread_Manager::instance()->wait();
  delete pEventHandler;
}*/
BOOST_AUTO_TEST_SUITE_END()

