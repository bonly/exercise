/*
 * Receive.cpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 */

#include "Receive.hpp"
#include "Files.hpp"

extern Files job;
extern shared_ptr<Parser> parser;

CNodeClient NodeRecv;
extern CRequestManager MsgManager;

int
Receive::svc(void)
{
  CNodeEventHandlerBase * pEventHandler = &EventHandler;
  NodeRecv.SetEventHandler(pEventHandler);
  NodeRecv.SetRequestManager(&MsgManager);
  //启动节点
  if(! NodeRecv.Active( "FileRecvNode", "127.0.0.1", 5000 ))
  {
    ACE_DEBUG((MY_INFO ACE_TEXT("Deduct node start failed.\n")));
    return -1;
  };

  return 0;
}

bool
CClientEventHandler::OnAnswerRequestFlow(CRequestFlowObj & RequestObj)
{
  clog << "in OnAnswerRequestFlow ====\n" <<  endl;
  Work_item *item = 0;
  char key[50];
  parser->get_ret_key(&RequestObj, "COMMSERIAL", key);
  parser->parse_ret(&RequestObj,item); //解压结果包
  shared_ptr<File> src = job.search_qry(key);//查找发送内容中相应的文件内容
  if(src.get()==NULL) //找不到源
  {
    clog << "cann't found src\n";
    return true;
  }
  clog << "found src ====\n" <<  endl;
  char bill[255];
  item->create_line(1,bill);//创建输出到话单的行记录内容
  //输出记录到文件
  clog << "the bill is: "<< bill << endl;
  delete item;

  return true;
}

/*
int ACE_TMAIN(int argc, ACE_TCHAR **argv)
{
  bool bRun = true;

 CNodeEventHandlerBase * pEventHandler = new CClientEventHandler();
 NodeClient.SetEventHandler(pEventHandler);

 //启动节点
 if(! NodeClient.Active( "FileClientNode", "127.0.0.1", 12345 ))
 {
   ACE_DEBUG((MY_INFO ACE_TEXT("Deduct node start failed.\n")));
   return -1;
 };
 ACE_Thread_Manager::instance()->wait();
 delete pEventHandler;
 return 0;
}
//*/
