/*
 * Master.hpp
 *
 *  Created on: 2010-1-26
 *      Author: bonly
 */

#ifndef MASTER_HPP_
#define MASTER_HPP_
#include "ace/Task.h"

class Master : public ACE_Task_Base
{
  public:
    virtual int svc (void);
};

#endif /* MASTER_HPP_ */
