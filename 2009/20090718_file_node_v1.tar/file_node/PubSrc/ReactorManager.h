// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\ReactorManager.h
//     Author : Bambo Huang
//    Purpose : ��ACE��� Reactor ʹ�õ�һ�����߿⣬���������ڲ�ͬϵͳ
//              ��ʹ�ò�ͬ�ķ�Ӧ���������� Reactor ��Ϣѭ���������߳�
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************

#ifndef __REACTORMANAGER_H__
#define __REACTORMANAGER_H__
#include "Defs.h"
#include "ReactorPoolThread.h"

class CReactorManager
{
friend class ACE_Singleton<CReactorManager, ACE_Recursive_Thread_Mutex>;
protected:
	CReactorManager(void);
	~CReactorManager();
public:
	int Run(void);
	int Stop(void);
private:
	bool m_bIsManagerRunning;
	CReactorPoolThread * m_pReactorThread;
#if defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
	ACE_Dev_Poll_Reactor * m_pReactorImpl;
#else
	ACE_TP_Reactor * m_pReactorImpl;
#endif //defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
	ACE_Reactor    * m_pReactor;
	ACE_Thread_Mutex m_Lock;
};

typedef ACE_Singleton<CReactorManager, ACE_Recursive_Thread_Mutex> ReactorManager;

#endif //__REACTORMANAGER_H__
