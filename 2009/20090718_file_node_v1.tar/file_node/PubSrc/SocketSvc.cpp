// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc/SocketSvc.cpp
//     Author : Bambo Huang
//    Purpose : Socket����Ϣ��������Ĵ������࣬��װ��һЩ����
// ****************************************************************************
// Update histories:
//
//  05/16/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
//  08/16/2007: By Bambo Huang
//              ����ע��
// ****************************************************************************
#include "SocketSvc.h"

CSocketSvc::CSocketSvc()
{
	m_bIsConnected = false;
}

int CSocketSvc::open (void *p )
{
	if( super::open(p) == -1)
	{
		return -1;
	}
	m_ConnectTimerHandler = new CConnectTimerHandler();
	m_ConnectTimerHandler->m_SocketHandle = peer().get_handle();
	ACE_Time_Value initialDelay (10); // ������10�����û��Ӧ�ͶϿ�����
	ACE_Reactor::instance()->schedule_timer(m_ConnectTimerHandler, 0, initialDelay);
	m_bIsConnected = true;
	if( this->peer().get_remote_addr(m_PeerAddr) == 0 &&
		m_PeerAddr.addr_to_string(m_szPeerName, MAXHOSTNAMELEN) == 0 )
	{
		ACE_DEBUG ((MY_DEBUG ACE_TEXT("Connection established from remote %s.\n"),
			m_szPeerName
			));
	}
	return on_open(p);
}

int CSocketSvc::handle_input (ACE_HANDLE fd )
{
	ACE_Reactor::instance()->cancel_timer(m_ConnectTimerHandler);
	return do_handle_input(fd);
}

int CSocketSvc::handle_output (ACE_HANDLE fd )
{
	return do_handle_output(fd);
}

int CSocketSvc::handle_close (ACE_HANDLE handle,
				  ACE_Reactor_Mask close_mask)
{
	if(close_mask == ACE_Event_Handler::TIMER_MASK)
	{
		return 0;
	}
	if (m_bIsConnected)
	{
		on_close(handle, close_mask);
		ACE_DEBUG ((MY_DEBUG ACE_TEXT("Connection closed from %s.\n"),
			m_szPeerName
			));
		m_bIsConnected = false;
	}
	return super::handle_close(handle, close_mask);
}

int CSocketSvc::HandleRecvResult(int nRecvCount)
{
	if( nRecvCount == 0)
	{
		ACE_DEBUG((MY_DEBUG ACE_TEXT("Connection closed by remote %s.\n"),
			m_szPeerName
			));
		return -1;
	}
	else if( nRecvCount == -1 )
	{
		if ( errno == EWOULDBLOCK)
		{	// In multithread enviroment, other thread may handling data,
			// so can check errno if it is EWOULDBLOCK
			return 0;
		}
		else if ( errno == ETIME)
		{
			return 0;
		}
		// ��Linux �У�Connection reset by peer���ᴥ��handle_close�¼����������´���
		if( errno == ECONNRESET)
		{
			// ��һ��Exception��֪ͨ
			handle_close(this->get_handle(), EXCEPT_MASK );
		}
		return -1;
	}
	return 0;
}

