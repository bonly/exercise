// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\Defs.h
//     Author : Bambo Huang
//    Purpose : ���õĺ궨���ͷ�ļ�����
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************

#ifndef __DEFS_H__
#define __DEFS_H__

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <list>
using namespace std;

////////////////////////////////////////////////////////////////////////////////
// Including ACE heads

#ifdef _DEBUG
#define ACE_NTRACE 1
#else
#define ACE_NTRACE 1
#endif

#include <ace/Assert.h>
#include <ace/Global_Macros.h>

#include <ace/OS.h>
#include <ace/OS_main.h>

#include <ace/Get_Opt.h>

#include <ace/Date_Time.h>

#include <ace/INET_Addr.h>
#include <ace/SOCK_Acceptor.h>
#include <ace/SOCK_Connector.h>
#include <ace/SOCK_Stream.h>

#include <ace/Task.h>
#include <ace/Thread_Manager.h>
#include <ace/Message_Block.h>

#include <ace/Svc_Handler.h>
#include <ace/Event_Handler.h>
#include <ace/TP_Reactor.h>
#include <ace/Reactor.h>

#include <ace/Acceptor.h>
#include <ace/Connector.h>

#include <ace/FILE_Connector.h>
#include <ace/FILE_IO.h>

#include <ace/SPIPE_Acceptor.h>
#include <ace/SPIPE_Connector.h>

#if defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
#include <ace/Dev_Poll_Reactor.h>
#endif //defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
////////////////////////////////////////////////////////////////////////////////
// Others basic heads

////////////////////////////////////////////////////////////////////////////////
// Macros

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

// ACE���Ժ��
#define MY_DEBUG      LM_DEBUG,     ACE_TEXT ("[DEBUG %T %P|%t] ")
#define MY_INFO       LM_INFO,      ACE_TEXT ("[INFO  %T %P|%t] ")
#define MY_ERROR      LM_ERROR,     ACE_TEXT ("[ERROR %T %P|%t] ")

// ��ʾ�����������������
#ifndef IN
#define IN
#endif // IN

#ifndef OUT
#define OUT
#endif // OUT

#endif //__DEFS_H__

