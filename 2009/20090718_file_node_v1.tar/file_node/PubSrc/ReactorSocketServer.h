// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\ReactorSocketServer.h
//     Author : Bambo Huang
//    Purpose : ���� ACE ��� Reactor ģ�͵� Socket �������ģ��
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************

#ifndef __REACTORSOCKETSERVER_H__
#define __REACTORSOCKETSERVER_H__

#include "Defs.h"
#include "ReactorManager.h"

template<class SOCKET_ACCEPTOR>
class CReactorSocketServer
{
public:
	CReactorSocketServer( u_short nPort )
		: m_ListenAddr( nPort )
	{

	}
	CReactorSocketServer(const char address[])
		: m_ListenAddr(address)
	{

	}
	CReactorSocketServer( const ACE_INET_Addr &SocketAddr)
		: m_ListenAddr(SocketAddr)
	{

	}
	~CReactorSocketServer(void){};
public:
	int Run(void)
	{
		ACE_TRACE("CReactorSocketServer::Run");

		if ( ReactorManager::instance()->Run() == -1)
		{
			return -1;
		}

		if( m_SocketAcceptor.open(m_ListenAddr) == -1 )
		{
			ACE_DEBUG((MY_ERROR ACE_TEXT("Listen failed on port: %u with %m\n"),
				m_ListenAddr.get_port_number()
				));
			return -1;
		}
		ACE_DEBUG((MY_INFO ACE_TEXT("Server started at port: %u\n"),
			m_ListenAddr.get_port_number()
			));
		return 0;
	}
	int Stop()
	{
		return ReactorManager::instance()->Stop();
	}
private:
	ACE_INET_Addr m_ListenAddr;
	SOCKET_ACCEPTOR m_SocketAcceptor;

	static CReactorPoolThread  *m_ReactorThreadPool;

};

#endif //__REACTORSOCKETSERVER_H__

