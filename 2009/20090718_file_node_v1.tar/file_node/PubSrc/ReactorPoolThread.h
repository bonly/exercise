// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\ReactorPoolThread.h
//     Author : Bambo Huang
//    Purpose : ACE��Reactor������Ϣѭ���߳���
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************

#ifndef __REACTORPOOLTHEAD_H__
#define __REACTORPOOLTHEAD_H__

#include "Defs.h"

class CReactorPoolThread :
	public ACE_Task_Base
{
public:
	CReactorPoolThread(ACE_Reactor *pReactor);
	~CReactorPoolThread(void);
public:
	int svc(void);
	void SetReactor(ACE_Reactor *pReactor);
private:
	ACE_Reactor *m_pReactor;
};

#endif //__REACTORPOOLTHEAD_H__

