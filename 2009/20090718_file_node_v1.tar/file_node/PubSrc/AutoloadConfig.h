#ifndef __AUTOLOADCONFIG_H__
#define __AUTOLOADCONFIG_H__
#include "../PubSrc/Defs.h"

class CAutoloadConfig
	: public ACE_Task<ACE_MT_SYNCH>
{
public  :
	int  Run(void);
	void Stop(void);
	void SetConfigFile(string strConfigFile)
	{
		m_strConfigFile = strConfigFile;
	}
public  :
	int LoadConfig(void)
	{
		ACE_Guard<ACE_Thread_Mutex> Guard(m_Lock);
		if ( LoadConfigInvoke() == 0 )
		{
			GetConfFileStat( m_ConfFileStat );
			return 0;
		}
		else
		{
			return -1;
		}
	}
protected:
	int GetConfFileStat( ACE_stat &ConfFileStat);
protected:
	ACE_stat m_ConfFileStat;
	ACE_Thread_Mutex m_Lock;
	string m_strConfigFile;
private :
	int svc(void);
	bool IsConfigFileChanged(void);
	virtual int LoadConfigInvoke(void) = 0;
	// ����б�Ҫ��֪ͨ����ģ����һЩ��Ҫ�Ķ���
	virtual int NotifyConfigChanged(void)
	{
		return 0;
	}
private :
	bool   m_bRunning;
};

#endif //__AUTOLOADCONFIG_H__
