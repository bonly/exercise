// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\Utilities.cpp
//     Author : Bambo Huang
//    Purpose : �����࣬�ṩ��һЩ�ַ��������Ĺ��ߡ����ܵĺ���
//              �Լ�һ��key/valueӳ�������ģ���ࣨ���ܵͣ��������ڴ�������ʹ�ã�
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************
#include "Utilities.h"

string CC::GetTagedTimeValue(const ACE_Date_Time &DateTime, char zTag)
{
	switch(zTag)
	{
	case '%':   //a literal %
		return "%";
	case 'a':   //locale's abbreviated weekday name (Sun..Sat)
		return CC::GetWDayName(DateTime.weekday());
	case 'A':   //locale's full weekday name, variable length (Sunday..Saturday)
		return CC::GetWDayNameL(DateTime.weekday()); ////Day of week (0-6; Sunday = 0)
	case 'b':   //locale's abbreviated month name (Jan..Dec)
		return CC::GetMonthName(DateTime.month());
	case 'B':   //locale's full month name, variable length (January..December)
		return CC::GetMonthNameL(DateTime.month());
	case 'd':   //day of month (01..31)
		{
			char zBuff[3];
			sprintf(zBuff, "%02d", DateTime.day());
			return zBuff;
		}
	case 'e':   //day of month, blank padded ( 1..31)
		{
			char zBuff[3];
			sprintf(zBuff, "%d", DateTime.day());
			return zBuff;
		}
//	case 'g':   //the 2-digit year corresponding to the %V week number
//	case 'G':   //the 4-digit year corresponding to the %V week number
	case 'h':   //same as %b
		return CC::GetMonthName(DateTime.month());
	case 'H':   //hour (00..23)
		{
			char zBuff[3];
			sprintf(zBuff, "%02d", DateTime.hour());
			return zBuff;
		}
	case 'I':   //hour (01..12)
		{
			char zBuff[3];
			sprintf(zBuff, "%02d", DateTime.hour() > 11 ? DateTime.hour() -11 : DateTime.hour() + 1);
			return zBuff;
		}
//	case 'j':   //day of year (001..366)
	case 'k':   //hour ( 0..23)
		{
			char zBuff[3];
			sprintf(zBuff, "%02d", DateTime.hour());
			return zBuff;
		}
	case 'l':   //hour ( 1..12)
		{
			char zBuff[3];
			sprintf(zBuff, "%02d", DateTime.hour() > 11 ? DateTime.hour() -11 : DateTime.hour() + 1);
			return zBuff;
		}
	case 'm':   //month (01..12)
		{
			char zBuff[3];
			sprintf(zBuff, "%02d", DateTime.month());
			return zBuff;
		}
	case 'M':   //minute (00..59)
		{
			char zBuff[3];
			sprintf(zBuff, "%02d", DateTime.minute());
			return zBuff;
		}
	case 'p':   //locale's upper case AM or PM indicator (blank in many locales)
		return DateTime.hour() > 11 ? "PM" : "AM";
	case 'P':   //locale's lower case am or pm indicator (blank in many locales)
		return DateTime.hour() > 11 ? "pm" : "am";
	case 'S':   //second (00..60); the 60 is necessary to accommodate a leap second
		{
			char zBuff[3];
			sprintf(zBuff, "%02d", DateTime.second());
			return zBuff;
		}
	case 'u':   //day of week (1..7);  1 represents Monday
		{
			char zBuff[2];
			sprintf(zBuff, "%d", DateTime.weekday() > 6 ? 1 : DateTime.weekday() < 0 ? 1 : DateTime.weekday() + 1 );
			return zBuff;
		}
//	case 'U':   //week number of year with Sunday as first day of week (00..53)
//	case 'V':   //week number of year with Monday as first day of week (01..53)
	case 'w':   //day of week (0..6);  0 represents Sunday
		{
			char zBuff[2];
			sprintf(zBuff, "%d", DateTime.weekday() > 6 ? 0 : DateTime.weekday() < 0 ? 0 : DateTime.weekday() );
			return zBuff;
		}
//	case 'W':   //week number of year with Monday as first day of week (00..53)
	case 'y':   //last two digits of year (00..99)
		{
			char zBuff[5];
			sprintf(zBuff, "%04d", DateTime.year() > 9999 ? 0 : DateTime.year() < 0 ? 0 : DateTime.year() );
			return zBuff + 2;
		}
	case 'Y':   //year (1970...)
		{
			char zBuff[5];
			sprintf(zBuff, "%04d", DateTime.year() > 9999 ? 0 : DateTime.year() < 0 ? 0 : DateTime.year() );
			return zBuff;
		}
	default:
		return "";
	}
}

char CCryptUtil::CharBase[]={	'0','1','2','3','4','5','6','7','8','9',
'A','B','C','D','E','F','G','H','I','J',
'K','L','M','N','O','P','Q','R','S','T',
'U','V','W','X','Y','Z','<','>','%','$','&'};

int CCryptUtil::GetCharIndex(char c)
{
	for(int i=0; i<41; i++)
	{
		if(c == CharBase[i])
		{
			return i;
		}
	}
	return 0;
}


string CCryptUtil::Encrypt(const string &Value, u_int Seed )
{
	if(Value.length() == 0)
	{
		return "";
	}
	string lValue = Value;
	int nMove[4]={2,3,5,7};
	string Key="";
	char nSeed[4];
	nSeed[0] = Seed >> 24;
	nSeed[1] = Seed >> 16 & 0xFF;
	nSeed[2] = Seed >> 8 & 0xFF;
	nSeed[3] = Seed & 0xFF;
	int nStrLen = static_cast<int>(lValue.length());
	if(nStrLen%2)nStrLen++;
	char *Buff = new char[nStrLen];
	char *Buff2= new char[nStrLen];
	char *Buff3= new char[nStrLen/2*3+1];
	Buff3[nStrLen/2*3] = 0;
	ACE_OS::memcpy(Buff,lValue.c_str(),nStrLen);
	int n,i;
	u_short k;
	for (i=0,n=0; i<nStrLen; i++)
	{
		Buff[i]^=nSeed[n];
		n++;
		if( n >= 3 ) n -= 3;
	}

	for(i=0, n=0; i< nStrLen; i++)
	{
		char t = ( Buff[0] << nMove[n] ) | ( ( Buff[0] & 0xFF ) >> (8 - nMove[n]) ) ;
		for(int j=1; j< nStrLen; j++)
		{
			Buff[j] ^= t;
		}
		ACE_OS::memcpy(Buff2,Buff+1,nStrLen-1);
		Buff2[nStrLen-1] = t;
		ACE_OS::memcpy(Buff,Buff2,nStrLen);
		n++;
		if(n > 3) n = 0;
	}

	for(i=0; i<nStrLen/2; i++)
	{
		k = ( Buff[i*2] << 8 ) | ( Buff[i*2+1] ) & 0xFF;
		k += (Seed * (i+1)) % 68921-65536;

		Buff3[i*3]=k%41;
		k-=Buff3[i*3];
		Buff3[i*3]=CharBase[static_cast<int>(Buff3[i*3])];
		k/=41;
		Buff3[i*3+1]=k%41;
		k-=Buff3[i*3+1];
		Buff3[i*3+1]=CharBase[static_cast<int>(Buff3[i*3+1])];
		k/=41;
		Buff3[i*3+2]=CharBase[k];
	}
	Key = Buff3;
	delete []Buff;
	delete []Buff2;
	delete []Buff3;
	return Key;
}

string CCryptUtil::Encrypt(const string &Value, const string &Seed)
{
	return Encrypt(Value,Hash(Seed));
}

string CCryptUtil::Decrypt(const string &Key,   u_int Seed )
{
	if(Key.length() < 3)
	{
		return "";
	}
	string lKey = CC::MakeUpper(Key);
	int nMove[4]={2,3,5,7};
	char nSeed[4];
	nSeed[0] = Seed >> 24;
	nSeed[1] = Seed >> 16 & 0xFF;
	nSeed[2] = Seed >> 8 & 0xFF;
	nSeed[3] = Seed & 0xFF;
	int nStrLen = static_cast<int>(lKey.length()) / 3 * 2;
	char * Buff = new char[nStrLen];
	char * Buff2 = new char[nStrLen+1];
	const char * p = lKey.c_str();
	int i;
	u_short k;
	for(i=0; i< nStrLen /2; i++)
	{
		k = GetCharIndex(*p);p++;
		k += GetCharIndex(*p)*41;p++;
		k += GetCharIndex(*p)*41*41;p++;
		k -= (Seed * (i+1)) % 68921-65536;
		Buff[2*i] = k >>8 & 0xFF;
		Buff[2*i+1] = k & 0xFF;
	}
	int n;
	for( i =0, n = nStrLen % 4 ; i< nStrLen; i++)
	{
		n--;
		if( n <0 ) n = 3;
		ACE_OS::memcpy(Buff2+1,Buff,nStrLen-1);
		Buff2[0]=Buff[nStrLen-1];
		ACE_OS::memcpy(Buff,Buff2,nStrLen);
		char t = Buff[0];
		for(int j=1; j< nStrLen; j++)
		{
			Buff[j] ^= t;
		}
		Buff[0] = ( ( t & 0xFF ) >> nMove [n] ) | ( t << ( 8-nMove[n] ) );
	}
	for (i=0,n=0; i<nStrLen; i++)
	{
		Buff[i]^=nSeed[n];
		n++;
		if( n >= 3 ) n -= 3;
	}
	ACE_OS::memcpy(Buff2,Buff,nStrLen);
	Buff2[nStrLen]=0;
	string Value=Buff2;
	delete []Buff;
	delete []Buff2;
	return Value;
}

string CCryptUtil::Decrypt(const string &Key,   const string &Seed)
{
	return Decrypt(Key,Hash(Seed));
}

u_int CCryptUtil::Hash(const string &Src)
{
	const char *p = Src.c_str();
	u_int n=0xFB73D951;
	u_int t;
	while (*p)
	{
		t = *p;
		n ^= t;
		t = n >> 29;
		n <<= 3;
		n = n | t;
		p++;
	}
	return n;
}

