// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\GWExceptions.h
//     Author : Bambo Huang
//    Purpose : �쳣�࣬���ǵ������ԣ�û�õ��쳣
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************

#ifndef __GWEXCEPTION_H__
#define __GWEXCEPTION_H__

#include "Defs.h"

class CBaseException
{
public:
	CBaseException(string strMessage = "Base exception.")
		: m_strMessage(strMessage)
	{}
	CBaseException(const CBaseException &e)
	{
		m_strMessage = e.m_strMessage;
	}
	virtual ~CBaseException() throw(){};
public:
	virtual string getMessage() const{return m_strMessage;}
	virtual void operator=(const CBaseException &other)
	{
		m_strMessage = other.m_strMessage;
	}
private:
	string m_strMessage;
};
#endif //__GWEXCEPTION_H__

