#include "AutoloadConfig.h"

int  CAutoloadConfig::Run(void)
{
	if (thr_count_ == 0)
	{
		if(LoadConfig() != 0)
		{
			return -1;
		}
		activate( THR_NEW_LWP | THR_JOINABLE );
	}
	return 0;
}

void CAutoloadConfig::Stop(void)
{
	m_bRunning = false;
}

int CAutoloadConfig::svc(void)
{
	m_bRunning = true;
	while ( m_bRunning )
	{
		if (IsConfigFileChanged())
		{
			ACE_DEBUG((MY_DEBUG ACE_TEXT("Configure file changed, reload.\n")));
			LoadConfig();
		}
		// ÿ���ѯ�����ļ��Ƿ�䶯
		ACE_OS::sleep(1);
	}
	return 0;
}

bool CAutoloadConfig::IsConfigFileChanged(void)
{
	ACE_stat FileStat;
	if (GetConfFileStat(FileStat) == 0)
	{
		if (FileStat.st_ctime != m_ConfFileStat.st_ctime
			|| FileStat.st_mtime != m_ConfFileStat.st_mtime)
		{
			return true;
		}
	}
	return false;
}

int CAutoloadConfig::GetConfFileStat( ACE_stat &ConfFileStat)
{
	ACE_FILE_IO File;
	ACE_FILE_Connector FileConnector;
	ACE_FILE_Addr FileAddr(m_strConfigFile.c_str());
	if( FileConnector.connect(File, FileAddr, NULL, ACE_Addr::sap_any, 0, O_RDONLY) != 0 )
	{
		ACE_DEBUG((MY_ERROR ACE_TEXT("Open configuration file %s failed.\n"), m_strConfigFile.c_str()));
		return -1;
	}
	if(ACE_OS::fstat(File.get_handle(), &ConfFileStat) != 0 )
	{
		ACE_DEBUG((MY_ERROR ACE_TEXT("Get configuration file %s's stat failed.\n"), m_strConfigFile.c_str()));
		return -1;
	}
	File.close();
	return 0;
}



