// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc/SocketSvc.h
//     Author : Bambo Huang
//    Purpose : Socket����Ϣ��������Ĵ������࣬��װ��һЩ����
// ****************************************************************************
// Update histories:
//
//  05/16/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
//  08/16/2007: By Bambo Huang
//              ����ע��
// ****************************************************************************

#ifndef __SOCKETSVC_H__
#define __SOCKETSVC_H__

#include "Defs.h"
#include "GlobalDefs.h"

// ������������������ܾò������������ӣ���Ϊ���������������ķ��޷�����

class CConnectTimerHandler : public ACE_Event_Handler
{
public:
	int handle_timeout (const ACE_Time_Value &current_time,
		const void * = 0)
	{
		if(m_SocketHandle != ACE_INVALID_HANDLE)
		{
			ACE_SOCK_Stream peer(m_SocketHandle);
			peer.close();
		}
		ACE_Reactor::instance()->cancel_timer(this);
		delete this;
		return 0;
	}
public:
	ACE_HANDLE m_SocketHandle;
};

class CSocketSvc
	: public ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_NULL_SYNCH>
{
	typedef ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_NULL_SYNCH> super;
public:
	CSocketSvc(void);
public:
	int open (void *p = 0);

	// Called when input is available from the client.
	int handle_input (ACE_HANDLE fd = ACE_INVALID_HANDLE);

	// Called when output is possible.
	int handle_output (ACE_HANDLE fd = ACE_INVALID_HANDLE);

	// Called when this handler is removed from the ACE_Reactor.
	int handle_close (ACE_HANDLE handle,
		ACE_Reactor_Mask close_mask);

	virtual int on_open ( void *p ) = 0;
	virtual int do_handle_input ( ACE_HANDLE fd ) = 0;
	virtual int do_handle_output ( ACE_HANDLE fd ) = 0;
	virtual int on_close (ACE_HANDLE handle, 
		ACE_Reactor_Mask close_mask) = 0;
protected:
	int HandleRecvResult(int nRecvCount);
protected:
	ACE_TCHAR m_szPeerName[MAXHOSTNAMELEN];
	ACE_INET_Addr m_PeerAddr;

	ACE_UINT8 m_ubDataBuff[MAX_DATA_SIZE];
private:
	bool m_bIsConnected;
	CConnectTimerHandler * m_ConnectTimerHandler;
};



#endif //__SOCKETSVC_H__

