// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\Utilities.h
//     Author : Bambo Huang
//    Purpose : �����࣬�ṩ��һЩ�ַ��������Ĺ��ߡ����ܵĺ���
//              �Լ�һ��key/valueӳ�������ģ���ࣨ���ܵͣ��������ڴ�������ʹ�ã�
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************

#ifndef __UTILITIES_H__
#define __UTILITIES_H__

#include <string>
#include "Defs.h"

using std::string;

class CParamPair
{
public:
	string m_strParamName;
	string m_strParamValue;
};

template<class LOCK_TYPE>
class CParamPairList
{
public:
	CParamPairList(){};
	CParamPairList(const CParamPairList<LOCK_TYPE> &Source)
	{
		m_Params = Source.m_Params;
	}
	CParamPairList<LOCK_TYPE> & operator=(const CParamPairList<LOCK_TYPE> &Source)
	{
		if (this == &Source) return *this;
		m_Params = Source.m_Params;
		return *this;
	}
	~CParamPairList(){};
public:
	void SetParam(string strParamName, string strParamValue)
	{
		if (strParamName.length() ==0)
		{
			return;
		}
		
		ACE_Guard<LOCK_TYPE> Guard(m_Lock);
		int nParamIndex = GetParmIndex(strParamName);
		if (nParamIndex == -1)
		{
			CParamPair Param;
			Param.m_strParamName = strParamName;
			Param.m_strParamValue = strParamValue;
			m_Params.push_back(Param);
		}
		else
		{
			m_Params[nParamIndex].m_strParamValue = strParamValue;
		}
	}
	// �����Ƿ�����������
	bool GetParam(string strParamName, string &strParamValue)
	{
		ACE_Guard<LOCK_TYPE> Guard(m_Lock);
		int nParamIndex = GetParmIndex(strParamName);
		if (nParamIndex == -1)
		{
			return false;
		}
		else
		{
			strParamValue = m_Params[nParamIndex].m_strParamValue;
			return true;
		}
	}
	// 
	string GetParam(string strParamName)
	{
		string strParamValue;
		GetParam(strParamName, strParamValue);
		return strParamValue;
	};
	void Clear(void)
	{
		ACE_Guard<LOCK_TYPE> Guard(m_Lock);
		m_Params.clear();
	}

	size_t Size(void) 
	{
		ACE_Guard<LOCK_TYPE> Guard(m_Lock);
		return m_Params.size();
	}

	CParamPair GetParam(size_t nIndex)
	{
		ACE_Guard<LOCK_TYPE> Guard(m_Lock);
		return m_Params[nIndex];
	}
	string Dump(void)
	{
		ACE_Guard<LOCK_TYPE> Guard(m_Lock);
		string strData;
		vector<CParamPair>::iterator p = m_Params.begin();
		while (p != m_Params.end())
		{
			strData += string("<")+p->m_strParamName+"="+p->m_strParamValue+">";
			p++;
		}
		return strData;
	};

private:
	LOCK_TYPE m_Lock;
	vector<CParamPair> m_Params;
private:
	int GetParmIndex(string strParamName)
	{
		for (size_t i=0; i< m_Params.size(); i++)
		{
			if (m_Params[i].m_strParamName == strParamName)
			{
				return (int )i;
			}
		}
		return -1;
	}
};

typedef CParamPairList<ACE_Null_Mutex>   CFastParamList;
typedef CParamPairList<ACE_Thread_Mutex> CSafeParamList;

namespace CC
{
	static const char szHex[] = 
		{'0','1','2','3',
		 '4','5','6','7',
		 '8','9','A','B',
		 'C','D','E','F'};
	inline string CharToHexString(char cChar)
	{
		char szOut[3];
		szOut[0]=szHex[ (cChar >> 4) & 0xF ];
		szOut[1]=szHex[cChar & 0xF];
		szOut[2]='\0';
		return string(szOut);
	}

	inline string CharToPrintableChar(char cChar)
	{
		char cPrint[2];
		cPrint[0] = cChar;
		cPrint[1] = 0x00;
		if ( ! ACE_OS::ace_isprint(cChar) )
		{
			cPrint[0] = '.';
		}
		return string(cPrint);
	}

	inline char HexToChar(char zHex[2])
	{
#define PREPROCESS(x)				\
	if (x >= '0' && x <= '9')		\
		x -= '0';					\
	else if ( x >= 'a' && x <= 'f')	\
		x = x - 'a' + 10;			\
	else if ( x >= 'A' && x <= 'F')	\
		x = x - 'A' + 10;			\
	else							\
		x = 0;
		char zHigh = zHex[0], zLow = zHex[1];
		PREPROCESS(zHigh);
		PREPROCESS(zLow);
		return (( zHigh << 4 ) & 0xF0 ) | zLow;
	}

	inline string Integer2String(int n)
	{
		char szBuff[65];
		ACE_OS::itoa(n, szBuff, 10);
		return szBuff;
	}

	inline string GetDateString(ACE_Date_Time & DateTime)
	{	// "yyyy-mm-dd" format
		char szWork[5];
		string strDate;

		strDate += ACE_OS::itoa( DateTime.year(), szWork, 10 );
		ACE_OS::itoa( DateTime.month(), szWork, 10);
		szWork[2] = 0x00 ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strDate += string("-") + szWork;
		ACE_OS::itoa( DateTime.day(), szWork, 10);
		szWork[2] = 0x00 ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strDate += string("-") + szWork;
		return strDate;
	}
	inline string GetDateString2(ACE_Date_Time & DateTime)
	{	// "yyyymmdd" format
		char szWork[5];
		string strDate;

		strDate += ACE_OS::itoa( DateTime.year(), szWork, 10 );
		ACE_OS::itoa( DateTime.month(), szWork, 10);
		szWork[2] = 0x00 ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strDate += szWork;
		ACE_OS::itoa( DateTime.day(), szWork, 10);
		szWork[2] = 0x00 ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strDate += szWork;
		return strDate;
	}
	inline string GetTimeString(ACE_Date_Time & DateTime)
	{// hh:nn:ss format
		char szWork[3];
		string strTime;
		szWork[2] = 0x00;
		ACE_OS::itoa( DateTime.hour(), szWork, 10) ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strTime += szWork;
		ACE_OS::itoa( DateTime.minute(), szWork, 10) ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strTime += string(":") + szWork;
		ACE_OS::itoa( DateTime.second(), szWork, 10) ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strTime += string(":") + szWork;
		return strTime;
	}
	inline string GetTimeString2(ACE_Date_Time & DateTime)
	{// hhnnss format
		char szWork[3];
		string strTime;
		szWork[2] = 0x00;
		ACE_OS::itoa( DateTime.hour(), szWork, 10) ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strTime += szWork;
		ACE_OS::itoa( DateTime.minute(), szWork, 10) ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strTime += szWork;
		ACE_OS::itoa( DateTime.second(), szWork, 10) ;
		if (szWork[1] == 0x00)
		{
			szWork[1] = szWork [0];
			szWork[0] = '0';
		}
		strTime += szWork;
		return strTime;
	}

	inline string GetDateTimeString(ACE_Date_Time &DateTime)
	{
		return GetDateString(DateTime) + " " + GetTimeString(DateTime);
	}

	inline string GetDateTimeString2(ACE_Date_Time &DateTime)
	{
		return GetDateString2(DateTime) + GetTimeString2(DateTime);
	}

	inline string MakeUpper(const string &Src)
	{
		string ReturnVal;
		char * Buff = new char[Src.length()+1];
		ACE_OS::strcpy(Buff,Src.c_str());
		char *p = Buff;
		while(*p)
		{
			*p = toupper(*p);
			p++;
		}
		ReturnVal = Buff;
		delete []Buff;
		return ReturnVal;
	}

	inline string MakeLower(const string &Src)
	{
		string ReturnVal;
		char * Buff = new char[Src.length()+1];
		ACE_OS::strcpy(Buff,Src.c_str());
		char *p = Buff;
		while(*p)
		{
			*p = tolower(*p);
			p++;
		}
		ReturnVal = Buff;
		delete []Buff;
		return ReturnVal;
	}

	inline string TrimAll(string str)
	{
		const char *pBeg = str.c_str();
		const char *pEnd = pBeg + str.length()-1;
		int nEnd=0;
		while (*pBeg == ' ' || *pBeg == '\t' || *pBeg == '\r' || *pBeg == '\n' )
		{
			pBeg++;
		}
		while (*pEnd == ' ' || *pEnd == '\t' || *pEnd == '\r' || *pEnd == '\n' )
		{
			nEnd++;
			pEnd--;
		}
		str = string(pBeg);
		str = str.substr(0,str.length()-nEnd);
		return str;
	}

	inline string ToUpper(string str)
	{
		string s = str;
		size_t n = s.length();
		char *p = (char *)s.c_str();
		for (size_t i=0; i < n; i++)
		{
			if (p[i] & 0x80)
			{	//���Ժ��ֵĲ���
				i ++;
				continue;
			}
			p[i] = ACE_OS::ace_toupper(p[i]);
		}
		return s;
	}
	
	// ����,�ָ�Ĳ������ֽ⣬ֻ�ֽ����ϼ����
	template<class LOCK_TYPE>
	inline bool ExpandParams(string strParams, CParamPairList<LOCK_TYPE> &Params)
	{
		size_t nBeginIndex = 0;
		size_t nEndIndex = 0;
		size_t nLength = strParams.length();
		int  nLevel = 0 ;
		const char * p = strParams.c_str();
		while (nEndIndex < nLength)
		{
			char c = p[nEndIndex];
			if( c == '<' )
			{
				nLevel ++;
			}
			else if( c == '>' )
			{
				nLevel --;
				if(nLevel < 0)
				{
					return false;

				}
			}
			else if( c == ',')
			{
				if( nLevel == 0)
				{
					string strParamStr = CC::TrimAll(strParams.substr(nBeginIndex,nEndIndex - nBeginIndex));
					size_t nSpliter = strParamStr.find('=');
					if (nSpliter == string::npos)
					{
						return false;
					}
					Params.SetParam(strParamStr.substr(0,nSpliter), strParamStr.substr(nSpliter+1));
					nBeginIndex = nEndIndex + 1;
				}
			}
			nEndIndex ++ ;
		}
		if (nLevel != 0)
		{
			return false;
		}
		// Ϊʲô��Ҫ����Ĵ��룿���������ǵ��ˣ���
		// �ҵ�ԭ�������","��Ϊ����nBeginIndex��nEndIndex��ȣ�����Ҫ�����¹���
		// ������Ҫ�����һ��","֮��Ķ�����������
		if (nBeginIndex != nEndIndex)
		{
			string strParamStr = CC::TrimAll(strParams.substr(nBeginIndex, nEndIndex - nBeginIndex));
			size_t nSpliter = strParamStr.find('=');
			if (nSpliter == string::npos)
			{
				return false;
			}
			Params.SetParam(strParamStr.substr(0,nSpliter), strParamStr.substr(nSpliter+1));
		}
		return true;
	}
	// ����<>�ָ�ļ�¼���ֽ⣬ֻ�ֽ����ϼ����
	inline bool ExpandRecords(string strRecordsString, vector<string> &Records)
	{
		Records.clear();
		size_t nBeginIndex = 0;
		size_t nScanIndex = 0;
		size_t nLength = strRecordsString.length();
		int  nLevel = 0 ;
		const char * p = strRecordsString.c_str();
#define  SCAN_STAT_SCAN_BEGIN	0
#define  SCAN_STAT_SCAN_END		1
		int  nScanStat = SCAN_STAT_SCAN_BEGIN;
		// �ҵ�һ����־λ
		while (nScanIndex < nLength)
		{
			char c = p[nScanIndex];
			nScanIndex ++ ;
			if (c == '<')
			{
				if ( nLevel == 0 && SCAN_STAT_SCAN_BEGIN == nScanStat)
				{
					nBeginIndex = nScanIndex -1;
					nScanStat = SCAN_STAT_SCAN_END;
				}
				nLevel ++ ;
			}
			if (c == '>')
			{
				nLevel -- ;
				if ( nLevel == 0 && SCAN_STAT_SCAN_END == nScanStat)
				{
					string strStepStr = strRecordsString.substr(nBeginIndex + 1, nScanIndex - nBeginIndex - 2 );
					Records.push_back(strStepStr);
					nScanStat = SCAN_STAT_SCAN_BEGIN;
				}
				if ( nLevel < 0)
				{
					return false;
				}
			}
		}
		if (nLevel != 0)
		{
			return false;
		}
		return true;
	}

	// �ֽ�NAME=VALUE�����Ĵ�
	inline bool ExpandParam(string strParamStr, string & strName, string &strValue)
	{
		int nSpliter = static_cast<int>(strParamStr.find('='));
		if (nSpliter < 0)
		{
			return false;
		}
		strName = strParamStr.substr(0,nSpliter);
		strValue = strParamStr.substr(nSpliter+1);
		return true;
	}
	// ��������ı�ʶ���ֽ��ַ�����GBK�룬֧������
	inline vector<string> ExpandString(const string &strInput, char cSplitter)
	{
		vector<string> PartsList;
		const char *p = strInput.c_str();
		string strPart;
		while( *p)
		{
			if ( *p == cSplitter)
			{
				PartsList.push_back(strPart);
				strPart = "";
				p++;
				continue;
			}
			strPart += *p;
			if ( *p & 0x80 )
			{
				p++;
				strPart += *p;
			}
			p++;
		}
		PartsList.push_back(strPart);
		return PartsList;
	}
	inline string GetMonthName(int nMonth)
	{
		switch(nMonth)
		{
		case 0:
			return "Jan";
		case 1:
			return "Feb";
		case 2:
			return "Mar";
		case 3:
			return "Apr";
		case 4:
			return "May";
		case 5:
			return "Jun";
		case 6:
			return "Jul";
		case 7:
			return "Aug";
		case 8:
			return "Sep";
		case 9:
			return "Oct";
		case 10:
			return "Nov";
		case 11:
			return "Dec";
		default:
			return "";
		}
	}
	inline string GetMonthNameL(int nMonth)
	{
		switch(nMonth)
		{
		case 0:
			return "January";
		case 1:
			return "February";
		case 2:
			return "March";
		case 3:
			return "April";
		case 4:
			return "May";
		case 5:
			return "June";
		case 6:
			return "July";
		case 7:
			return "August";
		case 8:
			return "September";
		case 9:
			return "October";
		case 10:
			return "November";
		case 11:
			return "December";
		default:
			return "";
		}
	}
	inline string GetWDayName(int nDay)
	{
		switch( nDay ) ////Day of week (0-6; Sunday = 0)
		{
		case 0:
			return "Sun";
		case 1:
			return "Mon";
		case 2:
			return "Tue";
		case 3:
			return "Wed";
		case 4:
			return "Thu";
		case 5:
			return "Fri";
		case 6:
			return "Sat";
		default:
			return "";
		}
	}

	inline string GetWDayNameL(int nDay)
	{
		switch( nDay ) ////Day of week (0-6; Sunday = 0)
		{
		case 0:
			return "Sunday";
		case 1:
			return "Monday";
		case 2:
			return "Tuesday";
		case 3:
			return "Wednesday";
		case 4:
			return "Thursday";
		case 5:
			return "Friday";
		case 6:
			return "Saturday";
		default:
			return "";
		}
	}

	// ���ݸ�ʽ�����ı����Ϣ��ȡ��Ӧ��ֵ����ǲο�Unix����date��ֻ��������tag
	string GetTagedTimeValue(const ACE_Date_Time &DateTime, char zTag);
}

class CCryptUtil
{	
	static char CharBase[];//37����ĸ
public:
	static string Encrypt(const string &Value, u_int Seed = 0x1234FEDC);
	static string Encrypt(const string &Value, const string &Seed);
	static string Decrypt(const string &Key,   u_int Seed = 0x1234FEDC);
	static string Decrypt(const string &Key,   const string &Seed);
	static u_int Hash(const string &Src);

private:
	static inline int GetCharIndex(char c);};

#endif //__UTILITIES_H__

