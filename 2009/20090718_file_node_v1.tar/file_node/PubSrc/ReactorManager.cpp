// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\ReactorManager.cpp
//     Author : Bambo Huang
//    Purpose : ��ACE��� Reactor ʹ�õ�һ�����߿⣬���������ڲ�ͬϵͳ
//              ��ʹ�ò�ͬ�ķ�Ӧ���������� Reactor ��Ϣѭ���������߳�
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************
#include "ReactorManager.h"


CReactorManager::CReactorManager(void)
{
	m_bIsManagerRunning = false;
	m_pReactorThread = NULL;
}

CReactorManager::~CReactorManager()
{
	if( m_pReactorThread )
	{
		delete m_pReactorThread;
	}
}

int CReactorManager::Run(void)
{
	ACE_Guard<ACE_Thread_Mutex> Guard(m_Lock);
	int nResult = 1; // returns 1 if Task is already an active object
	if ( ! m_bIsManagerRunning )
	{
#if defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
		m_pReactorImpl = new ACE_Dev_Poll_Reactor();
#else
		m_pReactorImpl = new ACE_TP_Reactor();
#endif
		m_pReactor = new ACE_Reactor(m_pReactorImpl,1);
		ACE_Reactor::instance( m_pReactor , 1 );
		if( m_pReactorThread )
		{
			m_pReactorThread->SetReactor(m_pReactor);
		}
		else
		{
			m_pReactorThread = new CReactorPoolThread(m_pReactor);
		}
		nResult = m_pReactorThread->activate(THR_NEW_LWP | THR_JOINABLE );
		if ( nResult != -1 )
		{
			m_bIsManagerRunning = true;
		}
	}
	return nResult;
}

int CReactorManager::Stop(void)
{
	if (m_bIsManagerRunning)
	{
		m_pReactor->end_reactor_event_loop();
		m_bIsManagerRunning = false;
	}
	return 0;
}

