// ****************************************************************************
//  Copyright (C) 2007, ���˵��ӿ������޹�˾
//  All Rights Reserved
//  --------------------------------------------------------------------------
//  File Name : PubSrc\ReactorPoolThread.cpp
//     Author : Bambo Huang
//    Purpose : ACE��Reactor������Ϣѭ���߳���
// ****************************************************************************
// Update Histories :
//
//  08/17/2007: By Bambo Huang
//              �����ĵ�
//  --------------------------------------------------------------------------
// ****************************************************************************
#include "ReactorPoolThread.h"

CReactorPoolThread::CReactorPoolThread(ACE_Reactor *pReactor)
	: m_pReactor(pReactor)
{
}

CReactorPoolThread::~CReactorPoolThread(void)
{
}

int CReactorPoolThread::svc(void)
{
	while (true)
	{
		if (m_pReactor->run_reactor_event_loop() == -1)
		{
			ACE_DEBUG((MY_DEBUG ACE_TEXT("Error %m\n")));
			if ( errno == EINTR )
			{
				continue;
			}
			return -1;
		}
		return 0;
	}
}

void CReactorPoolThread::SetReactor(ACE_Reactor *pReactor)
{
	m_pReactor = pReactor;
}
