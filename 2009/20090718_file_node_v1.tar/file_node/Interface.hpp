/*
 * Interface.hpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 */

#ifndef INTERFACE_HPP_
#define INTERFACE_HPP_
#include "pre.hpp"
#include "NodeSrc/NodeClientWorkTask.h"

class File_record
{
  public:
    virtual int //把数据转换为内部协议数据串
    create_cmd(CRequestFlowObj &,char *buf){return -1;}
    //File_record(){clog << "create File_record\n";}
    //virtual ~File_record(){clog << "delete File_record\n";}
};

class Work_item
{
  public:
    virtual int //把结果输出为回执记录
    create_line(const int line, char *buf);
};

class Parser
{
  public:
    virtual int  //解释文件
    parse_file(const int line, const char* buf, shared_ptr<File_record> &);

    virtual int //解释结果
    parse_ret(CRequestFlowObj *ret, Work_item **);
    virtual int //解释结果
    parse_ret(CRequestFlowObj *ret, shared_ptr<Work_item> &);

    virtual int //从结果包中取出关键字
    get_ret_key(CRequestFlowObj *ret, const char *key, char *value);
};

class BSS_Create_User : public Parser
{
  public:
    virtual int  //解释文件
    parse_file(const int line, const char* buf, shared_ptr<File_record> &);

    virtual int //解释结果
    parse_ret(CRequestFlowObj *ret, Work_item **);
    virtual int //解释结果
    parse_ret(CRequestFlowObj *ret, shared_ptr<Work_item> &);

    virtual int //从结果包中取出关键字
    get_ret_key(CRequestFlowObj *ret, const char *key, char *value);
};

class Create_user : public File_record
{
  public:
    char COMMSERIAL[20];
    char USERNUMBER[12];
    char TELE_TYPE[10];
    char STATE[2];
    char PROVINCE[10];
    char CITY[10];
    char BRAND[20];
    char ProdID[20];
    char SCPTYPE[10];
    char SCPID[10];
    char BALANCE[20];
    char VALIDDATE[20];
    char SIM[10];
    char IMS[10];
    char PUK[20];
    char res1[20];
    char SCP[20];

    //Create_user(){clog << "create Create_user\n";}
    //~Create_user(){clog << "delete Create_user\n";}
    virtual int //把数据转换为内部协议数据串
    create_cmd(CRequestFlowObj &obj,char *buf);
};

class BSS_Create_User_Ret : public Work_item
{
  public:
    char COMMSERIAL[20];
    char USERNUMBER[12];

  public:
    virtual int //把结果输出为回执记录
    create_line(const int line, char *buf);
};
#endif /* INTERFACE_HPP_ */
