/*
 * Sender.cpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 */

#include "Sender.hpp"
#include "Files.hpp"
#include "PubSrc/Defs.h"
#include "NodeSrc/NodeClient.h"

extern Files job;
extern shared_ptr<Parser> parser;
extern CNodeClient NodeSend;

int //读取数据发送线程
Sender::svc (void)
{
  CNodeEventHandlerBase * pEventHandler = &EventHandler;
  NodeSend.SetEventHandler(pEventHandler);

  while (true)
  {
    if(job.files.size()>=1)
    {
       //ACE_DEBUG
       //((LM_DEBUG, ACE_TEXT("(%t) star to read file job\n")));

       char buf[255];
       bzero(buf, sizeof(buf));
       int  line = 0;
       if((line=job.get_data(buf, sizeof(buf)))<0) //取数据
        {
         //ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%t) no data \n")));
         //ACE_OS::sleep(2);
         continue; //没有数据
        }

       //File_record *qry = 0;
       shared_ptr<File_record> qry;
       if(0!=parser->parse_file(line,buf,qry))  //解释数据
       {
          //解释不正确 或 无用的数据
         continue;
       }
       CRequestFlowObj *RequestObj = new CRequestFlowObj;
       char session_id[20];
       if(0!=qry->create_cmd(*RequestObj,session_id)) //生成命令
       {
         //生成命令失败
         clog << "create cmd err\n";
         //delete qry;
         delete RequestObj;
         continue;
       }
      int snd=-1;
      do
      {
        //发送数据包
       snd = NodeSend.SendRequest( *RequestObj );
      }while(snd!=SEND_REQ_OK);
      NodeSend.GetRequestManager()->AppendRequest(RequestObj);
      //delete qry;

     //更新标识
     job.record_done(make_pair(string(session_id),RequestObj));
    }
    //ACE_OS::sleep (2);
  }
  return 0;
}

bool
CClientEventHandler::OnAnswerRequestFlow(CRequestFlowObj & RequestObj)
{
  clog << "in OnAnswerRequestFlow ====\n" <<  endl;
//  Work_item *item=0;
  shared_ptr<Work_item> item;
  char key[50];
  parser->get_ret_key(&RequestObj, "COMMSERIAL", key);
//  parser->parse_ret(&RequestObj,item); //解压结果包
  parser->parse_ret(&RequestObj,item); //解压结果包
  shared_ptr<File> src = job.search_qry(key);//查找发送内容中相应的文件内容
  if(src.get()==NULL) //找不到源
  {
    clog << "cann't found src\n";
    return true;
  }
  clog << "found src ====\n" <<  endl;
  char bill[255];
  item->create_line(1,bill);//创建输出到话单的行记录内容
  //输出记录到文件
  clog << "the bill is: "<< bill << endl;

  //标记源文件记录
  job.inc_orecord(src);
//  delete item;
//  item=0;

  return true;
}

/*
send:
REGIST_NODE:NODE_ID=FileNode

recv:
ACK REGIST_NODE:RESULT=0

*/

