/*
 * main.cpp
 *
 *  Created on: 2010-1-26
 *      Author: bonly
 */
#include "Files.hpp"
#include "Master.hpp"
#include "Sender.hpp"
#include "Interface.hpp"

extern shared_ptr<Parser> parser;
extern Files job;
CNodeClient NodeSend;

int ACE_TMAIN (int, ACE_TCHAR *[])
{
  //启动节点
  if(! NodeSend.Active( "FileNode", "127.0.0.1", 5100 ))
  {
    ACE_DEBUG((MY_INFO ACE_TEXT("Deduct node start failed.\n")));
    return -1;
  };
  ACE_OS::sleep(2);

  //生成解释器
  parser = shared_ptr<Parser>  (new BSS_Create_User);

  //ACE_DEBUG
  //  ((LM_DEBUG, ACE_TEXT ("(%t) Main Thread running\n")));

  Master manager;
  int result = manager.activate ();
  //int result = manager.activate (THR_NEW_LWP | THR_JOINABLE,
  //                               1, 1,  ACE_THR_PRI_OTHER_DEF);
  ACE_ASSERT (result == 0);

  Sender reader;
  result = reader.activate();
//  result = reader.activate(THR_NEW_LWP | THR_JOINABLE,
//                                 1, 1,  ACE_THR_PRI_OTHER_MAX);
  ACE_ASSERT (result == 0);

//  Receive receive;
//  result = receive.activate();
////  result = receive.activate(THR_NEW_LWP | THR_JOINABLE,
////                                 1, 1,  ACE_THR_PRI_OTHER_MAX);
//  ACE_ASSERT (result == 0);

  ACE_Thread_Manager::instance()->wait();
  return 0;
}
