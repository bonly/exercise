#include "NodeClientSvc.h"
#include "NodeClientWorkTask.h"
#include "NodeClientMonTask.h"
#include "NodeClient.h"


int CNodeClientSvc::on_open ( void *p )
{
	ACE_DEBUG((MY_DEBUG ACE_TEXT("Connected .\n")));
	m_Step = STEP_GET_TAG;
	m_nCurrentStepGetLength = 0;
	m_nCmdDataBuffLength = 0;
	m_szCmdDataBuff = NULL;
	ACE_OS::memset(m_szPkgLength, 0, sizeof(m_szPkgLength));
	return 0;
}

int CNodeClientSvc::do_handle_input ( ACE_HANDLE fd )
{
	int nRecvCount = 0;
	//	ACE_Time_Value TimeOutValue(0,500);
	int nSockReadResult;
	switch(m_Step)
	{
	case STEP_GET_TAG:
		nSockReadResult = ReadSockData(m_szPkgHead, 4, STEP_GET_LENGTH);
		if (nSockReadResult == -1)
		{
			return -1; // ��TAGʧ��
		}
		else if ( nSockReadResult == 0 && m_Step == STEP_GET_LENGTH)
		{
			// Tag�Ѿ����꣬�жϱ�־�����ͨ���͵���һ����
			if(!(m_szPkgHead[0]=='S'&&m_szPkgHead[1]=='C'&&m_szPkgHead[2]=='I'&&m_szPkgHead[3]=='P'))
			{
				ACE_DEBUG((MY_ERROR ACE_TEXT("Wrong package received from %s, close connection.\n"), m_szPeerName));
				return -1;
			}
		}
		else
		{   // ���ɹ�������Tagû����
			return 0;
		}
		break;
	case STEP_GET_LENGTH:
		nSockReadResult = ReadSockData(m_szPkgLength, 8, STEP_GET_DATA);
		if (nSockReadResult == -1)
		{
			return -1; // ������ʧ��
		}
		else if (nSockReadResult == 0 && m_Step == STEP_GET_DATA )
		{
			//Length�Ѿ����꣬��һ��ת��
			m_nCmdDataLength = ACE_OS::atoi(m_szPkgLength);
		}
		else
		{
			return 0;
		}
		break;
	case STEP_GET_DATA:
		if ( m_nCmdDataLength +1 > m_nCmdDataBuffLength )
		{
			if (m_szCmdDataBuff)
			{
				delete []m_szCmdDataBuff;
			}
			m_szCmdDataBuff = new char[ m_nCmdDataLength + 1];
			m_nCmdDataBuffLength = m_nCmdDataLength + 1;
		}
		nSockReadResult = ReadSockData(m_szCmdDataBuff, m_nCmdDataLength, STEP_GET_SUM);

		if (nSockReadResult == -1)
		{
			return -1; // ������ʧ��
		}
		else if (nSockReadResult == 0 && m_Step == STEP_GET_SUM )
		{
			// ���꣬����
			m_szCmdDataBuff[m_nCmdDataLength]=0;
		}
		else
		{
			return 0;
		}
		break;
	case STEP_GET_SUM:
		nSockReadResult = ReadSockData(m_szCheckSum, 4, STEP_GET_TAG);
		if (nSockReadResult == -1)
		{
			return -1; // CheckSum ʧ��
		}
		else if (nSockReadResult == 0 && m_Step == STEP_GET_TAG )
		{

		}
		else
		{
			return 0;
		}
	}
	if(m_Step == STEP_GET_TAG)
	{
		CMsgPack *MsgPack = new CMsgPack(fd);
		MsgPack->m_nMsgType = CMsgPack::MSG_ON_DATA;
		MsgPack->m_nPkgLength = m_nCmdDataLength + 1;
		MsgPack->m_zPackage = new char[MsgPack->m_nPkgLength];

		// :-< ���õ�ʵ�ְ취
		size_t nHello = string(m_szCmdDataBuff).find("HELLO:");
		if ( nHello == string::npos )
		{
			string strLogMsg = string("Receive Message From Remote ") + m_szPeerName + " : "
				+ m_szCmdDataBuff;
			//		WRITE_LOG(strLogMsg);
			ACE_DEBUG((MY_DEBUG ACE_TEXT("%s\n"), strLogMsg.c_str()));	
		}

		ACE_OS::strcpy(MsgPack->m_zPackage, m_szCmdDataBuff);
		ACE_Message_Block *mb = new ACE_Message_Block( (const char *) MsgPack );
		int nQSize = m_Owner->GetWorkTask()->putq(mb);
		if (nQSize < 0)
		{
			ACE_DEBUG((MY_DEBUG ACE_TEXT("Putq Failed.\n")));
		}
		else if( nQSize > 300)
		{
			ACE_Time_Value tmSleep(0,10000);
			ACE_OS::sleep(tmSleep);
		}
	}
	return 0;
}
int CNodeClientSvc::do_handle_output ( ACE_HANDLE fd )
{
	return 0;
}

int CNodeClientSvc::on_close (ACE_HANDLE handle, ACE_Reactor_Mask close_mask)
{
	if(m_Owner)
	{
		if (m_Owner->IsRunning())
		{
			CNodeMonEvent *Event = new CNodeMonEvent(EVENT_CONN_LOST);
			ACE_Message_Block *mb = new ACE_Message_Block((const char *)Event);
			m_Owner->GetMonTask()->putq(mb);
		}
	}
	return 0;
}

int CNodeClientSvc::ReadSockData(char *szBuff, int nNeedLength, READ_STEP NextStep)
{
	ACE_Time_Value TimeOut(0,100);
	int nRecvCount = peer().recv(szBuff + m_nCurrentStepGetLength, nNeedLength - m_nCurrentStepGetLength , &TimeOut);
	if (HandleRecvResult(nRecvCount) == -1)
	{
		return -1;
	}
	if (nRecvCount > 0)
	{
		m_nCurrentStepGetLength += nRecvCount;
	}
	if (m_nCurrentStepGetLength == nNeedLength)
	{
		m_nCurrentStepGetLength = 0;
		m_Step = NextStep;
	}
	return 0;
}

void CNodeClientSvc::SetOwner(CNodeClient *Owner)
{
	m_Owner = Owner;
}

