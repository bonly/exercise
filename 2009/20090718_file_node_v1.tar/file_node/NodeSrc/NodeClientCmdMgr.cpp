#include "NodeClientCmdMgr.h"
#include "NodeClientMonTask.h"
#include "NodeClient.h"

char CCmdInfo::s_pkgHead[4]={'S','C','I','P'};

CCmdInfo::CCmdInfo( ACE_HANDLE Handle, CNodeClient *NodeClient )
:m_Handle(Handle)
,m_NodeClient(NodeClient)
,m_nCmdType(CMD_TYPE_REQUEST)
,m_bNeedDumpMsg(true)
{
	ACE_SOCK_Stream stream(Handle);
	ACE_INET_Addr PeerAddr;
	stream.get_remote_addr(PeerAddr);
	PeerAddr.addr_to_string(m_szPeerName, MAXHOSTNAMELEN);
}

CCmdInfo::~CCmdInfo()
{
}

int CCmdInfo::GetCmdStream(char *Buff, size_t &nSize)
{
	size_t nNeedSize = 4 + 8 + 4 ;// ��ͷ + ���� + У��
	string strCmd = m_strCmd + ":";
	if (m_nCmdType == CMD_TYPE_ANSWER)
	{
		strCmd = string("ACK ") + strCmd;
	}
	bool bIsFirstParam = true;
	for (size_t i=0; i< m_Params.Size(); i++)
	{
		if (bIsFirstParam)
		{
			bIsFirstParam = false;
		}
		else
		{
			strCmd += string(",");
		}
		CParamPair Param = m_Params.GetParam(i);
		strCmd += Param.m_strParamName+"="+Param.m_strParamValue;
	}
	nNeedSize += strCmd.length();
	if (nSize < nNeedSize)
	{
		nSize = nNeedSize;
		return -1;
	}
	if (Buff == NULL)
	{
		return -2;
	}
	ACE_OS::memcpy(Buff, s_pkgHead, 4);
	int nCmdLength = static_cast<int>(strCmd.length());
	ACE_OS::snprintf(Buff + 4 ,9,"%08d",nCmdLength);
	ACE_OS::memcpy(Buff + 12, strCmd.c_str(), nCmdLength);
	char zChkSum[4]={'\0','\0','\0','\0'};
	ACE_OS::memcpy(Buff +12 + nCmdLength, zChkSum, 4);
	return static_cast<int>(nNeedSize);
}

int CCmdInfo::SetCmdString(string strCmd)
{
	m_Params.Clear();
	string strOriginCmd = CC::TrimAll(strCmd);
	int nCmdSpliter = static_cast<int>(strOriginCmd.find(':'));
	if(nCmdSpliter == -1)
	{
		SetAsInvalidCmd(strOriginCmd);
		return SET_CMD_WRONG_CMD;
	}
	m_strCmd = strOriginCmd.substr(0, nCmdSpliter);
	int nPrefixSpliter = static_cast<int>(m_strCmd.find(' '));
	if ( nPrefixSpliter >0)
	{//�����ǰ�ñ�־
		string strPrefix = m_strCmd.substr(0, nPrefixSpliter );
		m_strCmd = m_strCmd.substr( nPrefixSpliter + 1 );
		if (strPrefix == "ACK")
		{
			m_nCmdType = CMD_TYPE_ANSWER;
		}
		else
		{
			SetAsInvalidCmd(strOriginCmd);
			return SET_CMD_WRONG_CMD;
		}
	}
	vector<string> Params;
	if (ExpandParams(strOriginCmd.substr(nCmdSpliter+1), Params) == SET_CMD_WRONG_PARAM)
	{
		SetAsInvalidCmd(strOriginCmd);
		return SET_CMD_WRONG_PARAM;
	}
	for(size_t i=0; i < Params.size(); i++)
	{
		nCmdSpliter = static_cast<int>(Params[i].find('='));
		if(nCmdSpliter == -1)
		{
			m_Params.Clear();
			SetAsInvalidCmd(strOriginCmd);
			return SET_CMD_WRONG_PARAM;
		}
		m_Params.SetParam(Params[i].substr(0,nCmdSpliter),Params[i].substr(nCmdSpliter+1));
	}
	return SET_CMD_OK;
}

int CCmdInfo::ExpandParams(string strParams, vector<string> &Params)
{
	size_t nBeginIndex = 0;
	size_t nEndIndex = 0;
	size_t nLength = strParams.length();
	int  nLevel = 0 ;
	const char * p = strParams.c_str();
	while (nEndIndex < nLength)
	{
		char c = p[nEndIndex];
		if( c == '<' )
		{
			nLevel ++;
		}
		else if( c == '>' )
		{
			nLevel --;
			if(nLevel < 0)
			{
				return SET_CMD_WRONG_PARAM;

			}
		}
		else if( c == ',')
		{
			if( nLevel == 0)
			{
				Params.push_back(CC::TrimAll(strParams.substr(nBeginIndex,nEndIndex - nBeginIndex)));
				nBeginIndex = nEndIndex + 1;
			}
		}
		nEndIndex ++ ;
	}
	if (nLevel != 0)
	{
		return SET_CMD_WRONG_PARAM;
	}
	if (nBeginIndex != nEndIndex)
	{
		Params.push_back(CC::TrimAll(strParams.substr(nBeginIndex, nEndIndex - nBeginIndex)));
	}
	return SET_CMD_OK;
}

string CCmdInfo::GetSendCmd(void)
{
	string strCmd = m_strCmd + ":";
	if (m_nCmdType == CMD_TYPE_ANSWER)
	{
		strCmd = string("ACK ") + strCmd;
	}
	bool bIsFirstParam = true;
	for (size_t i=0; i< m_Params.Size(); i++)
	{
		if (bIsFirstParam)
		{
			bIsFirstParam = false;
		}
		else
		{
			strCmd += string(",");
		}
		CParamPair Param = m_Params.GetParam(i);
		strCmd += Param.m_strParamName+"="+Param.m_strParamValue;
	}
	return strCmd;
}

int CCmdInfo::Send(void)
{
	ACE_SOCK_Stream Peer(m_Handle);
	size_t nBufferSize = 0;
	GetCmdStream(NULL, nBufferSize);
	char *Buffer = new char[nBufferSize];
	GetCmdStream(Buffer, nBufferSize);

	if(m_bNeedDumpMsg)
	{

		string strLogMsg = string("Send Message to Remote ") + m_szPeerName + " : "
			+ GetSendCmd();
		// WRITE_LOG(strLogMsg);
		ACE_DEBUG((MY_DEBUG ACE_TEXT("%s\n"),strLogMsg.c_str()));
	}

	int nSend = Peer.send_n(Buffer,nBufferSize);
	delete [] Buffer;
	return nSend > 0 ? SEND_CMD_OK : SEND_CMD_SOCK_ERR;
}

void CCmdInfo::SetAsInvalidCmd(string strOriginCmd)
{
	m_Params.Clear();
	m_nCmdType = CMD_TYPE_ANSWER;
	m_strCmd = "INVALID_CMD";
	m_Params.SetParam("CMD",string("<")+strOriginCmd+string(">"));
}

void CCmdInfo::SetAsUnsupportCmd(void)
{
	m_Params.Clear();
	m_nCmdType = CMD_TYPE_ANSWER;
	m_Params.SetParam("CMD",string("<")+m_strCmd+string(">"));
	m_strCmd = "UNSUPPORT_CMD";
}

void CCmdInfo::SetAsNotEnoughParam(void)
{
	// m_Params.Clear();
	m_nCmdType = CMD_TYPE_ANSWER;
	m_Params.SetParam("RESULT","98"); // ��������
}

CBaseCmd::CBaseCmd(ACE_HANDLE Handle)
:m_Handle(Handle)
{
}

void CBaseCmd::SetNodeClient(CNodeClient *NodeClient)
{
	m_NodeClient = NodeClient;
}

CRegistNodeCmd::CRegistNodeCmd(ACE_HANDLE Handle)
: CBaseCmd(Handle)
{

}

CRegistNodeCmd::~CRegistNodeCmd()
{

}

int CRegistNodeCmd::Execute(void)
{
	if (m_nCmdType == CMD_TYPE_REQUEST)
	{
		return EXECUTE_IMMEDIATE_CLOSE;
	}
	else
	{
		// ����Ϣ��MonTask��֪ͨע����
		CNodeMonEvent * Event = new CNodeMonEvent( m_nExecResult == REGIST_NODE_OK ? EVENT_NODE_REGISTED : EVENT_NODE_REGIST_FAILED);
		ACE_Message_Block *mb = new ACE_Message_Block((const char *) Event);
		m_NodeClient->GetMonTask()->putq(mb);
		return EXECUTE_WAIT;
	}
}

int CRegistNodeCmd::PrepareParam(CCmdInfo & CmdInfo)
{
	m_nCmdType = CmdInfo.m_nCmdType;
	if(m_nCmdType == CMD_TYPE_REQUEST)
	{
		if (CmdInfo.GetParam("NODE_ID", m_strNodeID))
		{
			return PREPARE_PARAM_OK;
		}
		else
		{
			return PREPARE_PARAM_FAILED;
		}
	}
	else
	{
		string strExecResult;
		if(CmdInfo.GetParam("RESULT", strExecResult))
		{
			if (strExecResult == "0")
			{
				m_nExecResult = REGIST_NODE_OK;
			}
			else
			{
				m_nExecResult = REGIST_NODE_FAILED;
			}
			return PREPARE_PARAM_OK;
		}
		else
		{
			return PREPARE_PARAM_FAILED;
		}
	}
}

CCmdInfo CRegistNodeCmd::GetCmdInfo(void)
{
	CCmdInfo CmdInfo(m_Handle, NULL);
	CmdInfo.SetCommand("REGIST_NODE");
	CmdInfo.m_nCmdType = CMD_TYPE_ANSWER;
	CmdInfo.SetParam("RESULT",m_nExecResult == REGIST_NODE_OK ? "0":"1");
	return CmdInfo;
}

CRequestFlowCmd::CRequestFlowCmd(ACE_HANDLE Handle)
: CBaseCmd(Handle)
{
}

CRequestFlowCmd::~CRequestFlowCmd()
{

}

int CRequestFlowCmd::Execute(void)
{
	if (m_nCmdType == CMD_TYPE_ANSWER)
	{
		vector<string> ParamPairs;
		CC::ExpandRecords(m_strParams, ParamPairs);
		CFastParamList Params;
		for (size_t n = 0; n < ParamPairs.size(); n++)
		{
			CFastParamList Param;
			CC::ExpandParams(ParamPairs[n], Param);
			for(size_t i =0; i < Param.Size(); i++)
			{
				CParamPair ParamPair = Param.GetParam(i);
				Params.SetParam(ParamPair.m_strParamName, ParamPair.m_strParamValue);
			}
		}
		// �����¼��������
		CRequestFlowObj * RequestObj = m_NodeClient->GetRequestManager()->GetRequest(m_strSessionId);
		if ( RequestObj )
		{
			for (size_t n = 0; n < Params.Size(); n ++)
			{
				CParamPair ParamPair = Params.GetParam(n);
				RequestObj->m_Params.SetParam(ParamPair.m_strParamName, ParamPair.m_strParamValue);
			}
			RequestObj->m_strResult = m_strExecResult;
			CNodeEventHandlerBase * EventHandler = m_NodeClient->GetWorkTask()->GetEventHandler();
			if( EventHandler )
			{
				EventHandler->OnAnswerRequestFlow( *RequestObj );
			}
			delete RequestObj;
		}
		// ��������ɾ��
		return EXECUTE_WAIT;
	}
	return EXECUTE_IMMEDIATE_CLOSE;
}

CCmdInfo CRequestFlowCmd::GetCmdInfo(void)
{
	CCmdInfo CmdInfo(m_Handle, NULL);
	CmdInfo.SetCommand("REQUEST_FLOW");
	CmdInfo.SetParam("SESSION",m_strSessionId);
	CmdInfo.SetParam("FLOW", m_strFlowId);
	CmdInfo.SetParam("PARAMS",m_strParams);
	if ( m_nCmdType == CMD_TYPE_ANSWER )
	{
		CmdInfo.SetParam("RESULT",m_strExecResult);
		CmdInfo.m_nCmdType = CMD_TYPE_ANSWER;
	}
	return CmdInfo;
}

int CRequestFlowCmd::PrepareParam(CCmdInfo &CmdInfo)
{
	m_nCmdType = CmdInfo.m_nCmdType;
	if(!CmdInfo.GetParam("SESSION",m_strSessionId))
	{
		return PREPARE_PARAM_FAILED;
	}
	if(!CmdInfo.GetParam("FLOW", m_strFlowId))
	{
		return PREPARE_PARAM_FAILED;
	}
	if(!CmdInfo.GetParam("PARAMS", m_strParams))
	{
		return PREPARE_PARAM_FAILED;
	}
	if (!CmdInfo.GetParam("RESULT", m_strExecResult))
	{
		return PREPARE_PARAM_FAILED;
	}
	m_nCmdType = CmdInfo.m_nCmdType;
	return PREPARE_PARAM_OK;
}

CCallFuncCmd::CCallFuncCmd(ACE_HANDLE Handle)
:CBaseCmd(Handle)
{
}

CCallFuncCmd::~CCallFuncCmd()
{

}

int CCallFuncCmd::Execute(void)
{
	if (m_nCmdType == CMD_TYPE_REQUEST)
	{
		vector<string> ParamPairs;
		CC::ExpandRecords(m_strParams, ParamPairs);
		CFastParamList Params;
		for (size_t n = 0; n < ParamPairs.size(); n++)
		{
			CFastParamList Param;
			CC::ExpandParams(ParamPairs[n], Param);
			for(size_t i =0; i < Param.Size(); i++)
			{
				CParamPair ParamPair = Param.GetParam(i);
				Params.SetParam(ParamPair.m_strParamName, ParamPair.m_strParamValue);
			}
		}
		CCallFuncObj * CallObj = new CCallFuncObj(m_Handle);
		CallObj->m_strFuncId = m_strFuncId;
		CallObj->m_strSessionId = m_strSessionId;
		CallObj->m_Params = Params;

		CNodeEventHandlerBase * EventHandler = m_NodeClient->GetWorkTask()->GetEventHandler();
		if( EventHandler )
		{
			EventHandler->OnCall( *CallObj);
		}
		delete CallObj;
		return EXECUTE_WAIT;
	}
	return EXECUTE_IMMEDIATE_CLOSE;
}

int CCallFuncCmd::PrepareParam(CCmdInfo &CmdInfo)
{
	m_nCmdType = CmdInfo.m_nCmdType;
	if (!CmdInfo.GetParam("SESSION", m_strSessionId))
	{
		return PREPARE_PARAM_FAILED;
	}
	if (!CmdInfo.GetParam("PARAMS", m_strParams))
	{
		return PREPARE_PARAM_FAILED;
	}
	if (!CmdInfo.GetParam("FUNC", m_strFuncId))
	{
		return PREPARE_PARAM_FAILED;
	}
	if (m_nCmdType == CMD_TYPE_ANSWER)
	{
		if (!CmdInfo.GetParam("RESULT", m_strCallResult))
		{
			return PREPARE_PARAM_FAILED;
		}
	}
	return PREPARE_PARAM_OK;
}

CCmdInfo CCallFuncCmd::GetCmdInfo(void)
{
	CCmdInfo CmdInfo(m_Handle, NULL);
	return CmdInfo;
}

CHelloCmd::CHelloCmd(ACE_HANDLE Handle)
:CBaseCmd(Handle)
{

}

CHelloCmd::~CHelloCmd()
{

}

int CHelloCmd::Execute(void)
{
	return EXECUTE_WAIT;
}

CCmdInfo CHelloCmd::GetCmdInfo(void)
{
	CCmdInfo CmdInfo(m_Handle,NULL);
	CmdInfo.SetCommand("HELLO");
	CmdInfo.m_nCmdType = CMD_TYPE_REQUEST;
	CmdInfo.m_bNeedDumpMsg = false;
	return CmdInfo;
}

int CHelloCmd::PrepareParam(CCmdInfo &CmdInfo)
{
	return 0;
}

int ParseCmd( CCmdInfo & CmdInfo, CBaseCmd ** BaseCmd)
{
	if (CC::ToUpper(CmdInfo.GetCommandStr()) == "REGIST_NODE" )
	{
		* BaseCmd = new CRegistNodeCmd(CmdInfo.GetSockHandle());
	}
	else if (CC::ToUpper(CmdInfo.GetCommandStr()) == "REQUEST_FLOW")
	{
		*BaseCmd = new CRequestFlowCmd(CmdInfo.GetSockHandle());
	}
	else if (CC::ToUpper(CmdInfo.GetCommandStr()) == "CALL_FUNC")
	{
		*BaseCmd = new CCallFuncCmd(CmdInfo.GetSockHandle());
	}
	else if (CC::ToUpper(CmdInfo.GetCommandStr()) == "HELLO")
	{
		*BaseCmd = new CHelloCmd(CmdInfo.GetSockHandle());
	}
	else
	{
		return PARSE_CMD_UNSUPPORT_CMD;
	}
	(* BaseCmd)->SetNodeClient(CmdInfo.GetNodeClient());
	if((* BaseCmd)->PrepareParam(CmdInfo))
	{
		delete (*BaseCmd);
		(*BaseCmd) = NULL;
		return PARSE_CMD_NOT_ENOUGH_PARAM;
	}
	return PARSE_CMD_OK;
}
