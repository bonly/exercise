#include "NodeClient.h"
#include "../PubSrc/ReactorManager.h"
CRequestManager MsgManager;

CNodeClient::CNodeClient()
{
	m_bIsClientRunning = false;
}

CNodeClient::~CNodeClient()
{

}

bool CNodeClient::Active(string strNodeId, string strHost, u_short nPort)
{
	if (!m_bIsClientRunning)
	{
		// ����ReactorManager
		ReactorManager::instance()->Run();
		m_MonTask.SetOwner(this);
		m_MonTask.activate(THR_NEW_LWP | THR_JOINABLE );
		m_WorkTask.SetOwner(this);
		m_WorkTask.activate(THR_NEW_LWP | THR_JOINABLE, 2 );
		CNodeMonEvent *Event = new CNodeMonEvent(EVENT_STARTUP);
		Event->m_Params.SetParam("NODEID", strNodeId);
		Event->m_Params.SetParam("HOST", strHost);
		Event->m_Params.SetParam("PORT", CC::Integer2String(nPort));
		ACE_Message_Block * mb = new ACE_Message_Block((char *) Event);
		m_MonTask.putq(mb);
		m_bIsClientRunning = true;
	}
	return true;
}

bool CNodeClient::Stop(void)
{
	m_bIsClientRunning = false;
	CNodeMonEvent *Event = new CNodeMonEvent(EVENT_SHUTDOWN);
	ACE_Message_Block * mb = new ACE_Message_Block((char *) Event);
	m_MonTask.putq(mb);
	m_WorkTask.stop();
	return true;
}

bool CNodeClient::CanWork(void)
{
	if (m_bIsClientRunning)
	{
		if (m_pNodeClientSvc)
		{
			return true;
		}
	}
	return false;
}

bool CNodeClient::m_bIsReactorThreadRunning = false;

#if defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
ACE_Dev_Poll_Reactor * CNodeClient::s_DPReactor = NULL;
ACE_Reactor    * CNodeClient::s_Reactor = NULL;
#else
ACE_TP_Reactor * CNodeClient::s_TPReactor = NULL;
ACE_Reactor    * CNodeClient::s_Reactor = NULL;
#endif //defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)

bool CNodeClient::StartReactorThread(void)
{
	if(!m_bIsReactorThreadRunning)
	{
#if defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
		s_DPReactor = new ACE_Dev_Poll_Reactor();
		s_Reactor = new ACE_Reactor(s_DPReactor,1);
		ACE_Reactor::instance( s_Reactor , 1 );
#else
		s_TPReactor = new ACE_TP_Reactor();
		s_Reactor = new ACE_Reactor(s_TPReactor,1);
		ACE_Reactor::instance( s_Reactor , 1 );
#endif
	}
	m_bIsReactorThreadRunning = true;
	return true;
}

void CNodeClient::SetEventHandler(CNodeEventHandlerBase * NodeEventHandler)
{
	m_WorkTask.SetEventHandler(NodeEventHandler);
}

int CNodeClient::SendRequest(CRequestFlowObj &ReqObj)
{
	// ������ŵ�NodeClientWorkTask��ͷȥ
	if(CanWork())
	{
		ReqObj.m_CommType = REQ;
		CRequestFlowObj *pRequestObj = new CRequestFlowObj(ReqObj);
		CMsgPack * MsgPack = new CMsgPack(ReqObj.m_SockHandle);
		MsgPack->m_nMsgType = CMsgPack::MSG_ON_SEND_REQUEST ;
		MsgPack->m_pObject = pRequestObj;
		ACE_Message_Block *mb = new ACE_Message_Block((const char *)MsgPack);
		m_WorkTask.putq(mb);
		return SEND_REQ_OK;
	}
	else
	{
		return SEND_REQ_NODE_NOT_CONNECT;
	}
}

int CNodeClient::AnswerCall(CCallFuncObj &CallObj)
{
	// ǿ������ΪAnswe ����
	// ������ŵ�NodeClientWorkTask��ͷȥ
	CallObj.m_CommType = ACK;
	CCallFuncObj *pCallObj = new CCallFuncObj(CallObj);
	CMsgPack * MsgPack = new CMsgPack(CallObj.m_SockHandle);
	MsgPack->m_nMsgType = CMsgPack::MSG_ON_SEND_CALL;
	MsgPack->m_pObject = pCallObj;
	ACE_Message_Block *mb = new ACE_Message_Block((const char *)MsgPack);
	m_WorkTask.putq(mb);
	return ANSWER_CALL_OK;
}

CRequestManager::CRequestManager()
{
}

CRequestManager::~CRequestManager()
{
	ACE_Guard<ACE_Thread_Mutex> Guard(m_Lock);
	map<string, CRequestFlowObj*>::iterator p = m_RequestList.begin();
	while (p != m_RequestList.end())
	{
		delete p->second;
		p++;
	}
	m_RequestList.clear();
}

void CRequestManager::AppendRequest(CRequestFlowObj *RequestObj)
{
	ACE_Guard<ACE_Thread_Mutex> Guard(m_Lock);
	//m_RequestList.push_back(RequestObj);
	map<string, CRequestFlowObj *>::value_type v(RequestObj->m_strSessionId, RequestObj);
	m_RequestList.insert(v);
}

CRequestFlowObj *CRequestManager::GetRequest(string strSessionId)
{
	ACE_Guard<ACE_Thread_Mutex> Guard(m_Lock);
	CRequestFlowObj * Obj = NULL;
	map<string, CRequestFlowObj*>::iterator p = m_RequestList.find(strSessionId);
	if ( p != m_RequestList.end())
	{
		Obj = p->second;
		m_RequestList.erase(p);
	}
	return Obj;
}

