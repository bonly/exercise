#include "NodeClientHeartBeat.h"
#include "NodeClientCmdMgr.h"
#include "NodeClientWorkTask.h"
#include "NodeClientMonTask.h"
#include "NodeClient.h"

int CNodeClientHeartBeatHandler::handle_timeout (const ACE_Time_Value &current_time,
					const void *)
{
	if(m_bIsWaitingAnswer)
	{
		// ����Ϊ�ڵ�ͨ�ų�ʱ��
		
	}
	else
	{
		CMsgPack *MsgPack = new CMsgPack(ACE_INVALID_HANDLE);
		MsgPack->m_nMsgType = CMsgPack::MSG_ON_HEARTBEAT;
		ACE_Message_Block *mb = new ACE_Message_Block((const char *)MsgPack);
		m_Owner->GetWorkTask()->putq(mb);
	}
	return 0;
}

