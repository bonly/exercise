#ifndef __NODECLIENTHEARTBEAT_H__
#define __NODECLIENTHEARTBEAT_H__

#include "../PubSrc/Defs.h"
class CNodeClient;

class CNodeClientHeartBeatHandler : public ACE_Event_Handler
{
public:
	int handle_timeout (const ACE_Time_Value &current_time,
		const void * = 0);
	CNodeClient * m_Owner;
	bool m_bIsWaitingAnswer;
};

#endif //__NODECLIENTHEARTBEAT_H__
