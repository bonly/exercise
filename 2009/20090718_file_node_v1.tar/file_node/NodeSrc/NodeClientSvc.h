#ifndef __NODECLIENTSVC_H__
#define __NODECLIENTSVC_H__

#include "../PubSrc/Defs.h"
#include "../PubSrc/SocketSvc.h"
#include "../PubSrc/Utilities.h"
#include "NodeClientWorkTask.h"

class CNodeClient;

class CNodeClientSvc
	: public CSocketSvc
{
private:
	int on_open ( void *p );
	int do_handle_input ( ACE_HANDLE fd );
	int do_handle_output ( ACE_HANDLE fd );
	int on_close (ACE_HANDLE handle, ACE_Reactor_Mask close_mask);
public:
	ACE_Time_Value m_ConnectTime;
private:
	char   m_szPkgHead[4];
	char   m_szPkgLength[9];     // 
	char   m_szCheckSum[4];
	char * m_szCmdDataBuff;      // 
	size_t m_nCmdDataBuffLength; // BufferLength
	size_t m_nCmdDataLength;	 // CommandLength
	int    m_nCurrentStepGetLength;
	enum   READ_STEP {STEP_GET_TAG, STEP_GET_LENGTH, STEP_GET_DATA, STEP_GET_SUM} m_Step;

	int ReadSockData(char *szBuff, int nNeedLength, READ_STEP NextStep);
	CNodeClient *m_Owner;
public:
	void SetOwner(CNodeClient *Owner);
	void Reset( void ){m_Step = STEP_GET_TAG; m_nCurrentStepGetLength = 0;}
};

#endif //__NODECLIENTSVC_H__

