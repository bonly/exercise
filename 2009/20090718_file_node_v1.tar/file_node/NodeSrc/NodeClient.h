#ifndef __NODECLIENT_H__
#define __NODECLIENT_H__

#include "../PubSrc/Defs.h"
#include "NodeClientMonTask.h"
#include "NodeClientSvc.h"
#include "NodeClientWorkTask.h"

#include <map>

using namespace std;


class CNodeEventHandlerBase;

class CRequestManager
{
public:
	CRequestManager();
	~CRequestManager();
public:
	void AppendRequest(CRequestFlowObj *RequestObj);
	CRequestFlowObj *GetRequest(string strSessionId);
private:
	ACE_Thread_Mutex m_Lock;
	// vector<CRequestFlowObj *> m_RequestList;
	map<string, CRequestFlowObj*> m_RequestList;
};

class CNodeClient
{
public:
	CNodeClient();
	~CNodeClient();
public:
	// ����ͻ��˲�ע��Ϊ strNodeId�Ľڵ�
	bool Active(string strNodeId, string strHost, u_short nPort);
	bool Stop(void);
	void SetEventHandler(CNodeEventHandlerBase *);
	CNodeClientMonTask * GetMonTask(void){return &m_MonTask;}
	CNodeClientWorkTask * GetWorkTask(void){return &m_WorkTask;}
	CRequestManager * GetRequestManager(void){return &m_RequestManager;}
	CNodeClientSvc *GetClientSvc(void){return m_pNodeClientSvc;}
	//void SetRequestManager(CRequestManager *manager){m_RequestManager=manager;}
	void SetClientSvc(CNodeClientSvc *NodeClientSvc){m_pNodeClientSvc = NodeClientSvc;}
	bool CanWork(void);
#define SEND_REQ_OK					0
#define SEND_REQ_NODE_BUSY			1
#define SEND_REQ_NODE_NOT_CONNECT	2
	int SendRequest(CRequestFlowObj &ReqObj);
#define ANSWER_CALL_OK					0
#define ANSWER_CALL_NODE_NOT_CONNECT	2
	int AnswerCall(CCallFuncObj &CallObj);

	bool IsRunning(void){return m_bIsClientRunning;}
private:
	bool m_bIsClientRunning;
	CNodeClientMonTask m_MonTask;
	CNodeClientWorkTask m_WorkTask;
	CRequestManager m_RequestManager;
	CNodeClientSvc *m_pNodeClientSvc;
private:
	static bool StartReactorThread(void);
	static bool m_bIsReactorThreadRunning;
#if defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
	static ACE_Dev_Poll_Reactor * s_DPReactor;
	static ACE_Reactor    * s_Reactor;
#else
	static ACE_TP_Reactor * s_TPReactor;
	static ACE_Reactor    * s_Reactor;
#endif //defined (ACE_HAS_DEV_POLL) || defined (ACE_HAS_EVENT_POLL)
};

#endif //__NODECLIENT_H__

