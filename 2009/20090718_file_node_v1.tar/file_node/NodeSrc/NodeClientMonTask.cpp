#include "NodeClientMonTask.h"
#include "NodeClientCmdMgr.h"
#include "NodeClient.h"
#include "NodeClientHeartBeat.h"


int CNodeClientMonTask::svc(void)
{
	m_bRuning = true;
	m_HeatBeatMon = NULL;
	while (m_bRuning)
	{
		ACE_Message_Block *MessageBlock = NULL;
		if (this->getq (MessageBlock ) < 0)
		{
			if ( errno == EWOULDBLOCK )
			{
				continue ;
			}
			break;
		}
		CNodeMonEvent *Event = (CNodeMonEvent *)MessageBlock->rd_ptr();
		switch(Event->m_Event)
		{
		case EVENT_STARTUP:
			m_strHost = Event->m_Params.GetParam("HOST");
			m_strPort = Event->m_Params.GetParam("PORT");
			m_strNodeId = Event->m_Params.GetParam("NODEID");
			// ǧ��ע�⣬����û��break
		case EVENT_CONN_LOST:
			m_Owner->SetClientSvc(NULL);
			if(m_HeatBeatMon)
			{
				ACE_Reactor::instance()->cancel_timer(m_HeatBeatMon, 0);
				delete m_HeatBeatMon;
				m_HeatBeatMon = NULL;
			}
			if (!MakeConnect(m_strHost, m_strPort))
			{
				ACE_Time_Value tmSleep(1);
				ACE_OS::sleep(tmSleep);
				CNodeMonEvent *Event = new CNodeMonEvent(EVENT_CONN_LOST);
				ACE_Message_Block *mb = new ACE_Message_Block((const char *) Event);
				putq(mb);
				break;
			}
			// ����ע��ָ��
			if (!RegistSelf(m_strNodeId))
			{
				ACE_Time_Value tmSleep(1);
				ACE_OS::sleep(tmSleep);
				CNodeMonEvent *Event = new CNodeMonEvent(EVENT_NODE_REGIST_FAILED);
				ACE_Message_Block *mb = new ACE_Message_Block((const char *) Event);
				putq(mb);
			}
			break;
		case EVENT_NODE_REGISTED:
			ACE_DEBUG((MY_DEBUG ACE_TEXT("Regist self ok!\n")));
			m_bNodeRegisted = true;
			break;
		case EVENT_NODE_REGIST_FAILED:
			// �����ǽڵ��Ѿ�ע�ᣬҲ�������ϴηǷ��˳����Է���ûȷ���ڵ��Ѿ��Ͽ�
			// �ƺ�û��ʲô������
			break;
		case EVENT_SHUTDOWN:
			if(m_HeatBeatMon)
			{
				ACE_Reactor::instance()->cancel_timer(m_HeatBeatMon, 0);
				delete m_HeatBeatMon;
				m_HeatBeatMon = NULL;
			}
			m_bNodeRegisted = false;
			flush();
			m_bRuning = false;
			break;
		default:
			;
		}
		MessageBlock->release();
		delete Event;
	}
	return 0;
}

void CNodeClientMonTask::stop(void)
{
	m_bRuning = false;
	flush();
}

bool CNodeClientMonTask::MakeConnect(string strHost, string strPort)
{
	m_bNodeRegisted = false;
	ACE_DEBUG((MY_DEBUG ACE_TEXT("Trying to connect to %s:%s \n")
		, strHost.c_str()
		, strPort.c_str()));
	ACE_Connector<CNodeClientSvc, ACE_SOCK_CONNECTOR> connector;

	ACE_INET_Addr port_to_connect((strHost +":"+strPort).c_str());

	// new �����Ķ��󣬻������ӶϿ���������ʧ�ܵ�ʱ���Զ�����
	m_pNodeClientSvc = new CNodeClientSvc();
	
	m_pNodeClientSvc->SetOwner(NULL);
	if( connector.connect( m_pNodeClientSvc , port_to_connect) != -1)
	{
		m_pNodeClientSvc->SetOwner(m_Owner);
		m_Owner->SetClientSvc(m_pNodeClientSvc);
		// ��������
		m_HeatBeatMon = new CNodeClientHeartBeatHandler;
		m_HeatBeatMon->m_bIsWaitingAnswer = false;
		m_HeatBeatMon->m_Owner = m_Owner;
		ACE_Time_Value tmDelay(100), tmInterval(100);
		ACE_Reactor::instance()->schedule_timer(m_HeatBeatMon, 0, tmDelay, tmInterval);
		return true;
	}
	ACE_DEBUG((MY_DEBUG ACE_TEXT("Connect %s:%s failed.\n")
		, strHost.c_str()
		, strPort.c_str()));
	return false;
}

bool CNodeClientMonTask::RegistSelf(string strNodeId)
{
	CCmdInfo cmd(m_pNodeClientSvc->peer().get_handle(), NULL);
	cmd.SetCommand("REGIST_NODE");
	cmd.SetParam("NODE_ID", strNodeId);
	return 	cmd.Send() == SEND_CMD_OK;
}

void CNodeClientMonTask::SetOwner(CNodeClient * Owner)
{
	m_Owner = Owner;
}


