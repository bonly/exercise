#ifndef __NODECLIENTMONTASK_H__
#define __NODECLIENTMONTASK_H__
#include "../PubSrc/Defs.h"
#include "../PubSrc/Utilities.h"
#include "NodeClientSvc.h"

class CNodeClientHeartBeatHandler;


enum NODE_EVENT{EVENT_STARTUP, EVENT_NODE_REGISTED, 
	EVENT_NODE_REGIST_FAILED, EVENT_CONN_LOST, EVENT_SHUTDOWN,
	EVENT_HEARTBEAT };
class CNodeMonEvent
{
public:
	CNodeMonEvent(NODE_EVENT Event)
		: m_Event(Event)
	{};
public:
	NODE_EVENT m_Event;
	CFastParamList m_Params;
};

class CNodeClientWorkTask;
class CNodeClient;

class CNodeClientMonTask
	: public ACE_Task<ACE_MT_SYNCH>
{
public:
	int svc(void);
	void stop(void);
public:
	bool m_bRuning;
	CNodeClientHeartBeatHandler * m_HeatBeatMon;
public:
	void SetOwner(CNodeClient * Owner);
private:
	bool MakeConnect(string strHost, string strPort);

	bool RegistSelf(string strNodeId);

	string m_strHost;
	string m_strPort;
	string m_strNodeId;
	bool m_bNodeRegisted;

	// CNodeClientSvc m_NodeClientSvc;
	CNodeClientSvc *m_pNodeClientSvc;
	CNodeClient *m_Owner;
};

#endif //__NODECLIENTMONTASK_H__

