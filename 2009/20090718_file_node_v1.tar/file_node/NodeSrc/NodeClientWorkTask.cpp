#include "NodeClientWorkTask.h"
#include "NodeClientMonTask.h"
#include "NodeClientSvc.h"
#include "NodeClientCmdMgr.h"
#include "NodeClient.h"

int CNodeClientWorkTask::svc(void)
{
	m_bRuning = true;
	while (m_bRuning)
	{
		ACE_Message_Block *MessageBlock = NULL;
		CNodeMonEvent *Event = NULL;
		if (this->getq (MessageBlock ) < 0)
		{
			if ( errno == EWOULDBLOCK )
			{
				continue ;
			}
			break;
		}
		CCmdInfo ResultInfo(ACE_INVALID_HANDLE, NULL);
		CMsgPack *MsgPack = (CMsgPack *)MessageBlock->rd_ptr();
		MessageBlock->release();
		switch(MsgPack->m_nMsgType)
		{
		case CMsgPack::MSG_ON_CONNECT:
			// ��������
			break;
		case CMsgPack::MSG_ON_CLOSE:
			// ���ӹرգ�֪ͨ����߳�
			Event = new CNodeMonEvent(EVENT_CONN_LOST);
			MessageBlock = new ACE_Message_Block((const char *) Event);
			m_Owner->GetMonTask()->putq(MessageBlock);
			break;
		case CMsgPack::MSG_ON_DATA: // ����ݴ�socket����
			// �������
			{
				CCmdInfo CmdInfo(MsgPack->m_Handle, m_Owner);
				switch( CmdInfo.SetCmdString(MsgPack->m_zPackage))
				{
				case SET_CMD_OK:
					// ���ù��ܵ�
					CBaseCmd * CmdObj;
					switch (ParseCmd(CmdInfo, &CmdObj))
					{
					case PARSE_CMD_OK :
						CmdObj->SetNodeClient(m_Owner);
						switch ( CmdObj->Execute() )
						{
						case EXECUTE_IMMEDIATE:
							ResultInfo = CmdObj->GetCmdInfo();
							ResultInfo.Send();
							break;
						case EXECUTE_IMMEDIATE_CLOSE:
							ResultInfo = CmdObj->GetCmdInfo();
							ResultInfo.Send();
							ACE_SOCK_Stream peer(ResultInfo.GetSockHandle()) ;
							peer.close();
						}
						delete CmdObj;
						break;
					case PARSE_CMD_UNSUPPORT_CMD :
						CmdInfo.SetAsUnsupportCmd();
						CmdInfo.Send();
						break;
					case PARSE_CMD_NOT_ENOUGH_PARAM	:
						CmdInfo.SetAsNotEnoughParam();
						CmdInfo.Send();
						break;
					}
					break;
				case SET_CMD_WRONG_CMD:
				case SET_CMD_WRONG_PARAM:
				default:
					CmdInfo.Send();
				}
			}
			break;
		case CMsgPack::MSG_ON_SEND_CALL:
			{
				CCallFuncObj * CallObj = (CCallFuncObj *) MsgPack->m_pObject;
				CCmdInfo CmdInfo(CallObj->m_SockHandle, m_Owner);
				CmdInfo.SetCommand("CALL_FUNC");
				CmdInfo.m_nCmdType = CMD_TYPE_ANSWER;
				CmdInfo.SetParam("SESSION", CallObj->m_strSessionId);
				CmdInfo.SetParam("FUNC", CallObj->m_strFuncId);
				CmdInfo.SetParam("PARAMS", CallObj->m_Params.Dump());
				CmdInfo.SetParam("RESULT", CallObj->m_strResult);
				CmdInfo.Send();
				delete CallObj;
			}
			break;
		case CMsgPack::MSG_ON_SEND_REQUEST:
			{
				CRequestFlowObj * RequestObj = (CRequestFlowObj *) MsgPack->m_pObject;
				// �������󣬲��������ͳ�ȥ��
				if (m_Owner->GetClientSvc() == NULL)
				{
					// ����ʧ�ܣ�����Ϊͨ��ʧ�ܴ���
					if (m_NodeEventHandler)
					{
						RequestObj->m_strResult="2"; // ����ƽ̨�ĳ�����Ϣ����Ӧƽ̨��RESULT(����õĻ�)
						CRequestFlowObj ReqObj(*RequestObj);
						m_NodeEventHandler->OnAnswerRequestFlow(ReqObj);
						delete RequestObj;
					}
				}
				else
				{
					CCmdInfo CmdInfo(m_Owner->GetClientSvc()->get_handle(), m_Owner);
					CmdInfo.SetCommand("REQUEST_FLOW");
					CmdInfo.m_nCmdType = CMD_TYPE_REQUEST;
					CmdInfo.SetParam("SESSION", RequestObj->m_strSessionId);
					CmdInfo.SetParam("FLOW",RequestObj->m_strFlowId);
					CmdInfo.SetParam("PARAMS", RequestObj->m_Params.Dump());
					if (CmdInfo.Send() == SEND_CMD_SOCK_ERR)
					{
						// ����ʧ�ܣ�����Ϊͨ��ʧ�ܴ���
						if (m_NodeEventHandler)
						{
							RequestObj->m_strResult="2"; // ����ƽ̨�ĳ�����Ϣ����Ӧƽ̨��RESULT(����õĻ�)
							CRequestFlowObj ReqObj(*RequestObj);
							m_NodeEventHandler->OnAnswerRequestFlow(ReqObj);
							delete RequestObj;
						}
					}
					else
					{
						// ���ͳɹ��������
						m_Owner->GetRequestManager()->AppendRequest(RequestObj);
					}
				}
			}
			break;
		case CMsgPack::MSG_ON_HEARTBEAT:
			{
				CCmdInfo CmdInfo(m_Owner->GetClientSvc()->get_handle(), m_Owner);
				CmdInfo.SetCommand("HELLO");
				CmdInfo.m_nCmdType = CMD_TYPE_REQUEST;
				CmdInfo.m_bNeedDumpMsg = false;
				if (CmdInfo.Send() == SEND_CMD_SOCK_ERR)
				{
					ACE_DEBUG((MY_DEBUG ACE_TEXT("Send hello failed.\n")));
				}
			}
			break;
		}
		delete MsgPack;
	}
	return 0;
}

void CNodeClientWorkTask::stop(void)
{
	m_bRuning = false;
	flush();
}

void CNodeClientWorkTask::SetEventHandler(CNodeEventHandlerBase * NodeEventHandler)
{
	if (m_NodeEventHandler)
	{
		delete m_NodeEventHandler;
	}
	m_NodeEventHandler = NodeEventHandler;
}

void CNodeClientWorkTask::SetOwner(CNodeClient * Owner)
{
	m_Owner = Owner;
}

CRequestFlowObj::CRequestFlowObj(ACE_HANDLE SockHandle, COMM_TYPE CommType)
	: m_SockHandle(SockHandle)
	, m_CommType(CommType)
{

}

CRequestFlowObj::CRequestFlowObj(const CRequestFlowObj & Source)
	: m_CommType    (Source.m_CommType    )
	, m_strSessionId(Source.m_strSessionId)
	, m_strFlowId   (Source.m_strFlowId   )
	, m_Params      (Source.m_Params      )
	, m_strResult   (Source.m_strResult   )
	, m_SockHandle  (Source.m_SockHandle  )
{

}

CCallFuncObj::CCallFuncObj(ACE_HANDLE SockHandle, COMM_TYPE CommType)
	: m_SockHandle(SockHandle)
	, m_CommType(CommType)
{

}

CCallFuncObj::CCallFuncObj(const CCallFuncObj & Source)
	: m_CommType    (Source.m_CommType    )
	, m_strSessionId(Source.m_strSessionId)
	, m_strFuncId   (Source.m_strFuncId   )
	, m_Params      (Source.m_Params      )
	, m_strResult   (Source.m_strResult   )
	, m_SockHandle  (Source.m_SockHandle  )
{

}


