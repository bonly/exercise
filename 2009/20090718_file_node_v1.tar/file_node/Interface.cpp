/*
 * Interface.cpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 */
#include "pre.hpp"
#include "Interface.hpp"

shared_ptr<Parser> parser;

int //解释文件
Parser::parse_file(int line, const char* buf, shared_ptr<File_record> &qry)
{
  return -1;
}


//5210011449477112,13168628378,GSM,0,510,570,G011,GX167,,2,13,5000,20111231000000,0,460012829917006,0,5210011412336848,Y
//返回值:
//0:成功的有效数据  1:成功的无效数据,如行首或统计 -1:失败
int //解释文件
BSS_Create_User::parse_file(int line, const char* buf, shared_ptr<File_record> &qry)
{
  clog << "parse BSS_Create_User file line " << line << endl;
  clog << "data are: " << buf << endl;
  //if (line==1) //首行
  //   return 1;

  //Create_user *obj= 0;
  try
  {
    shared_ptr<Create_user> obj(new Create_user);
    //obj = new Create_user;  //外部调用者需手工删除
    //todo:解释字段数据 把数据转给对象
    string str(buf);
    int begin = 0;
    int end = 0;
    int len = 0;

    end = str.find_first_of(',',begin);
    len = end - begin;
    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->COMMSERIAL);
    begin = end+1;

    end = str.find_first_of(',',begin);
    len = end - begin;
    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->USERNUMBER);
    begin = end+1;

//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->TELE_TYPE);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->STATE);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->PROVINCE);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->CITY);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->BRAND);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->ProdID);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    char nothing[2];
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",nothing);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->SCPTYPE);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->SCPID);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->BALANCE);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->VALIDDATE);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->SIM);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->IMS);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->PUK);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%[^,],",obj->res1);
//    begin = end+1;
//
//    end = str.find_first_of(',',begin);
//    len = end - begin;
//    sscanf (str.substr(begin,len).c_str(),"%s",obj->SCP);
//    begin = end+1;

//    sscanf (buf,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],"
//                  "%[^,],%[^,],%[^,],%[^,],%[^,],%[^,],"
//                  "%[^,],%[^,],%[^,],%[^,],%[^,]",
//         obj->COMMSERIAL,obj->USERNUMBER,obj->TELE_TYPE,
//         obj->STATE,obj->PROVINCE,obj->CITY,
//         obj->BRAND,obj->ProdID,obj->SCPTYPE,
//         obj->SCPID,obj->BALANCE,obj->VALIDDATE,
//         obj->SIM,obj->IMS,obj->PUK,
//         obj->res1,obj->SCP
//    );

    qry = obj;
  }
  catch(std::exception &e)
  {
    //delete obj;
    return -1;
  }
  return 0;
}

int //创建数据包
Create_user::create_cmd(CRequestFlowObj &obj, char *buf)
{
  try
  {
    obj.m_strFlowId = "BSS_CREATE_CUSTOMER";
    obj.m_strSessionId = COMMSERIAL;
    strcpy(buf, COMMSERIAL);
    obj.m_Params.SetParam("COMMSERIAL", COMMSERIAL);
    obj.m_Params.SetParam("USERNUMBER", USERNUMBER);
  }
  catch(std::exception &e)
  {
    clog << "create cmd err: " << e.what() << endl;
    return -1;
  }

  return 0;
}

int //解释ret
Parser::parse_ret(CRequestFlowObj *ret, Work_item **item)
{
  return -1;
}

int //解释ret
Parser::parse_ret(CRequestFlowObj *ret, shared_ptr<Work_item> &item)
{
  return -1;
}

int //从结果包中取出关键字
Parser::get_ret_key(CRequestFlowObj *ret, const char *key, char *value)
{
  return -1;
}

int //解释结果
BSS_Create_User::parse_ret(CRequestFlowObj *ret, shared_ptr<Work_item> &item)
{
  shared_ptr<BSS_Create_User_Ret> obj(new BSS_Create_User_Ret);
  if (ret->m_strResult == "0")
  {
    string strValue;
    ret->m_Params.GetParam("COMMSERIAL", strValue);
    strcpy(obj->COMMSERIAL,strValue.c_str());
  }
  else
  {
    // ...
  }
  item=obj;
  return 0;
}

int //解释结果
BSS_Create_User::parse_ret(CRequestFlowObj *ret, Work_item **item)
{
  BSS_Create_User_Ret *obj = new BSS_Create_User_Ret;
  if (ret->m_strResult == "0")
  {
    string strValue;
    ret->m_Params.GetParam("COMMSERIAL", strValue);
    strcpy(obj->COMMSERIAL,strValue.c_str());
  }
  else
  {
    // ...
  }
  *item = obj;
  return 0;
}

int //从结果包中取出关键字
BSS_Create_User::get_ret_key(CRequestFlowObj *ret, const char *key, char *value)
{
  string strVal;
  ret->m_Params.GetParam(key, strVal);
  strcpy(value, strVal.c_str());
  return 0;
}

int //把结果输出为回执记录
Work_item::create_line(const int line, char *buf)
{
   return -1;
}

int //把结果输出为回执记录
BSS_Create_User_Ret::create_line(const int line, char *buf)
{
   sprintf(buf,"%s,%s",COMMSERIAL,USERNUMBER);
   return 0;
}
