/*
 * Master.cpp
 *
 *  Created on: 2010-1-26
 *      Author: bonly
 */

#include "Master.hpp"
#include "Files.hpp"
extern Files job;

int //主线程
Master::svc (void)
{
  while (true)
  {
//    ACE_DEBUG
//      ((LM_DEBUG, ACE_TEXT ("(%t) Master Thread running\n")));
    //清理完成的文件
    job.remove_done();
    if(job.files.size()<1)
    {
//       ACE_DEBUG
//       ((LM_DEBUG, ACE_TEXT("(%t) star to add file job\n")));

        //扫描目录放入文件
       job.dir("/tmp/job/","test");
    }
    ACE_OS::sleep (2);
  }
  return 0;
}

