/*
 * Files.cpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 *       On Solaris, compile with -D_REENTRANT, on AIX with -D_THREAD_SAFE. On Linux, compile with '-pthread' (though Linux errno is thread-safe by default).
 */

#include "Files.hpp"
Files job;

void //标记增加一条发送记录
File::inc_irecord(Tmp &mp)
{
  ++irecord;
  record.insert(mp);
}

void //标记增加一条结果记录
File::inc_orecord()
{
  ++orecord;
  if(read_done && (irecord==orecord))
  {
    write_done = true;
    //关闭文件
    //ofile.close();
  }
}

int //删除文件
File::remove_file()
{
  if( remove( ifile_name.c_str() ) != 0 )
    perror( "Error deleting file" );
  else
    puts( "File successfully deleted" );
  return 0;
}

//返回结果
//0:成功,并且是最后一个记录  -1:失败 >=1:成功,并返回行数
int //取得行记录对象
File::get_obj (char *buf, int size)
{
  try
  {
    if(!ifile.is_open())//文件未打开
    {
      ifile.open(ifile_name.c_str(),ios_base::in);
    }
    ifile.getline(buf,size);
  }
  catch(ios_base::failure &e)
  {
    clog << "从文件读入记录失败:" << e.what() << endl;
  }

  iline += 1;
  int result = 0;
  if (chk_read_done()==true)
     result = 0;
  else
     result = iline;
  return result;
}

bool //检查文件是否已全部读取完毕
File::chk_read_done()
{
  if (ifile.peek()==EOF)
  {
    read_done = true;
    ifile.close();
    return true;
  }
  return false;
}

bool //检查文件或目录是否存在并可访问
Files::is_exists(const char* pfile)
{
  return (access(pfile, F_OK) == 0);
}

int  //取出指定目录中符合条件的文件名
Files::dir(const char* pdir, const char* namelike)
{
  DIR* pDir = NULL;

  struct dirent* pDirent;
  struct stat statinfo;

  int cnt = 0;
  //files.clear();
  if (is_exists(pdir))
    pDir = opendir(pdir);
  else
  {
    return -1;
  }
  if (pDir == NULL)
  {
    return -2;
  }

  char szFullName[256];
  while ((pDirent = readdir(pDir)) != NULL)
  {
    if ((strcmp(pDirent->d_name, ".") == 0) || (strcmp(pDirent->d_name, "..")
        == 0))
      continue;

    //if( max != 0 && cnt >= max )
    //        break;

    memset(szFullName, 0, sizeof(szFullName));
    strcpy(szFullName, pdir);
    strcat(szFullName, "/");
    strcat(szFullName, pDirent->d_name);
    if (stat(szFullName, &statinfo) == -1)
      continue;
    /* is directory */
    if (S_ISDIR( statinfo.st_mode ))
      continue;

    string name(szFullName);
    //if (name.find(namelike, 0) == string::npos)
    //  continue;  //只读文件名为指定形式的文件

    shared_ptr<File> file(new File);
    file->ifile_name=szFullName;
    file->ofile_name="../ret/";
    file->ofile_name.append(pDirent->d_name);
    file->iline = 0;
    file->irecord = 0;
    file->orecord = 0;
    file->read_done = false;
    file->write_done = false;

    ACE_Guard<ACE_Thread_Mutex> guard (_mutex);
    files.push_back(file);
    cnt++;

    //一次只读一个文件处理
   break;
  }

  closedir(pDir);

  return 0;
}

//当返回是NULL时,检查errno
//1
shared_ptr<File> //取得操作的文件对象
Files::get_not_done_file()
{
  shared_ptr<File> next_file;
  if(!files.empty())
  {
    if(_cur_file.get()==NULL || _cur_file->read_done) //已经读完 或 空值(首读)
    {
       //当前文件已经读完,读下一个文件
       //暂时只考虑打开一个文件,以后改为打开多个文件时再用find
      //list<shared_ptr<File> > it
      if((*files.begin())->read_done==false)
        next_file = *files.begin();
    }
    else //未读完
    {
      next_file = _cur_file; //继续读当前文件
    }
  }
  return next_file;
}


//返回值
//>=1:成功,并返回行数 -1:失败
//errno:1没有文件
int //取工作内容
Files::get_data(char *buf, int size)
{
  ACE_Guard<ACE_Thread_Mutex> guard (_mutex);
  if ((_cur_file = job.get_not_done_file()).get()==NULL)
  {
    errno = 1;//没有文件
    return -1;
  }
  if( _cur_file->read_done == true)
  {
    //当前文件即最后得到的文件已经读完,因假设只读一个文件,所以要等主线程移走此文件
    errno = 2;//没有未完成的文件
    return -1;
  }
  return _cur_file->get_obj(buf, size);
}

void //标识当前文件增加一条完成记录
Files::record_done(Tmp mp)
{
  ACE_Guard<ACE_Thread_Mutex> guard (_mutex);
  _cur_file->inc_irecord(mp);
  record.insert(mp);
}

//返回结果
//当shared_ptr<File> 是空时,检查errno
//1:没有文件
shared_ptr<File> //根据流水号中的文件标识查找源文件
Files::search_qry(const char* serial)
{
  ACE_Guard<ACE_Thread_Mutex> guard (_mutex);
  //因为暂时只有一个文件
  shared_ptr<File> ret;
  if (!files.empty())
  {
    ret = *files.begin();
  }
  else
  {
    errno = 1;
  }
  return ret;
}

int //清除已完成的文件
Files::remove_done()
{
  ACE_Guard<ACE_Thread_Mutex> guard (_mutex);
  BOOST_FOREACH(shared_ptr<File> f, files)
  {
     if(f->read_done==true && f->irecord==f->orecord)
     {
        BOOST_FOREACH(Tmp m, f->record)
        {
          delete m.second; //删除由文件记录生成的相应辅助包对象
          record.erase(record.find(m.first)); //删除总文件管理器中的相应包对象
        }
       f->remove_file();
     }
  }
  files.remove_if(oper_file_finished());
  return 0;
}

int //标识增加完成一条结果记录
Files::inc_orecord(shared_ptr<File> &file)
{
  ACE_Guard<ACE_Thread_Mutex> guard (_mutex);
  file->inc_orecord();
  return 0;
}



