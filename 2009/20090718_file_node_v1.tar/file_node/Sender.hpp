/*
 * Sender.hpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 */

#ifndef SENDER_HPP_
#define SENDER_HPP_
#include "pre.hpp"
#include "ace/Task.h"
#include "PubSrc/Defs.h"
#include "NodeSrc/NodeClient.h"

class CClientEventHandler : public CNodeEventHandlerBase
{
  public:
    virtual bool  // 处理消息的回应
    OnAnswerRequestFlow(CRequestFlowObj &);
};

class Sender : public ACE_Task_Base
{
  public:
    virtual int svc (void);

  private:
    CClientEventHandler EventHandler;
};

#endif /* SENDER_HPP_ */
