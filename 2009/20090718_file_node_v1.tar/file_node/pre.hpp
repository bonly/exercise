/*
 * pre.hpp
 *
 *  Created on: 2010-1-25
 *      Author: bonly
 */

#ifndef PRE_HPP_
#define PRE_HPP_
#include <string>
#include <iostream>
#include <fstream>
#include <list>
using namespace std;

#include <dirent.h>
#include <sys/stat.h>
#include <strings.h>

#include <cstring>

#include <boost/shared_ptr.hpp>
#include <boost/foreach.hpp>
using namespace boost;
/*
template <typename T>
class shared_ptr
{
  private:
    T* px;
    long* pn;
    typedef shared_ptr<T> this_type;

  public:
    shared_ptr():px(0),pn(0){}
    shared_ptr(T* p){px=p;pn=new long(1);}
    shared_ptr(const shared_ptr& r):px(r.px){++*(pn=r.pn);}
    shared_ptr& operator=(const shared_ptr& r)
    {this_type(r).swap(*this); return *this;}
    shared_ptr& operator=(shared_ptr& r)
    {this_type(r).swap(*this);return *this;}
    T& operator* () {return *px;}
    T* operator-> () {return px;}
    bool is_null(){return px==0?true:false;}
    ~shared_ptr ()
    {
      if (pn==NULL) return;
      if (--*pn==0)
      {
        delete px;px=NULL;
        delete pn;pn=NULL;
      }
    }
    long count (){return *pn;}
    void swap(shared_ptr<T> &other)
    {
      std::swap(px, other.px);
      std::swap(pn, other.pn);
    }
    void reset()
    {this_type().swap(*this);}
};
*/
/* -DACE_HAS_AIO_CALLS
 *
 * #undef ACE_HAS_DEV_POLL
 * #undef ACE_HAS_EVENT_POLL
 *
 */
#endif /* PRE_HPP_ */
