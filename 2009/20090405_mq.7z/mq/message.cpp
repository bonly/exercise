#include "message.hpp"
#include "data.hpp"
#include <fcntl.h>

enum{FILE_MODE=S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH};

int //������Ϣ���пɲ��������.
MQ::get_room(const char* name)
{
  struct mq_attr attr;
  attr.mq_maxmsg = 256;//���е���Ϣ��
  attr.mq_msgsize = sizeof(BF_SUBSCRIBER); //ÿ����Ϣ����󳤶�
  int flags = O_WRONLY;

  _mqd = mq_open(name,flags,FILE_MODE,NULL);
//BONLY_DEBUG
  if (_mqd == -1)
  {
//BONLY_DEBUG
    if (errno == ENOENT) //errno= 2:  No such file or directory
    {
//BONLY_DEBUG
     //��������
     flags |= O_CREAT;
     _mqd = mq_open(name,flags,FILE_MODE,attr);
//BONLY_DEBUG
     if (_mqd < 0)
     {
//BONLY_DEBUG
      perror ("mq_open");
      printf("[%d]errno: %d\n",getpid(),errno);
//BONLY_DEBUG
      return -1;
     }
    }
    else
    {
//BONLY_DEBUG
      perror ("mq_open");
      printf("[%d]errno: %d\n",getpid(),errno);
      close();
//BONLY_DEBUG
      return -1;
    }
  }
  if (Mq_getattr(_mqd, &attr)<0)
  {//ȡ��������
    close();
    return -1;
  }

  strcpy (_name, name);
  close();
  return (attr.mq_maxmsg - attr.mq_curmsgs);
}

int
MQ::send(const char* ptr, size_t len)
{
//BONLY_DEBUG  
  int flags = O_WRONLY | O_NONBLOCK;  
  _mqd = mq_open(_name,flags,FILE_MODE,NULL);
//BONLY_DEBUG  
  if (_mqd <0)
  {
    perror("mq_open");
    close();
    return -1;
  }
//BONLY_DEBUG
  int result = Mq_send(_mqd,ptr,len,0);
  if (result <0)
  {
    close();
    return -1;
  }
//BONLY_DEBUG
  close();
//BONLY_DEBUG  
  return result;
}

int
MQ::get_bf_subscriber(const char* name, BF_SUBSCRIBER* sub)
{
  struct mq_attr attr;
  attr.mq_maxmsg = 256;//���е���Ϣ��
  attr.mq_msgsize = sizeof(BF_SUBSCRIBER); //ÿ����Ϣ����󳤶�
  int flags = O_RDONLY | O_NONBLOCK;
  _mqd = Mq_open(name,flags,FILE_MODE,NULL);
  if (_mqd == -1 )
  {
    if (errno == 2) //errno= 2:  No such file or directory
    {
     //��������
     flags |= O_CREAT;
     _mqd = mq_open(name,flags,FILE_MODE,attr);

     if (_mqd < 0)
     {
      perror ("mq_open");
      printf("[%d]errno: %d\n",getpid(),errno);
      Mq_close(_mqd);
      return -1;
     }
    }
    else
    {
      perror ("mq_open");
      printf("[%d]errno: %d\n",getpid(),errno);
      Mq_close(_mqd);
      return -1;
    }
  }

  if (Mq_getattr(_mqd, &attr)<0)
  {
    Mq_close(_mqd);
    return -1;
  }

  //todo:�Ƿ�����BF_SUBSCRIBER�����ܱ�����Ϣ?

  uint_t prio = 0;
  ssize_t n = Mq_receive(_mqd,(char*)sub,attr.mq_msgsize,&prio);

  strcpy (_name, name);
  Mq_close(_mqd);
  return n;
}

int
MQ::unlink()
{
  return Mq_unlink(_name);
}
//==========================
//������Ϣ���к���
//==========================
mqd_t
MQ::Mq_open(const char* name, int oflag,...)
{
  mqd_t mqd = mq_open(name,oflag);

  if (mqd<0)
  {
    //errno=2 : No such file or directory
    //errno=22: Invalid argument
    //errno=24: Too many open files
    //errno=28: No space left on device
    perror("mq_open");
    printf("[%d]errno: %d\n",getpid(),errno);
  }
  return mqd;
}

int
MQ::Mq_close(mqd_t mqdes)
{
  int ret = mq_close(mqdes);
  if (ret < 0)
    perror("mq_close");
  return ret;
}

int
MQ::Mq_unlink(const char *name)
{
  int ret = mq_unlink(name);
  if (ret < 0)
    perror("mq_unlink");
  return ret;
}

int
MQ::Mq_getattr(mqd_t mqdes, struct mq_attr *attr)
{
  int ret = mq_getattr(mqdes,attr);
  if (ret < 0)
    perror("mq_getattr");
  return ret;
}

int
MQ::Mq_setattr(mqd_t mqdes, const struct mq_attr *attr,
               struct mq_attr *oattr)
{
  int ret = mq_setattr(mqdes,attr,oattr);
  if (ret < 0)
    perror("mq_setattr");
  return ret;
}

int
MQ::Mq_send(mqd_t mqdes, const char* ptr, size_t len,
            unsigned int prio)
{
//BONLY_DEBUG  
  int ret = mq_send(mqdes,ptr,len,prio);
  if (ret < 0)
  {
    //errno=11:Resource temporarily unavailable
    //�����ط�����������ȡ
    if (errno != 11)
    {
      perror("mq_send");
      printf("[%d]errno: %d\n",getpid(),errno);
    }
  }
//BONLY_DEBUG    
  return ret;
}

ssize_t
MQ::Mq_receive(mqd_t mqdes, char* ptr, size_t len,
               unsigned int *priop)
{
  ssize_t ret = mq_receive(mqdes, ptr, len, priop);
  if (ret < 0)
  {
    //errno=11:Resource temporarily unavailable
    //�����ط�����������ȡ
    if (errno != 11)
    {
      perror("mq_receive");
      printf("[%d]errno: %d\n",getpid(),errno);
    }
  }
  return ret;
}


