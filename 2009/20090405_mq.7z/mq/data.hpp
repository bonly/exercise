//============================================================================
// Name        : 
// Author      : bonly
// Version     :
// Copyright   : 
// Description : �����������ݽṹ
//============================================================================
#ifndef __DATA_HPP__
#define __DATA_HPP__

//�û�
struct BF_SUBSCRIBER
{
  long long          SUBS_ID;
  long long          ACC_NBR;
  char               BRAND_ID[2+1];
  char               STATUS[2+1];
  char               BELONG_DISTRICT[6+1];
  int                SUBS_TYPE;
  int                DEF_ACCT_ID;
  BF_SUBSCRIBER()
  {memset(this,0,sizeof(BF_SUBSCRIBER));}
};

#endif 

