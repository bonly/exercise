#include "message.hpp"
#include "data.hpp"
#include <boost/shared_ptr.hpp>
#include <unistd.h>

using namespace boost;

int
main(int argc, char* argv[])
{
  MQ mq;
  for(;;)
  {
    shared_ptr<BF_SUBSCRIBER> sub(new BF_SUBSCRIBER);
    mq.get_bf_subscriber("/tmp/test",
                     &(*sub));
    sleep(atoi(argv[1]));
  }
  return 0;
}
  
/*
aCC -AA +DD64 recvmain.cpp message.o -o mrecv -lrt -L/home/hejb/boost_1_37_0/stage/lib -lboost_system-mt
*/
