//============================================================================
// Name        : 
// Author      : bonly
// Version     :
// Copyright   : 
// Description : ��Ϣ����
//============================================================================
#ifndef __MESSAGE_HPP__
#define __MESSAGE_HPP__
#include <mqueue.h>
#include <cstring>

struct BF_SUBSCRIBER;
class MQ
{
  public:
    MQ(){memset(_name,0,255);}
    int get_room(const char* name);
    int send(const char* ptr, size_t len);
    int get_bf_subscriber(const char* name, BF_SUBSCRIBER* sub);
    int unlink();

  private:
    char _name[255];
    mqd_t _mqd;

  private:
    int   close(){return Mq_close(_mqd);}//�ɸ���Ĺ�����������ر�
    
  private:  
    mqd_t Mq_open(const char* name, int oflag,...);
    int   Mq_close(mqd_t mqdes);
    int   Mq_unlink(const char *name);
    int   Mq_getattr(mqd_t mqdes, struct mq_attr *attr);
    int   Mq_setattr(mqd_t mqdes, const struct mq_attr *attr,
                     struct mq_attr *oattr);
    int   Mq_send(mqd_t mqdes, const char* ptr, size_t len,
                     unsigned int prio);
  ssize_t Mq_receive(mqd_t mqdes, char* ptr, size_t len,
                     unsigned int *priop);
};

#endif
