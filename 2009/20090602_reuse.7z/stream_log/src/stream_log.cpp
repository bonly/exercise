//============================================================================
// Name        : stream_log.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : application, Ansi-style
//============================================================================
#define _WIN32_WINNT
#define __USE_W32_SOCKETS
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <boost/asio.hpp>
using namespace boost;
using namespace boost::asio;
#include <iostream>
using namespace std;

class Acceptor
{
  public:
    Acceptor(io_service io):_io(io)
    {
      ip::tcp::endpoint ep(ip::address::from_string("127.0.0.1"),9837);
      _acceptor.open(ep.protocol());
      _acceptor.set_option(ip::tcp::acceptor::reuse_address(true));
      _acceptor.bind(ep);
      _acceptor.listen();
      _acceptor.async_accept(_socket,
          bind(&Acceptor::on_accepted,this,placeholders::error));
    }
  private:
    io_service        &_io;
    ip:tcp::socket     _socket;
    ip::tcp::acceptor  _acceptor;
};

class Application
{
  public:
    int run()
    {
        _threads.create_thread (bind)
    }
  private:
    thread_group _theads;
};

int main()
{
    Application app;
    app.run();

	return 0;
}
