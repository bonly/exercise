/*
 * application.cpp
 *
 *  Created on: 2009-8-27
 *      Author: bonly
 */
#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/lexical_cast.hpp>
#include <iostream>
using namespace std;
using namespace boost;
using namespace boost::asio;

class Process
{


};

class Acceptor
{
  public:
    Acceptor(io_service &io):_io(io),_socket(io),_acceptor(io)
    {
      ip::tcp::endpoint ep(
          ip::address::from_string("192.168.0.11"),9898);
      _acceptor.open(ep.protocol());
      _acceptor.set_option(ip::tcp::acceptor::reuse_address(true));
      _acceptor.bind(ep);
      _acceptor.listen();
    }
    int on_accepted(boost::system::error_code const &e)
    {
      if(!e)
      {
        cerr << "Accept a client\n";
        pid_t pid;
        static char i='0';
        if((pid=fork())==0)
        {
          _acceptor.close();
          if (execlp("/mnt/he/workspace/Application/Debug/Process","Process",
                     lexical_cast<string>(_socket.native()).c_str(),lexical_cast<string>(i).c_str(),(char*)0)<0)
            cerr << "start process fail\n";
          exit(0);
        }
        ++i;
        _socket.close();
        _acceptor.async_accept(_socket,
            bind (&Acceptor::on_accepted, this, placeholders::error));
      }
      else
      {
        std::cerr << "Accept error: " << e.message() << "\n";
      }
      return 0;
    }
    int run()
    {
      //_acceptor.accept(_socket);
      _acceptor.async_accept(_socket,
          bind (&Acceptor::on_accepted, this, placeholders::error));
      return 0;
    }

  private:
    io_service &_io;
    ip::tcp::socket _socket;
    ip::tcp::acceptor _acceptor;
};

class Application
{
  public:
    Application():worker(io)
    {
    }
    int run()
    {
      Acceptor acc(io);
      acc.run();
      while (true)
      {
        //std::cout << "OK before "<< std::endl;
        io.run();
        //std::cout << "OK after"<< std::endl;
      }
      return 0;
    }
  private:
    io_service io;
    io_service::work worker;
};

int
main()
{
  Application app;
  app.run();
  std::cout << "OK"<< std::endl;
  return 0;
}
