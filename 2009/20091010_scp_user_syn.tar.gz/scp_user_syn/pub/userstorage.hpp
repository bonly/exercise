#ifndef __USERSTORAGE_HPP__
#define __USERSTORAGE_HPP__

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

const int NDCBUFF_LEN   = 1000;
const int SN1_LEN       = 10000;
const int SN2_LEN       = 10000;


//��ʾ�ֻ�������4λ
struct SN2
{
    typedef char STATETYPE;

    SN2();
    void init();

    long        balance[SN2_LEN];
    long        timestamp;
    u_short     scpid[SN2_LEN];
    u_short     card_effect[SN2_LEN];
    u_short     card_expire[SN2_LEN];
    u_short     balance_effect[SN2_LEN];
    u_short     balance_expire[SN2_LEN];
    u_short     count;
    char        valid_balance[SN2_LEN / 8];
    STATETYPE   state[SN2_LEN];
    STATETYPE   life[SN2_LEN];
    int         area[SN2_LEN];
};

//��ʾ�ֻ�����м�4λ
struct SN1
{
    SN1();
    void init();

    SN2*    sn1List[SN1_LEN];
    int     inFile[SN1_LEN];
    int     count;      //SN1�Ŷε�����
};


struct PageList
{
    int  ndc;
    int  sn1;
    SN2* ptr;
};

class UserStorage
{
public:
    UserStorage();
    ~UserStorage();

    int init();

    int add(int ndc, int sn1, int sn2, long balance,
            const char* balance_effect, const char* balance_expire);

    int add(int ndc, int sn1, int sn2, SN2::STATETYPE state,
            u_short scpid, const char* card_expire, const int life);

    int add(int ndc, int sn1, int sn2, SN2::STATETYPE state,
            u_short scpid, const char* card_effect,const char* card_expire, long balance,
            const char* balance_effect, const char* balance_expire,
            SN2::STATETYPE life, const char* area
            );

    int enum_all_user(FILE* file);

    long get_count();

private:
    SN2* add(int ndc, int sn1, int sn2);

    int enum_user_memlimit(FILE* file);

    int enum_user_nolimit(FILE* file);

private:
    long  m_count;
    SN1*  m_ndcBuff[NDCBUFF_LEN];       //��ʾ�ֻ�����ͷ3λ������������
};

u_short compress_date(const char* date);

void extra_date(u_short usdate, char* date);

#endif
