#ifndef __LOG_HPP__
#define __LOG_HPP__

#include "config.hpp"


class Log
{
public:
    Log();
    ~Log();

    static Log* get_instance();
    static Log* get_error_log_instance();
    static Log* get_data_log_instance();

    int open(const char*);

    int openErrorLog(const char* fileName);

    void close();

    void write_log(const char* format, ...);

    void write_buffer(const void* buffer, int size);

    const std::string& get_file_name();

    void write_time();

private:
    std::string m_fileName;
    FILE*       m_logfile;
    bool        m_isEmpty;
    bool        m_isErrLog;
};


#endif
