#include <string>
#include <string.h>
#include <iostream>
#include <errno.h>
#include <time.h>
#include <stdarg.h>
#include "log.hpp"
#include "config.hpp"

using namespace std;

Log::Log()
    : m_logfile(NULL), m_isEmpty(true)
{
}

Log::~Log()
{
    close();
}

int Log::open(const char* appName)
{
    string log_path;
    
    if(!Config::get_instance()->get_item("cfg", "log_path", log_path))
    {
        cout << "Failed to get log path !\n";
        return -1;
    }

    time_t t = time(NULL);
    struct tm* ptm = localtime(&t);
    char logFileName[1024] = {0};
    snprintf(logFileName, 1023, "%s/%s_%4d%.2d%.2d_%.2d%.2d%.2d.log",
        log_path.c_str(),
        appName,
        ptm->tm_year + 1900,
        ptm->tm_mon  + 1,
        ptm->tm_mday,
        ptm->tm_hour,
        ptm->tm_min,
        ptm->tm_sec);

    m_fileName = logFileName;
    m_logfile  = fopen(logFileName, "aw");

    if(NULL == m_logfile)
    {
        printf("Failed to create log file: %s\n", strerror(errno));
        return -1;
    }

    m_isEmpty  = true;
    m_isErrLog = false;
    return 0;
}

int Log::openErrorLog(const char* fileName)
{
    string log_path;

    if(!Config::get_instance()->get_item("cfg", "err_log_path", log_path))
    {
        cout << "Failed to get log path !\n";
        return -1;
    }

    time_t t = time(NULL);
    struct tm* ptm = localtime(&t);
    char logFileName[1024] = {0};

    snprintf(logFileName, 1023, "%s/%s_%4d%.2d%.2d_%.2d%.2d%.2d.err",
        log_path.c_str(),
        fileName,
        ptm->tm_year + 1900,
        ptm->tm_mon  + 1,
        ptm->tm_mday,
        ptm->tm_hour,
        ptm->tm_min,
        ptm->tm_sec);

    m_fileName = logFileName;
    m_logfile  = fopen(logFileName, "aw");

    if(NULL == m_logfile)
    {
        printf("Failed to create log file: %s\n", strerror(errno));
        return -1;
    }

    m_isEmpty  = true;
    m_isErrLog = true;
    return 0;
}

void Log::close()
{
    if(m_logfile)
    {
        fclose(m_logfile);
        m_logfile = NULL;

        //如果日志是空的,就把文件删掉
        if(m_isErrLog && m_isEmpty)
        {
            remove(m_fileName.c_str());
        }
    }
}

void Log::write_log(const char* format, ...)
{
    if(NULL == m_logfile)
    {
        return;
    }
    
    m_isEmpty = false;
    va_list ap;
    va_start(ap, format);
    vfprintf(m_logfile, format, ap);
    va_end(ap);
}

void Log::write_buffer(const void* buffer, int size)
{
    if(NULL == m_logfile)
    {
        return;
    }
    
    m_isEmpty = false;
    fwrite(buffer, size, 1, m_logfile);
}

void Log::write_time()
{
    if(NULL == m_logfile)
    {
        return;
    }
    
    m_isEmpty = false;
    time_t t = time(NULL);
    struct tm* ptm = localtime(&t);

    fprintf(m_logfile, "Info: [Time] %.2d:%.2d:%.2d\n",
        ptm->tm_hour,
        ptm->tm_min,
        ptm->tm_sec);
}

const std::string& Log::get_file_name()
{
    return m_fileName;
}

Log* Log::get_instance()
{
    static Log slog;
    return &slog;
}

Log* Log::get_error_log_instance()
{
    static Log elog;
    return &elog;
}

Log* Log::get_data_log_instance()
{
    static Log dlog;
    return &dlog;
}
