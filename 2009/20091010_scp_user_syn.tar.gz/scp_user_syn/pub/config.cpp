#include "config.hpp"
#include <string.h>

using namespace std;

void Analyzer::process_null_line(char c)
{
	switch(c)
	{
	case '\0':
	case ' ':
	case '\t':
		_state = NULLLINE;
		return;

	case '[':
		process_section(c);
		return;

	case '#':
		_state = COMMENTBEGIN;
		return;

	default:
		break;
	}

	if( ('A' <= c && 'Z' >= c) ||
		('a' <= c && 'z' >= c) ||
		('0' <= c && '9' >= c) ||
		'_' == c )
	{
		process_item(c);
	}
}

void Analyzer::process_item(char c)
{
	switch(_state)
	{
	case NULLLINE:
		_cfgObj.item.itemname.begin = _index;
		_state = ITEMNAME;
		break;

	case ITEMNAME:
		if(' ' == c || '\t' == c)
		{
			_cfgObj.item.itemname.end = _index;
			_state = ITEMNAMEEND;
		}
		else if('=' == c)
		{
			_cfgObj.item.itemname.end = _index;
			_state = ITEMASSIGN;
		}
		else if( !(
			('A' <= c && 'Z' >= c) ||
			('a' <= c && 'z' >= c) ||
			('0' <= c && '9' >= c) ||
			'-' == c || '_' == c) )
		{
			_state = FAIL;
		}
		break;

	case ITEMNAMEEND:
		if('=' == c)
		{
			_state = ITEMASSIGN;
		}
		else if(' ' != c && '\t' != c)
		{
            cout << "dbg: ---------- 1" << endl;
			_state = FAIL;
		}
		break;

	case ITEMASSIGN:
		if('#' == c)
		{
            cout << "dbg: ---------- 2" << endl;
			_state = FAIL;
		}
		else if('\0' == c)  //��������ֵ
		{
            //cout << "dbg: ---------- 3" << endl;
			//_state = FAIL;
            _cfgObj.item.itemvalue.begin = _index;
            _cfgObj.item.itemvalue.end   = _index;
            _state = ITEMVALUE;
		}
		else if(' ' != c && '\t' != c)
		{
			_cfgObj.item.itemvalue.begin = _index;
			_state = ITEMVALUE;
		}
		break;

	case ITEMVALUE:
		if('#' == c)
		{
			_cfgObj.item.itemvalue.end = _index;
			_cfgObj.item.comment.begin = _index;
			_state = ITEMCOMMENTBEGIN;
		}
		else if('\0' == c)
		{
			_cfgObj.item.itemvalue.end = _index;
		}
		break;

	default:
        cout << "dbg: ---------- 4" << endl;
		_state = FAIL;
		break;
	}
}

void Analyzer::process_section(char c)
{
	switch(_state)
	{
	case NULLLINE:
		_state = ('[' == c) ? SECTIONBEGIN : FAIL;
		break;

	case SECTIONBEGIN:
		if( ('A' <= c && 'Z' >= c) ||
			('a' <= c && 'z' >= c) ||
			('0' <= c && '9' >= c) ||
			'_' == c )
		{
			_cfgObj.section.begin = _index;
			_state = SECTIONNAME;
		}
		else if(' ' != c && '\t' != c)
		{
            cout << "dbg: ---------- 5" << endl;
			_state = FAIL;
		}
		break;

	case SECTIONNAME:
		if(' ' == c || '\t' == c)
		{
			_cfgObj.section.end = _index;
			_state = SECTIONNAMEEND;
		}
		else if(']' == c)
		{
			_cfgObj.section.end = _index;
			_state = SECTIONEND;
		}
		else if( !(
			('A' <= c && 'Z' >= c) ||
			('a' <= c && 'z' >= c) ||
			('0' <= c && '9' >= c) ||
			'-' == c || '_' == c) )
		{
            cout << "dbg: ---------- 6" << endl;
			_state = FAIL;
		}
		break;

	case SECTIONNAMEEND:
		if(']' == c)
		{
			_state = SECTIONEND;
		}
		else if(' ' != c && '\t' != c)
		{
            cout << "dbg: ---------- 7" << endl;
			_state = FAIL;
		}
		break;

	case SECTIONEND:
		if('#' == c)
		{
			_cfgObj.section.comment.begin = _index;
			_state = SECTIONCOMMENTBEGIN;
		}
		else if(' ' != c && '\t' != c && '\0' != c)
		{
            cout << "dbg: ---------- 8" << endl;
			_state = FAIL;
		}
		break;

    default:
        break;
	}
}

void Analyzer::process_comment(char c)
{
	switch(_state)
	{
	case SECTIONCOMMENTBEGIN:
		_state = SECTIONCOMMENT;
		break;

	case SECTIONCOMMENT:
		if('\0' == c)
		{
			_cfgObj.section.comment.end = _index;
		}
		break;

	case ITEMCOMMENTBEGIN:
		_state = ITEMCOMMENT;
		break;

	case ITEMCOMMENT:
		if('\0' == c)
		{
			_cfgObj.item.comment.end = _index;
		}
		break;

	case COMMENTBEGIN:
		_state = COMMENT;
		break;

	case COMMENT:
		if('\0' == c)
		{
			_cfgObj.comment.end = _index;
		}
		break;

	default:
        cout << "dbg: ---------- 9" << endl;
		_state = FAIL;
		break;
	}
}

void Analyzer::process_error(char c)
{/*��*/}

void Analyzer::_dispatch(char c)
{
	switch(_state)
	{
	case NULLLINE:
		process_null_line(c);
		break;

	case ITEMNAME:
	case ITEMNAMEEND:
	case ITEMVALUE:
	case ITEMASSIGN:
		process_item(c);
		break;

	case SECTIONBEGIN:
	case SECTIONEND:
	case SECTIONNAME:
	case SECTIONNAMEEND:
		process_section(c);
		break;

	case ITEMCOMMENT:
	case SECTIONCOMMENT:
	case COMMENTBEGIN:
	case COMMENT:
	case SECTIONCOMMENTBEGIN:
	case ITEMCOMMENTBEGIN:
		process_comment(c);
		break;

	case FAIL:
		process_error(c);
		break;

	default:
		break;
	}
}

Analyzer::TYPE Analyzer::state_to_type(Analyzer::STATE state)
{
	switch(state)
	{
	case COMMENT:
		return TYPE_COMMENT;

	case NULLLINE:
		return TYPE_NULLLINE;

	case ITEMVALUE:
	case ITEMCOMMENT:
		return TYPE_ITEM;

	case SECTIONEND:
	case SECTIONCOMMENT:
		return TYPE_SECTION;

	default:
		return TYPE_INVALID;
	}

	//return TYPE_INVALID;
}

Analyzer::Analyzer()
{/*空*/}

Analyzer::TYPE Analyzer::operator () (char (&buffer)[MAX_LINE_SIZE])
{
	_state = NULLLINE;	//��ʼ״̬ΪNULLLINE
	memset(&_cfgObj, 0, sizeof(_cfgObj));

	for(_index = 0; _index < MAX_LINE_SIZE; ++_index)
	{
		_dispatch(buffer[_index]);

		if('\0' == buffer[_index])
		{
			_dispatch('\0');
			return state_to_type(_state);
		}
	}

    cout << "dbg: ---------- 10" << endl;
	return TYPE_INVALID;
}

bool Analyzer::get_section(string& sectionName, char const* buffer)
{
	if(SECTIONCOMMENT == _state || SECTIONEND == _state)
	{
		sectionName.clear();
		sectionName.append(&buffer[_cfgObj.section.begin],
			_cfgObj.section.end - _cfgObj.section.begin);
		return true;
	}

    cout << "dbg: ---------- 11" << endl;
	return false;
}

bool Analyzer::get_comment(string& comment, char const* buffer)
{
	switch(_state)
	{
    	case SECTIONCOMMENT:
    		comment.clear();
    		comment.append(&buffer[_cfgObj.section.comment.begin + 2],
    			_cfgObj.section.comment.end - _cfgObj.section.comment.begin - 2);
    		return true;
    
    	case ITEMCOMMENT:
    		comment.clear();
    		comment.append(&buffer[_cfgObj.item.comment.begin + 2],
    			_cfgObj.item.comment.end - _cfgObj.item.comment.begin - 2);
    		return true;
    
    	case COMMENT:
    		comment.clear();
    		comment.append(&buffer[_cfgObj.comment.begin + 2],
    			_cfgObj.comment.end - _cfgObj.comment.begin - 2);
    		return true;
    
        default:
            break;
	}

    cout << "dbg: ---------- 12" << endl;
	return false;
}

bool Analyzer::get_item(string& itemName, string& itemValue, char const* buffer)
{
	if(ITEMCOMMENT == _state || ITEMVALUE == _state)
	{
		itemName.clear();
		itemValue.clear();
		itemName.append(&buffer[_cfgObj.item.itemname.begin], _cfgObj.item.itemname.end - _cfgObj.item.itemname.begin);

        if(_cfgObj.item.itemvalue.begin == _cfgObj.item.itemvalue.end)
        {
            return true;
        }

		//ȥ��valueĩβ�Ŀո�
		while(1)
		{
			if(buffer[_cfgObj.item.itemvalue.end - 1] == ' ' ||
				buffer[_cfgObj.item.itemvalue.end - 1] == '\t')
			{
				--_cfgObj.item.itemvalue.end;
			}
			else
			{
				break;
			}
		}

		itemValue.append(&buffer[_cfgObj.item.itemvalue.begin], _cfgObj.item.itemvalue.end - _cfgObj.item.itemvalue.begin);
		return true;
	}

    cout << "dbg: ---------- 13" << endl;
	return false;
}

///////////////////////////////////////////////////////////////////

Config::Config()
{/*��*/}

Config::~Config()
{/*��*/}

bool Config::load(const string& fileName)
{
	std::fstream cfgFile;
	cfgFile.open(fileName.c_str(), ios::in);

	if(0 == cfgFile.is_open())
	{
        cout << "dbg: ---------- 14" << endl;
		return false;
	}

	Analyzer analyzer;
	char buff[Analyzer::MAX_LINE_SIZE] = {0};
	
	//����ȱʡ��section
	string sectionName = ".default";
	_sectionList.insert(make_pair(sectionName, ItemList()));

	while(!cfgFile.eof())
	{
		cfgFile.getline(buff, Analyzer::MAX_LINE_SIZE);

		switch(analyzer(buff))
		{
		case Analyzer::TYPE_SECTION:
			{
				analyzer.get_section(sectionName, buff);

				SectionPtr sPtr = _sectionList.find(sectionName);

				if(_sectionList.end() == sPtr)
				{
					_sectionList.insert(make_pair(sectionName, ItemList()));
				}
			}
			break;

		case Analyzer::TYPE_ITEM:
			{
				string name, val;
				analyzer.get_item(name, val, buff);

				SectionPtr sPtr = _sectionList.find(sectionName);

				if(_sectionList.end() == sPtr)
				{
                    cout << "dbg: ---------- 15" << endl;
					return false;
				}

				sPtr->second.insert(make_pair(name, val));
			}
			break;

		case Analyzer::TYPE_NULLLINE:
		case Analyzer::TYPE_COMMENT:
			break;

		case Analyzer::TYPE_INVALID:
            cout << "dbg: ---------- 16" << endl;
			return false;

		default:
			break;
		}
	}

	return true;
}

bool Config::get_item(const string& sectionName, const string& itemName, string& value)
{
	SectionPtr sPtr = _sectionList.find(sectionName);

	if(_sectionList.end() == sPtr)
	{
        cout << "dbg: ---------- 17" << endl;
		return false;
	}

	ItemPtr iPtr = sPtr->second.find(itemName);

	if(sPtr->second.end() == iPtr)
	{
		return false;
	}

	value = iPtr->second;
	return true;
}

void Config::get_section_list(SectionList& secList)
{
	secList.clear();

	for(SectionPtr sPtr = _sectionList.begin(); sPtr != _sectionList.end(); ++sPtr)
	{
		secList.push_back(sPtr->first);
	}
}

Config* Config::get_instance()
{
    static Config cfg;
    return &cfg;
}
