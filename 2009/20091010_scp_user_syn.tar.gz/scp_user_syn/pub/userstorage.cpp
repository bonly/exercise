#include <stdlib.h>
#include <iostream>
#include "userstorage.hpp"
#include "defs.hpp"

using namespace std;

SN2::SN2()
{
    init();
}

void SN2::init()
{
    count = 0;
    memset(balance, 0, sizeof(balance));
    memset(state, _INVALID_VALUE, sizeof(state));
    memset(life, _LIFE_INVALID, sizeof(life));
    memset(valid_balance, 0, sizeof(valid_balance));
}

SN1::SN1() : count(0)
{
    memset(sn1List, 0, sizeof(sn1List));
}

void SN1::init()
{
    count = 0;
    memset(sn1List, 0, sizeof(sn1List));
    memset(inFile, -1, sizeof(inFile));
}

UserStorage::UserStorage() : m_count(0)
{
    memset(m_ndcBuff, 0, sizeof(m_ndcBuff));
}

UserStorage::~UserStorage()
{
    int ndc, sn1;

    for(ndc = 0; ndc < NDCBUFF_LEN; ++ndc)
    {
        if(NULL != m_ndcBuff[ndc])
        {
            for(sn1 = 0; sn1 < SN1_LEN; ++sn1)
            {
                if(NULL != m_ndcBuff[ndc]->sn1List[sn1])
                {
                    free(m_ndcBuff[ndc]->sn1List[sn1]);
                }
            }

            free(m_ndcBuff[ndc]);
        }
    }
}

int UserStorage::init()
{
    return 0;
}

////////////////////////////////////////////////////////////////////////

SN2* UserStorage::add(int ndc, int sn1, int sn2)
{
    SN2* sn2Ptr = NULL;

    if(NULL == m_ndcBuff[ndc])
    {
        m_ndcBuff[ndc] = (SN1*)malloc(sizeof(SN1));

        if(NULL == m_ndcBuff[ndc])
        {
            return NULL;
        }

        m_ndcBuff[ndc]->init();
    }

    sn2Ptr = m_ndcBuff[ndc]->sn1List[sn1];

    if(NULL == sn2Ptr)
    {
        sn2Ptr = (SN2*)malloc(sizeof(SN2));

        if(NULL == sn2Ptr)
        {
            return NULL;
        }

        sn2Ptr->init();
        m_ndcBuff[ndc]->count++;

        m_ndcBuff[ndc]->sn1List[sn1] = sn2Ptr;
        sn2Ptr->timestamp = m_count;
    }
    else
    {
        sn2Ptr->timestamp = m_count;
    }

    return sn2Ptr;
}


int UserStorage::add(int ndc, int sn1, int sn2, long balance,
                     const char* balance_effect, const char* balance_expire)
{
    SN2* sn2Ptr = add(ndc, sn1, sn2);

    if(NULL == sn2Ptr)
    {
        return -1;
    }

    sn2Ptr->balance[sn2] += balance;
    sn2Ptr->balance_effect[sn2] = compress_date(balance_effect);
    sn2Ptr->balance_expire[sn2] = compress_date(balance_expire);
    sn2Ptr->valid_balance[sn2 / 8] |= (1 << (sn2 % 8));

    return 0;
}

int UserStorage::add(int ndc, int sn1, int sn2, SN2::STATETYPE state,
                     u_short scpid, const char* card_expire, const int life)
{
    SN2* sn2Ptr = add(ndc, sn1, sn2);

    if(NULL == sn2Ptr)
    {
        return -1;
    }

    if(_INVALID_VALUE == sn2Ptr->state[sn2])
    {
        sn2Ptr->state[sn2] = (SN2::STATETYPE)state;
        sn2Ptr->scpid[sn2] = scpid;
        sn2Ptr->card_expire[sn2] = compress_date(card_expire);
        sn2Ptr->life[sn2]  = life;
        sn2Ptr->area[sn2]  = 0;
        sn2Ptr->count++;
        m_count++;
    }
fprintf(stderr, "add\n");
    return 0;
}

int UserStorage::add(int ndc, int sn1, int sn2, SN2::STATETYPE state,
                     u_short scpid, const char* card_effect, const char* card_expire, long balance,
                     const char* balance_effect, const char* balance_expire,
                     SN2::STATETYPE life, const char* area)
{
    SN2* sn2Ptr = add(ndc, sn1, sn2);
    if(NULL == sn2Ptr)
    {
        return -1;
    }

    if(_INVALID_VALUE == sn2Ptr->state[sn2])
    {
        sn2Ptr->state[sn2]   = (SN2::STATETYPE)state;
        sn2Ptr->balance[sn2] = balance * 2;
        sn2Ptr->valid_balance[sn2 / 8] |= (1 << (sn2 % 8));
        sn2Ptr->scpid[sn2] = scpid;
        sn2Ptr->card_effect[sn2]    = compress_date(card_effect);
        sn2Ptr->card_expire[sn2]    = compress_date(card_expire);
        sn2Ptr->balance_effect[sn2] = compress_date(balance_effect);
        sn2Ptr->balance_expire[sn2] = compress_date(balance_expire);
        sn2Ptr->life[sn2]    = (SN2::STATETYPE)life;        	
        sn2Ptr->area[sn2]    = atoi(area);
     
        sn2Ptr->count++;
        m_count++;
    }

    return 0;
}

long UserStorage::get_count()
{
    return m_count;
}

int UserStorage::enum_all_user(FILE* file)
{
    return enum_user_nolimit(file);
}

int UserStorage::enum_user_memlimit(FILE* file)
{
    _ASSERT(NULL != msisdn_array);
    char card_expire[9];
    char balance_effect[9];
    char balance_expire[9];
    long ndc = 0;
    long sn1 = 0;
    long sn2 = 0;
    long index = 0;
    long ndc_sn1 = 0;
    SN2* sn2Ptr;

    for(; ndc < NDCBUFF_LEN; ++ndc)
    {
        if(NULL != m_ndcBuff[ndc])
        {
            for(sn1 = 0; sn1 < SN1_LEN; ++sn1, ndc_sn1 += 10000)
            {
                if((NULL == m_ndcBuff[ndc]->sn1List[sn1]) &&
                     (-1 == m_ndcBuff[ndc]->inFile[sn1]))
                {
                    continue;
                }

                if(NULL != m_ndcBuff[ndc]->sn1List[sn1])
                {
                    sn2Ptr = m_ndcBuff[ndc]->sn1List[sn1];
                }
                else
                {
                    if(NULL == sn2Ptr)
                    {
                        cout << "Error" << endl;
                        return -1;
                    }
                }

                for(sn2 = 0; sn2 < SN2_LEN; ++sn2)
                {
                    extra_date(sn2Ptr->card_expire[sn2], card_expire);

                    if(_INVALID_VALUE != sn2Ptr->state[sn2])
                    {
                        ++index;
                        if(sn2Ptr->valid_balance[sn2 / 8] & (1 << (sn2 % 8)))
                        {
                            extra_date(sn2Ptr->balance_effect[sn2], balance_effect);
                            extra_date(sn2Ptr->balance_expire[sn2], balance_expire);

                            fprintf(file,
                                "%11ld,%3d,%8d,%8s,%16ld,%8s,%8s\n",
                                ndc_sn1 + sn2,
                                sn2Ptr->state[sn2],
                                sn2Ptr->scpid[sn2],
                                card_expire,
                                sn2Ptr->balance[sn2],
                                balance_effect,
                                balance_expire);
                        }
                        else
                        {
                            fprintf(file,
                                "%11ld,%3d,%8d,%8s,%16s,%8s,%8s\n",
                                ndc_sn1 + sn2,
                                sn2Ptr->state[sn2],
                                sn2Ptr->scpid[sn2],
                                card_expire,
                                "<NULL>",
                                "<NULL>",
                                "<NULL>");
                        }

                        if(m_count == index)
                        {
                            return 0;
                        }
                    }
                }
            }
        }
        else
        {
            ndc_sn1 += 100000000;
        }
    }

    return 0;
}

int UserStorage::enum_user_nolimit(FILE* file)
{	
    _ASSERT(NULL != msisdn_array);

    char card_effect[9];
    char card_expire[9];
    char balance_effect[9];
    char balance_expire[9];
    long long ndc = 0;
    long long sn1 = 0;
    long long sn2 = 0;
    long long index = 0;
    long long ndc_sn1 = 0;
    SN2* sn2Ptr;

    for(; ndc < NDCBUFF_LEN; ++ndc)
    {
        if(NULL != m_ndcBuff[ndc])
        {
            for(sn1 = 0; sn1 < SN1_LEN; ++sn1, ndc_sn1 += 10000)
            {
                if(NULL != m_ndcBuff[ndc]->sn1List[sn1])
                {
                    sn2Ptr = m_ndcBuff[ndc]->sn1List[sn1];

                    for(sn2 = 0; sn2 < SN2_LEN; ++sn2)
                    {       	
                        extra_date(sn2Ptr->card_expire[sn2], card_expire);
                        extra_date(sn2Ptr->card_effect[sn2], card_effect);
if(sn2==1059)fprintf(stderr,"%s%d\n",__FILE__,__LINE__); 
                        if(_INVALID_VALUE != sn2Ptr->state[sn2])
                        {
                            ++index;
if(sn2==1059)fprintf(stderr,"%s%d\n",__FILE__,__LINE__); 
                            if(sn2Ptr->valid_balance[sn2 / 8] & (1 << (sn2 % 8)))
                            {
                                extra_date(sn2Ptr->balance_effect[sn2], balance_effect);
                                extra_date(sn2Ptr->balance_expire[sn2], balance_expire);

                                fprintf(file,
                                    "%11lld,%3d,%8d,%8s,%8s,%16ld,%8s,%8s,%3d,%3d\n",
                                    ndc_sn1 + sn2,
                                    sn2Ptr->state[sn2],
                                    sn2Ptr->scpid[sn2],
                                    card_effect,
                                    card_expire,
                                    sn2Ptr->balance[sn2],
                                    balance_effect,
                                    balance_expire,
                                    sn2Ptr->life[sn2],
                                    sn2Ptr->area[sn2]
                                    );
                            }
                            else
                            {
                                fprintf(file,
                                    "%11ld,%3d,%8d,%8s,%8s,%16s,%8s,%8s,%3d,%3d\n",
                                    ndc_sn1 + sn2,
                                    sn2Ptr->state[sn2],
                                    sn2Ptr->scpid[sn2],
                                    card_effect,
                                    card_expire,
                                    "<NULL>",
                                    "<NULL>",
                                    "<NULL>",
                                          0,
                                          0);
                            }

                            if(m_count == index)
                            {
                                return 0;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            ndc_sn1 += 100000000;
        }
    }

    return 0;
}

u_short compress_date(const char* date)
{
    u_short tmpy = (date[0] - '0') * 1000 +
                   (date[1] - '0') * 100 +
                   (date[2] - '0') * 10 +
                   (date[3] - '0');

    tmpy = (tmpy - 1980) << 9;
    u_short tmpm = ((date[4] - '0') * 10+ (date[5] - '0')) << 5;
    u_short tmpd = ((date[6] - '0') * 10+ (date[7] - '0')) - 1;
    return (tmpy + tmpm + tmpd);
}

void extra_date(u_short usdate, char* date)
{
    u_short tmpy = (usdate >> 9) + 1980;
    u_short tmpm = (usdate & 0x1FF) >> 5;
    u_short tmpd = (usdate & 0x1F) + 1;
    sprintf(date, "%04d%02d%02d", tmpy, tmpm, tmpd);
}
