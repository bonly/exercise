#ifndef __DEFS_HPP__
#define __DEFS_HPP__

#include <string>
#include <list>
#include <signal.h>
#include <string.h>
#include <vector>
#include <stdlib.h>
#include "config.hpp"


#define CUST_ID(ACC_NBR)    (ACC_NBR + 900000000000)
#define SUBS_ID(ACC_NBR)    (ACC_NBR + 800000000000)
#define ACCT_ID(ACC_NBR)    (ACC_NBR * 10 + 7000000000001)

const long CONV_1900_1970 = 2208988800L;

const int MAX_MOD_FILE_NUM = 60;

//////////////////////////////////////////////////////////////////////////////////////

const int LINE_SIZE     = 86;
const int MSISDN_SIZE   = 11;
const int STATE_START   = 12;
const int STATE_END     = 14;
const int BALANCE_BEGIN = 34;
const int BALANCE_END   = 49;
const int LIFE_BEGIN    = 80;
const int LIFE_END      = 81;
const int AREA_BEGIN    = 82;
const int AREA_END      = 85;

//////////////////////////////////////////////////////////////////////////////////////

struct UniFile
{
    double balance;
    char   state[4];
    char   MSISDN[12];
    char   card_effect[9];
    char   card_expire[9];
    char   balance_effect[9];
    char   balance_expire[9];
    char   life;
    char   area[4];
};


enum SUBS_STATUS
{
    USER_STATE_BOOT,
    USER_STATE_ACTIVE_STOP,
    USER_STATE_MISSING,
    USER_STATE_PRE_CANCEL,
    USER_STATE_CANCEL,
    USER_STATE_STOP,
    USER_STATE_HALF_STOP,
    USER_STATE_LOCK,
    USER_STATE_WAITE_TOPUP,
    USER_STATE_PRE_EASTABLSH,
    _INVALID_VALUE = -1
};

enum LIFE_STATUS
{
	LIFE_NOT_ACTIVE=0,
	LIFE_USING=1,
	LIFE_TOPUP=2,
	LIFE_LOCK=3,
	LIFE_TOPUP2=4,
	LIFE_LOCK2=5,
	LIFE_DEL=9,
	_LIFE_INVALID=-1
};

/*
enum STATE_VALUE
{
    _2HA,           //正常
    _2HB,           //注销
    _2HC,           //
    _2HD,           //
    _2HE,           //停机
    _2HF,           //
    _2HG,           //挂失
    _2HH,           //
    _2HI,           //
    _2HJ,           //
    _2HK,           //半停机
    _2HL,           //黑名单
    _2HM,           //未激活
    _INVALID_VALUE, //无效值
    _DELETE,        //删除状态
    INVALID_STATE = -1
};
*/

#ifdef __DEBUG__
    #define _ASSERT(x) if(!(x)){printf("ASSERT:\n  File     : %s\n  Function : %s\n  Line     : %d\n  Failed   : (%s)\n", __FILE__, __FUNCTION__, __LINE__, #x);exit(0);}
#else
    #define _ASSERT(x)
#endif

template<class TYPE>
class Array_Guard
{
public:
    Array_Guard(long size)
    {
        if(0 >= size)
        {
            throw 0;
        }

        m_length = size * sizeof(TYPE);
        m_ptr = (TYPE*)malloc(m_length);

        if(NULL == m_ptr)
        {
            throw 0;
        }
    }

    Array_Guard(const Array_Guard& array_guard) :
         m_ptr(NULL), m_length(0)
    {
    }

    Array_Guard() : m_ptr(NULL), m_length(0)
    {
    }

    ~Array_Guard()
    {
        if(m_ptr)
        {
            free(m_ptr);
        }
    }

    void allocate(long size)
    {
        if(0 >= size)
        {
            throw 0;
        }

        m_length = size * sizeof(TYPE);
        m_ptr = (TYPE*)malloc(m_length);

        if(NULL == m_ptr)
        {
            throw 0;
        }
    }

    inline operator TYPE* ()
    {
        return m_ptr;
    }

    inline size_t length()
    {
        return m_length;
    }

private:
    TYPE*   m_ptr;
    size_t  m_length;
};

class NumberRangeFilter
{
    struct NumberRange
    {
        long long start;
        long long end;
        long long count;
    };

    enum NRStatus
    {
        NR_FIND_START_NUMBER,
        NR_FIND_END_NUMBER,
        NR_START_NUMBER,
        NR_END_NUMBER,
        NR_INVALID_RANGE,
        NR_SEPERATER,
        NR_FIND_SEMICOLON
    };

public:
    bool init(const char* number);

    bool inNumberRange(long long number);

    void dump();

private:
    void insertNRList(const std::string& num1, const std::string& num2, std::vector<NumberRange>& nrlist);

private:
    std::vector<NumberRange>    m_numberList;
};

inline static void split_number(const char* msisdn, int& ndc, int& sn1, int& sn2)
{
    _ASSERT(NULL != msisdn);

    long long i = atoll(msisdn);
    ndc = static_cast<int>(i / 100000000);
    sn1 = static_cast<int>((i / 10000) % 10000);
    sn2 = static_cast<int>(i % 10000);
}

inline static void split_number(long long msisdn, int& ndc, int& sn1, int& sn2)
{
    ndc = static_cast<int>(msisdn / 100000000);
    sn1 = static_cast<int>((msisdn / 10000) % 10000);
    sn2 = static_cast<int>(msisdn % 10000);
}

inline static int check_ndc(int ndc)
{
    if((130 > ndc) || (134 < ndc))
    {
        return -1;
    }

    return 0;
}

LIFE_STATUS translate_hw_life(const long SubState, const int AccountState,
                              const long file_date,const long lock_stop,
                              const long AccountStop,const long ServiceStop,
                              const double balance);
SUBS_STATUS translate_hw_state(int SubState, int AccountState);
SUBS_STATUS translate_state(const char* state);
int translate_state(SUBS_STATUS, char (&state)[4]);

extern "C" typedef void (*sighandler_t)(int);
void install_sighandler(sighandler_t handler);

long get_time(char* strtime);

//是否闰年
int is_leap_year(int year);

//获取一个月的最后一天
int get_last_day(int year, int month);

int check_date_format(char date[9]);
int check_date_format(int& year, int& month, int& day);

//根据year,month,day获取下一天的日期
void get_yesterday(int year, int month, int day, int& year2, int& month2, int& day2);

int create_succ_file(const std::string& tmp_file_path, const char* appName);

#define print_time dbg_print_time
#define vprint_time dbg_vprint_time

void dbg_print_time();
void dbg_vprint_time(const char* fmt, ...);

#define INIT_LOG(APP_NAME)\
    if(0 != Log::get_instance()->open(APP_NAME))\
    {\
        return -1;\
    }


bool init_config();


#define OPEN_DATA_LOG(FILE_NAME)\
    if(0 != Log::get_data_log_instance()->openErrorLog(FILE_NAME))\
    {\
        return -1;\
    }

#define OPEN_ERR_LOG(FILE_NAME)\
    if(0 != Log::get_error_log_instance()->openErrorLog(FILE_NAME))\
    {\
        return -1;\
    }

#define CLOSE_ERR_LOG() Log::get_error_log_instance()->close()

#define CLOSE_DATA_LOG() Log::get_data_log_instance()->close()

#define WRITE_LOG Log::get_instance()->write_log

#define WRITE_ERR_LOG Log::get_error_log_instance()->write_log

#define WRITE_DATA_LOG Log::get_data_log_instance()->write_log

#define WRITE_ERR_LOG_BUFFER(PTR, SIZE) Log::get_error_log_instance()->write_buffer(PTR, SIZE)

#define WRITE_DATA_LOG_BUFFER(PTR, SIZE) Log::get_data_log_instance()->write_buffer(PTR, SIZE)

#define LOG_TIME Log::get_instance()->write_time

#define LOG_SEPARATOR Log::get_instance()->write_log(\
    "==============================================================\n");

#endif
