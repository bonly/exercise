#include <stdarg.h>
#include <stdlib.h>
#include "defs.hpp"




bool init_config()
{
    char* ocs_home = getenv("OCS_HOME");

    if(NULL == ocs_home || 0 == strlen(ocs_home))
    {
        std::cout << "Environment 'OCS_HOME' not exist;";
        return false;
    }

    char cfg_path[1024];
    sprintf(cfg_path, "%s/etc/scptoocs.cfg", ocs_home);
    if(!Config::get_instance()->load(cfg_path))
    {
        std::cout << "Failed to read configuration !\n";
        return false;
    }

    return true;
}


long get_time(char* strtime)
{
    char str[12];
    struct tm tm = {0};

    memcpy(str, strtime, 4);
    str[4] = '\0';
    tm.tm_year = atoi(str) - 1900;

    memcpy(str, strtime + 4, 2);
    str[2] = '\0';
    tm.tm_mon = atoi(str) - 1;

    memcpy(str, strtime + 6, 2);
    str[2] = '\0';
    tm.tm_mday = atoi(str);

    return mktime(&tm) + CONV_1900_1970;
}

LIFE_STATUS translate_hw_life(const long SubState, const int AccountState,
                              const long file_date,const long lock_stop,
                              const long AccountStop,const long ServiceStop,
                              const double AccountLeft)
{
//fprintf(stderr, "substat:%ld accstat:%d file:%ld lock:%ld accstop:%ld serstop:%ld left:%f\n",
//   	SubState,AccountState,file_date,lock_stop,AccountStop,ServiceStop,AccountLeft);
   	
	LIFE_STATUS ret = LIFE_USING;
	if (AccountState==1)
	{
		if (lock_stop < file_date)
			return ret = LIFE_DEL;
		if (AccountStop < file_date)
			return ret = LIFE_LOCK;
	}
	else if(AccountState==3||AccountState==7)
	{
		return ret = LIFE_NOT_ACTIVE;
	}
	if (ServiceStop < file_date || AccountLeft < 0)
	{
		return ret  = LIFE_TOPUP;
	}
	return ret;
}
                              
SUBS_STATUS translate_hw_state(int SubState, int AccountState)
{
    switch(AccountState)
    {
        case 1:             //有效
            if(1 == SubState)       //开机
            {
                return USER_STATE_BOOT; //开机
            }
            else if(0 == SubState)  //全停机
            {
                return USER_STATE_STOP; //停机
            }
            else if(6 == SubState)  //停呼入权限（允许呼出）
            {
                return USER_STATE_HALF_STOP;    //半停机
            }
            else
            {
                return _INVALID_VALUE;
            }

        case 2:             //黑名单
            return USER_STATE_MISSING;  //挂失

        case 3:             //未头次使用
            return USER_STATE_PRE_EASTABLSH;    //预开户

        case 4:             //挂失
            return USER_STATE_MISSING;  //挂失

        case 5:             //HLR激活
            return USER_STATE_BOOT; //开机

        case 6:             //生成
            if(1 == SubState)       //开机
            {
                return USER_STATE_BOOT; //开机
            }
            else if(0 == SubState)  //全停机
            {
                return USER_STATE_STOP; //停机
            }
            else if(6 == SubState)  //停呼入权限（允许呼出）
            {
                return USER_STATE_HALF_STOP;    //半停机
            }
            else
            {
                return _INVALID_VALUE;
            }

        case 7:             //未头次使用挂失
            return USER_STATE_MISSING;  //挂失

        case 8:             //黑名单挂失
            return USER_STATE_MISSING;  //挂失

        default:
            return _INVALID_VALUE;
    }
}


SUBS_STATUS translate_state(const char* state)
{
    if('0' == state[0])
    {
        switch(state[1])
        {
        case '0':   //开机
            return USER_STATE_BOOT;

        case '1':   //主动停机
            return USER_STATE_ACTIVE_STOP;

        case '3':   //挂失
            return USER_STATE_MISSING;

        case '4':   //预约销户
            return USER_STATE_PRE_CANCEL;

        case '5':   //销户
            return USER_STATE_CANCEL;

        case '6':   //停机
            return USER_STATE_STOP;

        case '7':   //半停
            return USER_STATE_HALF_STOP;

        case '8':   //锁定
            return USER_STATE_LOCK;

        case '9':   //待充值
            return USER_STATE_WAITE_TOPUP;
        }
    }
    else if('9' == state[0] && '9' == state[1]) //预开户
    {
        return USER_STATE_PRE_EASTABLSH;
    }

    return _INVALID_VALUE;
}

int translate_state(SUBS_STATUS stateVal, char (&state)[4])
{
    state[0] = '0';
    state[2] = '\0';

    switch(stateVal)
    {
    case USER_STATE_BOOT:
        state[1] = '0';
        break;

    case USER_STATE_ACTIVE_STOP:
        state[1] = '1';
        break;

    case USER_STATE_MISSING:
        state[1] = '3';
        break;

    case USER_STATE_PRE_CANCEL:
        state[1] = '4';
        break;

    case USER_STATE_CANCEL:
        state[1] = '5';
        break;

    case USER_STATE_STOP:
        state[1] = '6';
        break;

    case USER_STATE_HALF_STOP:
        state[1] = '7';
        break;

    case USER_STATE_LOCK:
        state[1] = '8';
        break;

    case USER_STATE_WAITE_TOPUP:
        state[1] = '9';
        break;

    case USER_STATE_PRE_EASTABLSH:
        state[0] = '9';
        state[1] = '9';
        break;

    case _INVALID_VALUE:
        return -1;
    }

    return -1;
}

void dbg_print_time()
{
    time_t t = time(NULL);
    struct tm* ptm = localtime(&t);

    printf("%.2d:%.2d:%.2d\n",
        ptm->tm_hour,
        ptm->tm_min,
        ptm->tm_sec);
}

void dbg_vprint_time(const char* fmt, ...)
{
    time_t t = time(NULL);
    struct tm* ptm = localtime(&t);

    printf("%.2d:%.2d:%.2d - ",
        ptm->tm_hour,
        ptm->tm_min,
        ptm->tm_sec);

    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
}

void install_sighandler(sighandler_t handler)
{
    signal(SIGINT,  handler);
    signal(SIGHUP,  handler);
    signal(SIGQUIT, handler);
    signal(SIGTERM, handler);
    signal(SIGTSTP, handler);
}

int is_leap_year(int year)
{
    if((((year%4) == 0) && ((year%100) != 0)) || ((year%400) == 0))
    {
        return 1;
    }

    return 0;
}

int get_last_day(int year, int month)
{
    switch(month)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            return 31;

        case 4:
        case 6:
        case 9:
        case 11:
            return 30;

        case 2:
            if(is_leap_year(year))
            {
                return 29;
            }
            else
            {
                return 28;
            }

        default:
            return -1;
    }
}

int check_date_format(char date[9])
{
    int year = (date[0] - '0') * 1000 +
               (date[1] - '0') * 100  +
               (date[2] - '0') * 10   +
               (date[3] - '0');

    int month = (date[4] - '0') * 10 + date[5] - '0';

    if(1 > month || month > 12)
    {
        return -1;
    }

    int day = (date[6] - '0') * 10 + date[7] - '0';

    switch(month)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            if(1 > day || day > 31) //�жϴ��µ������Ƿ���ȷ
            {
                return -1;
            }
            break;

        case 4:
        case 6:
        case 9:
        case 11:
            if(1 > day || day > 30) //�ж�С�µ������Ƿ���ȷ
            {
                return -1;
            }
            break;

        case 2:
            if(is_leap_year(year))     //����
            {
                if(1 > day || day > 29)
                {
                    return -1;
                }
            }
            else
            {
                if(1 > day || day > 28)
                {
                    return -1;
                }
            }

            break;
    }

    //�޸����ݲ���1980��2100֮��������
    if(1980 > year)
    {
        memcpy(date, "19800101", 9);
    }
    else if(year > 2100)
    {
        memcpy(date, "21001231", 9);
    }

    return 0;
}

int check_date_format(int& year, int& month, int& day)
{
    if(1 > month || month > 12)
    {
        return -1;
    }

    switch(month)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            if(1 > day || day > 31) //�жϴ��µ������Ƿ���ȷ
            {
                return -1;
            }
            break;

        case 4:
        case 6:
        case 9:
        case 11:
            if(1 > day || day > 30) //�ж�С�µ������Ƿ���ȷ
            {
                return -1;
            }
            break;

        case 2:
            if(is_leap_year(year))     //����
            {
                if(1 > day || day > 29)
                {
                    return -1;
                }
            }
            else
            {
                if(1 > day || day > 28)
                {
                    return -1;
                }
            }
            break;
    }

    //�޸����ݲ���1980��2100֮��������
    if(1980 > year)
    {
        year  = 1980;
        month = 1;
        day   = 1;
    }
    else if(year > 2100)
    {
        year  = 2100;
        month = 12;
        day   = 31;
    }

    return 0;
}

void get_yesterday(int year, int month, int day, int& year2, int& month2, int& day2)
{
    if(1 == day)
    {
        if(1 == month)
        {
            year2  = year - 1;
            month2 = 12;
        }
        else
        {
            year2  = year;
            month2 = month - 1;
        }

        day2   = get_last_day(year2, month2);
    }
    else
    {
        year2  = year;
        month2 = month;
        day2   = day - 1;
    }
}

int create_succ_file(const std::string& tmp_file_path, const char* appName)
{
    std::string fn = tmp_file_path + "/success_" + appName;
    FILE* file = fopen(fn.c_str(), "w");

    if(file)
    {
        fclose(file);
        return 0;
    }

    return -1;
}

bool NumberRangeFilter::inNumberRange(long long number)
{
    int cnt = (int)m_numberList.size();

    if(0 == cnt)
    {
        return true;
    }

    for(int i = 0; i < cnt; ++i)
    {
        if(number >= m_numberList[i].start && number <= m_numberList[i].end)
        {
            ++m_numberList[i].count;
            return true;
        }
    }

    return false;
}

void NumberRangeFilter::insertNRList(const std::string& num1, const std::string& num2, std::vector<NumberRange>& nrlist)
{
    int size1 = num1.size();
    int size2 = num2.size();
    std::string tmpnum1 = num1;
    std::string tmpnum2 = num2;

    if((0 != size1 && 11 >= size1) && (0 != size2 && 11 >= size2))
    {
        int i;

        for(i = size1; i < 11; ++i)
        {
            tmpnum1 += '0';
        }

        for(i = size2; i < 11; ++i)
        {
            tmpnum2 += '0';
        }

        NumberRange nr;
        nr.start = atoll(tmpnum1.c_str());
        nr.end   = atoll(tmpnum2.c_str());
        nr.count = 0;

        if(nr.start > nr.end)
        {
            long long temp = nr.start;
            nr.start = nr.end;
            nr.end   = temp;
        }

        nrlist.push_back(nr);
    }
}

bool NumberRangeFilter::init(const char* number_str)
{
    int pos = 0;
    NRStatus status = NR_FIND_START_NUMBER;
    std::string num1, num2;

    while('\0' != number_str[pos])
    {
        switch(status)
        {
        case NR_FIND_START_NUMBER:
            num1 = "";
            if('0' <= number_str[pos] && number_str[pos] <= '9')
            {
                num1 = number_str[pos];
                status = NR_START_NUMBER;
            }
            else if(' ' != number_str[pos])
            {
                status = NR_INVALID_RANGE;
            }
            break;

        case NR_START_NUMBER:
            if('0' <= number_str[pos] && number_str[pos] <= '9')
            {
                num1 += number_str[pos];
            }
            else if('-' == number_str[pos])
            {
                status = NR_FIND_END_NUMBER;
            }
            else if(' ' == number_str[pos])
            {
                status = NR_SEPERATER;
            }
            else
            {
                status = NR_INVALID_RANGE;
            }
            break;

        case NR_SEPERATER:
            if('-' == number_str[pos])
            {
                status = NR_FIND_END_NUMBER;
            }
            else if(' ' != number_str[pos])
            {
                status = NR_INVALID_RANGE;
            }
            break;

        case NR_FIND_END_NUMBER:
            num2 = "";

            if('0' <= number_str[pos] && number_str[pos] <= '9')
            {
                num2 = number_str[pos];
                status = NR_END_NUMBER;
            }
            else if(' ' != number_str[pos])
            {
                status = NR_INVALID_RANGE;
            }
            break;

        case NR_END_NUMBER:
            if('0' <= number_str[pos] && number_str[pos] <= '9')
            {
                num2 += number_str[pos];
            }
            else if(';' == number_str[pos])
            {
                insertNRList(num1, num2, m_numberList);
                status = NR_FIND_START_NUMBER;  //����һ���Ŷ�
            }
            else if(' ' == number_str[pos])
            {
                status = NR_FIND_SEMICOLON;
            }
            else
            {
                status = NR_INVALID_RANGE;
            }
            break;

        case NR_FIND_SEMICOLON:
            if(';' == number_str[pos])
            {
                insertNRList(num1, num2, m_numberList);
                status = NR_FIND_START_NUMBER;  //����һ���Ŷ�
            }
            else if(' ' != number_str[pos])
            {
                status = NR_INVALID_RANGE;
            }
            break;

        case NR_INVALID_RANGE:
            return false;

        default:
            return false;
        }

        ++pos;
    }

    if(NR_END_NUMBER == status)
    {
        insertNRList(num1, num2, m_numberList);
    }

    return true;
}

void NumberRangeFilter::dump()
{
    int cnt = (int)m_numberList.size();

    for(int i = 0; i < cnt; ++i)
    {
        std::cout << m_numberList[i].start << "-" << m_numberList[i].end << " : " << m_numberList[i].count << std::endl;
    }
}
