#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <fstream>
#include <list>
#include <map>
#include <iostream>


class Analyzer
{
public:
	enum {MAX_LINE_SIZE = 1024};

	enum TYPE {
            TYPE_SECTION,
            TYPE_ITEM,
            TYPE_COMMENT,
            TYPE_NULLLINE,
            TYPE_INVALID
    };

private:

	enum STATE {
		NULLLINE,
		ITEMNAME,
		ITEMNAMEEND,
		ITEMASSIGN,
		ITEMVALUE,
		ITEMCOMMENTBEGIN,
		ITEMCOMMENT,
		SECTIONBEGIN,
		SECTIONNAME,
		SECTIONNAMEEND,
		SECTIONEND,
		SECTIONCOMMENTBEGIN,
		SECTIONCOMMENT,
		COMMENTBEGIN,
		COMMENT,
		FAIL
	};

	union ConfigObj
	{
		struct Section
		{
			int begin;
			int end;
			struct Comment
			{
				int begin;
				int end;
			}comment;
		}section;

		struct Item
		{
			struct Itemname
			{
				int begin;
				int end;
			}itemname;
			struct Itemvalue
			{
				int begin;
				int end;
			}itemvalue;
			struct Comment
			{
				int begin;
				int end;
			}comment;
		}item;

		struct Comment
		{
			int begin;
			int end;
		}comment;
	};

	int			_index;
	STATE		_state;
	ConfigObj	_cfgObj;

private:

	void process_null_line(char c);
	void process_item(char c);
	void process_section(char c);
	void process_comment(char c);
	void process_error(char c);
	void _dispatch(char c);
	static TYPE state_to_type(STATE state);

public:

	Analyzer();

	TYPE operator () (char (&buffer)[MAX_LINE_SIZE]);	
	bool get_section(std::string& sectionName, char const* buffer);
	bool get_comment(std::string& comment, char const* buffer);
	bool get_item(std::string& itemName, std::string& itemValue, char const* buffer);
};


class Config
{
public:
    static Config* get_instance();

private:
	typedef std::map<std::string, std::string>           ItemList;
	typedef std::map<std::string, ItemList>              SectionMap;
	typedef std::map<std::string, std::string>::iterator ItemPtr;
	typedef std::map<std::string, ItemList>::iterator    SectionPtr;
	SectionMap		_sectionList;

public:
	typedef std::list<std::string>                       SectionList;

	Config();
	~Config();

	bool load(const std::string& fileName);
	bool get_item(const std::string& sectionName, const std::string& itemName, std::string& value);
	void get_section_list(SectionList& secList);
};

#endif
