#ifndef __UTC_HPP__
#define __UTC_HPP__
#include <ctime>
#include <string.h>
#include <stdio.h>
#include <errno.h>
/*
 * ������ʱ���๤��
 */
class CUtcTime
{
public:
  CUtcTime(){};
  ~CUtcTime(){};

  static time_t Time(time_t tTime=0);
  static time_t MakeTime(int nYear, int nMonth, int nDay, int nHour=0, int nMinute=0, int nSecond=0);
  static char *ToString(char *szTime, const char *szFormat, time_t tUtcTime);
  static char *Format(char *szTime, const char *szFormat, const struct tm *ptm);
  static int  IsLeapYear(int nYear);
};

struct DAY
{
  char year[5];
  char month[3];
  char day[3];
  DAY(const char* data)
  {
    memset (this,0,sizeof(DAY));
    strncpy (year,data,4);
    strncpy (month,data+4,2);
    strncpy (day,data+6,2);
  }
};
#endif


