#ifndef __FILEFILTER_HPP__
#define __FILEFILTER_HPP__

#include <set>
#include <vector>
#include <stdlib.h>
#include <string>
#include "fileop.hpp"

enum FILE_DATE
{
    FD_TODAY            = 0,
    FD_YESTERDAY        = 1,
    FD_BEFORE_YESTERDAY = 2,
    FD_INVALID_DATE     = -1
};

struct FileListItm
{
    std::string date;
    std::string fileName;
};

class FileFilter
{
public:
    FileFilter(int checkFileName);
    ~FileFilter();
    int init(const char* fileName, DATA_FILE_TYPE fileType);
    int check_file(char* fileName);
    int finish(int cancle);

private:
    int check_huawei_filename(char* fileName);
    int check_siemens_filename(char* fileName);

private:
    DATA_FILE_TYPE              m_fileType;
    int                         m_file;
    int                         m_checkFileName;
    std::string                 m_fileName;
    char                        m_date[5][9];
    std::vector<FileListItm>    m_oldFileList;
    std::vector<FileListItm>    m_newFileList;
};

#endif
