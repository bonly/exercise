#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <iostream>
#include <errno.h>
#include <string>
#include <sys/stat.h>
#include "defs.hpp"
#include "config.hpp"
#include "log.hpp"
#include "utc.hpp"

const char VERSION[] = {"1.0.0"};

using namespace std;


int g_errno = 0;

int    g_mod_file_size = -1;
string g_tmp_file_path;
string g_del_state;
int    g_del_state_val;
long   g_balance_threshold = 1000;

FILE* g_scpFile        = NULL;
FILE* g_ocsFile        = NULL;

#ifdef __SQLSCRIPT__
//���SQL�ű�
char  g_curr_number[12] = {0};
FILE* g_insertsql = NULL;
FILE* g_nouse_insertsql = NULL;
FILE* g_servSqlFile    = NULL;
FILE* g_balanceSqlFile = NULL;
#else
//���insert.lst,modify.lst,delete.lst�����ļ�
FILE* g_insertFile     = NULL;
FILE* g_deleteFile     = NULL;
FILE* g_modifyFile     = NULL;
#endif

bool  g_scp_eof        = false;
bool  g_ocs_eof        = false;
int   g_ocs_line_count = 0;
int   g_scp_line_count = 0;
int   g_ocs_user_count = 0;
int   g_scp_user_count = 0;
int   g_del_user_count = 0;
int   g_ins_user_count = 0;
int   g_mod_user_count = 0;

int  read_config();
int  openFile();
void closeAllFile();
int  getLineCount(const char* fileName);
void sort();
void lineToStruct(char (&scpLine)[LINE_SIZE], UniFile& uniFile);
void readOcsFile(char (&ocsLine)[LINE_SIZE]);
void readScpFile(char (&scpLine)[LINE_SIZE]);
void writeDeleteFile(char (&ocsLine)[LINE_SIZE]);
void writeModifyFile(char (&scpLine)[LINE_SIZE], bool modify_state,
        bool modify_balance, bool modify_date, bool modify_life);
void writeInsertFile(char (&scpLine)[LINE_SIZE]);
void writeAllOcsLine();
void writeAllScpLine();


int main(int argc, char** argv)
{
    init_config();
    INIT_LOG("SF");

    if(2 == argc)
    {
        if(0 == strcmp(argv[1], "-v"))
        {
            printf("%s\n", VERSION);
            exit(0);
        }
    }

    if(-1 == read_config())
    {
        return -1;
    }

    int retval = 0;

    if(-1 == openFile())
    {
        retval = -1;
    }
    else
    {
    	  srand (time(0));
        print_time();
        sort();
        print_time();

        if(g_ocs_user_count != g_ocs_line_count)
        {
            WRITE_LOG("Error: [MAIN] Not all the ocs record had been processed !\n");
            retval = -1;
        }

        if(g_scp_line_count != g_scp_user_count)
        {
            WRITE_LOG("Error: [MAIN] Not all the scp record had been processed !\n");
            retval = -1;
        }

        LOG_SEPARATOR;
        WRITE_LOG("Info: [Result] ocs_file line count      = %d\n", g_ocs_line_count);
        WRITE_LOG("Info: [Result] processed ocs user count = %d\n", g_ocs_user_count);
        WRITE_LOG("Info: [Result] scp_file line count      = %d\n", g_scp_line_count);
        WRITE_LOG("Info: [Result] processed scp user count = %d\n", g_scp_user_count);
        WRITE_LOG("Info: [Result] delete user count        = %d\n", g_del_user_count);
        WRITE_LOG("Info: [Result] insert user count        = %d\n", g_ins_user_count);
        WRITE_LOG("Info: [Result] modify user count        = %d\n", g_mod_user_count);

        if(0 != g_errno)
        {
            retval = -1;
        }
    }

    closeAllFile();
    LOG_TIME();

    if(-1 != retval)
    {
        create_succ_file(g_tmp_file_path, "sf");
    }

    return retval;
}

int read_config()
{
    if(!Config::get_instance()->get_item("cfg", "tmp_file_path", g_tmp_file_path))
    {
        WRITE_LOG("Error: [READ_CONFIG] Failed to get tmp_file_path from config.cfg !\n");
        return -1;
    }

    if(0 == g_tmp_file_path.size())
    {
        WRITE_LOG("Error: [READ_CONFIG] Failed to get tmp_file_path from config.cfg !\n");
        return -1;
    }

    string mod_file_size;
    if(Config::get_instance()->get_item("cfg", "mod_file_size", mod_file_size))
    {
        int tmp = atoi(mod_file_size.c_str());

        if(-1 == tmp)
        {
            g_mod_file_size = -1;
        }
        else if(500000 <= tmp && tmp <= 5000000)
        {
            g_mod_file_size = tmp;
        }
    }
    else
    {
        g_mod_file_size = -1;
    }

    string del_state = "2HZ";
    if(Config::get_instance()->get_item("cfg", "del_state", del_state))
    {
        if(2 != del_state.size())
        {
            WRITE_LOG("Error: [Config] Invalid del_state = %s\n", del_state.c_str());
            return -1;
        }

        g_del_state_val = translate_state(del_state.c_str());

        if(_INVALID_VALUE == g_del_state_val)
        {
            WRITE_LOG("Error: [Config] Invalid del_state = %s\n", del_state.c_str());
            return -1;
        }
    }

    string balance_threshold;
    if(Config::get_instance()->get_item("cfg", "balance_threshold", balance_threshold))
    {
        long tmp = atol(balance_threshold.c_str());

        if(0 <= tmp)
        {
            g_balance_threshold = tmp;
        }
    }

    g_del_state = del_state;

    WRITE_LOG("Info: [Config] tmp_file_path = %s\n", g_tmp_file_path.c_str());
    WRITE_LOG("Info: [Config] mod_file_size = %d\n", g_mod_file_size);
    WRITE_LOG("Info: [Config] del_state     = %s\n", g_del_state.c_str());
    WRITE_LOG("Info: [Config] balance_threshold = %ld\n", g_balance_threshold);
    return 0;
}

int getLineCount(const char* fileName)
{
    struct stat buf;
    errno = 0;

    if(0 != stat(fileName, &buf))
    {
        WRITE_LOG("Error: [GETLINECOUNT] Failed to get file '%s' status: %s !\n",
            fileName, strerror(errno));
        return -1;
    }

    if(0 != (buf.st_size % LINE_SIZE))
    {    	  
        WRITE_LOG("Error: [GETLINECOUNT] Invalid file format: '%s' !\n", fileName);
        return -1;
    }

    return (buf.st_size / LINE_SIZE);
}

int openFile()
{
    string scp_file(g_tmp_file_path + "/scp_file.lst");
    string ocs_file(g_tmp_file_path + "/ocs_file.lst");

    g_scp_line_count = getLineCount(scp_file.c_str());

    if(-1 == g_scp_line_count)
    {
        return -1;
    }

    if(0 == g_scp_line_count)
    {
        WRITE_LOG("Warning: scp file is empty !\n");
    }

    g_scpFile = fopen(scp_file.c_str(), "r");
    if(NULL == g_scpFile)
    {
        WRITE_LOG("Error: [OPENFILE] Failed to open file '%s' !\n",
            scp_file.c_str());
        return -1;
    }

    g_ocs_line_count = getLineCount(ocs_file.c_str());

    if(-1 == g_ocs_line_count)
    {
        return -1;
    }

    if(0 == g_ocs_line_count)
    {
        WRITE_LOG("Warning: ocs file is empty !\n");
    }

    g_ocsFile = fopen(ocs_file.c_str(), "r");
    if(NULL == g_ocsFile)
    {
        WRITE_LOG("Error: [OPENFILE] Failed to open file '%s' !\n",
            ocs_file.c_str());
        return -1;
    }


#ifdef __SQLSCRIPT__
    //���SQL�ű�
    string servsql_file(g_tmp_file_path + "/serv.sql");
    string balancesql_file(g_tmp_file_path + "/balance.sql");

    g_servSqlFile = fopen(servsql_file.c_str(), "w");

    if(NULL == g_servSqlFile)
    {
        WRITE_LOG("Error: [OPENFILE] Failed to open file '%s' !\n",
            servsql_file.c_str());
        return -1;
    }

    g_balanceSqlFile = fopen(balancesql_file.c_str(), "w");
    if(NULL == g_balanceSqlFile)
    {
        WRITE_LOG("Error: [OPENFILE] Failed to open file '%s' !\n",
            balancesql_file.c_str());
        return -1;
    }

#else

    //���insert.lst,modify.lst,delete.lst�����ļ�
    string delete_file(g_tmp_file_path + "/delete.lst");
    string insert_file(g_tmp_file_path + "/insert.lst");
    string modify_file(g_tmp_file_path + "/modify.lst");

    g_deleteFile = fopen(delete_file.c_str(), "w");
    if(NULL == g_deleteFile)
    {
        WRITE_LOG("Error: [OPENFILE] Failed to open file '%s' !\n",
            delete_file.c_str());
        return -1;
    }
    else
    {
        WRITE_LOG("Info: create file 'delete.lst'\n");
        fprintf(g_deleteFile,"<?xml version=\"1.0\" encoding=\"gb2312\"?>\n<BIZ>\n");
    }

    g_insertFile = fopen(insert_file.c_str(), "w");
    if(NULL == g_insertFile)
    {
        WRITE_LOG("Error: [OPENFILE] Failed to open file '%s' !\n",
            insert_file.c_str());
        return -1;
    }
    else
    {
        WRITE_LOG("Info: create file 'insert.lst'\n");
    }

    g_modifyFile = fopen(modify_file.c_str(), "w");
    if(NULL == g_modifyFile)
    {
        WRITE_LOG("Error: [OPENFILE] Failed to open file '%s' !\n",
            modify_file.c_str());
        return -1;
    }
    else
    {
        WRITE_LOG("Info: create file 'insert.lst'\n");
    }
#endif

    return 0;
}


void closeFile(FILE*& fd)
{
    if(NULL != fd)
    {
        fclose(fd);
        fd = NULL;
    }
}


void closeAllFile()
{
    closeFile(g_scpFile);
    closeFile(g_ocsFile);

#ifdef __SQLSCRIPT__
    closeFile(g_servSqlFile);
    closeFile(g_balanceSqlFile);
#else
    closeFile(g_insertFile);
    fprintf(g_deleteFile, "</BIZ>\n");
    closeFile(g_deleteFile);
    closeFile(g_modifyFile);
#endif
}

void readOcsFile(char (&ocsLine)[LINE_SIZE])
{
    errno = 0;

    int readSize = fread(ocsLine, 1, LINE_SIZE, g_ocsFile);

    if(LINE_SIZE != readSize)
    {
        if(0 == errno)
        {
            g_ocs_eof = true;
        }
        else
        {
            WRITE_LOG("Error: [READOCSFILE] Failed to read ocs file : '%s'\n",
                        strerror(errno));
            g_errno = -1;
        }
    }
    else
    {
        ++g_ocs_user_count;
    }
}

void readScpFile(char (&scpLine)[LINE_SIZE])
{
    errno = 0;

    int readSize = fread(scpLine, 1, LINE_SIZE, g_scpFile);

    if(LINE_SIZE != readSize)
    {
        if(0 == errno)
        {
            g_scp_eof = true;
        }
        else
        {
            WRITE_LOG("Error: [READSCPFILE] Failed to read scp file : '%s'\n",
                        strerror(errno));
            g_errno = -1;
        }
    }
    else
    {
        ++g_scp_user_count;
    }
}

void writeDeleteFile(char (&ocsLine)[LINE_SIZE])
{
#ifdef __SQLSCRIPT__
    return;
#else
    errno = 0;

    int j = 0;
    char strtoval[4] = {'\0'};

    for(int i = 12; i < 15; ++i)
    {
        if(' ' != ocsLine[i])
        {
            strtoval[j] = ocsLine[i];
            ++j;
        }
    }

    int del_val = atoi(strtoval);

    if(del_val == g_del_state_val)
    {
        return;
    }

    //fprintf(g_deleteFile, "%.11s\n", ocsLine);
    fprintf(g_deleteFile,
      "  <REC>\n"
      "    <COMMSERIAL>%d</COMMSERIAL>\n"
      "    <USERNUMBER>%.11s</USERNUMBER>\n"
      "    <TELE_TYPE></TELE_TYPE>\n"
      "    <USERID></USERID>\n"
      "    <SCPTYPE></SCPTYPE>\n"
      "    <SCPID></SCPID>\n"
      "  </REC>\n",
      rand(),ocsLine);

    if(0 == errno)
    {
        ++g_del_user_count;
    }
    else
    {
        WRITE_LOG("Error: [WRITEDELETEFILE] Failed to write file 'delete.lst': '%s'\n",
                    strerror(errno));
        g_errno = -1;
    }
#endif
}

void lineToStruct(char (&scpLine)[LINE_SIZE], UniFile& uniFile)
{
    memcpy(uniFile.MSISDN, scpLine, 11);
    uniFile.MSISDN[11] = 0;

    int i;
    int state = 0;


    for(i = STATE_START; i <= STATE_END; ++i)
    {
        if(' ' != scpLine[i])
        {
            state *= 10;
            state += scpLine[i] - '0';
        }
    }

    translate_state(SUBS_STATUS(state), uniFile.state);

    int bi = 0;
    char balance[14] = {0};

    for(i = BALANCE_BEGIN; i <= BALANCE_END; ++i)
    {
        if(' ' != scpLine[i])
        {
            balance[bi] = scpLine[i];
            ++bi;
        }
    }

    uniFile.balance = atof(balance) / 2;
    
    /*//��scp�ļ�Ϊ׼ʱ,����ʱ���޸���������
    //�޸�Ϊ�����С�ڵ�����ʱ�����û���״̬��Ϊ����ֵ
    if(uniFile.balance <= 0)
    {
    	uniFile.state[0] = '0';
    	uniFile.state[1] = '9';
    	WRITE_LOG("Warn: [LINETOSTRUCT] user balance lettle 0,set the state to '%s'\n", uniFile.state);
    }
    */

    memcpy(uniFile.card_effect,    &scpLine[STATE_END   +  2], 8);
    memcpy(uniFile.card_expire,    &scpLine[STATE_END   + 11], 8);
    memcpy(uniFile.balance_effect, &scpLine[BALANCE_END +  2], 8);
    memcpy(uniFile.balance_expire, &scpLine[BALANCE_END + 11], 8);
    uniFile.life = scpLine[LIFE_BEGIN];
    memcpy(uniFile.area,           &scpLine[AREA_BEGIN], 4);
    
    uniFile.card_effect[8]    = 0;
    uniFile.card_expire[8]    = 0;
    uniFile.balance_effect[8] = 0;
    uniFile.balance_expire[8] = 0;
}


void writeInsertFile(char (&scpLine)[LINE_SIZE])
{
    UniFile uniFile;

    lineToStruct(scpLine, uniFile);

#ifdef __SQLSCRIPT__
    if(0 != memcmp(uniFile.MSISDN, g_curr_number, 7))
    {
        memcpy(g_curr_number, uniFile.MSISDN, 7);

        char file_name[1024] = {'\0'};
        sprintf(file_name, "%s/%s.sql", g_tmp_file_path.c_str(), g_curr_number);

        if(NULL == g_insertsql)
        {
            fclose(g_insertsql);
        }

        g_insertsql = fopen(file_name, "w");
        if(NULL == g_insertsql)
        {
            WRITE_LOG("Error: [WRITEINSERTFILE] Faile to create file '%s'\n", file_name);
            exit(-1);
        }

        sprintf(file_name, "%s/%s.sql.nouse", g_tmp_file_path.c_str(), g_curr_number);

        if(NULL == g_nouse_insertsql)
        {
            fclose(g_nouse_insertsql);
        }

        g_nouse_insertsql = fopen(file_name, "w");
        if(NULL == g_nouse_insertsql)
        {
            WRITE_LOG("Error: [WRITEINSERTFILE] Faile to create file '%s'\n", file_name);
            exit(-1);
        }
    }

    fprintf(g_insertsql,
        "insert into OCSUSER.serv ("
                "SERV_ID,"
                "PRODUCT_ID,"
                "CUST_ID,"
                "CREATE_DATE,"
                "STATE,"
                "STATE_DATE,"
                "BRAND) "
        "values ("
                "%s,"
                "200,"
                "%s,"
                "SYSDATE,"
                "'%s',"
                "SYSDATE,"
                "0);\n",
        uniFile.MSISDN, uniFile.MSISDN, uniFile.state);

    fprintf(g_nouse_insertsql,
        "insert into OCSUSER.cust_serv ("
                "SERV_ID, "
                "CUST_ID) "
        "values ("
                "%s, "
                "%s);\n",
        uniFile.MSISDN, uniFile.MSISDN);

    
    fprintf(g_nouse_insertsql,
        "insert into OCSUSER.serv_identification ("
                "SERV_ID,"
                "ACC_NBR,"
                "AGREEMENT_ID,"
                "EFF_DATE,"
                "EXP_DATE) "
        "values ("
                "%s, "
                "'%s',"
                "%s,"
                "TO_DATE('%s', 'YYYYMMDD'),"
                "TO_DATE('%s', 'YYYYMMDD'));\n",
        uniFile.MSISDN, uniFile.MSISDN, uniFile.MSISDN, uniFile.balance_effect, uniFile.balance_expire);

    fprintf(g_insertsql,
        "insert into OCSUSER.Cust ("
                "CUST_ID,"
                "CUST_NAME,"
                "CUST_TYPE_ID,"
                "CUST_LOCATION,"
                "IS_VIP,"
                "CUST_CODE,"
                "STATE,"
                "EFF_DATE,"
                "EXP_DATE) "
        "values ("
                "%s,"
                "'name',"
                "'0',"
                "0,"
                "to_char(0),"
                "to_char(0),"
                "'00A',"
                "TO_DATE('%s', 'YYYYMMDD'),"
                "TO_DATE('%s', 'YYYYMMDD'));\n",
        uniFile.MSISDN, uniFile.balance_effect, uniFile.balance_expire);

    fprintf(g_nouse_insertsql,
        "insert into OCSUSER.Offer_Detail_instance ("
                "INSTANCE_RELATION_ID,"
                "PRODUCT_OFFER_INSTANCE_ID,"
                "INSTANCE_ID,"
                "INSTANCE_TYPE,"
                "EFF_DATE,"
                "EXP_DATE,"
                "STATE) "
        "values ("
                "%s,"
                "%s,"
                "%s,"
                "'10A',"
                "TO_DATE('%s', 'YYYYMMDD'),"
                "TO_DATE('%s', 'YYYYMMDD'),"
                "'00A');\n",
        uniFile.MSISDN, uniFile.MSISDN, uniFile.MSISDN, uniFile.balance_effect, uniFile.balance_expire);

    fprintf(g_nouse_insertsql,
        "insert into OCSUSER.Product_Offer_Instance ("
                "PRODUCT_OFFER_INSTANCE_ID,"
                "CUST_ID,"
                "CUST_AGREEMENT_ID,"
                "PRODUCT_OFFER_ID,"
                "EFF_DATE,"
                "STATE_DATE, STATE) "
        "values ("
                "%s,"
                "%s,"
                "%s,"
                "123,"
                "TO_DATE('%s', 'YYYYMMDD'),"
                "SYSDATE,"
                "'00A');\n",
        uniFile.MSISDN, uniFile.MSISDN, uniFile.MSISDN, uniFile.balance_effect);

    std::string balance_acct_id = "9";
    balance_acct_id += uniFile.MSISDN;

    fprintf(g_insertsql,
        "insert into OCSUSER.BALANCE_ACCT ("
                "CUST_ID,"
                "BALANCE_ACCT_TYPE_ID,"
                "BALANCE_ACCT_ID,"
                "ACCT_NAME,"
                "ADDRESS_ID,"
                "STATE,"
                "STATE_DATE) "
        "values ("
                "%s,"
                "1,"
                "%s,"
                "'un',"
                "0,"
                "'00A',"
                "SYSDATE);\n",
        uniFile.MSISDN, balance_acct_id.c_str());

    fprintf(g_insertsql,
        "INSERT INTO OCSUSER.balance_acct_item ("
                "BALANCE_ACCT_ID,"
                "BALANCE_ACCT_ITEM_ID,"
                "BALANCE,"
                "BALANCE_TYPE_ID,"
                "BALANCE_PRIORITY,"
                "EFF_DATE,"
                "EXP_DATE,"
                "STATE,"
                "STATE_DATE) "
        "VALUES ("
                "%s,"
                "OCSUSER.SEQ_BALANCE_ACCT_ITEM_ID.nextval,"
                "%f,"
                "3500,"
                "10,"
                "TO_DATE('%s', 'YYYYMMDD'),"
                "TO_DATE('%s', 'YYYYMMDD'),"
                "'00A',"
                "SYSDATE);\ncommit;\n",
        balance_acct_id.c_str(), uniFile.balance, uniFile.balance_effect, uniFile.balance_expire);

    fprintf(g_nouse_insertsql,
        "INSERT INTO OCSUSER.serv_attr ("
                "SERV_ID,"
                "AGREEMENT_ID,"
                "ATTR_ID,"
                "ATTR_VAL,"
                "EFF_DATE,"
                "EXP_DATE) "
        "VALUES ("
                "%s,"
                "1001,"
                "800,"
                "'12346',"
                "TO_DATE('20070101', 'YYYYMMDD'),"
                "TO_DATE('20100101', 'YYYYMMDD'));\ncommit;\n",
        uniFile.MSISDN);
#else
    errno = 0;
    fwrite(&uniFile, sizeof(uniFile), 1, g_insertFile);

    if(0 == errno)
    {
        ++g_ins_user_count;
    }
    else
    {
        WRITE_LOG("Error: [WRITEINSERTFILE] Failed to write file 'insert.lst': '%s'\n",
                    strerror(errno));
        g_errno = -1;
    }
#endif
}

void writeModifyFile(char (&scpLine)[LINE_SIZE], bool modify_state,
        bool modify_balance, bool modify_date, bool modify_life)
{
    UniFile uniFile;
    lineToStruct(scpLine, uniFile);

    errno = 0;

#ifdef __SQLSCRIPT__
/*
    if(modify_state)
    {
        fprintf(g_servSqlFile,
            "update OCSUSER.serv set state = \'%s\', STATE_DATE = SYSDATE "
            "where serv_id = %ld;\ncommit;\n",
            uniFile.state, atol(uniFile.MSISDN));
    }

    if(modify_date || modify_balance)
    {
        fprintf(g_balanceSqlFile,
            "update OCSUSER.balance_acct_item SET "
                "eff_date = TO_DATE(\'%s\', 'YYYYMMDD'), "
                "exp_date = TO_DATE(\'%s\', 'YYYYMMDD'), "
                "balance = %.2f "
            "where BALANCE_ACCT_ID = %ld "
                "AND balance_type_id = 3500;\ncommit;\n",
            uniFile.balance_effect, uniFile.balance_expire,
            uniFile.balance,
            atol(uniFile.MSISDN) + 900000000000);
    }
*/
    if (modify_state)
    {
    	fprintf(g_servSqlFile,
    	   "UPDATE BF_SUBSCRIBER SET "
    	   "status=\'%s\' WHERE acc_nbr=%ld;\ncommit;\n",
    	   uniFile.state, atol(uniFile.MSISDN));
    }    
    if (modify_date || modify_balance)
    {
    	  DAY beff(uniFile.balance_effect);
    	  DAY bexp(uniFile.balance_expire);
        fprintf(g_balanceSqlFile,
            "update BF_ACCT_BALANCE SET "
                "eff_date = %ld, "
                "exp_date = %ld, "
                "balance = %.2f "
            "where ACCT_ID = %ld "
                "AND ACCT_BALANCE_ITEM_ID = 3500;\ncommit;\n",
            CUtcTime::MakeTime(atoi(beff.year),atoi(beff.month),atoi(beff.day)), 
            CUtcTime::MakeTime(atoi(bexp.year),atoi(bexp.month),atoi(bexp.day)),
            uniFile.balance,
            atoll(uniFile.MSISDN)*10 + 7000000000001);    	
    }
    if (modify_life)
    {
    	DAY beff(uniFile.balance_effect);
    	DAY bexp(uniFile.balance_expire);    	
    	fprintf(g_balanceSqlFile,
    	  "update BF_ACCOUNT SET "
    	  " EXPIRY_DATE = %lld, "
    	  " UPDATE_DATE = %lld "
    	  "where ACCT_ID = %lld;\ncommit;\n ",
    	  CUtcTime::MakeTime(atoi(bexp.year),atoi(bexp.month),atoi(bexp.day)),
    	  CUtcTime::Time(0),
    	  atoll(uniFile.MSISDN)*10 + 7000000000001);    	
    }
#else
    if(modify_state || modify_date || modify_balance)
    {
        fwrite(&uniFile, sizeof(uniFile), 1, g_modifyFile);

        if(0 == errno)
        {
            ++g_mod_user_count;
        }
        else
        {
            WRITE_LOG("Error: [WRITEMODIFYFILE] Failed to write file 'modify.lst': '%s'\n",
                        strerror(errno));
            g_errno = -1;
        }
    }
#endif
}

void writeAllOcsLine()
{
    char ocsLine[LINE_SIZE];
    readOcsFile(ocsLine);

    while((!g_ocs_eof) && (0 == g_errno))
    {
        writeDeleteFile(ocsLine);
        readOcsFile(ocsLine);
    }
}

void writeAllScpLine()
{
    char scpLine[LINE_SIZE];
    readScpFile(scpLine);

    while((!g_scp_eof) && (0 == g_errno))
    {
        writeInsertFile(scpLine);
        readScpFile(scpLine);
    }
}

void sort()
{
    int  cmp_isdn;
    char ocsLine[LINE_SIZE];
    char scpLine[LINE_SIZE];

    readOcsFile(ocsLine);
    readScpFile(scpLine);

    if(0 != g_errno)
    {
        return;
    }

    int cmp_state;
    int cmp_balance;
    int cmp_date;
    int cmp_life;
    char strbalance[20];

    while((!g_scp_eof) && (!g_ocs_eof))
    {
        cmp_isdn = memcmp(ocsLine, scpLine, MSISDN_SIZE);

        if(0 == cmp_isdn)
        {
            cmp_state   = memcmp(&ocsLine[12], &scpLine[12], 12);   //�Ƚ�״̬��SCPID
            cmp_date    = memcmp(&ocsLine[51], &scpLine[51], 17);   //�Ƚ�����
            cmp_balance = memcmp(&ocsLine[34], &scpLine[34], 16);   //�Ƚ����
            cmp_life    = memcmp(&ocsLine[71], &scpLine[71], 1);    //�Ƚ���������

            if(0 != cmp_state || 0 != cmp_date || 0 != cmp_life)
            {
                writeModifyFile(scpLine, cmp_state, false, cmp_date, cmp_life);
            }
            else if(0 != cmp_balance)
            {
                int j = 0;
                char c;
                for(int i = BALANCE_BEGIN; i <= BALANCE_END; ++i)
                {
                    c = scpLine[i];

                    if(' ' != c)
                    {
                        strbalance[j] = c;
                        ++j;
                    }
                }

                strbalance[j] = '\0';

                double balance = atof(strbalance);
                if(balance < g_balance_threshold)   //���С�ڷ�ֵ
                {
                    writeModifyFile(scpLine, false, true, false, false);
                }
            }

            readOcsFile(ocsLine);
            readScpFile(scpLine);
        }
        else if(0 < cmp_isdn)
        {
            writeInsertFile(scpLine);
            readScpFile(scpLine);
        }
        else
        {
            writeDeleteFile(ocsLine);
            readOcsFile(ocsLine);
        }

        if(0 != g_errno)
        {
            return;
        }
    }

    if(g_scp_eof && (!g_ocs_eof))
    {
        writeDeleteFile(ocsLine);
        writeAllOcsLine();
    }

    if(g_ocs_eof && (!g_scp_eof))
    {
        writeInsertFile(scpLine);
        writeAllScpLine();
    }
}
