#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include "defs.hpp"
#include "filefilter.hpp"
#include "log.hpp"

using namespace std;

//算出前5天的日期
void get_date(char (&date)[5][9])
{
    time_t t = time(NULL);
    struct tm* ptm = localtime(&t);

    int year   = ptm->tm_year + 1900;
    int month  = ptm->tm_mon  + 1;
    int day    = ptm->tm_mday;
    int year2  = 0;
    int month2 = 0;
    int day2   = 0;
    
    for(int i = 0; i < 5; ++i)
    {
        sprintf(date[i], "%.4d%.2d%.2d", year,  month,  day);
        get_yesterday(year,  month,  day,  year2, month2, day2);

        year  = year2;
        month = month2;
        day   = day2;
    }
}

FileFilter::FileFilter(int checkFileName) :
    m_fileType(INVALID_FILE), m_file(-1), m_checkFileName(checkFileName)
{
    get_date(m_date);
}

FileFilter::~FileFilter()
{
}

int FileFilter::init(const char* fileName, DATA_FILE_TYPE fileType)
{
    if((HUAWEI_FILE != fileType) && (SIEMENS_FILE != fileType))
    {
        m_fileType = INVALID_FILE;
        WRITE_LOG("Error: [INIT] invalide file type\n");
        return -1;
    }

    m_fileType = fileType;

    if(1 == m_checkFileName)
    {
        struct stat buf;
        if(-1 == stat(fileName, &buf))
        {
            WRITE_LOG("Error: [INIT] failed to get file '%s' status\n", fileName);
            return -1;
        }

        m_file = open(fileName, O_RDWR);

        if(-1 == m_file)
        {
            WRITE_LOG("Error: [INIT] failed to open file '%s'\n", fileName);
            return -1;
        }

        m_fileName = fileName;

        if(0 == buf.st_size)    //�ļ��ǿյ�
        {
            return 0;
        }

        try
        {
            Array_Guard<char> fileBuffer(buf.st_size);
            read(m_file, fileBuffer, buf.st_size);

            int index    = 0;
            int start    = 0;
            int end      = 0;
            char date[9] = {0};
            FileListItm fl;

            //��ȡ�ļ��б������м�¼
            for(int i = 0; i < buf.st_size; ++i)
            {
                if(0x0A == fileBuffer[i])   //���������з�
                {
                    index = 0;

                    if(start != end)
                    {
                        fl.date     = date;
                        fl.fileName = string(&fileBuffer[start], end - start);
                        m_oldFileList.push_back(fl);
                    }
                }
                else
                {
                    if(7 >= index)
                    {
                        date[index] = fileBuffer[i];
                    }
                    else if(8 == index)
                    {
                        if(' ' != fileBuffer[i])    //�ļ���ʽ����ȷ
                        {
                            WRITE_LOG("Error: [INIT] bad format\n");
                            return -1;
                        }

                        if(-1 == check_date_format(date))
                        {
                            WRITE_LOG("Error: [INIT] CHECK_DATE_FORMAT] bad format\n");
                            return -1;
                        }

                        start = i + 1;              //��һ���ַ���ʼ�����ļ���
                        end   = start;
                    }
                    else
                    {
                        ++end;
                    }

                    ++index;
                }
            }
        }
        catch(...)
        {
            WRITE_LOG("Error: [INIT] out of memory\n");
            return -1;
        }
    }

    return 0;
}

int FileFilter::check_huawei_filename(char* fileName)
{
    int fnLen = strlen(fileName);

    //�����ļ����ĸ�ʽ�Ƿ�ΪPPSUSERDATA_����_xxx_0000.unl
    if(fnLen < 30)
    {
        return -1;
    }

    if(0 != memcmp("PPSUSERDATA_", fileName, 12))
    {
        return -1;
    }

    if(0 != memcmp("_0000.unl", &fileName[fnLen - 9], 9))
    {
        return -1;
    }

    if(1 == m_checkFileName)
    {
        //�����ļ��������Ƿ�������5����
        for(int i = 0; i < 5; ++i)
        {
            if(0 != memcmp(m_date[i], &fileName[12], 8))
            {
                return 0;
            }
        }

        return -1;
    }
    else if(2 == m_checkFileName)
    {
        //�ļ������ڲ��ǽ���
        if(0 != memcmp(m_date[0], &fileName[12], 8))
        {
            return -1;
        }
    }

    return 0;
}

int FileFilter::check_siemens_filename(char* fileName)
{
    int fnLen = strlen(fileName);

    //�����ļ����ĸ�ʽ�Ƿ�Ϊallsubs_x??_����
    if(18 > fnLen)
    {
        return -1;
    }

    if(0 != memcmp("allsubs_x", fileName, 9))
    {
        return -1;
    }

    if(-1 == check_date_format(&fileName[fnLen - 8]))
    {
        return -1;
    }

    if(1 == m_checkFileName)
    {
        //�����ļ��������Ƿ�������5����
        for(int i = 0; i < 5; ++i)
        {
            if(0 != memcmp(m_date[i], &fileName[12], 8))
            {
                return 0;
            }
        }

        return -1;
    }
    else if(2 == m_checkFileName)
    {
        //�ļ������ڲ�������
        if(0 != memcmp(m_date[1], &fileName[fnLen - 8], 8))
        {
            return -1;
        }
    }

    return 0;
}

int FileFilter::check_file(char* fileName)
{
    if(0 == m_checkFileName)
    {
        return 0;
    }

    if(HUAWEI_FILE == m_fileType)          //��Ϊ�ļ�
    {
        if(-1 == check_huawei_filename(fileName))
        {
            return -1;
        }
    }
    else if(SIEMENS_FILE == m_fileType)    //�������ļ�
    {
        if(-1 == check_siemens_filename(fileName))
        {
            return -1;
        }
    }
    else
    {
        return -1;
    }

    if(1 == m_checkFileName)
    {
        std::vector<FileListItm>::iterator   ptr = m_oldFileList.begin();
        std::vector<FileListItm>::iterator enptr = m_oldFileList.end();

        //���ļ��б��е��ļ��������Ա�
        for(; ptr != enptr; ++ptr)
        {
            if(fileName == ptr->fileName)
            {
                return -1;
            }
        }
    }

    //δ���������ļ����뵽�ļ�����
    FileListItm fl;
    fl.date     = m_date[0];
    fl.fileName = fileName;
    m_newFileList.push_back(fl);
    return 0;
}

int FileFilter::finish(int cancle)
{
    //����д�ļ��б�
    if(0 == m_checkFileName || 2 == m_checkFileName)
    {
        return 0;
    }

    if(-1 != m_file)
    {
        //�������ļ��������´���
        ftruncate(m_file, 0);
        close(m_file);
        m_file = open(m_fileName.c_str(), O_RDWR);

        if(-1 == m_file)
        {
            return -1;
        }

        std::vector<FileListItm>::iterator   ptr = m_oldFileList.begin();
        std::vector<FileListItm>::iterator enptr = m_oldFileList.end();

        for(; ptr != enptr; ++ptr)
        {
            //����4�����ļ�����д���ļ��б���
            for(int i = 0; i < 5; ++i)
            {
                if(m_date[i] == ptr->date)
                {
                    write(m_file, m_date[i], 8);
                    write(m_file, " ", 1);
                    write(m_file, ptr->fileName.c_str(), ptr->fileName.size());
                    write(m_file, "\n", 1);
                }
            }
        }

        //�ѽ��촦�������ļ���д���ļ��б���
        ptr   = m_newFileList.begin();
        enptr = m_newFileList.end();

        for(; ptr != enptr; ++ptr)
        {
            write(m_file, ptr->date.c_str(), 8);
            write(m_file, " ", 1);
            write(m_file, ptr->fileName.c_str(), ptr->fileName.size());
            write(m_file, "\n", 1);
        }

        close(m_file);
    }

    return -1;
}
