#include <errno.h>
#include <string.h>
#include <iostream>
#include <libgen.h>
#include "fileop.hpp"

using namespace std;
extern int g_total_line;
extern int g_error_line;
extern NumberRangeFilter g_numberRangeFilter;
extern map<int, int> g_scpidMap;
string get_file_name(const char* pathName);




template<typename DataType>
int FileOp<DataType>::open(const std::string& fileName, int scpid)
{
    m_file = fopen(fileName.c_str(), "r");
    
    if(NULL == m_file)          //文件打开失败
    {
        WRITE_LOG("Error: [OPEN] %s\n", strerror(errno));
        return -1;
    }

    char *bname = basename((char *)fileName.c_str());
    string filename(bname);
    string fdate(filename.substr(12,8));
    strncpy(m_date,fdate.c_str(),9);
    
    m_scpid = scpid;
    m_iseof = 0;
    ((DataType*)this)->reset_context(1);
    return 0;
}

template<typename DataType>
void FileOp<DataType>::close()
{
    m_lineCount  = 0;
    m_errorCount = 0;

    if(NULL != m_file)
    {
        fclose(m_file);
        m_file = NULL;
    }
}

template<typename DataType>
int FileOp<DataType>::read()
{
    if(NULL == m_file)
    {
        return -1;
    }

    if(0 == m_iseof)
    {
        m_readSize = 0;
        errno      = 0;
        m_readSize = fread(m_buff, 1, FILE_BUFFER_SIZE, m_file);

        if(((int)FILE_BUFFER_SIZE != m_readSize) && (0 == errno))
        {
            m_iseof = 1;
        }
        else if(0 != errno)
        {
            WRITE_LOG("Error: [READ] %s\n", strerror(errno));
            return -1;
        }

        if(-1 == ((DataType*)this)->read_data(m_buff, m_readSize))
        {
            return -1;
        }
    }

    return 0;
}

template<typename DataType>
int FileOp<DataType>::is_eof()
{
    return m_iseof;
}

template<typename DataType>
int FileOp<DataType>::output(const DataFileStruct& data)
{
    _ASSERT(NULL != m_opFile);

    if(g_numberRangeFilter.inNumberRange(data.msisdn_number))
    {
        if(-1 == m_pUserStorage->add(data.ndc, data.sn1, data.sn2, data.state,
            m_scpid, data.card_effect, data.card_expire, data.balance,
            data.balance_effect, data.balance_expire,
            data.life,data.areaNumber))
        {
            WRITE_LOG("Error: [OUTPUT] out of memory\n");
            return -1;
        }
    }

    return 0;
}

template<typename DataType>
int FileOp<DataType>::get_total_line()
{
    return m_lineCount;
}

template<typename DataType>
int FileOp<DataType>::get_error_line()
{
    return m_errorCount;
}

//////////////////////////////////////////////////////////////////////////////////////

HuaweiFile::HuaweiFile(FILE* opFile, UserStorage* pUserStorage)
{
    m_pUserStorage = pUserStorage;
    m_opFile = opFile;
    memset(m_huaweiData.data_line, 0, sizeof(m_huaweiData.data_line));
    memset(&m_huaweiData.balance_effect, 0, sizeof(m_huaweiData.balance_effect));
    memset(&m_huaweiData.balance_expire, 0, sizeof(m_huaweiData.balance_expire));
    memset(&m_huaweiData.card_expire, 0, sizeof(m_huaweiData.card_expire));
}

void HuaweiFile::reset_context(int lineno)
{
    m_status  = READ_MSISDN;
    m_index   = 0;
    m_column  = 0;
    m_sign    = 1;
    m_lineno  = lineno;
    m_balance = 0;

    memset(m_huaweiData.MSISDN, 0, sizeof(m_huaweiData.MSISDN));
    memset(m_huaweiData.areaNumber, 0, sizeof(m_huaweiData.areaNumber));
    m_huaweiData.SubState   = 0;
    m_huaweiData.pid        = 0;
    m_huaweiData.balance    = 0;
    m_huaweiData.state      = _INVALID_VALUE;
    m_huaweiData.lineno     = lineno;
    m_huaweiData.errorCode  = UNKNOWN_ERROR;
}

void HuaweiFile::read_msisdn(char c)
{
    if(('0' <= c) && ('9' >= c))
    {
        if(DataFileStruct::MSISDN_LEN <= m_index)
        {
            m_huaweiData.errorCode = MSISDN_TOO_LONG;
            m_status = INVALID_STATUS;
        }
        else
        {
            m_huaweiData.MSISDN[m_index] = c;
            ++m_index;
        }
    }
    else
    {
        if('|' == c)
        {
            if(0 == m_index)
            {
                m_huaweiData.errorCode = MSISDN_INVALID_LEN;
                m_status = INVALID_STATUS;
            }

            m_huaweiData.msisdn_number = atoll(m_huaweiData.MSISDN);
            split_number(m_huaweiData.msisdn_number,
                m_huaweiData.ndc,
                m_huaweiData.sn1,
                m_huaweiData.sn2);

            int ndc_valid = 1;
            extern int g_check_ndc;

            if((1 == g_check_ndc) && (-1 == check_ndc(m_huaweiData.ndc)))
            {
                ndc_valid = 0;
            }

            if(0 == ndc_valid)
            {
                m_status  = INVALID_STATUS;
                m_huaweiData.errorCode = MSISDN_INVALID_NDC;
            }
            else
            {
                m_status = READ_SUBSTATE;
            }

            m_index  = 0;
            return;
        }
        else
        {
            m_huaweiData.errorCode = MSISDN_INVALID_CHAR;
            m_status = INVALID_STATUS;
        }
    }
}

void HuaweiFile::read_substate(char c)
{
    if(('0' != c) && ('1' != c) && ('6' != c) && ('|' != c))
    {
        m_status = INVALID_STATUS;
        m_huaweiData.errorCode = SUBSTATE_INVALID_CHAR;
    }
    else
    {
        if('|' == c)
        {
            m_index  = 0;
            m_status = READ_PID;
            return;
        }
        else
        {
            if(0 == m_index)
            {
                m_huaweiData.SubState = c - '0';
            }
            else
            {
                m_status = INVALID_STATUS;
                m_huaweiData.errorCode = SUBSTATE_TOO_LONG;
                ++m_index;
            }
        }
    }
}

void HuaweiFile::read_pid(char c)
{
    if('|' == c)
    {
        if(0 == m_index)
        {
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = PID_INVALID_LEN;
        }
        else
        {
            m_index  = 0;
            m_status = READ_ACCOUNTLEFT;
            return;
        }
    }
    else if(('0' <= c) && ('9' >= c))
    {
        if(10 > m_index)
        {
            m_huaweiData.pid *= 10;
            m_huaweiData.pid += c - '0';
            ++m_index;
        }
        else
        {
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = PID_INVALID_LEN;
        }
    }
    else
    {
        m_status = INVALID_STATUS;
        m_huaweiData.errorCode = PID_INVALID_CHAR;
    }
}

void HuaweiFile::read_accountleft(char c)
{
    if(('-' == c) && (0 == m_index))
    {
        m_sign = -1;
    }
    else
    {
        if(('0' <= c) && ('9' >= c))
        {
            if((11 < m_index))
            {
                m_status = INVALID_STATUS;
                m_huaweiData.errorCode = BALANCE_TOO_LONG;
            }
            else
            {
                m_balance *= 10;
                m_balance += c - '0';
                ++m_index;
            }
        }
        else if('|' == c)
        {
            if(0 == m_index)
            {
                m_status = INVALID_STATUS;
                m_huaweiData.errorCode = BALANCE_INVALID_LEN;
            }
            else
            {
                m_huaweiData.balance  = (double)m_balance * m_sign;
                m_index               = 0;
                m_status              = READ_ACCOUNTSTATE;
                return;
            }
        }
        else
        {
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = BALANCE_INVALID_CHAR;
        }
    }
}

void HuaweiFile::tran_life()
{
	m_huaweiData.life = translate_hw_life(m_huaweiData.SubState, m_huaweiData.AccountState,
	                  atol(m_date), atol(m_huaweiData.card_expire),
	                  atol(m_huaweiData.card_effect), atol(m_huaweiData.balance_expire),
	                  m_huaweiData.balance
	);
//fprintf(stderr, "life : %d\n", m_huaweiData.LifeState);	
  m_status = READ_IGNORE2;
}
	
void HuaweiFile::read_state(char c)
{
    if(0 == m_index)
    {
        if(('1' <= c) && ('8' >= c))
        {
            m_accountState = c - '0';
            ++m_index;
        }
        else
        {
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = STATE_INVALID_VALUE;
        }
    }
    else
    {
        if('|' == c)
        {
        	  m_huaweiData.AccountState = m_accountState;
            m_huaweiData.state = translate_hw_state(m_huaweiData.SubState,
                                                    m_accountState);
            m_index  = 0;
            m_status = READ_SERVICESTART;
            return;
        }
        else
        {
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = STATE_INVALID_LEN;
        }
    }
}

void HuaweiFile::read_servicestart(char c)
{
    if(('0' <= c) && ('9' >= c))
    {
        if(7 >= m_index)
        {
            m_huaweiData.balance_effect[m_index] = c;
            ++m_index;
        }
        else
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = SERVICESTART_INVALID_LEN;
        }
    }
    else if('|' == c)
    {
        if(8 != m_index)
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = SERVICESTART_INVALID_LEN;
        }
        else
        {
            if(-1 == check_date_format(m_huaweiData.balance_effect))
            {
                m_status = INVALID_STATUS;
                m_huaweiData.errorCode = INVALID_DATE_FORMAT;
            }
            else
            {
                m_index  = 0;
                m_status = READ_CALLSERVICESTOP;
            }

            return;
        }
    }
    else
    {
        m_index  = 0;
        m_status = INVALID_STATUS;
        m_huaweiData.errorCode = SERVICESTART_INVALID_CHAR;
    }
}

void HuaweiFile::read_callservicestop(char c)
{
    if(('0' <= c) && ('9' >= c))
    {
        if(7 >= m_index)
        {
            m_huaweiData.balance_expire[m_index] = c;
            ++m_index;
        }
        else
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = CALLSERVICESTOP_INVALID_LEN;
        }
    }
    else if('|' == c)
    {
        if(8 != m_index)
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = CALLSERVICESTOP_INVALID_LEN;
        }
        else
        {
            if(-1 == check_date_format(m_huaweiData.balance_expire))
            {
                m_status = INVALID_STATUS;
                m_huaweiData.errorCode = INVALID_DATE_FORMAT;
            }
            else
            {
                m_index  = 0;
                m_status = READ_ACCOUNTSTOP;
            }

            return;
        }
    }
    else
    {
        m_index  = 0;
        m_status = INVALID_STATUS;
        m_huaweiData.errorCode = CALLSERVICESTOP_INVALID_CHAR;
    }
}

void HuaweiFile::read_accountstop(char c)
{
    if(('0' <= c) && ('9' >= c))
    {
        if(7 >= m_index)
        {
            m_huaweiData.card_effect[m_index] = c;
            ++m_index;
        }
        else
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = ACCOUNTSTOP_INVALID_LEN;
        }
    }
    else if('|' == c)
    {
        if(8 != m_index)
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = ACCOUNTSTOP_INVALID_LEN;
        }
        else
        {
            if(-1 == check_date_format(m_huaweiData.card_effect))
            {
                m_status = INVALID_STATUS;
                m_huaweiData.errorCode = INVALID_DATE_FORMAT;
            }
            else
            {
                m_index  = 0;
                m_status = READ_LOCKSTOP;
            }

            return;
        }
    }
    else
    {
        m_index  = 0;
        m_status = INVALID_STATUS;
        m_huaweiData.errorCode = ACCOUNTSTOP_INVALID_CHAR;
    }
}

void HuaweiFile::read_lockstop(char c)
{
    if(('0' <= c) && ('9' >= c))
    {
        if(7 >= m_index)
        {
            m_huaweiData.card_expire[m_index] = c;
            ++m_index;
        }
        else
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = LOCKSTOP_INVALID_LEN;
        }
    }
    else if('|' == c)
    {
        if(8 != m_index)
        {
            if(0 == m_index)
            {
                //memcpy(m_huaweiData.card_expire, "21001231", 9);
                m_index  = 0;
                m_status = READ_AREANUMBER;
                return;
            }
            else
            {
                m_index  = 0;
                m_status = INVALID_STATUS;
                m_huaweiData.errorCode = LOCKSTOP_INVALID_LEN;
            }
        }
        else
        {
            if(-1 == check_date_format(m_huaweiData.card_expire))
            {
                m_status = INVALID_STATUS;
                m_huaweiData.errorCode = INVALID_DATE_FORMAT;
            }
            else
            {
                m_index  = 0;
                m_status = READ_AREANUMBER;
            }

            return;
        }
    }
    else
    {
        m_index  = 0;
        m_status = INVALID_STATUS;
        m_huaweiData.errorCode = LOCKSTOP_INVALID_CHAR;
    }
}

void HuaweiFile::read_areanumber(char c)
{
    if(('0' <= c) && ('9' >= c))
    {
        if(5 >= m_index)
        {
            m_huaweiData.areaNumber[m_index] = c;
            ++m_index;
        }
        else
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = AREANUMBER_INVALID_LEN;
        }
    }
    else if('|' == c)
    {
        if(6 < m_index || 0 == m_index)
        {
            m_index  = 0;
            m_status = INVALID_STATUS;
            m_huaweiData.errorCode = AREANUMBER_INVALID_LEN;
        }
        else
        {
            m_index  = 0;
            m_status = TRAN_LIFE;
            return;
        }
    }
    else
    {
        m_index  = 0;
        m_status = INVALID_STATUS;
        m_huaweiData.errorCode = AREANUMBER_INVALID_CHAR;
    }
}

int HuaweiFile::read_data(char* fileBuff, int size)
{
    _ASSERT(NULL != fileBuff);
    _ASSERT(0 < size);

    char c;
    int newline = 0;

    for(int i = 0; size > i; ++i)
    {
        c = fileBuff[i];
        newline = 0;

        if(NEW_LINE == c)
        {
            ++m_lineCount;

            if(SUCCESS == m_huaweiData.errorCode)
            {
                if(-1 == output(m_huaweiData))
                {
                    return -1;
                }
            }
            else
            {
                ++m_errorCount;
                m_huaweiData.data_line[m_column] = 0;

                WRITE_DATA_LOG("%s: %s\n", m_huaweiData.data_line,
                    get_error_desc(m_huaweiData.errorCode));
            }

            newline = 1;
            reset_context(m_lineno + 1);
            continue;
        }
        else
        {
            //判断内容是否超长
            if((sizeof(m_huaweiData.data_line) - 1) > size_t(m_column))
            {
                m_huaweiData.data_line[m_column] = c;
                ++m_column;
            }
        }

        switch(m_status)
        {
            case READ_MSISDN:
                read_msisdn(c);
                break;

            case READ_SUBSTATE:
                read_substate(c);
                break;

            case READ_PID:
                read_pid(c);
                break;

            case READ_ACCOUNTLEFT:
                read_accountleft(c);
                break;

            case READ_ACCOUNTSTATE:
                read_state(c);
                break;

            case READ_SERVICESTART:
                read_servicestart(c);
                break;

            case READ_CALLSERVICESTOP:
                read_callservicestop(c);
                break;

            case READ_ACCOUNTSTOP:
                read_accountstop(c);
                break;

            case READ_LOCKSTOP:
                read_lockstop(c);
                break;

            case READ_AREANUMBER:
                read_areanumber(c);
                break;

            case TRAN_LIFE:
            	  tran_life();
            	  break;
            	  
            case READ_IGNORE2:
                m_huaweiData.errorCode = SUCCESS;
                break;

            default:
                break;
        }
    }

    if((0 == newline) && (0 != m_iseof))
    {
        ++m_lineCount;

        if(SUCCESS == m_huaweiData.errorCode)
        {
            if(-1 == output(m_huaweiData))
            {
                return -1;
            }
        }
        else
        {
            ++m_errorCount;
            m_huaweiData.data_line[m_column] = 0;

            WRITE_DATA_LOG("%s: %s\n", m_huaweiData.data_line,
                get_error_desc(m_huaweiData.errorCode));
        }

        reset_context(m_lineno + 1);
    }

    return 0;
}


//////////////////////////////////////////////////////////////////////////////////////

int get_scpid(const char* fileName, int len)
{
    if(len < 12)
    {
        return -1;
    }

    int j = 1;
    int fileNo = 0;
    int fileNoLen = 0;

    for(int i = len - 10; i >= 0; --i)
    {
        if(!isdigit(fileName[i]))
        {
            break;
        }

        ++fileNoLen;
        fileNo += (fileName[i] - '0') * j;
        j *= 10;
    }

    if(0 == fileNoLen || fileNoLen > 4)
    {
        return -1;
    }

    map<int, int>::iterator ptr = g_scpidMap.find(fileNo);
    if(ptr == g_scpidMap.end())
    {
        return -1;
    }

    return ptr->second;
}


int proc_huawei_files(FileList& fileList, FILE* opFile, UserStorage* us)
{
    _ASSERT(NULL != opFile);

    HuaweiFile  huaweiFileOp(opFile, us);
    FileListPtr fileNamePtr;

    int scpid;

    for(fileNamePtr = fileList.begin();
        fileNamePtr != fileList.end();
        ++fileNamePtr)
    {
        LOG_SEPARATOR;
        WRITE_LOG("Info: [Result] Huawei File '%s'\n", fileNamePtr->c_str());
        scpid = get_scpid(fileNamePtr->c_str(), fileNamePtr->size());
        if(-1 == scpid) //找不到scpid，不处理这个文件
        {
            WRITE_LOG("Warn: [Result] scpid not found\n");
            continue;
        }
        else
        {
            WRITE_LOG("Info: [Result] scpid = %d\n", scpid);
        }

        string opFileName = get_file_name(fileNamePtr->c_str());
        OPEN_DATA_LOG(opFileName.c_str());

        if(-1 == huaweiFileOp.open(*fileNamePtr, scpid))
        {
            return -1;
        }

        do
        {
            if(-1 == huaweiFileOp.read())
            {
                return -1;
            }
        }
        while(!huaweiFileOp.is_eof());

        if(0 == huaweiFileOp.get_total_line())
        {
            WRITE_LOG("Warning: scp file is empty!\n");
        }
        else
        {
            g_total_line += huaweiFileOp.get_total_line();
            g_error_line += huaweiFileOp.get_error_line();
            WRITE_LOG("Total line: %d\n", huaweiFileOp.get_total_line());
            WRITE_LOG("Error line: %d\n", huaweiFileOp.get_error_line());
        }

        CLOSE_DATA_LOG();
        huaweiFileOp.close();
    }
    return 0;
}

//////////////////////////////////////////////////////////////////////////////////////

static const char* error_desc[ERROR_CODE_COUNT];

void init_error_desc()
{
    error_desc[SUCCESS]                      = "Success";
    error_desc[MSISDN_TOO_LONG]              = "MSISDN: too long";
    error_desc[MSISDN_INVALID_LEN]           = "MSISDN: invalid length";
    error_desc[MSISDN_INVALID_CHAR]          = "MSISDN: invalid character";
    error_desc[MSISDN_INVALID_SPACE]         = "MSISDN: invalid space";
    error_desc[MSISDN_INVALID_NDC]           = "MSISDN: invalid NDC";
    error_desc[PID_INVALID_LEN]              = "Pid: invalid length";
    error_desc[PID_INVALID_CHAR]             = "Pid: invalid character";
    error_desc[PID_INVALID_SPACE]            = "Pid: invalid space";
    error_desc[FIRSTCALLFLAG_TOO_LONG]       = "Firstcallflag: too long";
    error_desc[FIRSTCALLFLAG_INVALID_CHAR]   = "Firstcallflag: invalid character";
    error_desc[FIRSTCALLFLAG_INVALID_SPACE]  = "Firstcallflag: invalid space";
    error_desc[FIRSTCALLFLAG_INVALID_VALUE]  = "Firstcallflag: invalid value";
    error_desc[BALANCE_INVALID_CHAR]         = "Balance: invalid character";
    error_desc[BALANCE_TOO_LONG]             = "Balance: too long";
    error_desc[BALANCE_INVALID_SPACE]        = "Balance: invalid space";
    error_desc[STATE_TOO_LONG]               = "STATE: too long";
    error_desc[STATE_INVALID_CHAR]           = "State: invalid character";
    error_desc[STATE_INVALID_SPACE]          = "State: invalid space";
    error_desc[STATE_INVALID_VALUE]          = "State: invalid value";
    error_desc[STATE_INVALID_LEN]            = "State: invalid length";
    error_desc[PID_INVALID_VALUE]            = "Pid: invalid value";
    error_desc[BALANCE_INVALID_LEN]          = "Balance: invalid length";
    error_desc[SUBSTATE_INVALID_VALUE]       = "Substate: invalid value";
    error_desc[SUBSTATE_INVALID_CHAR]        = "Substate: invalid character";
    error_desc[SUBSTATE_INVALID_LEN]         = "Substate: invalid length";
    error_desc[SUBSTATE_TOO_LONG]            = "Substate: too long";
    error_desc[SERVICESTART_INVALID_LEN]     = "Servicestart: invalid length";
    error_desc[SERVICESTART_INVALID_CHAR]    = "Servicestart: invalid character";
    error_desc[CALLSERVICESTOP_INVALID_LEN]  = "Callservicestop: invalid length";
    error_desc[CALLSERVICESTOP_INVALID_CHAR] = "Callservicestop: invalid character";
    error_desc[ACCOUNTSTOP_INVALID_LEN]      = "Accountstop: invalid length";
    error_desc[ACCOUNTSTOP_INVALID_CHAR]     = "Accountstop: invalid character";
    error_desc[LOCKSTOP_INVALID_LEN]         = "Lockstop: invalid length";
    error_desc[LOCKSTOP_INVALID_CHAR]        = "Lockstop: invalid character";
    error_desc[AREANUMBER_INVALID_LEN]       = "Areanumber: invalid length";
    error_desc[AREANUMBER_INVALID_CHAR]      = "Areanumber: invalid character";
    error_desc[CREDIT_INVALID_SPACE]         = "Credit: invalid length";
    error_desc[CREDIT_INVALID_CHAR]          = "Credit: invalid character";
    error_desc[INVALID_DATE_FORMAT]          = "Date: invalid format";
    error_desc[FOUND_RETURN_CHAR]            = "Found return character";
    error_desc[UNKNOWN_ERROR]                = "Unknown error";
}

const char* get_error_desc(DATAERROR error_code)
{
    if(ERROR_CODE_COUNT < error_code)
    {
        return error_desc[UNKNOWN_ERROR];
    }

    return error_desc[error_code];
}

string get_file_name(const char* pathName)
{
    int len = strlen(pathName);

    int i = len - 1;
    for(; i >= 0; --i)
    {
        if('/' == pathName[i])
        {
            ++i;
            break;
        }
    }

    return string(&pathName[i]);
}
