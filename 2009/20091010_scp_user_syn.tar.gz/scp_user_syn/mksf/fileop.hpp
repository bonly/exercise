#ifndef __FILEOP_HPP__
#define __FILEOP_HPP__

#include <set>
#include "defs.hpp"
#include "log.hpp"
#include "config.hpp"
#include "userstorage.hpp"

typedef std::set<std::string>             FileList;
typedef std::set<std::string>::iterator   FileListPtr;

enum DATAERROR {
    SUCCESS,
    MSISDN_TOO_LONG,
    MSISDN_INVALID_CHAR,
    MSISDN_INVALID_SPACE,
    MSISDN_INVALID_NDC,
    PID_INVALID_LEN,
    PID_INVALID_CHAR,
    PID_INVALID_SPACE,
    STATE_TOO_LONG,
    STATE_INVALID_CHAR,
    STATE_INVALID_SPACE,
    STATE_INVALID_VALUE,
    STATE_INVALID_LEN,
    FIRSTCALLFLAG_TOO_LONG,
    FIRSTCALLFLAG_INVALID_CHAR,
    FIRSTCALLFLAG_INVALID_SPACE,
    FIRSTCALLFLAG_INVALID_VALUE,
    BALANCE_INVALID_CHAR,
    BALANCE_INVALID_SPACE,
    BALANCE_TOO_LONG,
    MSISDN_INVALID_LEN,
    PID_INVALID_VALUE,
    BALANCE_INVALID_LEN,
    SUBSTATE_INVALID_VALUE,
    SUBSTATE_INVALID_CHAR,
    SUBSTATE_INVALID_LEN,
    SUBSTATE_TOO_LONG,
    SERVICESTART_INVALID_LEN,
    SERVICESTART_INVALID_CHAR,
    CALLSERVICESTOP_INVALID_LEN,
    CALLSERVICESTOP_INVALID_CHAR,
    ACCOUNTSTOP_INVALID_LEN,
    ACCOUNTSTOP_INVALID_CHAR,
    LOCKSTOP_INVALID_LEN,
    LOCKSTOP_INVALID_CHAR,
    AREANUMBER_INVALID_LEN,
    AREANUMBER_INVALID_CHAR,
    CREDIT_INVALID_SPACE,
    CREDIT_INVALID_CHAR,
    INVALID_DATE_FORMAT,
    FOUND_RETURN_CHAR,
    UNKNOWN_ERROR,
    ERROR_CODE_COUNT
};

void  init_error_desc();
const char* get_error_desc(DATAERROR error_code);

const unsigned int FILE_BUFFER_SIZE = 4096;
const char         NEW_LINE         = 0X0A;

typedef char OcsDate[9];

struct DataFileStruct
{
    enum{MSISDN_LEN = 13};

    DATAERROR   errorCode;
    int         lineno;

    long        pid; //文件名中带
    char        MSISDN[MSISDN_LEN + 1];
    SUBS_STATUS state;
    double      balance;
    char        areaNumber[6];
    LIFE_STATUS life;

    OcsDate     balance_effect;
    OcsDate     balance_expire;
    OcsDate     card_effect;
    OcsDate     card_expire;

    long long   msisdn_number;
    int         ndc;
    int         sn1;
    int         sn2;

    char        data_line[200];
};

struct HuaweiData : public DataFileStruct
{
    long    SubState;
    int     AccountState;
};


enum DATA_FILE_TYPE
{
    HUAWEI_FILE  = 0,
    SIEMENS_FILE = 1,
    INVALID_FILE = -1
};


template<typename DataType>
class FileOp
{
public:
    int  open(const std::string&, int scpid);
    void close();
    int  read();
    int  is_eof();
    int  get_total_line();
    int  get_error_line();
    char* file_date(){return m_date;}

protected:
    FileOp() :
        m_opFile(NULL), m_file(NULL), m_pUserStorage(NULL),
        m_iseof(0), m_lineCount(0), m_errorCount(0)
    {}
    
    ~FileOp()
    {
        close();
    }

    int output(const DataFileStruct& data);

protected:
    FILE*        m_opFile;
    FILE*        m_file;
    UserStorage* m_pUserStorage;
    char         m_date[9];
    int          m_scpid;
    int          m_iseof;
    int          m_readSize;
    int          m_lineCount;
    int          m_errorCount;
    char         m_buff[FILE_BUFFER_SIZE];
};


class HuaweiFile : public FileOp<HuaweiFile>
{
friend class FileOp<HuaweiFile>;
private:
    enum STATUS {
        READ_MSISDN,
        READ_SUBSTATE,
        READ_PID,
        READ_ACCOUNTLEFT,
        READ_ACCOUNTSTATE,
        READ_SERVICESTART,
        READ_CALLSERVICESTOP,
        READ_ACCOUNTSTOP,
        READ_LOCKSTOP,
        READ_AREANUMBER,
        TRAN_LIFE,
        READ_IGNORE2,
        INVALID_STATUS = -1
    };

public:
    HuaweiFile(FILE*, UserStorage*);

protected:

    void reset_context(int lineno);
    int read_data(char*, int);

private:
    void read_msisdn(char c);
    void read_substate(char c);
    void read_pid(char c);
    void read_accountleft(char c);
    void read_state(char c);
    void read_servicestart(char c);
    void read_callservicestop(char c);
    void read_accountstop(char c);
    void read_lockstop(char c);
    void read_areanumber(char c);
    void tran_life();

private:
    int         m_accountState;
    long long   m_column;
    long long   m_balance;
    long long   m_index;
    int         m_sign;
    int         m_lineno;
    HuaweiData  m_huaweiData;
    STATUS      m_status;
};


int proc_huawei_files(FileList&, FILE*, UserStorage*);

#endif
