#include <iostream>
#include <stdio.h>
#include <list>
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <map>
#include "log.hpp"
#include "fileop.hpp"
#include "defs.hpp"
#include "config.hpp"
#include "filefilter.hpp"

const char VERSION[] = {"1.0.0"};

using namespace std;


int g_total_line = 0;
int g_error_line = 0;
NumberRangeFilter g_numberRangeFilter;

int    g_check_file_name = 1;
int    g_check_ndc = 0;
string g_tmp_file_path;
string g_scp_file_path;
string g_huawei_path;
map<int, int> g_scpidMap;

int read_config();
int get_all_huawei_files(FileList& fileList);
int proc_all_file(FILE* opFile, UserStorage& us);
int proc_file_from_arg(int argc, char* argv[], FILE* opFile, UserStorage& us);
int create_succ_file();


int main(int argc, char* argv[])
{
    init_error_desc();

    init_config();
    INIT_LOG("MKSF");

    if(2 == argc)
    {
        if(0 == strcmp(argv[1], "-v"))
        {
            printf("%s\n", VERSION);
            exit(0);
        }
    }

    if(-1 == read_config())
    {
        return -1;
    }

    string scp_file = g_scp_file_path + "/scp_file.lst";
    FILE* opFile = fopen(scp_file.c_str(), "w");

    if(NULL == opFile)
    {
        WRITE_LOG("Error: [MAIN] failed to create scp file !\n");
        return -1;
    }

    int retval;
    UserStorage us;
    us.init();

    if(1 < argc)
    {
        retval = proc_file_from_arg(argc, argv, opFile, us);
    }
    else
    {
        retval = proc_all_file(opFile, us);
    }

    if(0 == retval)
    {
        us.enum_all_user(opFile);
    }

    fclose(opFile);

    LOG_SEPARATOR;
    WRITE_LOG("Info: [Result] Total line = %d\n", g_total_line);
    WRITE_LOG("Info: [Result] Error line = %d\n", g_error_line);
    LOG_TIME();

    create_succ_file(g_tmp_file_path, "mksf");
    g_numberRangeFilter.dump();
    return retval;
}

int  read_config()
{
    string number;
    char cfgName[25];
    int i = 0;

    while(1)
    {
        ++i;
        sprintf(cfgName, "number%03d", i);

        if(Config::get_instance()->get_item("cfg", cfgName, number))
        {
            if(false == g_numberRangeFilter.init(number.c_str()))
            {
                WRITE_LOG("Error: [READ_CONFIG] Failed to get number !\n");
                return -1;
            }
        }
        else
        {
            break;
        }
    }

    if(!Config::get_instance()->get_item("cfg", "tmp_file_path", g_tmp_file_path))
    {
        WRITE_LOG("Error: [READ_CONFIG] Failed to get tmp_file_path !\n");
        return -1;
    }

    if(0 == g_tmp_file_path.size())
    {
        WRITE_LOG("Error: [READ_CONFIG] Failed to get tmp_file_path !\n");
        return -1;
    }


    if(!Config::get_instance()->get_item("cfg", "scp_file_path", g_scp_file_path))
    {
        WRITE_LOG("Error: [READ_CONFIG] Failed to get scp_file_path !\n");
        return -1;
    }

    if(0 == g_scp_file_path.size())
    {
        WRITE_LOG("Error: [READ_CONFIG] Failed to get scp_file_path !\n");
        return -1;
    }

    if(!Config::get_instance()->get_item("cfg", "huawei_path", g_huawei_path))
    {
        WRITE_LOG("Error: [READ_CONFIG] Failed to get huawei_path !\n");
        return -1;
    }

    if(0 == g_huawei_path.size())
    {
        WRITE_LOG("Error: [READ_CONFIG] Failed to get huawei_path !\n");
        return -1;
    }

    string check_ndc;
    if(Config::get_instance()->get_item("cfg", "check_ndc", check_ndc))
    {
        int tmp = atoi(check_ndc.c_str());

        if(tmp == 1)
        {
            g_check_ndc = 1;
        }
        else
        {
            g_check_ndc = 0;
        }
    }

    string check_file_name;
    if(Config::get_instance()->get_item("cfg", "check_file_name", check_file_name))
    {
        int tmp = atoi(check_file_name.c_str());

        if(0 == tmp || 1 == tmp || 2 == tmp)
        {
            g_check_file_name = tmp;
        }
        else
        {
            g_check_file_name = 2;
        }
    }

    string scpid_value;
    char cfg_scpid[12];
    char fileNo[20];
    char scpid[20];
    int fileNoLen, scpid_len;
    for(i = 1; i < 1000; ++i)
    {
        sprintf(cfg_scpid, "scpid%03d", i);

        if(!Config::get_instance()->get_item("cfg", cfg_scpid, scpid_value))
        {
            break;
        }

        memset(fileNo, 0, sizeof(fileNo));
        memset(scpid,  0, sizeof(scpid));

        int j = 0;
        int len = scpid_value.size();
        fileNoLen = 0;
        scpid_len = 0;

        for(j = 0; j < len; ++j)
        {
            if(isblank(scpid_value[j]))
            {
                if(0 == fileNoLen)
                {
                    WRITE_LOG("Error: [READ_CONFIG] Invalid scpid: %s\n", scpid_value.c_str());
                    return -1;
                }

                break;
            }

            fileNo[fileNoLen] = scpid_value[j];
            ++fileNoLen;
        }

        for(; j < len; ++j)
        {
            if(!isblank(scpid_value[j]))
            {
                break;
            }
        }

        for(; j < len; ++j)
        {
            if('\0' == scpid_value[j] || isblank(scpid_value[j]))
            {
                if(0 == scpid)
                {
                    WRITE_LOG("Error: [READ_CONFIG] Invalid scpid: %s\n", scpid_value.c_str());
                    return -1;
                }

                break;
            }

            scpid[scpid_len] = scpid_value[j];
            ++scpid_len;
        }

        g_scpidMap[atoi(fileNo)] = atoi(scpid);
    }

    WRITE_LOG("Info: [Config] tmp_file_path   = %s\n", g_tmp_file_path.c_str());
    WRITE_LOG("Info: [Config] scp_file_path   = %s\n", g_scp_file_path.c_str());
    WRITE_LOG("Info: [Config] huawei_path     = %s\n", g_huawei_path.c_str());
    WRITE_LOG("Info: [Config] check_ndc       = %d\n", g_check_ndc);
    WRITE_LOG("Info: [Config] check_file_name = %d\n", g_check_file_name);

    map<int, int>::iterator ptr;
    for(ptr = g_scpidMap.begin(); ptr != g_scpidMap.end(); ++ptr)
    {
        WRITE_LOG("Info: [Config] scpid: %d - '%d'\n", ptr->first, ptr->second);
    }

    return 0;
}

int get_all_huawei_files(FileList& fileList)
{
    errno = 0;

    DIR* pdir = opendir(g_huawei_path.c_str());

    if(NULL == pdir)
    {
        if(0 != errno)
        {
            WRITE_LOG("Error: [GET_ALL_HUAWEI_FILES] %s\n", strerror(errno));
        }
        else
        {
            WRITE_LOG("Error: [GET_ALL_HUAWEI_FILES] Failed to open directory\n");
        }
    }

    FileFilter ff(g_check_file_name);

    char* ocs_home = getenv("OCS_HOME");

    if(NULL == ocs_home || 0 == strlen(ocs_home))
    {
        std::cout << "Environment 'OCS_HOME' not exist;";
        return false;
    }

    char hw_file[1024];
    sprintf(hw_file, "%s/etc/huawei_file.txt", ocs_home);

    if(-1 == ff.init(hw_file, HUAWEI_FILE))
    {
        WRITE_LOG("Error: [GET_ALL_HUAWEI_FILES] failed to read huawei file list\n");
        return -1;
    }

    string fullName;
    struct stat buf;
    struct dirent *dirp;

    for(;;)
    {
        dirp = readdir(pdir);

        if(NULL == dirp)
        {
            if(0 != errno)
            {
                WRITE_LOG("Error: [GET_ALL_HUAWEI_FILES] %s\n", strerror(errno));
            }

            break;
        }

        fullName = g_huawei_path + "/" + dirp->d_name;

        if(0 != stat(fullName.c_str(), &buf))
        {
            if(0 != errno)
            {
                WRITE_LOG("Error: [GET_ALL_HUAWEI_FILES] %s\n", strerror(errno));
            }
            else
            {
                WRITE_LOG("Error: [GET_ALL_HUAWEI_FILES] Failed to read file '%s'\n", fullName.c_str());
            }

            break;
        }

        if(S_ISREG(buf.st_mode))
        {
            if(0 == ff.check_file(dirp->d_name))
            {
                fileList.insert(fullName);
            }
            else
            {
                printf("Warning: invalid file '%s'\n", fullName.c_str());
                WRITE_LOG("Warning: invalid file '%s'\n", fullName.c_str());
            }
        }
    }

    ff.finish(0);
    closedir(pdir);

    return 0;
}


int proc_all_file(FILE* opFile, UserStorage& us)
{
    int retval;
    FileList fileList;

    if(0 == get_all_huawei_files(fileList))
    {
        if(0 == fileList.size())
        {
            WRITE_LOG("Warning: No file of huawei had been processed\n");
        }

        retval = proc_huawei_files(fileList, opFile, &us);
        fileList.clear();

        if(-1 == retval)
        {
            return -1;
        }
    }

    return 0;
}

int proc_file_from_arg(int argc, char* argv[], FILE* opFile, UserStorage& us)
{
    _ASSERT(NULL != argv);

    FileList        hwFileList;
    FileList        seiFileList;
    FileListPtr     fileNamePtr;
    DATA_FILE_TYPE  dataFileType = INVALID_FILE;

    for(int i = 1; i < argc; ++i)
    {
        if(0 == strcmp("-h", argv[i]))
        {
            dataFileType = HUAWEI_FILE;
        }
        else if(0 == strcmp("-s", argv[i]))
        {
            dataFileType = SIEMENS_FILE;
        }
        else
        {
            switch(dataFileType)
            {
                case HUAWEI_FILE:
                    hwFileList.insert(argv[i]);
                    break;

                case SIEMENS_FILE:
                    seiFileList.insert(argv[i]);
                    break;

                default:
                    WRITE_LOG("Error: [PROC_FILE_FROM_ARG] Invalid arguement\n");
                    return -1;
            }
        }
    }

    if(0 != hwFileList.size())
    {
        if(-1 == proc_huawei_files(hwFileList, opFile, &us))
        {
            return -1;
        }
    }

    if(0 != seiFileList.size())
    {
        if(-1 == proc_huawei_files(seiFileList, opFile, &us))
        {
            return -1;
        }
    }

    return 0;
}

int create_succ_file()
{
    string fn = g_tmp_file_path + "/mksf_success";
    FILE* file = fopen(fn.c_str(), "w");
    fclose(file);
    return 0;
}
