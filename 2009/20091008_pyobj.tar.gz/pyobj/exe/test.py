#!/usr/bin/python
import pyobjk

def somePythonCallBackFunction( n ):
    print "Application called \"somePythonCallBackFunction\" and passed: " + str( n )

pyobjk.setCallback( somePythonCallBackFunction );

print "pyobj.getApplicationValue() returned: " + str( pyobjk.getApplicationValue() )

pyobjk.setApplicationValue( 55 )

print "pyobj.getApplicationValue() returned: " + str( pyobjk.getApplicationValue() )

returnValue = -1

