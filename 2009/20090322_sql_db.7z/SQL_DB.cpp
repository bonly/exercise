/*
 * SQL_DB.cpp
 *
 *  Created on: 2009-4-18
 *      Author: Bonly
 */

#include "SQL_DB.hpp"

namespace bonly
{
int
Command::Perform()
{
	int ret = sqlite3_step (_stmt);
	if (!(ret == SQLITE_ROW
			||ret == SQLITE_DONE
      ||ret == SQLITE_OK))
	{
		_db->errmsg("Command::Perform");
	}
  return ret;
}

int
Command::Drop()
{
	int ret = sqlite3_finalize(_stmt);
	if (ret != SQLITE_OK)
	{
		_db->errmsg("Command::Drop");
	}
	return ret;
}

int  Command::setParam(int i, int val)
{
	int ret = sqlite3_bind_int (_stmt,i,val);
	if (SQLITE_OK != ret)
	{
		_db->errmsg("Command::setParam");
	}
	return ret;
}

int  Command::setParam(int i, const char* val, int n, void(*p)(void*))
{
	int ret = sqlite3_bind_text (_stmt,i,val,n,p);
	if (SQLITE_OK != ret)
	{
		_db->errmsg("Command::setParam");
	}
	return ret;
}

void Command::getColumn(int i, int* var)
{
	*var = sqlite3_column_int(_stmt, i);
}

void Command::getColumn(int i, const unsigned char* var)
{
  var = sqlite3_column_text(_stmt, i);
}

/*
 * *******************************************************************
 */
DB::DB(){}
DB::DB(const char* dsn)
{	Connect (dsn);}
DB::~DB(){}

int
DB::Connect (const char* dsn)
{
	int ret = sqlite3_open (dsn, &_db);
	if (ret != SQLITE_OK)
	{
		errmsg("DB::Connect");
	}
	return ret;
}

int
DB::Disconnect()
{
	sqlite3_stmt *pStmt;
	while( (pStmt = sqlite3_next_stmt(_db, 0))!=0 )
	{
	    sqlite3_finalize(pStmt);
	}

	int ret = sqlite3_close (_db);
	if (ret != SQLITE_OK)
	{
		errmsg("DB::Disconnect");
	}
	return ret;
}

PCmd
DB::Prepare (const char* sql)
{
	const char* tail;
	PCmd cmd (new Command);
	cmd->_db=this;
	//param[3]=-1: ����sql�ĵ�һ��\000��ֹ
	int ret = sqlite3_prepare(_db,sql,-1,&(cmd->_stmt),&tail);
	if (ret != SQLITE_OK)
	{
     errmsg("DB::Prepare");
	}
	return cmd;
}

void
DB::errmsg(const char* where)
{
	printf("When %s\n",where);
	printf("error code: %d\n"
			   "ext   code: %d\n"
			   "       msg: %s\n",
			    sqlite3_errcode(_db),
			    sqlite3_extended_errcode(_db),
			    sqlite3_errmsg(_db));
}


}
