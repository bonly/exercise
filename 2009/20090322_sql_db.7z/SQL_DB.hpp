/*
 * SQL_DB.h
 *
 *  Created on: 2009-4-18
 *      Author: Bonly
 */

#ifndef __SQL_DB_HPP__
#define __SQL_DB_HPP__
#include <boost/shared_ptr.hpp>
#include <iostream>
#include "sqlite3.h"
namespace bonly
{
using namespace std;
using namespace boost;

class DB;
class Command
{
	public:
		friend  class DB;
		//void        db(DB* d){_db=d;}
		int           Perform();
		//int         Close();
		int           Drop();
		sqlite3_stmt* stmt()
		{return _stmt;}

		int           setParam(int i, int val);
		int           setParam(int, const char*, int n, void(*p)(void*)=SQLITE_STATIC);

    void          getColumn(int i, int* var);
    void          getColumn(int i, const unsigned char *var);

	private:
		sqlite3_stmt*  _stmt;
		DB*            _db;
};

typedef shared_ptr<Command> PCmd;

class DB
{
	public:
		DB();
		DB::DB(const char* dsn);
		virtual ~DB();
		int      Connect(const char* dsn);
		int      Disconnect();
		PCmd     Prepare(const char* sql);
		//int    Commit();
		//int    Rollback();
		void     errmsg(const char* where);

	private:
		sqlite3*      _db;
};
}
#endif /* __SQL_DB_HPP__ */
