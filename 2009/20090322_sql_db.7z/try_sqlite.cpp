/*
 * try_sqlite.cpp
 *
 *  Created on: 2009-4-19
 *      Author: Bonly
 */
#include "SQL_DB.hpp"
using namespace bonly;
int
main()
{
  DB db("testa");
  PCmd ta = db.Prepare("select count(*) from sqlite_master where tbl_name='myta'");
  int tbl=-1;
  if (ta->Perform()==SQLITE_ROW)
  	tbl=sqlite3_column_int(ta->stmt(),0);

  if(tbl<=0)
  {
		ta = db.Prepare("create table myta(k int, ca varchar(20))");
		if (ta->Perform()!=SQLITE_DONE)
		{
			db.errmsg("create");
			cerr << "create fail\n";
		}
  }
  ta = db.Prepare("insert into myta values(35,'test')");
  if (ta->Perform()!=SQLITE_DONE)
  {
  	db.errmsg("insert");
    cerr << "inser fail\n";
  }

  ta = db.Prepare("select * from myta");
  while (ta->Perform()==SQLITE_ROW)
  {
  	int d;
  	ta->getColumn(0, &d);
  	unsigned char buf[20+1];
  	ta->getColumn(1, buf);
  	cout << d << "\t" << buf <<endl;
  }
  ta->Drop();
  db.Disconnect();
	return 0;
}
