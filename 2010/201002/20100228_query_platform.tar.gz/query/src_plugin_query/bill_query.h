/**
 *  @brief 定义并行查询插件接口
 *  @date 2011-05-18 lqb create
 *  @date 2011-07-26 bonly 修改为转存消息到队列
 *
 */
#ifndef __BILL_QUERY_H__
#define __BILL_QUERY_H__

#define QUERY_DEBUG(...)\
    R5_DEBUG(g_r5_plog, ("[query] " __VA_ARGS__))
#define QUERY_INFO(...)\
    R5_INFO(g_r5_plog, ("[query] " __VA_ARGS__))
#define QUERY_ERROR(...)\
    R5_ERROR(g_r5_plog, ("[query] " __VA_ARGS__))
#define QUERY_WARN(...)\
    R5_WARN(g_r5_plog, ("[query] " __VA_ARGS__))
#define QUERY_TRACE(...)\
    R5_TRACE(g_r5_plog, ("[query] " __VA_ARGS__))

#define PRO_DB_LEN 32

struct bill_conf{
    char db_host[PRO_DB_LEN + 1];
    char db_name[PRO_DB_LEN + 1];
    char db_username[PRO_DB_LEN + 1];
    char db_password[PRO_DB_LEN + 1];
    int db_port;
};


struct table_name{
    char name[32];
};

class R5_Log;
struct query_protocol;
struct route_info;

/** @brief 初始化插件,导出的
 *  @param *conf_file 配置文件
 *  @param *plog 日志指针
 *  @return -1:失败 0:成功
 */
extern "C" int initialize(const char* conf_file, R5_Log* plog);

/** @brief 销毁插件,导出的
 *  @return -1:失败 0:成功
 */
extern "C" int destroy();

/** @brief 话单查询,导出的
 *  @param *protocol 协议结构体
 *  @param *route_result 路由结果
 *  @param *bill 语单缓存区
 *  @param *billlen 缓存区大小
 *  @return -1:失败 0:成功
 */
extern "C" int bill_query(const void* protocol, const void* route_result, void* bill, int* billlen);

int find_innodb_table(int begin, int end, int index, MYSQL* db);

int get_tables(query_protocol* protocol, route_info* route);

int query_bill(char* buf, int* len, query_protocol* protocol, route_info* route);

int connect_mysql(const char* connect_str);

#endif
