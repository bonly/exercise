/*
 *date:2011-05-18
 *author:lqb
 */

#include <mysql.h>
#include <stdlib.h>
#include <time.h>

//先采用string实现？
#include <string>
#include <map>
#include <vector>

#include "bill_query.h"
#include "comm_structs.h"
#include "query_type.h"

//from base lib
#include"iniconfig.h"
#include"r5api.h"

using namespace std;

R5_Log* g_r5_plog;
static MYSQL* g_querydb = NULL;
map<string, MYSQL*> g_mysql_map;

vector<table_name> g_table_vec;

//vector<table_info> g_table_vec;

int initialize(const char* conf_file, R5_Log* plog)
{
    if (NULL == plog)
    {
        fprintf(stderr, "plog is NULL!\n");
        return -1;
    }

    g_r5_plog = plog;

    /*  bill_conf conf;
     memset(&conf, 0, sizeof(bill_conf));

     //读取配置文件
     IniConfig config;
     if (config.open(conf_file) < 0) {
     QUERY_ERROR("open file(%s) error!\n", conf_file);
     return -1;
     }

     const char* query = "BILL_QUERY";

     //db_host
     const char* db_host = config.getValue(query, "DB_HOST");
     if(db_host && strlen(db_host) != 0){
     strncpy(conf.db_host, db_host, PRO_DB_LEN);
     } else {
     QUERY_ERROR("read DB_HOST item failed, configure file:%s.\n", conf_file);
     return -1;
     }

     //db_dbname
     const char* db_name = config.getValue(query, "BD_DBNAME");
     if(db_name && strlen(db_name) != 0){
     strncpy(conf.db_name, db_name, PRO_DB_LEN);
     } else {
     QUERY_ERROR("read DB_DBNAME failed, configure file:%s\n", conf_file);
     return -1;
     }

     //db_username
     const char* db_username = config.getValue(query, "DB_USERNAME");
     if(db_username && strlen(db_username) != 0){
     strncpy(conf.db_username, db_username, PRO_DB_LEN);
     } else {
     QUERY_ERROR("read DB_USERNAME failed, configure file:%s\n", conf_file);
     return -1;
     }

     //db_password
     const char* db_password = config.getValue(query, "DB_PASSWORD");
     if(db_password && strlen(db_password) != 0){
     strncpy(conf.db_password, db_password, PRO_DB_LEN);
     } else {
     QUERY_WARN("read db_password failed, configure file:%s\n", conf_file);
     //return -1;
     }

     // db_port
     const char* db_port = config.getValue(query, "DB_PORT");
     if(db_port && strlen(db_port) != 0){
     conf.db_port = atoi(db_port);
     } else {
     QUERY_ERROR("read db_port failed, configure file:%s\n", conf_file);
     return -1;
     }
     */

    /*
     //初始化数据库连接
     g_querydb = mysql_init(0);
     if(NULL == g_querydb){
     QUERY_ERROR("mysql_init failed.\n");
     return -1;
     }

     if (!mysql_real_connect(g_querydb, conf.db_host, conf.db_username,
     conf.db_password, conf.db_name, conf.db_port, 0, 0)) {
     QUERY_ERROR("mysql: error=[%s]\n", mysql_error(g_querydb));
     return -1;
     }
     */

    return 0;
}

int destroy()
{

    //关闭数据库连接
    if (NULL != g_querydb)
        mysql_close(g_querydb);

    map<string, MYSQL*>::iterator it;
    for (it = g_mysql_map.begin(); it != g_mysql_map.end(); ++it)
    {
        if (NULL != it->second)
            mysql_close(it->second);

    }

    return 0;
}

int bill_query(const void* protocol, const void* route_result, void* bill,
            int* billlen)
{
    if (NULL == protocol || NULL == route_result || NULL == bill
                || NULL == billlen)
    {
        QUERY_ERROR("param error, at least one params NULL!\n");
        return -1;
    }

    query_protocol* proto = (query_protocol*) protocol;
    route_info_list* route = (route_info_list*) route_result;

    long long number = strtoll(proto->sub_no, NULL, 10);
    int tab_index = (int) (number % 5000);
    g_table_vec.clear();

    QUERY_INFO("query user:%s, time:%s\n", proto->sub_no, proto->query_time);

    *billlen = 0;
    char*p = (char*) bill;

    for (int i = 0; i < route->count; ++i)
    {
        get_tables(proto, &(route->route_item[i]));
        if (0 == query_bill(p, billlen, proto, &(route->route_item[i])))
            break;
    }

    return 0;
}

int query_bill(char* buf, int* len, query_protocol* protocol, route_info* route)
{
    char query[256];
    int n;
    char* p = buf;
    long long id = strtoll(protocol->sub_no, NULL, 10);

    for (vector<table_name>::iterator it = g_table_vec.begin();
                it != g_table_vec.end(); ++it)
                {
        memset(query, 0, sizeof(query));
        n = 0;
        if ('0' == protocol->cdr_type)
        {
            n =
                        snprintf(
                                    query,
                                    sizeof(query),
                                    "select * from %s where subno = '%s' and start_time >= '%s' and start_time <= '%s' limit 2",
                                    it->name, protocol->sub_no,
                                    protocol->begin_date, protocol->end_date);
        }
        else
        {
            n =
                        snprintf(
                                    query,
                                    sizeof(query),
                                    "select * from %s where subno = '%s' and xd_type = '%c' and start_time >= '%s' and start_time <= '%s' limit 2",
                                    it->name, protocol->sub_no,
                                    protocol->cdr_type, protocol->begin_date,
                                    protocol->end_date);
        }

        QUERY_DEBUG("SQL:%s\n", query);

        string str(route->connect_string);
        map<string, MYSQL*>::iterator it = g_mysql_map.find(str);
        if (it == g_mysql_map.end())
        {
            if (connect_mysql(route->connect_string) < 0)
            {
                QUERY_WARN("connect to mysql faield. con_str = %s\n",
                            route->connect_string);
                return -1;
            }
        }

        it = g_mysql_map.find(str);
        MYSQL* db = it->second;

        //
        const int r = mysql_real_query(db, query, n > 0 ? n : 0);
        if (r != 0)
        {
            unsigned int err = mysql_errno(db);
            QUERY_ERROR(" 1146 mysql: error=[%s] errno =%d\n", mysql_error(db),
                        err);
            //Table 'db_name.table' doesn't exist
            if (1146 == err)
                continue;

            //MySQL server has gone away
            if (2006 == err)
                g_mysql_map.erase(it);

            return -1;
        }

        MYSQL_ROW row = 0;
        unsigned long *lengths = 0;
        unsigned int num_rows = 0;
        unsigned int num_flds = 0;
        MYSQL_RES *res = mysql_store_result(db);

        if (res != 0)
        {
            num_rows = mysql_num_rows(res);
            num_flds = mysql_num_fields(res);
            QUERY_DEBUG("num_rows:%d, num_flds:%d\n", num_rows, num_flds);
            while ((row = mysql_fetch_row(res)))
            {
                lengths = mysql_fetch_lengths(res);
                for (int i = 0; i < num_flds; ++i)
                {
                    strcpy(p, row[i]);
                    p += lengths[i];
                    *len += lengths[i];
                    *p = '|';
                    p++;
                    (*len)++;

                    if (*len >= 32 * 1024 * 1024)
                        return -2;
                }
                *p = '&';
                p++;
                (*len)++;
            }

            //QUERY_DEBUG("query len:%d query result:%s\n", *len, buf + PRO_HEAD_LEN);
        }

        mysql_free_result(res);
    }

    //添加协议头
    /*
     p = buf;
     *len += PROTOCOL_HEAD_LEN;

     protocol_head* header = &(protocol->header);

     memcpy(p, header->command, PRO_COMMAND_LEN);
     p += PRO_COMMAND_LEN;
     *p = '\0';
     p++;

     memcpy(p, header->sequence, PRO_SEQUENCE_LEN);
     p += PRO_SEQUENCE_LEN;
     *p = '\0';
     p++;

     snprintf(p, PRO_LENGTH_LEN, "%d", *len);
     p += PRO_LENGTH_LEN;
     *p = '\0';
     p++;

     memcpy(p, header->system, PRO_SYSTEM_LEN);
     p += PRO_SYSTEM_LEN;
     *p = '\0';
     p++;

     //encrypt_flag
     *p = '0';
     p++;

     //errcode
     //if(0 == protocol->result_code){
     *p = '0';
     p++;
     //} else {
     //    *p = '1';
     //    p++;
     //}

     //morepkt
     *p = '0';
     p++;

     memcpy(p, header->decompresslen, PRO_DECOM_LEN);
     p += PRO_DECOM_LEN;
     */
    return 0;
}

int connect_mysql(const char* connect_str)
{
    string str_con(connect_str);
    char *str = (char*) connect_str;
    bill_conf conf;
    memset(&conf, 0, sizeof(conf));

    //default username:'root'
    //default password:null
    strncpy(conf.db_username, "root", PRO_DB_LEN);

    do
    {
        char* p = strchr(str, '|');
        if (NULL == p)
        {
            return -1;
        }
        memcpy(conf.db_host, str, p - str);
        str = p + 1;

        p = strchr(str, '|');
        if (NULL == p)
        {
            return -1;
        }
        char tmp[8] = { 0 };
        memcpy(tmp, str, p - str);
        conf.db_port = atoi(tmp);
        str = p + 1;

        p = strchr(str, '|');
        if (NULL == p)
        {
            strncpy(conf.db_name, str, PRO_DB_LEN);
            break;
        }
        memcpy(conf.db_name, str, p - str);
        str = p + 1;

        memset(conf.db_username, 0, sizeof(conf.db_username));
        p = strchr(str, '|');
        if (NULL == p)
        {
            strncpy(conf.db_username, str, PRO_DB_LEN);
            break;
        }
        memcpy(conf.db_username, str, p - str);
        str = p + 1;

        strncpy(conf.db_password, str, PRO_DB_LEN);
    } while (0);

    //初始化数据库连接
    MYSQL* db = mysql_init(0);
    if (NULL == db)
    {
        QUERY_ERROR("mysql_init failed.\n");
        return -1;
    }

    if (!mysql_real_connect(db, conf.db_host, conf.db_username,
                conf.db_password, conf.db_name, conf.db_port, 0, 0))
    {
        QUERY_ERROR("mysql: error=[%s]\n", mysql_error(db));
        return -1;
    }

    g_mysql_map.insert(make_pair<string, MYSQL*>(str_con, db));
    map<string, MYSQL*>::iterator it = g_mysql_map.find(str_con);
    if (it == g_mysql_map.end())
        return -1;

    QUERY_INFO("connect to mysql success! constr = %s\n", connect_str);

    return 0;
}

int get_tables(query_protocol* protocol, route_info* route)
{
    char date_begin[8] = { 0 };
    char date_end[8] = { 0 };

    memcpy(date_begin, protocol->begin_date, 6);
    memcpy(date_end, protocol->end_date, 6);
    int d_begin = atoi(date_begin);
    int d_end = atoi(date_end);

    long long number = strtoll(protocol->sub_no, NULL, 10);
    int tab_index = (int) (number % 5000);

    QUERY_DEBUG("begin:%d end:%d index:%d\n", d_begin, d_end, tab_index);

    string str(route->connect_string);
    map<string, MYSQL*>::iterator it = g_mysql_map.find(str);
    if (it == g_mysql_map.end())
    {
        if (connect_mysql(route->connect_string) < 0)
        {
            QUERY_WARN("connect to mysql faield. con_str = %s\n",
                        route->connect_string);
            return -1;
        }
    }

    it = g_mysql_map.find(str);
    MYSQL* db = it->second;

    /*
     //MYISAM表
     for(int i = d_begin; i <= d_end; ++i){
     for(int type = 1; type < 8; ++type){
     table_name table;
     snprintf(table.name, sizeof(table.name), "BILL_%06d_%02d_%02d", i, type, tab_index);
     g_table_vec.push_back(table);
     QUERY_DEBUG("table:%s\n", table.name);
     }
     }
     */
    //innodb表 
    find_innodb_table(d_begin, d_end, tab_index, db);

    /*just for test*************************************/
//#if 0
    table_name table;
    snprintf(table.name, sizeof(table.name), "BILL_201106_01_%02d", tab_index);
    g_table_vec.push_back(table);
    QUERY_DEBUG("table:%s\n", table.name);
//#endif
    /*just for test*************************************/

    return 0;
}

int find_innodb_table(int begin, int end, int index, MYSQL* db)
{
    char query[256] = { 0 };

    const int len =
                snprintf(
                            query,
                            sizeof(query),
                            "select tablename, Table_num from indb_newtable_record where status != 2 and time >= %d and time <= %d",
                            begin, end);
    QUERY_DEBUG("SQL:%s\n", query);

    const int r = mysql_real_query(db, query, len > 0 ? len : 0);
    if (r != 0)
    {
        QUERY_ERROR("mysql: error=[%s]\n", mysql_error(db));
        return -1;
    }

    MYSQL_ROW row = 0;
    unsigned long *lengths = 0;
    //unsigned int num_rows = 0;
    unsigned int num_flds = 0;
    MYSQL_RES *res = mysql_store_result(db);

    if (res != 0)
    {
        //返回结果集中的列数
        num_flds = mysql_num_fields(res);

        while ((row = mysql_fetch_row(res)))
        {
            QUERY_DEBUG("num_flds:%d\n", num_flds);
            //取所有列的长度
            lengths = mysql_fetch_lengths(res);

            if (2 == num_flds)
            {
                table_name table;
                memset(&table, 0, sizeof(table_name));
                if (0 == strncmp(row[0], "BILL_HISTORY", 12))
                {
                    snprintf(table.name, sizeof(table.name), "%s_%03d", row[0],
                                atoi(row[1]));
                    g_table_vec.push_back(table);
                    QUERY_DEBUG("table:%s\n", table.name);
                }
                else
                {
                    snprintf(table.name, sizeof(table.name), "%s_%03d_%03d",
                                row[0], index, atoi(row[1]));
                    g_table_vec.push_back(table);
                    QUERY_DEBUG("table:%s\n", table.name);
                }

            }
        }
    }

    mysql_free_result(res);

    return 0;
}

