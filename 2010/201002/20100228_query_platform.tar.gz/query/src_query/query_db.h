#ifndef __QUERY_DB_H__
#define __QUERY_DB_H__
#include "query_type.h"
/** @brief 日志宏
 *
 */
#define QUERY_DEBUG(...)\
	R5_DEBUG(&g_r5_log, ("[query] " __VA_ARGS__))
#define QUERY_INFO(...)\
	R5_INFO(&g_r5_log, ("[query] " __VA_ARGS__))
#define QUERY_ERROR(...)\
	R5_ERROR(&g_r5_log, ("[query] " __VA_ARGS__))
#define QUERY_WARN(...)\
	R5_WARN(&g_r5_log, ("[query] " __VA_ARGS__))
#define QUERY_TRACE(...)\
	R5_TRACE(&g_r5_log, ("[query] " __VA_ARGS__))

/// 数据库相关的名称长度
#define PRO_DB_LEN 32

/** @brief 请求消息结构
 *
 */
struct request_message
{
        char connect_str[64];
        char table_name[32];
        char sub_no[20];
        char start_time[20];
        char end_time[20];
};

/** @brief 配置
 *
 */
struct bill_conf
{
        char db_host[PRO_DB_LEN + 1];
        char db_name[PRO_DB_LEN + 1];
        char db_username[PRO_DB_LEN + 1];
        char db_password[PRO_DB_LEN + 1];
        int db_port;
};

/** @brief 参数
 *
 */
struct param
{
        char conf_file[MAX_FILE_LEN + 1];
        bool deamon;
};

/** @brief 帮助说明
 *
 */
void usage(const char* exec_file);

/** @brief 显示版本
 *
 */
void show_version();

/** @解释启动参数
 *
 */
int read_arg(int argc, char* argv[]);

/** @brief 处理消息队列的主函数
 *  @param *pbuf 存放结果的级冲区
 *  @param inqueue 结果消息队列
 *  @param outqueue 请求消息队列
 *  @return
 */
int process(char* pbuf, int inqueue, int outqueue);

/** @brief  到数据库中查清单
 *  @param *buf 存储清单内容的缓冲区
 *  @param *request 请求数据结构
 *  @param inqueue 结果消息队列
 *  @param ms 队列消息用户结构
 *  @return 0:成功 其它:失败
 */
int query_bill(char* buf, request_message* request, int inqueue, struct msgform ms);

/** @brief 程序退出时的清理操作
 *
 */
void exit();

/** @brief 连接mysql数据库
 *  @param *connect_str 连接串
 *  @return
 */
int connect_mysql(const char* connect_str);

/** @brief 送返回消息
 *  @param *pbuf 存放着结果的缓冲区
 *  @param msglen 结果的大小
 *  @param count 总记录数
 *  @param current_num 当前记录
 *  @param inqueue 结果消息队列
 *  @return 0:成功 其它:失败
 */
int pack_back_msg(char* pbuf, int msglen, int count, int current_num, int inqueue, struct msgform ms);

#endif //__QUERY_DB_H__
