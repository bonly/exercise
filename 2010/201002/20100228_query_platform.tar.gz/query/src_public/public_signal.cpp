/**
 *
 */

#include "public_signal.h"


_SIGNAL_BEGIN_NAMESPACE

bool g_bSigTerm = false;  //SIGTERM信号标记
bool g_bSigChild = false; //SIGCHILD信号标记
bool g_bSigHup = false;   //SIGHUP信号标记
bool g_bSigUsr2 = false;  //SIGUSR2信号标记
bool g_bSigAlarm = false; //SIGALARM信号标记
bool g_bSigPipe = false;  //SIGPIPE信号标记

int HandleSignal()
{
    //int nRet=0;
    int nRetVal = 0;

    if(g_bSigTerm == true)//程序终止信号处理
    {
        //处理终止信号时可能会产生SIGCHILD信号
        //将DoSigChild放在DoSigTerm之后
        g_bSigTerm = false;
        int nRet = DoSigTerm();
        nRetVal = nRet < 0 ? nRet:nRetVal;
    }

    if(g_bSigHup == true)//升级信号处理
    {
        //处理升级信号时可能会产生SIGCHILD信号
        //将DoSigChild放在DoSigHup之后
        //在DoSigHup()需要判断信号标记，所以将还原g_nSigHup放在后面
        int nRet = DoSigHup();
        g_bSigHup = false;
        nRetVal = nRet < 0 ? nRet:nRetVal;
    }

    if(g_bSigPipe == true)//SIGPIPE信号
    {
        //处理SIGPIPE信号时可能会产生SIGCHILD信号
        //将DoSigChild放在DoSigPipe之后
        g_bSigPipe = false;
        int nRet = DoSigPipe();
        nRetVal = nRet < 0 ? nRet:nRetVal;
    }

    if(g_bSigChild == true)//子进程退出信号处理
    {
        g_bSigChild = false;
        int nRet = DoSigChild();
        nRetVal = nRet < 0 ? nRet:nRetVal;
    }

    if(g_bSigUsr2 == true)//刷新日志信号处理
    {
        g_bSigUsr2 = false;
        int nRet = DoSigUsr2();
        nRetVal = nRet < 0 ? nRet:nRetVal;
    }

    if(g_bSigAlarm == true)
    {
        g_bSigAlarm = false;
        int nRet = DoSigAlarm();
        nRetVal = nRet < 0 ? nRet:nRetVal;
    }

    return nRetVal;
}

void SigTerm(int signo)
{
    g_bSigTerm = true;
}

void SigChild(int signo)
{
    g_bSigChild = true;
}

void SigHup(int signo)
{
    g_bSigHup = true;
}

void SigUsr2(int signo)
{
    g_bSigUsr2 = true;
}

void SigAlarm(int signo)
{
    g_bSigAlarm = true;
}

void SigPipe(int signo)
{
    g_bSigPipe = true;
}

_SIGNAL_END_NAMESPACE
