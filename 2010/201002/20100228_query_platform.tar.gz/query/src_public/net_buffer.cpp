#include "net_buffer.h"

#include "tools.h"
#include<limits.h>



RecvBuffer::RecvBuffer() : m_ptr(0), m_size(0), m_dump(false)
{
}


char* RecvBuffer::get_write_ptr()
{
    if((0 != m_ptr) && (0 != m_size))
    {
        /* 缓冲区的数据移到缓冲区的头部 */
        memmove(m_buff, &m_buff[m_ptr], m_size);
    }

    m_ptr = 0;
    return &m_buff[m_size];     /* 返回缓冲区尾部的指针 */
}


const char* RecvBuffer::get_read_ptr()
{
    if(0 != (m_ptr & 3)) /* 缓冲区头部的偏移量不是4的倍数 */
	{
		memmove(m_buff, &m_buff[m_ptr], m_size);
    	m_ptr = 0;
		//PXY_ERROR("Invalid offset %d\n", m_ptr);
	}

    return &m_buff[m_ptr];      /* 返回缓冲区头部的指针 */
}


void RecvBuffer::set_write_size(int size)
{
    m_size += size;
}


void RecvBuffer::set_read_size(int size)
{
    m_ptr  += size;
    m_size -= size;
}


int RecvBuffer::get_data_size() const
{
    return m_size;
}


int RecvBuffer::get_free_size() const
{
    return (RECV_BUFF_SIZE - m_size);
}


bool RecvBuffer::is_full() const
{
    return (RECV_BUFF_SIZE <= m_size);
}


void RecvBuffer::clear()
{
    m_ptr  = 0;
    m_size = 0;
}


///////////////////////////////////////////////////////////////////
#if 0
SendBuffer::BuffStruct::BuffStruct() :
    sended_size(0), msgInfo(0, 0, NULL, 0)
{
}

SendBuffer::SendBuffer() : m_ptr(0), m_msg_count(0)
{
}

bool SendBuffer::is_empty()
{
    if(0 == m_msg_count)
    {
        return true;
    }

    return false;
}


bool SendBuffer::is_full()
{
    return (SEND_BUFF_COUNT <= m_msg_count) ? true : false;
}


void SendBuffer::move_buffptr(int& ptr, int count)
{
    ptr += count;

    if(SEND_BUFF_COUNT <= ptr)
    {
        ptr -= SEND_BUFF_COUNT;
    }
}


/* 把消息包加入缓冲区队列的尾部 */
int SendBuffer::write_message(const SendMsgInfo& msgInfo)
{
    if(MAX_MSG_LENGHT < msgInfo.size)
    {
        //PXY_ERROR("Invalid message length %d\n", msgInfo.size);
        return INVALID_MSG_LEN;
    }

    if(is_full())
    {
        //PXY_WARN("Send buffer is full\n");
        return SEND_BUFFER_FULL;
    }

    int tmpptr = m_ptr;
    move_buffptr(tmpptr, m_msg_count);

    ++m_msg_count;

    memcpy(&m_buff[tmpptr].msgInfo, &msgInfo, sizeof(SendMsgInfo));
    memcpy(m_buff[tmpptr].buff, msgInfo.mesg, msgInfo.size);

    m_buff[tmpptr].msgInfo.mesg = m_buff[tmpptr].buff;
    m_buff[tmpptr].sended_size = 0;
    return 0;
}


/* 根据缓冲区队列中消息的数量，生成iovec数组 */
int SendBuffer::get_read_ptr(IoVecArray& iov)
{
    int send_cnt  = 0;
    int tmpptr = m_ptr;

    int msg_count = m_msg_count + send_cnt;

    /* 如果消息包数目超过writev函数的限制，就只返回部分消息 */
    if(IOV_MAX < msg_count)
    {
        msg_count = IOV_MAX;
    }

    /* 把消息加入iovec数组中 */
    BuffStruct* pbs;
    for(; send_cnt < msg_count; ++send_cnt)
    {
        pbs = &m_buff[tmpptr];
        iov[send_cnt].iov_base = pbs->buff + pbs->sended_size;
        iov[send_cnt].iov_len  = pbs->msgInfo.size - pbs->sended_size;
        move_buffptr(tmpptr, 1);
    }

    return msg_count;
}


int SendBuffer::set_read_size(int size, SendMsgInfoPtrArray& msgInfo)
{
    int tmpsize = size;  /* 已发送字节数 */
    int tmpptr  = m_ptr;
    int buff_count = 0;
    int remainder_size;

    BuffStruct* pbs;

    while(0 < tmpsize)
    {
        pbs = &m_buff[tmpptr];
        remainder_size = pbs->msgInfo.size - pbs->sended_size;

        if(tmpsize >= remainder_size)       /* 数据已经全部发送了 */
        {
            tmpsize -= remainder_size;
            pbs->sended_size  = pbs->msgInfo.size;
            msgInfo[buff_count] = &pbs->msgInfo;
            ++buff_count;
            --m_msg_count;
        }
        else                                /* 数据只发送了一部分 */
        {
            pbs->sended_size += tmpsize;
            tmpsize = 0;
        }

        move_buffptr(tmpptr);
    }

    move_buffptr(m_ptr, buff_count);
    return buff_count;
}


int SendBuffer::discard_incomplete_msg(const SendMsgInfo*& pMsgInfo)
{
    if(0 < m_msg_count)
    {
        if(0 != m_buff[m_ptr].sended_size)
        {
            m_buff[m_ptr].msgInfo.size = 0;
            m_buff[m_ptr].sended_size  = 0;
            pMsgInfo = &m_buff[m_ptr].msgInfo;

            move_buffptr(m_ptr);

            --m_msg_count;
            return 1;
        }
    }

    return 0;
}


/* 丢弃缓冲区中所有消息，并返回被丢弃的消息的信息 */
int SendBuffer::discard_all_msg(SendMsgInfoPtrArray& msgInfo)
{
    int tmpptr = m_ptr;
    int tmp_msg_count = m_msg_count;

    for(int i = 0; i < m_msg_count; ++i)
    {
        msgInfo[i] = &m_buff[tmpptr].msgInfo;
        move_buffptr(tmpptr);
    }

    m_msg_count = 0;
    return tmp_msg_count;
}
#endif
