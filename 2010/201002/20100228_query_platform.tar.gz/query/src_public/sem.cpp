/*
* auther:lqb
* date:2010-05-05
*/

#include <errno.h>
#include <time.h>
#include <string.h>

#include"sem.h"

Csem::Csem():m_semid(-1), m_err(0)
{
//	memset(m_sbuf, 0, sizeof(m_sbuf));
}

Csem::Csem(const char* sem_file): m_semid(-1), m_err(0)
{
//	memset(m_sbuf, 0, sizeof(m_sbuf));
	create(sem_file);
}

Csem::~Csem()
{
	//destroy();
}

int Csem::create(const char* sem_file)
{
	key_t key = ftok(sem_file, 1);
	if(key_t(-1) == key)
	{
		m_err = TOCK_ERROR;
    	return -1;
	}

	m_semid = semget(key, BLOCK_CNT_MAX + 1, 0660|IPC_CREAT);
	if(m_semid < 0)
	{
		m_err = SEMGET_ERR;
    	return -1;
	}

    return init();
}

int Csem::attach(const char* sem_file)
{
	key_t key = ftok(sem_file, 1);
	if(key_t(-1) == key)
	{
		m_err = TOCK_ERROR;
    	return -1;
	}

	m_semid = semget(key, 0, 0);
	if(m_semid < 0)
	{
		m_err = SEMATTACH_ERR;
    	return -1;
	}

	return 0;
}


int Csem::init()
{
	if(m_semid < 0)
	{
		m_err = SEMID_ERR;
		return -1;
	}

	unsigned short array[BLOCK_CNT_MAX + 1];
	for(int i = 0; i < BLOCK_CNT_MAX + 1; ++i)
	{
	    array[i] = 1;
	}

	union semun arg;
	arg.val = 1;
	arg.ary = array;

	if(semctl(m_semid, BLOCK_CNT_MAX + 1, SETALL, arg) < 0)
	{
		m_err = SEMCTL_ERR;
    	return -1;
	}

	return 0;
}


bool Csem::is_exist(const char* sem_file){
	key_t key = ftok(sem_file, 1);
	if(key_t(-1) == key)
	{
    	return false;
	}

	m_semid = semget(key, 0, 0);
	if(m_semid < 0)
	{
    	return false;
	}

	m_semid = -1;

	return true;
}

void Csem::destroy()
{
	if(m_semid < 0)
	{
		m_err = SEMID_ERR;
		return;
	}

    union semun arg;
    memset(&arg, 0, sizeof(arg));
    semctl(m_semid, BLOCK_CNT_MAX + 1, IPC_RMID, arg);
}


int Csem::p(int index)
{
	if(m_semid < 0)
	{
		m_err = SEMID_ERR;
		return -1;
	}

	if(index < 0 || index >= BLOCK_CNT_MAX + 1)
	{
		m_err = INDEX_ERR;
		return -1;
	}

	struct sembuf tmpbuf;
	struct sembuf* pbuf = &tmpbuf;
	pbuf->sem_num = index;
	pbuf->sem_op  = -1;
	pbuf->sem_flg = IPC_NOWAIT;

	int ret = semop(m_semid, pbuf, 1);
	if(ret < 0)
	{
		m_err = errno;
	}

	return ret;
}

int Csem::p_wait(int index, int timeout)
{
	if(m_semid < 0)
	{
		m_err = SEMID_ERR;
		return -1;
	}

	if(index < 0 || index >= BLOCK_CNT_MAX + 1)
	{
		m_err = INDEX_ERR;
		return -1;
	}

	struct sembuf tmpbuf;
	struct sembuf* pbuf = &tmpbuf;
	pbuf->sem_num = index;
	pbuf->sem_op  = -1;
	pbuf->sem_flg = 0;

	struct timespec ts;
	ts.tv_sec = 0;
	ts.tv_nsec = timeout * 1000; //����Ϊ������

	int ret = -1;

    do{
	    ret= semtimedop(m_semid, pbuf, 1, &ts);
    }while(ret < 0 && errno == EINTR);

    if(ret < 0)
	{
		m_err = errno;
	}

	return ret;
}

int Csem::v(int index)
{
	if(m_semid < 0)
	{
		m_err = SEMID_ERR;
		return -1;
	}

	if(index < 0 || index >= BLOCK_CNT_MAX + 1)
	{
		m_err = INDEX_ERR;
		return -1;
	}

	struct sembuf tmpbuf;
	struct sembuf* pbuf = &tmpbuf;
	pbuf->sem_num = index;
	pbuf->sem_op  = 1;
	pbuf->sem_flg = IPC_NOWAIT;

	int ret = semop(m_semid, pbuf, 1);
	if(ret < 0)
	{
		m_err = errno;
	}

	return ret;
}

