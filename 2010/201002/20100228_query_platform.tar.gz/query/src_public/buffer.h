#ifndef __BUFFER_H__
#define __BUFFER_H__

/*
* date:2010-04-29
* auther: lqb
*/

#include"sem.h"
#include"share_mem.h"

#define BLOCK_CNT_MIN 2
#define BLOCK_CNT_MAX 16

class buffer
{
public:
	buffer();
	~buffer();

	int lock();
	int lock_wait(int timeout);
	int unlock();

	int get_data_size();
	int get_free_size();


	void clear();

	int get_head(char* dest, int len);
	int read(char* dest, int rlen);
	int write(const char* src, int wlen);

	int set_sem(Csem *p_sem);

	int attach_shm(share_mem*shm, int index);

	int clear_bufdata();

	const char* error() const;

    void set_write_ptr(int size);
    void set_read_ptr(int size);

private:

	int is_full() const;
	int is_empty() const;


//private:
public:
	char *m_base;

	int  m_buffsize;

	int m_read; //读指针
	int m_write; //写指针

	int m_index;

	int m_datasize;
	int m_freesize;
	share_mem* m_shm;
	block_header *m_head;
	//m_read和m_write都初始化为0，且m_write >= m_read，当m_write == m_read 时，buffer为空；
	//当m_write - m_read == m_buffsize 时，buffer满
	char m_errbuf[256];

	Csem *m_semaphore;	//信号灯
};

#endif
