#ifndef __BILL_QUERY_H__
#define __BILL_QUERY_H__
/*
*date:2011-05-18
*author:lqb
*/

#define QUERY_DEBUG(...)\
    R5_DEBUG(g_r5_plog, ("[query] " __VA_ARGS__))
#define QUERY_INFO(...)\
    R5_INFO(g_r5_plog, ("[query] " __VA_ARGS__))
#define QUERY_ERROR(...)\
    R5_ERROR(g_r5_plog, ("[query] " __VA_ARGS__))
#define QUERY_WARN(...)\
    R5_WARN(g_r5_plog, ("[query] " __VA_ARGS__))
#define QUERY_TRACE(...)\
    R5_TRACE(g_r5_plog, ("[query] " __VA_ARGS__))

#define PRO_DB_LEN 32

struct bill_conf{
    char db_host[PRO_DB_LEN + 1];
    char db_name[PRO_DB_LEN + 1];
    char db_username[PRO_DB_LEN + 1];
    char db_password[PRO_DB_LEN + 1];
    int db_port;
    int modulo_num;
};


struct table_name{
    char name[32];
};

class R5_Log;
struct query_protocol;
struct route_info;

extern "C" int initialize(const char* conf_file, R5_Log* plog);

extern "C" void db_heartbit();

extern "C" int destroy();

extern "C" int bill_query(const void* protocol, const void* route_result, void* bill, int* billlen);

int find_innodb_table(int begin, int end, int index, MYSQL* db);

int get_tables(query_protocol* protocol, route_info* route);

int query_bill(char* buf, int* len, query_protocol* protocol, route_info* route);

int connect_mysql(const char* connect_str);


struct request_message{
	char connect_str[64];
	char table_name[32];
	char sub_no[20];
	char start_time[20];
	char end_time[20];
};

#endif
