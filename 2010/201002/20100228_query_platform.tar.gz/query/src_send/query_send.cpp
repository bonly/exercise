/*
*
*
*/

#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/epoll.h>

//#include <map>

#include"query_send.h"
#include"query_type.h"
#include"cepoll.h"
#include"share_mem.h"
#include"buffer.h"
#include"tools.h"
#include"public_signal.h"
#include "hexdump.h"

//from base lib
#include"iniconfig.h"
//#include"sysinfo.h"
#include"r5api.h"

send_param g_param;
send_conf  g_conf;

//share_mem g_shm;
//Csem g_sem;

FDList g_fd[FD_SIZE];
int g_fdmap[FD_SIZE];
char *g_buf = 0;

R5_Log g_r5_log;
//int g_blcok_cnt = -1;

int g_exit = 0;


int read_arg(int argc, char* argv[])
{
	strncpy(g_param.exec_file, argv[0], sizeof(g_param.exec_file));

    int optch;
    extern char *optarg;
    const char optstring[] = "hvt:c:C:S:s:";

    while((optch = getopt(argc, argv, optstring)) != -1)
    {
        switch(optch)
        {
            case 'h':   /* 打印帮助信息 */
                usage();
                exit(0);

            case 'v':   /* 显示版本号 */
				show_version();
                exit(0);

			case 'C':
            case 'c':   /* 配置文件 */
                strcpy(g_param.conf_file, optarg);
                break;

            case 'S':
            case 's':  /* socket描述符*/
                g_param.sockfd = atoi(optarg);
                break;

            default:
                break;
        }
    }

    if('\0' == g_param.conf_file[0])
    {
    	usage();
    	return -1;
    }

	return 0;
}


int load_conf(bool is_reload)
{
	if(!is_reload)
	{
		memset(&g_conf, 0, sizeof(g_conf));
	}

    IniConfig config;
    if(config.open(g_param.conf_file) < 0)
    {
        printf("open %s failed:%s\n", g_param.conf_file, strerror(errno));
        return -1;
    }

	const char* comm = "COMM";


    /* 日志路径 */
    const char* log_path = config.getValue(comm, "LOG_PATH");
    if(log_path && strlen(log_path) != 0)
    {
        if(0 != path_string(log_path, g_conf.log_path, sizeof(g_conf.log_path)))
        {
            printf("read LOG_PATH item failed, configure file: '%s', LOG_PATH: '%s'.\n",
                   g_param.conf_file, log_path);
            return -1;
        }
    }
    else
    {
        printf("read LOG_PATH item failed, configure file:%s.\n", g_param.conf_file);
    	return -1;
    }


    /* 文件日志级别 */
    const char* file_level = config.getValue(comm, "LOG_LEVEL_FILE");
    if(file_level && strlen(file_level) != 0)
    {
    	g_conf.file_level = atoi(file_level);
    	if(g_conf.file_level < 0 || g_conf.file_level > 120)
    	{
    		printf("LOG_LEVEL_FILE = %d error! use default-----info level\n", g_conf.file_level);
    		g_conf.file_level = 40;
    	}
    }
    else
    {
    	printf("read LOG_LEVEL_FILE failed, use default-----info level\n");
    	g_conf.file_level = 40;
    }


    /* 终端日志级别 */
    const char* term_level = config.getValue(comm, "LOG_LEVEL_TERM");
    if(term_level && strlen(term_level) != 0)
    {
    	g_conf.term_level = atoi(term_level);
    	if(g_conf.term_level < 0 || g_conf.term_level > 120)
    	{
    		printf("LOG_LEVEL_TERM = %d error! use default-----info level\n", g_conf.term_level);
    		g_conf.term_level = 40;
    	}
    }
    else
    {
    	printf("read LOG_LEVEL_TERM failed, use default-----info level\n");
    	g_conf.term_level = 40;
    }

    //初始化日志
	INIT_LOG((&g_r5_log), g_conf.log_path, "query_send", g_conf.file_level,
             g_conf.term_level);

    /* 共享内存文件 */
    const char* shm = config.getValue(comm, "SHM_FILE");
    if(shm && strlen(shm) != 0)
    {
    	strncpy(g_conf.shm_file, shm, sizeof(g_conf.shm_file) - 1);
    }
    else
    {
    	printf("[%s:%d]read SHM_FILE failed, configure file:%s.\n", __FILE__, __LINE__, g_param.conf_file);
    	return -1;
    }

    /* 信号灯文件 */
    const char* sem = config.getValue(comm, "SEM_FILE");
    if(sem && strlen(sem) != 0)
    {
        char tmp[256] = {0};
        strncpy(g_conf.sem_file, sem, sizeof(g_conf.sem_file) - 1);

    }
    else
    {
        printf("read SEM_FILE failed, configure file:%s.\n", g_param.conf_file);
        return -1;
    }

    /*send buf size*/
    const char *send_buf_size = config.getValue(comm, "SEND_BUFF_SIZE");
    if(send_buf_size && strlen(send_buf_size) != 0)
    {
        g_conf.send_buf_size = atoi(send_buf_size);
        g_conf.send_buf_size *= 1024;
        if(g_conf.send_buf_size < 4096 || g_conf.send_buf_size > 16*1024*1024)
        {
            printf("send buf size too small ro too large.size = %dk\n", g_conf.send_buf_size);
            printf("set to default size:400k\n");
            g_conf.send_buf_size = 400*1024;
        }
    }
    else
    {
        printf("set send buff size to default:400k\n");
        g_conf.send_buf_size = 400*1024;
    }

   	//强制解锁时间 单位：毫秒
    const char* lock_time = config.getValue(comm, "LCOK_TIME");
    if(lock_time && strlen(lock_time) != 0)
    {
    	g_conf.lock_time = atoi(lock_time);
    	if(g_conf.lock_time < 0 || g_conf.lock_time > 1000){
    	    printf("lock_time's value valid, set to default 30ms\n");
    	    g_conf.lock_time = 30;
    	}
    }
    else
    {
        g_conf.lock_time = 30;
    }


    return 0;
}


void usage()
{
    printf("usage : %s [-c configure filename] [-s sockfd] [-e] [-h] [-v]\n", g_param.exec_file);
    printf("        -h show help, optional\n");
    printf("        -v show version, optional\n");
    printf("        -c configure filename, must\n");
    printf("        -s socketpair fd, must\n");
    printf("-----------------------------------------------\n");
    printf("example:\n");
    printf("%s -c ../etc/proxy.conf -s 4\n", g_param.exec_file);
}


void show_version()
{
#ifdef PROGRAM_VERSION
    printf("Program version:%s\n\n", PROGRAM_VERSION);
#else
    printf("No version\n");
#endif
}


int init(share_mem& mem, Csem& sem)
{
    /*连接共享内存*/
	if(mem.attach(g_conf.shm_file) < 0){
        SEND_ERROR("initial share memory failed, err = %d, file = %s\n",
            mem.error(), g_conf.shm_file);
		return -1;
	}

	shm_header *shm_header = mem.get_shm_header();
	int blcok_cnt = shm_header->block_cnt;
	if(blcok_cnt < BLOCK_CNT_MIN || blcok_cnt > BLOCK_CNT_MAX)
	{
	    SEND_ERROR("blcok_cnt error!cnt = %d\n", blcok_cnt);
	    return -1;
	}

	/*连接信号量*/
	if(sem.attach(g_conf.sem_file) < 0)	{
		SEND_ERROR("attach sem failed, err = %d, file = %s\n",
		    sem.error(), g_conf.sem_file);
		return -1;
	}

	//创建放数据包的缓冲区
	g_buf = (char*)malloc(1024*16);

	return 0;
}

//信号量注册
int register_signal()
{
    //退出
    if(my_signal(SIGTERM, Signal::SigTerm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM, strerror(errno));
        return -1;
    }

    //退出
    if(my_signal(SIGINT, Signal::SigTerm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGINT, strerror(errno));
        return -1;
    }

    //重读配置
    if(my_signal(SIGHUP, Signal::SigHup, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGHUP, strerror(errno));
        return -1;
    }

    //刷新日志
    if(my_signal(SIGUSR2, Signal::SigUsr2, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR2, strerror(errno));
        return -1;
    }

    /* ALARM中断应立即返回  */
    if(my_signal(SIGALRM, Signal::SigAlarm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGALRM, strerror(errno));
        return -1;
    }

    /* PIPE中断应该立即返回 */
    if(my_signal(SIGPIPE, Signal::SigPipe, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGPIPE, strerror(errno));
        return -1;
    }

    //忽略
    if(my_signal(SIGCHLD, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD, strerror(errno));
        return -1;
    }

    //忽略
    if(my_signal(SIGUSR1, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR1, strerror(errno));
        return -1;
    }

    return 0;
}

int accept_fd(int fd, int block_cnt, CEpoll* pep, share_mem& mem){

    char buf[32] = {0};
    int len = sizeof(buf);
    int newsock = -1;

    int ret = recv_fd(fd, buf, len, &newsock);
    if(ret < 0 || newsock < 0){
        int  err = errno;
        SEND_ERROR("recvfd failed.\n");
        //if(EAGAIN != err && EINTR != err){
            pep->delete_fd(fd);
        //}

        return -1;
    }


	//recv使用偶数编号的缓冲区

	int uid = atoi(buf);
	if(newsock >= FD_SIZE){
	    SEND_WARN("too many fd have connected!\n");
	    return -1;
	}

	static int index = 1;
	FDList& hfd = g_fd[newsock];
	hfd.buf_index = index;
	index += 2;
	index %= block_cnt;

	block_header* header = mem.m_pblock[hfd.buf_index].pheader;
	if(NULL == header){
	    SEND_INFO("get block_header failed, index = %d\n", hfd.buf_index);
	    return RE_FAILED;
	}

	if(0 == header->is_use){
	    header->is_use = 1;
	    header->type = NET_SEND;
    }

	hfd.unique_id = uid;
	hfd.user_con.status = Con::Connected;

    g_fdmap[uid] = newsock;

    SEND_INFO("receive fd success, fd = %d unique_id = %d\n", newsock, hfd.unique_id);

    return RE_SUCCESS;
}

int read_message(int index, buffer& buff, share_mem& mem){
    int ret = -1;
    ///上锁
    if(buff.lock() < 0){
        ///强制解锁判断
        if(1 != force_unlock(index, g_conf.lock_time, buff, mem)){
            //SEND_DEBUG("read buff %d locked!\n", nIndex);
            return 2;
        }

        if(buff.lock() < 0){
            //SEND_DEBUG("read buff %d locked!\n", nIndex);
            return 2;
        }
    }

    ///更新上锁时间
    gettimeofday((timeval * )&(mem.m_pblock[index].pheader->last_lock), 0);

    int nDataSize = buff.get_data_size();

    //数据小于消息头长度
    if(nDataSize < BLOCKLEN){
        if(buff.unlock()<0)
            SEND_ERROR("index %d unlock failed!\n", index);

        return 1;
    }

    /// 从缓冲区读取Block_Head,并从其size中读出对应长度的数据来发送
    Block_Head bh;
    ret = buff.get_head((char*)&bh, BLOCKLEN);
    if(ret != 0){
        if(buff.unlock()<0)
            SEND_ERROR("index %d unlock failed!\n", index);

        SEND_DEBUG("get_head index %d no message!\n", index);
        return 1;
    }
    //HexDump(all_head, PROTOCOL_HEAD_LEN+BLOCKLEN);

    if(bh.size < BLOCKLEN || bh.size > (4096+BLOCKLEN)){
        SEND_ERROR("msglen error! msglen = %d\n", bh.size);
        //跳过错误数据
        buff.set_read_ptr(bh.size);

        if(buff.unlock()<0)
            SEND_ERROR("index %d unlock failed!\n", index);

        if(bh.size == 0)
            sleep(1);

        return -1;
    }

    int uid = bh.index;  //atoi(tmp);
    SEND_DEBUG("unique_id = %d\n", uid);

    int fd = g_fdmap[uid];
    SEND_DEBUG("fd = %d\n", fd);
    if(fd <= 0){
        //网络连接异常，丢弃该报文
        buff.set_read_ptr(bh.size);

        if(buff.unlock()<0)
            SEND_ERROR("index %d unlock failed!\n", index);

        SEND_WARN("fd error! fd = %d\n", fd);
        return 1;
    }

    //获取socket的缓冲区
    Con& hcon = g_fd[fd].user_con;
    char* writeptr = hcon.cbuf.buffer.get_write_ptr();
    buff.set_read_ptr(BLOCKLEN); //跳过BLOCK_HEAD
    if((bh.size - BLOCKLEN) > buff.get_data_size()) //重定位
    {
        if(buff.unlock() < 0)
            SEND_ERROR("index %d unlock failed!\n", index);
        return 1;
    }
    //数据放入socket缓冲区
    ret = buff.read((char *)writeptr, bh.size - BLOCKLEN);
    if(ret < 0){
        if(buff.unlock() < 0)
            SEND_ERROR("index %d unlock failed!\n", index);

        SEND_INFO("read msg error! ret = %d\n", ret);
        return 1;
    }

    ///更新缓冲区读时间
    //gettimeofday(&(g_Smem.m_pblock[nIndex].pheader->read_time), 0);

    //重定位
    buff.set_read_ptr(bh.size - BLOCKLEN);
    buff.get_data_size();

    ///释放锁
    ret = buff.unlock();
    if(ret < 0)
         SEND_ERROR("index %d unlock failed!\n", index);

    hcon.cbuf.buffer.set_write_size(bh.size - BLOCKLEN);

    if(send_data(fd) < 0){
        SEND_WARN("send_data failed.\n");
        connection_info* ptr = mem.m_info[g_fd[fd].unique_id].pinfo;
        g_fdmap[ptr->unique_id] = 0;
        if(0 == ptr->status)
            ptr->status = 1;
    }


    if(LOG_CHECK_DEBUG(&g_r5_log)){
        //char*p = head;
        //SEND_DEBUG("send data:%s|%s|%s|%s\n", p, p + 10, p + 18, p + 26);
        SEND_DEBUG("send data:%s|%d|%d|%d\n", bh.ip, bh.port, bh.size, bh.index);
    }
}
/*
int read_message(int index, buffer& buff, share_mem& mem){
    int ret = -1;
    ///上锁
    if(buff.lock() < 0){
        ///强制解锁判断
        if(1 != force_unlock(index, g_conf.lock_time, buff, mem)){
            //SEND_DEBUG("read buff %d locked!\n", nIndex);
            return 2;
        }

        if(buff.lock() < 0){
            //SEND_DEBUG("read buff %d locked!\n", nIndex);
            return 2;
        }
    }

    ///更新上锁时间
    gettimeofday((timeval * )&(mem.m_pblock[index].pheader->last_lock), 0);

    int nDataSize = buff.get_data_size();

    //数据小于消息头长度
    if(nDataSize < BLOCKLEN){
        if(buff.unlock()<0)
            SEND_ERROR("index %d unlock failed!\n", index);

        return 1;
    }

    /// 从缓冲区读取Block_Head,并从其size中读出对应长度的数据来发送
    Block_Head bh;
    ret = buff.get_head((char*)&bh, BLOCKLEN);
    if(ret != 0){
        if(buff.unlock()<0)
            SEND_ERROR("index %d unlock failed!\n", index);

        SEND_DEBUG("get_head index %d no message!\n", index);
        return 1;
    }
    //HexDump(all_head, PROTOCOL_HEAD_LEN+BLOCKLEN);

    if(bh.size < BLOCKLEN || bh.size > 4096){
        SEND_ERROR("msglen error! msglen = %d\n", bh.size);
        //跳过错误数据
        buff.set_read_ptr(bh.size);

        if(buff.unlock()<0)
            SEND_ERROR("index %d unlock failed!\n", index);

        if(bh.size == 0)
            sleep(1);

        return -1;
    }

    int uid = bh.index;  //atoi(tmp);
    SEND_DEBUG("unique_id = %d\n", uid);

    int fd = g_fdmap[uid];
    SEND_DEBUG("fd = %d\n", fd);
    if(fd <= 0){
        //网络连接异常，丢弃该报文
        buff.set_read_ptr(bh.size);

        if(buff.unlock()<0)
            SEND_ERROR("index %d unlock failed!\n", index);

        SEND_WARN("fd error! fd = %d\n", fd);
        return 1;
    }

    //从共享内存中取应答包体放到发送区中
    Con& hcon = g_fd[fd].user_con;
    char* writeptr = hcon.cbuf.buffer.get_write_ptr();
    buff.set_read_ptr(BLOCKLEN); //跳过BLOCK_HEAD
    if((bh.size - BLOCKLEN) < buff.get_data_size()) //重定位
        return 1;
    ret = buff.read((char *)writeptr, bh.size - BLOCKLEN);
    if(ret < 0){
        if(buff.unlock() < 0)
            SEND_ERROR("index %d unlock failed!\n", index);

        SEND_INFO("read msg error! ret = %d\n", ret);
        return 1;
    }

    ///更新缓冲区读时间
    //gettimeofday(&(g_Smem.m_pblock[nIndex].pheader->read_time), 0);
    buff.set_read_ptr(bh.size - BLOCKLEN); //重定位
    ///释放锁
    ret = buff.unlock();
    if(ret < 0)
         SEND_ERROR("index %d unlock failed!\n", index);

    hcon.cbuf.buffer.set_write_size(bh.size - BLOCKLEN);

    if(send_data(fd) < 0){
        SEND_WARN("send_data failed.\n");
        connection_info* ptr = mem.m_info[g_fd[fd].unique_id].pinfo;
        g_fdmap[ptr->unique_id] = 0;
        if(0 == ptr->status)
            ptr->status = 1;
    }


    if(LOG_CHECK_DEBUG(&g_r5_log)){
        //char*p = head;
        //SEND_DEBUG("send data:%s|%s|%s|%s\n", p, p + 10, p + 18, p + 26);
        SEND_DEBUG("send data:%s|%d|%s|%s\n", bh.ip, bh.port, bh.size, bh.index);
    }
}
*/

//读取缓冲区里的数据
int send_data(int fd){
    Con& hcon = g_fd[fd].user_con;

	const char* readptr = hcon.cbuf.buffer.get_read_ptr();
    int size = hcon.cbuf.buffer.get_data_size();

	int ret = 0;
	while(1)
	{
		int slen = send(fd, readptr + ret, size - ret, 0);
		if(slen < 0)
		{
			if(errno == EINTR)
				continue;
			else if(errno == EAGAIN || errno == EWOULDBLOCK)
				break;
			else
			{
				int err = errno;
				SEND_WARN("send data error:[%d, %s]",  err, strerror(err));
				hcon.status = Con::Broken;
				g_fd[fd].type = 0;
				return -1;
			}
		}

		SEND_DEBUG("send data to socket len:%d\n",slen);
		HexDump((char*)readptr + ret, (size_t)slen);

		ret += slen;
		if(ret == size)
			break;
	}

	if(ret > 0){
		hcon.active_time = (int)time(NULL);
	    hcon.cbuf.buffer.set_read_size(ret);
	}

    SEND_DEBUG("in send_data, fd = %d datalen = %d\n", fd, ret);

	return ret;
}


int force_unlock(int index, int waittime, buffer& buff, share_mem& mem)
{
    if(index < 0 || waittime <= 0)
    {
        SEND_ERROR("force_unlock input param wrong!\n");
        return -1;
    }
    ///判断时间间隔
    struct timeval tp_local;
    gettimeofday(&tp_local, 0);
    struct timeval volatile *tp_past = &(mem.m_pblock[index].pheader->last_lock);
    //单位：毫秒
    int diff = (tp_local.tv_sec - tp_past->tv_sec)*1000 + (tp_local.tv_usec - tp_past->tv_usec)/1000;

    if( diff >= waittime)
    ///强制解锁
    {
        if(buff.unlock() < 0)
        {
            SEND_ERROR("nIndex %d force unlock failed!\n", index);
            return -1;
        }
        SEND_INFO("index %d unlock force, difftime %d, past time %d : %d, now time %d : %d!\n",\
         index, diff, tp_past->tv_sec, tp_past->tv_usec, tp_local.tv_sec, tp_local.tv_usec);
        return 1;
    }
    ///是否重置状态

    return 0;
}

/*
发送处理流程
*/
int send_process(share_mem& mem, Csem& sem)
{
    buffer buff[BLOCK_CNT_MAX];
    //CTcp tcp;

    //初始化epoll
	CEpoll* pepoll = new CEpoll(10, 10, 1/*毫秒*/);
    if(NULL == pepoll){
        SEND_ERROR("new epoll failed.\n")
        return RE_FAILED;
    }

	if(RE_SUCCESS != pepoll->init()){
		SEND_ERROR("poll init failed!\n");
		return RE_FAILED;
	}

	if(RE_SUCCESS != pepoll->add_fd(g_param.sockfd, EPOLLIN|EPOLLERR)) {
		SEND_ERROR("add socket fd to poll failed! fd = %d \n", g_param.sockfd);
		return RE_FAILED;
	}
	g_fd[g_param.sockfd].user_con.status = Con::Connected;

	//初始化缓冲区
    shm_header *header = mem.get_shm_header();
    if(NULL != header){
        for(int i = 0; i < header->block_cnt; ++i){
            if(buff[i].set_sem(&sem)<0){
                SEND_ERROR("buff set_sem failed!\n");
                return -1;
            }

            //连接对应缓冲块
            if(buff[i].attach_shm(&mem, i) < 0){
                SEND_ERROR("attach_shm %d failed!\n", i);
                return -1;
            }
        }
    }

    SEND_INFO("Program running!\n");

    vector<CEpoll::EpollEve> EV;
    while(1){
        if(g_exit)
            break;

        if(RE_SUCCESS != pepoll->wait(EV)){
            int err = errno;
			SEND_WARN("epoll failed,err:%s\n", strerror(err));

			if(Signal::HandleSignal() < 0)
            	return RE_FAILED;

        	if(err != EINTR)
        	    break;
        }

		vector<CEpoll::EpollEve>::iterator iter;
		for(iter = EV.begin(); iter != EV.end(); ++iter){
			if(iter->fd == g_param.sockfd){
				accept_fd(iter->fd, header->block_cnt, pepoll, mem);
			}
		}

		struct block_header *pblock=NULL;

		for(int i = 0; i < header->block_cnt; ++i){
		    pblock = mem.m_pblock[i].pheader;
		    if(pblock->type == NET_SEND){
		        read_message(i, buff[i], mem);
		    }
		}

        EV.clear();
        status_check(mem);
    }

    clear_socket(pepoll);

    if(NULL != pepoll){
        delete pepoll;
        pepoll = NULL;
    }

    return 0;
}

void status_check(share_mem& mem){
    for(int i = 0; i < FD_SIZE; ++i){
        connection_info* ptr = mem.m_info[i].pinfo;
        if(ptr->unique_id > 0 && ptr->status == 2){
            int fd = g_fdmap[ptr->unique_id];
            if(fd > 0){
                close(fd);
                g_fdmap[ptr->unique_id] = 0;
            }
            //这里不加锁，因为只有一个recv或send进程
            ptr->status = 3;

            SEND_WARN("close socket, unique_id = %d\n", ptr->unique_id);
        }
    }

}


void clear_socket(CEpoll * pep){
    for(int i = 0; i < FD_SIZE; ++i){
        if(g_fd[i].user_con.status != Con::Broken){
            close(i);
            g_fd[i].user_con.status = Con::Broken;
            g_fdmap[g_fd[i].unique_id] = 0;
        }
    }
}


int main(int argc, char* argv[])
{
//    bool abc=true;
//    while(abc)
//    {
//        sleep(5);
//    }
    if(read_arg(argc, argv) < 0){
        fprintf(stderr, "read args failed.\n");
        return -1;
    }

    if(load_conf() < 0){
        fprintf(stderr, "load configure failed.\n");
        return -1;
    }

    share_mem mem;
    Csem sem;

    if(init(mem, sem) < 0){
        fprintf(stderr, "init failed.\n");
        return -1;
    }

    if(register_signal() < 0){
        SEND_ERROR("register signal failed.\n");
        return -1;
    }

    send_process(mem, sem);

    mem.destroy();

    SEND_INFO("Program exit!\n");

    return 0;
}


int DoSigTerm(){
    SEND_WARN("interruptted by SIGTERM.\n");

    g_exit = 1;
    return 0;
}

int DoSigChild(){
    SEND_WARN("interruptted by SIGCHLD.\n");

    return 0;
}

int DoSigHup(){
    SEND_WARN("interruptted by SIGHUP.\n");

    return load_conf(true);
}

int DoSigUsr2(){
    SEND_WARN("interruptted by SIGUSR2.\n");

    g_r5_log.flush();
    return 0;
}


int DoSigAlarm(){
    SEND_WARN("interruptted by SIGALRM.\n");

    return 0;
}

int DoSigPipe(){
    SEND_WARN("interruptted by SIGPIPE.\n");

    return -1;
}

