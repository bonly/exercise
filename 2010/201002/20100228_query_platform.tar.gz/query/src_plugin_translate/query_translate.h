#ifndef __QUERY_TRANSLATE_H__
#define __QUERY_TRANSLATE_H__
/*
*date:2011-05-19
*author:lqb
*/

#define TRANS_DEBUG(...)\
    R5_DEBUG(g_r5_plog, ("[trans] " __VA_ARGS__))
#define TRANS_INFO(...)\
    R5_INFO(g_r5_plog, ("[trans] " __VA_ARGS__))
#define TRANS_ERROR(...)\
    R5_ERROR(g_r5_plog, ("[trans] " __VA_ARGS__))
#define TRANS_WARN(...)\
    R5_WARN(g_r5_plog, ("[trans] " __VA_ARGS__))
#define TRANS_TRACE(...)\
    R5_TRACE(g_r5_plog, ("[trans] " __VA_ARGS__))
    
#define MAX_FILE_LEN 256

#include "query_type.h"
#include "comm_structs.h"
class R5_Log;

extern "C" int initialize(const char* conf_file, R5_Log* plog);

extern "C" int destroy();

extern "C" int bill_translate(const char* inmsg, int inlen, const void* protocol, void* outmsg, int* outlen);

#include <map>
/// 语音类数据要转出的数据结构
struct TVoice
{
        char start_time[17 + 1]; /// 时间  9
        char Visit_Area[50 + 1]; ///通信地点  17
        char Communication_Mode[80 + 1]; ///通信方式
        char B_subno[24 + 1]; ///对方号码 18
        char duration[20 + 1]; ///通信时长  63
        char Communication_Type[28 + 1]; ///通信类型

        char fee[10]; ///实收费用

        ///套餐优惠
        ///优惠或减免
        char Mob_fee[8 + 1]; ///移动费 23
        char Toll_fee[8 + 1]; ///长途费 24
        char Inf_fee[8 + 1]; /// 信息费 25

        char bus_type[2 + 1]; ///通信业务类型  47
        char direct_type[1 + 1]; ///方向类型 51
        char subbus_type[2 + 1]; ///子业务类型  38

        char Bill_type[2 + 1]; ///帐单类型 19
        char carry_type[2 + 1]; ///承载类型 55

        char toll_type[1 + 1]; ///长途类型 54
        char roam_type[1 + 1]; ///漫游类型 53

};
struct translate_map
{
	 map<string, string> call;
	 map<string, string> prodid;
	 map<string, string> spname;
	 map<string, string> sp_code;
	 map<string, string>::iterator pcall;
	 map<string, string>::iterator pprodid;
	 map<string, string>::iterator pspname;
	 map<string, string>::iterator psp_code;
	
};



struct trans
{
	char translate_file[MAX_FILE_LEN + 1];	
};

struct translatemap
{
	char translatemap_file[MAX_FILE_LEN + 1];
  
};

#define PRO_DB_LEN 32
struct tansmap_conf{
    char db_host[PRO_DB_LEN + 1];
    char db_name[PRO_DB_LEN + 1];
    char db_username[PRO_DB_LEN + 1];
    char db_password[PRO_DB_LEN + 1];
    int  db_port;
};

extern "C" int Load_AreaData(const char* file_name);
int table_to_map(const char* connect_str);
#endif
