
// create by derek 20070507

#ifndef __R5_STRING_H__
#define __R5_STRING_H__

#include <vector>
#include <string>

using std::vector;
using std::string;
    
//-----------------------------------------------------------------------------
void trimLeft(char *item, char ch = ' ');
void trimRight(char *item, char ch = ' ');
    
//ȥ��ǰ��Ŀո��tab
void trim(char *item);

// cout = 0 �������е�ch, cout>0 ����cout��ch
void parser(const char *item, char ch, vector<string> &v, int cout=0);

#endif // __R5_STRING_H__
