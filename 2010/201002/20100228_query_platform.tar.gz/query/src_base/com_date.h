////////////////////////////////////////////
//com_date.h
//CCommonDate Class Header file
//created by tanjie 2007
///////////////////////////////////////////
#ifndef _CCOMMONDATE_H_
#define _CCOMMONDATE_H_
#include <time.h>
#include <string>
#include "base_constants.h"
#include "sqltypes.h"
#define CONV_1900_1970        2208988800UL 

extern BASE2_INT64 ts2l(TIMESTAMP_STRUCT &ts);

typedef unsigned int diam_tm; 
//typedef struct tm TIMESTAMP_STRUCT;
//

class CCommonDate
{
public:
    //constructions and destruction
    CCommonDate();
    CCommonDate(const tm &_date_tm);
    CCommonDate(int _year, int _month, int _date, int _hrs = 0, int _min = 0, int _sec = 0);
    CCommonDate(time_t _timestamp);
    CCommonDate(const CCommonDate &date);

    //delete by chensiwei 2008-11-17
    //����diameter ��ʱ��(��1900�꿪ʼ),�����ʱ��ת���ɱ�׼��1970 ���ʱ��(����time_t)
    //CCommonDate(const diam_tm _diam_tm);

    ~CCommonDate();
    
    int getYear();
    CCommonDate &setYear(int _year);
    
    int getMonth();
    CCommonDate &setMonth(int _month);
    
    int getDay();
    CCommonDate &setDay(int _day);
    
    int getHour();
    CCommonDate &setHour(int _hour);
    
    int getMinute();
    CCommonDate &setMinute(int _minute);
    
    int getSecond();
    CCommonDate &setSecond(int _second);
    
    int getWeekDay();
    
    CCommonDate &addYear(int _yearoffset);
    CCommonDate &addMonth(int _monthoffset);
    CCommonDate &addDay(int _dayoffset);
    CCommonDate &addHour(int _houroffset);
    CCommonDate &addMinute(int _minuteoffset);
    CCommonDate &addSecond(int _secondoffset);
    CCommonDate &addWeek(int _weekoffset);
    
    CCommonDate operator=(const CCommonDate &right);
    
    void getDayPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime);
    void getWeekPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime);
    void getTensdayPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime);
    void getMonthPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime);
    void getYearPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime);

    
    BASE2_INT64 getTimeStamp();
    
    //check if this class is valid
    bool isValid();
    
    //make this class valid using mktime()
    time_t validate();
    
    //mark this class invalid
    void invalidate();
    
    void getTimeString(char *_ochTimeStr);

    std::string getTimeString();

    bool isLeapYear(int _iYear);
    
    int getLastDayByMonth(int _iYear,int _iMonth);
    
    //������1900��������ʼ��ʱ��(diam_tm)
    diam_tm getDiamTimeStamp();
    
/**
 * ��������ʱ��Ϊ׼������ת����TimesTen �е�������
 * ������
 * sec   : ��������ʱ��Ϊ׼������
 * offset: ʱ��ƫ����
 */

void secondToTimestamp(TIMESTAMP_STRUCT *ts, time_t sec, time_t offset=0, int nTZ=8);   
BASE2_INT64 TimestampToCurrSecond (TIMESTAMP_STRUCT &ts);
BASE2_INT64 TimestampToSecond (TIMESTAMP_STRUCT &ts);

protected:
    struct tm m_datetm;
    bool m_bIsValid;
};  //end of CCommonDate



#endif

