/**
 *
 */

#include "cdr_log.h"

#define CDR_IO_BUFFER_SIZE 64*1024

CDRLog::CDRLog():m_pCdrLog(NULL), m_uLogSize(0), m_uLogCnt(0), m_nMaxSize(100000)
{
    //memset(m_sFullName, 0, MAX_PATH_LEN+MAX_NAME_LEN);
    memset(m_sWorkPath, 0, MAX_PATH_LEN);
    memset(m_sBakPath, 0, MAX_PATH_LEN);
    memset(m_sTargetPath, 0, MAX_PATH_LEN);
    memset(m_sPrefix, 0, MAX_PREFIX_LEN);
    memset(m_sFileName, 0, MAX_NAME_LEN);
    memset(&m_date, 0, sizeof(m_date));

    m_nSwitchTime = 0;
    m_nTimeInterval = 900;

    //char *pHome = getenv("OCS_HOME");
    //sprintf(m_sWorkPath,"%s/logs", pHome);

    strcpy(m_sPrefix, "CDR");

    time_t  t;
    struct  tm  tt;
    time(&t);

#ifdef SunOS
    memcpy(&tt, localtime(&t), sizeof(struct tm));
#else
    localtime_r(&t, &tt);
#endif

    memcpy(&m_date, &tt, sizeof(m_date));
}
int CDRLog::SetCdrHeader(const char *nm)
{
    //日志的文件名产生规则：XXXX_时间_进程号_计数.bin
    int len = strlen(nm);
    if(len == 0)
        return -1;

    if(m_pCdrLog != NULL)
        Close();

    strcpy(m_sPrefix, nm);

    return 0;
}

int CDRLog::SetWorkPath(const char *nm)
{
    int len = strlen(nm);
    if(len == 0)
        return -1;

    if(m_pCdrLog != NULL)
        Close();

    DIR_IS_EXIT(nm);

    strcpy(m_sWorkPath, nm);

    return 0;
}

int CDRLog::SetBakPath(const char *nm)
{
    int len = strlen(nm);
    if(len == 0)
        return -1;

    if(m_pCdrLog != NULL)
        Close();

    DIR_IS_EXIT(nm);

    strcpy(m_sBakPath, nm);

    return 0;
}

int CDRLog::SetTargetPath(const char *nm)
{
    int len = strlen(nm);
    if(len == 0)
        return -1;

    if(m_pCdrLog != NULL)
        Close();

    DIR_IS_EXIT(nm);

    strcpy(m_sTargetPath, nm);

    return 0;
}

int CDRLog::SetCdrSize(int size)
{
    if(m_pCdrLog != NULL)
        Close();

    m_nMaxSize = size;

    return 0;
}

int CDRLog::SetCdrTimeInterval(int interval)
{
    if(m_pCdrLog != NULL)
        Close();

    m_nTimeInterval = interval;

    return 0;
}

FILE *CDRLog::Open()
{
    if(m_pCdrLog != NULL)
        Close();

    time_t  t;
    struct  tm  tt;
    time(&t);

#ifdef SunOS
    memcpy(&tt, localtime(&t), sizeof(struct tm));
#else
    localtime_r(&t, &tt);
#endif

    //-------------------------------------------------------
    // add by chenliang
    /**
    if(m_date.tm_year!=tt.tm_year||m_date.tm_mon!=tt.tm_mon||m_date.tm_mday!=tt.tm_mday)
    {
        m_uLogCnt = 0;
        memcpy(&m_date, &tt, sizeof(m_date));
    }*/
    // 文件名中的时间为创建时间, 开始存储话单的时间
    memcpy(&m_date, &tt, sizeof(m_date));
    m_nSwitchTime = t;  // 设置上一次切换时间
    //-------------------------------------------------------

    if(strlen(m_sWorkPath) == 0 || strlen(m_sBakPath) == 0 || strlen(m_sTargetPath) == 0)
    {
        fprintf(stderr, "ERROR not set cdr path:%s,%s,%s.\n", m_sWorkPath, m_sBakPath, m_sTargetPath);
        //assert(false);
        return NULL;
    }

    snprintf(m_sFileName, MAX_NAME_LEN, "%s_%04d%02d%02d%02d%02d%02d_%d_%d.bin",
        m_sPrefix, m_date.tm_year+1900, m_date.tm_mon+1, m_date.tm_mday, m_date.tm_hour, m_date.tm_min, m_date.tm_sec, getpid(), m_uLogCnt);

    char name2[MAX_PATH_LEN+MAX_NAME_LEN] = {0};
    snprintf(name2, MAX_PATH_LEN+MAX_NAME_LEN, "%s/%s.tmp", m_sWorkPath, m_sFileName);

    m_pCdrLog = fopen(name2, "wb");
    static char szBuf[CDR_IO_BUFFER_SIZE+1];

    if(m_pCdrLog == NULL)
        fprintf(stderr, "ERROR Open [%s] cdr sFile\n", name2);
    else
        setvbuf(m_pCdrLog, szBuf, _IOFBF, CDR_IO_BUFFER_SIZE);

    m_uLogSize = 0;
    m_uLogCnt++;

    return m_pCdrLog;
}

void CDRLog::Close()
{
    if(m_pCdrLog != NULL)
    {
        fclose(m_pCdrLog);
        m_pCdrLog = NULL;

        char sOldPath[MAX_PATH_LEN+MAX_NAME_LEN] = {0};
        snprintf(sOldPath, MAX_PATH_LEN+MAX_NAME_LEN, "%s/%s.tmp", m_sWorkPath, m_sFileName);

        char sNewPath[MAX_PATH_LEN+MAX_NAME_LEN] = {0};
        snprintf(sNewPath, MAX_PATH_LEN, "%s/%04d%02d", m_sBakPath, m_date.tm_year+1900, m_date.tm_mon+1);
        if(access(sNewPath, F_OK) != 0)
        {
            mkdir(sNewPath, 0755);
        }
        
        snprintf(sNewPath, MAX_PATH_LEN, "%s/%02d", sNewPath, m_date.tm_mday);
        if(access(sNewPath, F_OK) != 0)
        {
            mkdir(sNewPath, 0755);
        }
        
        snprintf(sNewPath, MAX_PATH_LEN+MAX_NAME_LEN, "%s/%s", sNewPath, m_sFileName);

        rename(sOldPath, sNewPath);

        char name2[MAX_PATH_LEN+MAX_NAME_LEN] = {0};
        snprintf(name2, MAX_PATH_LEN+MAX_NAME_LEN, "%s/%s", m_sTargetPath, m_sFileName);
        link(sNewPath, name2);
    }

    m_uLogSize = 0;

    return;
}

// time：CDR会话开始时间
int CDRLog::Write(const void *ptr, int len) //写日志
{
    if(m_pCdrLog == NULL)//未打开文件
    {
        if(Open() == NULL)
            return -1;
    }
    else if(m_uLogSize>=m_nMaxSize)//CDR大小超过最大限制
    {
        Close();
        if(Open() == NULL)
            return -1;
    }

    //-------------------------------------------------------
    // 定时切换文件 add by chenliang
    // CDR时间与文件时间间隔大于切换间隔时间, 则需要切换
    time_t cdrTime;
    time(&cdrTime);
    if (cdrTime-m_nSwitchTime >= m_nTimeInterval)
    {
        Close();
        if(Open() == NULL)
            return -1;
    }
    //-----------------------------------------------------

    // 写cdr
    if(fwrite(ptr, len, 1, m_pCdrLog) != 1)
    {
        fprintf(stderr, "ERROR Write [%s/%s.tmp] cdr sFile\n", m_sWorkPath, m_sFileName);
        return -1;
    }

    m_uLogSize++;

    return 0;
}

// 刷新旧CDR文件并切换新cdr文件
int CDRLog::Flush()
{
    if(m_pCdrLog != NULL)
    {
        fflush(m_pCdrLog);
        
        //-------------------------------------------------------
        // 定时切换文件 add by chenliang
        // CDR时间与文件时间间隔大于切换间隔时间, 则需要切换
        time_t  t;
        time(&t);
        if (t-m_nSwitchTime >= m_nTimeInterval)
        {
            Close();
            if(Open() == NULL)
                return -1;
        }
    }
    return 0;
    //-----------------------------------------------------
}
