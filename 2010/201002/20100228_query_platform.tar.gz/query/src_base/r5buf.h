
// create by derek 20070420
// modify 20070507
// modify 20070518

#ifndef __R5_BUFFER_H__
#define __R5_BUFFER_H__

#include <string>
using std::string;
//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
class R5Buf
{
public:
    #define BASE_BUFFER_STEP 4
    
public:
    R5Buf():buf(0), buf_capacity(0), buf_size(0) { }
    
    R5Buf(int sz):buf_size(sz), buf_capacity((sz+4)/4*4)
    {        
        buf = new char[buf_capacity];
        memset(buf, 0 ,buf_capacity); 
    }
    
    inline R5Buf(const char* data, int sz):buf_size(sz), buf_capacity((sz+4)/4*4)
    {        
        buf = new char[buf_capacity];
        memcpy(buf, data, sz);
        buf[sz] = 0;
    }
    
    virtual ~R5Buf() { if (buf != 0) delete []buf; }

    char* resize(int sz) // ���뻺������������ԭ����
    {
        if ( sz>= buf_capacity)
        {
            if (sz<32) buf_capacity = 32;
            else buf_capacity = (sz+4)/4*4;
            char* _tmp = new char[buf_capacity];
            memset(_tmp, 0, buf_capacity);
            
            if ( buf != 0 )
            {
                memcpy(_tmp, buf, (sz>buf_size)?buf_size:sz);
                delete []buf;
            }
                
            buf = _tmp;
        }
        else if ( buf_capacity-1>sz*BASE_BUFFER_STEP && buf_capacity>32 )
        {
            if (sz<32) buf_capacity = 32;
            else buf_capacity = (sz+4)/4*4;
            char* _tmp = new char[buf_capacity];
            memset(_tmp, 0, buf_capacity);
            
            if ( buf != 0 )
            {
                memcpy(_tmp, buf, (sz>buf_size)?buf_size:sz);
                delete []buf;
            }
                
            buf = _tmp;
        }
        buf_size = sz;
        
        return buf;
    }
    
    inline char *get(int sz) // �����»����� �����ڴ���п�����
    {
        if ( sz>= buf_capacity)
        {
            if (sz<32) buf_capacity = 32;
            else buf_capacity = (sz+4)/4*4;
            char* _tmp = new char[buf_capacity];
            //memset(_tmp, 0, buf_capacity);
            
            if (buf != 0 ) delete []buf;
                
            buf = _tmp;
        }
        else if ( buf_capacity-1>sz*BASE_BUFFER_STEP && buf_capacity>32 )
        {
            if (sz<32) buf_capacity = 32;
            else buf_capacity = (sz+4)/4*4;
            char* _tmp = new char[buf_capacity];
            //memset(_tmp, 0, buf_capacity);
            
            if (buf != 0 ) delete []buf;
                
            buf = _tmp;
        }
        memset(buf, 0, buf_capacity);
        
        buf_size = sz;
        
        return buf;
    }

    inline void assign(const char *_data, int sz)
    {        
        memcpy(get(sz), _data, sz);
    }
    
    inline int capacity()const { return buf_capacity; }
    
    inline const char *c_str()const { return buf; }
    inline const char *data()const { return buf; }
    
    inline int size()const { return buf_size; }
        
public:
    inline R5Buf& operator= (const std::string &data)
    {        
        memcpy(get(data.size()), data.data(), data.size());
        
        return *this;
    }

    inline R5Buf& operator= (const char* data)
    {
        if (buf == data) return *this;
            
        int len = strlen(data);
        memcpy(get(len), data, len);
        
        return *this;
    }
    
    R5Buf& operator=(const R5Buf& right)
    {
        if (this == &right) return *this;
        
        memcpy(get(right.buf_size), right.buf, right.buf_size);
                
        return *this;
    }
    
private:
    char *buf;
    int buf_size;
    int buf_capacity;
};

#endif // __R5_BUFFER_H__
