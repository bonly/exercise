
// create by derek 20070410
// modify 20070428
// modify 20070429

#ifndef __R5_LOG__
#define __R5_LOG__

#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <unistd.h>
#include <string>
#include <assert.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <stdlib.h>
#include "log.h"

using namespace std;
// ��־�����ļ�����¼��
#define LOG_SIZE            1000000
// �ļ���������СĬ��ֵ����ʹ��setLogBuffer����
#define IO_BUFFER_SIZE      10*1024*1024
// ��־�ļ�����δ�С�������Զ��ύ
#define LOG_BUFFER_SIZE     1048576


// WIN32 Compatibility 
#ifdef _WIN32
#define vsnprintf _vsnprintf
#endif




// R5 Compatibility
#define r5_log_trace    log_trace
#define r5_log_debug    log_debug
#define r5_log_info     log_info
#define r5_log_warn     log_warn
#define r5_log_error    log_error
#define r5_log_fatal    log_fatal
#define r5_log_end      log_end

#define LOG_DIR_MODE        0755
#define ONE_DAY_SECONDS     86400

//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
class R5_Log
{
public:
    R5_Log ();
    virtual ~R5_Log();
public:
    // ������־ͷ����
    void setLogNameHead(const char *nm);
    // ������־��Ŀ¼
    void setLogSubDir(const char *dir);
    int logOpen();
    int logOpen(FILE * *log_fd, const char *name);
    void logOnlyClose();
    void logNormalClose();

    int setLogDir(const char *dir);
	int setErrLogDir(const char *dir);
    int setErrLoginfo(const char *errLogpath);
    int chkDir ( const char *dir );

    int log1(const char *format, ...); //д��־
    int log2(const char *format, ...); //д�ն�
	
	//modify by cyx 5-12
	int setLogBuffer(const char *size);
	int setSwitchTime(const char *swith_t);
	
    inline void setConditional(int le, int li, const char * f, bool bAutoWrap=false)
    {
        assert(le>=log_trace&&le<=log_end);
        level = le;
        line = li;
        file = f;
        m_bAutoWrap = bAutoWrap;
    }
    inline void setLevelClass(int le_fl, int le_tm)
    {
        level_file = le_fl;
        level_term = le_tm;
    }
    inline bool checkLevelFile(int le)
    {
        return le>=level_file;
    }
    inline  bool checkLevelTerm(int le)
    {
        return le>=level_term;
    }
    inline void setLoopFlag()
    {
//	    pro_loop_flag = bFlag;
    }

    void flush( bool bFlushInfo=true );

    //���ݾɽӿ�
    //bCommitNormal: true��ʾ�ύ����������־�ļ� false��ʾ�ύ��������־��
    //bWriteBoth: �����ļ����ύ
	int CommitLog(bool whocommit = true, bool wboth = false);
    //nCommitType 0--������־ 1--������־
    int CommitOnly ( int nCommitType );
    //�������������
	void ClearBuffer();
protected:
	void HandleOverBuffer(int nSizeCheck);
    int logFileName ();

protected:
    int line;
    const char* file;
    int level;
    int level_file;
    int level_term;
    bool m_bAutoWrap;
	
    FILE *os_log;
    FILE *os_err_log;
    
    unsigned int log_size; // log size
    unsigned int log_count; // log count
    char name[PATH_MAX];
    char prefix[128];
    char subdir[128];
    char fulldir[PATH_MAX];
    int  isdefalutpath;
    struct tm m_date;
    char *m_szBuf;    
    char *m_err_szBuf;
    
    bool m_IsErr;
    char errname[PATH_MAX];
    char errprefix[128];
    char errfulldir[PATH_MAX];
    
    char m_logBuf[LOG_BUFFER_SIZE];
    unsigned int m_log_realsize;
    
	//modify by cyx 5-15
    int m_nBufferSize;
    time_t m_nSwitchTime;

};

#endif //__R5_LOG__

