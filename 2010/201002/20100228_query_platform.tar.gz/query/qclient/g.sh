#!/bin/sh
let count=2
python my.list.py $count
c=0
while [ $c -lt $count ] ; do
time ./client -h 127.0.0.1 -p 30098 -l my$c.lst &
let c=$c+1
echo $c
done
sleep 5
rm my*.lst
