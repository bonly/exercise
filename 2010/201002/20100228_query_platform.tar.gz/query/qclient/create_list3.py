#!/usr/bin/python

import random

#try:
f=open('test3.lst', 'w')	

i = 0

while True:
	num=random.randint(13700000000, 13700800000)
	str=''
	str = '%d|20110510000000|20110630000000\n' % (num)	
	#print str
	f.write(str)
	i = i + 1

	if i == 100:
		break


#finally:
f.close()
#print line,
