#ifndef __PLUGIN_QUERY_H__
#define __PLUGIN_QUERY_H__

/*
*date:2011-05-09
*author:lqb
*/
class R5_Log;

int init_query(const char* conf_file, const char* lib_file, R5_Log* plog);

int query_initialize(const char* conf_file, R5_Log* plog);

int query_destroy();

int bill_query(const void* protocol, const void* route_result, void* bill, int* billlen);

#endif
