/*
*date:2011-05-09
*author:lqb
*/
#include <dlfcn.h>

#include "r5api.h"
#include "plugin_route.h"
#include "comm_structs.h"

extern R5_Log g_r5_log;

int (*p_route_initialize)(const char*, R5_Log*);

int (*p_route_destroy)();

int (*p_route_msg)(const char* sub_no, void* route_list, int cmdtype);

int (*p_route_heartbit)();


int init_route(const char* conf_file, const char* lib_file, R5_Log* plog){
    /// ���ض�̬��
    char *error = NULL;
    void *p_route = dlopen(lib_file , RTLD_LAZY);
    error=dlerror();
    if(p_route == NULL)
    {
        LOG_ERROR("open library %s failed\n error:%s\n" , lib_file, error);
        return -1;
    }
    dlerror();

    ///���غ���
    p_route_initialize = (int(*)(const char*, R5_Log*))::dlsym(p_route , "initialize");
    if ((error = dlerror()) != NULL)
    {
        ///����
        LOG_ERROR("load route_initialize fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();

    p_route_destroy = (int(*)())::dlsym(p_route, "destroy");
    if ((error = dlerror()) != NULL)
    {
        ///����
        LOG_ERROR("load route_destroy fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();

    p_route_msg = (int(*)(const char*, void*, int))::dlsym(p_route, "route_msg");
    if ((error = dlerror()) != NULL)
    {
        ///����
        LOG_ERROR("load route_msg fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();


    p_route_heartbit = (int(*)())::dlsym(p_route, "route_heartbit");
    if ((error = dlerror()) != NULL)
    {
        ///����
        LOG_ERROR("load route_heartbit fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();

    ///��̬���ʼ��
    int nRet = route_initialize(conf_file, plog);
    if(nRet < 0)
    {
        LOG_ERROR("route_initialize failed!\n");
        return -1;
    }

    return 0;
}

int route_initialize(const char* conf_file, R5_Log* plog){
    return p_route_initialize(conf_file, plog);
}

int route_destroy(){
    return p_route_destroy();
}

int route_msg(const char* sub_no, void* route_list, int cmdtype){
    return p_route_msg(sub_no, route_list, cmdtype);
}

int route_heartbit(){
    return p_route_heartbit();
}
