/*
*date:2011-05-10
*author:lqb
*/

#include "query_process.h"
#include "plugin_protocol.h"
#include "plugin_route.h"
#include "plugin_query.h"
#include "plugin_translate.h"
#include "query_type.h"
#include "share_mem.h"
#include "buffer.h"
#include "tools.h"
#include "public_signal.h"
#include "comm_structs.h"

//from base lib
#include"iniconfig.h"
#include"r5api.h"
#include "log_mgr.h"
#include "hexdump.h"

query_conf  g_conf;
struct query_param param;
char g_configure_file[MAX_FILE_LEN + 1];

//在使用tcmalloc的情况下，以下两个全局变量完全没有必要
char* g_billbuf = NULL; //最大查询条数为5w条，大约占内存25M
char* g_translated = NULL;
int g_billlen = 0;


R5_Log g_r5_log;
LogMgr g_logmgr;

int g_exit = 0;


int read_arg(int argc, char* argv[], struct query_param& param)
{
	strncpy(param.exec_file, argv[0], sizeof(param.exec_file));
	param.is_deamon = 1;

    int optch;
    extern char *optarg;
    const char optstring[] = "hvt:c:C:S:s:er:w:";

    while((optch = getopt(argc, argv, optstring)) != -1)
    {
        switch(optch)
        {
            case 'h':   /* 打印帮助信息 */
                usage(param);
                exit(0);

            case 'v':   /* 显示版本号 */
				show_version();
                exit(0);

			case 'C':
            case 'c':   /* 配置文件 */
                strcpy(param.conf_file, optarg);
                break;

            case 'e':
                param.is_deamon = 0;
                break;

                /*
            case 'r':
                param.readfd = atoi(optarg);
                break;

            case 'w':
                param.writefd = atoi(optarg);
                break;
                */

            default:
                break;
        }
    }

    if('\0' == param.conf_file[0]){
    	usage(param);
    	return -1;
    } else {
        strncpy(g_configure_file, param.conf_file, MAX_FILE_LEN);
        g_configure_file[strlen(param.conf_file)] = '\0';
    }

	return 0;
}


void usage(struct query_param& param)
{
    printf("usage : %s [-c configure filename] [-e] [-h] [-v]\n", param.exec_file);
    printf("        -h show help, optional\n");
    printf("        -v show version, optional\n");
    printf("        -c configure filename, MUST\n");
    printf("-----------------------------------------------\n");
    printf("example:\n");
    printf("%s -c ../etc/query_conf.conf\n", param.exec_file);
}


void show_version()
{
#ifdef PROGRAM_VERSION
    printf("Program version:%s\n\n", PROGRAM_VERSION);
#else
    printf("No version\n");
#endif
}


int load_conf(bool is_reload){

	if(!is_reload)
		memset(&g_conf, 0, sizeof(g_conf));

    IniConfig config;
    if(config.open(g_configure_file) < 0){
        printf("open %s failed:%s\n", g_configure_file, strerror(errno));
        return -1;
    }

	const char* comm = "COMM";


    /* 日志路径 */
    const char* log_path = config.getValue(comm, "LOG_PATH");
    if(log_path && strlen(log_path) != 0){
        if(0 != path_string(log_path, g_conf.log_path, sizeof(g_conf.log_path))){
            printf("read LOG_PATH item failed, configure file: '%s', LOG_PATH: '%s'.\n",
                   g_configure_file, log_path);
            return -1;
        }
    } else {
        printf("read LOG_PATH item failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }


    /* 文件日志级别 */
    const char* file_level = config.getValue(comm, "LOG_LEVEL_FILE");
    if(file_level && strlen(file_level) != 0){
    	g_conf.file_level = atoi(file_level);
    	if(g_conf.file_level < 0 || g_conf.file_level > 120){
    		printf("LOG_LEVEL_FILE = %d error! use default-----info level\n", g_conf.file_level);
    		g_conf.file_level = 40;
    	}
    } else {
    	printf("read LOG_LEVEL_FILE failed, use default-----info level\n");
    	g_conf.file_level = 40;
    }


    /* 终端日志级别 */
    const char* term_level = config.getValue(comm, "LOG_LEVEL_TERM");
    if(term_level && strlen(term_level) != 0){
    	g_conf.term_level = atoi(term_level);
    	if(g_conf.term_level < 0 || g_conf.term_level > 120){
    		printf("LOG_LEVEL_TERM = %d error! use default-----info level\n", g_conf.term_level);
    		g_conf.term_level = 40;
    	}
    } else {
    	printf("read LOG_LEVEL_TERM failed, use default-----info level\n");
    	g_conf.term_level = 40;
    }

	INIT_LOG((&g_r5_log), g_conf.log_path, "query_process", g_conf.file_level,
             g_conf.term_level);

    /* 共享内存文件 */
    const char* shm = config.getValue(comm, "SHM_FILE");
    if(shm && strlen(shm) != 0){
    	strncpy(g_conf.shm_file, shm, sizeof(g_conf.shm_file) - 1);
    } else {
    	printf("read SHM_FILE failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }

    /* 信号灯文件 */
    const char* sem = config.getValue(comm, "SEM_FILE");
    if(sem && strlen(sem) != 0) {
        char tmp[256] = {0};
        strncpy(g_conf.sem_file, sem, sizeof(g_conf.sem_file) - 1);

    } else {
        printf("read SEM_FILE failed, configure file:%s.\n", g_configure_file);
        return -1;
    }

//    //@todo 加载RECV的PIPE
//    strncpy(g_conf.recv_pipe, "/tmp/query_recv_pipe", sizeof(g_conf.recv_pipe));
//
//    //@todo 加载process的PIPE
//    strncpy(g_conf.local_pipe,"/tmp/process_pipe",sizeof(g_conf.recv_pipe));

    // 加载稽核日志的配置  WorkPath
    const char* lmgr_work = config.getValue(comm, "LMGR_WORK");
    if(lmgr_work && strlen(lmgr_work) != 0) {
        char tmp[256] = {0};
        strncpy(g_conf.lmgr_work, lmgr_work, sizeof(g_conf.lmgr_work) - 1);

    } else {
        printf("read LMGR_WORK failed, configure file:%s.\n", g_configure_file);
        return -1;
    }

    // 加载稽核日志的配置  BakPath
    const char* lmgr_bak = config.getValue(comm, "LMGR_BACK");
    if(lmgr_bak && strlen(lmgr_bak) != 0) {
        char tmp[256] = {0};
        strncpy(g_conf.lmgr_bak, lmgr_bak, sizeof(g_conf.lmgr_bak) - 1);

    } else {
        printf("read LMGR_BACK failed, configure file:%s.\n", g_configure_file);
        return -1;
    }

    // 加载稽核日志的配置  TargetPath
    const char* lmgr_target = config.getValue(comm, "LMGR_TARGET");
    if(lmgr_target && strlen(lmgr_target) != 0) {
        char tmp[256] = {0};
        strncpy(g_conf.lmgr_target, lmgr_target, sizeof(g_conf.lmgr_target) - 1);

    } else {
        printf("read LMGR_TARGET failed, configure file:%s.\n", g_configure_file);
        return -1;
    }

    // 加载稽核日志的配置  CdrHeader
    const char* lmgr_head = config.getValue(comm, "CDR_HEADER");
    if(lmgr_head && strlen(lmgr_head) != 0) {
        char tmp[256] = {0};
        strncpy(g_conf.lmgr_head, lmgr_head, sizeof(g_conf.lmgr_head) - 1);

    } else {
        printf("read CDR_HEADER failed, set as default:%s.\n", "qls.query.stat");
        strncpy(g_conf.lmgr_head, "qls.query.stat", sizeof(g_conf.lmgr_head));
    }

   	//强制解锁时间 单位：毫秒  默认30毫秒
    const char* lock_time = config.getValue(comm, "LCOK_TIME");
    if(lock_time && strlen(lock_time) != 0)
    {
    	g_conf.lock_time = atoi(lock_time);
    	if(g_conf.lock_time < 0 || g_conf.lock_time > 1000){
    	    printf("lock_time's value valid, set to default 30ms\n");
    	    g_conf.lock_time = 30;
    	}
    }
    else
    {
        g_conf.lock_time = 30;
    }

    /* 协议解析插件 */
    const char* protocol = config.getValue(comm, "PROTOCOL_FILE");
    if(protocol && strlen(protocol) != 0){
    	strncpy(g_conf.protocol_plugin, protocol, MAX_FILE_LEN);
    } else {
    	printf("read PROTOCOL_FILE failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }


   	/*路由插件*/
   	const char* route = config.getValue(comm, "ROUTE_FILE");
   	if(route && strlen(route) != 0){
   	    strncpy(g_conf.route_plugin, route, MAX_FILE_LEN);
   	} else {
   	    printf("read ROUTE_FILE failed, configure file:%s\n", g_configure_file);
   	    return -1;
   	}


   	/*查询插件*/
   	const char* query = config.getValue(comm, "QUERY_FILE");
   	if(query && strlen(query) != 0){
   	    strncpy(g_conf.query_plugin, query, MAX_FILE_LEN);
   	} else {
   	    printf("read QUERY_FILE failed, configure file:%s\n", g_configure_file);
   	    return -1;
   	}


   	/*业务处理插件*/
   	const char* trans = config.getValue(comm, "TRANSLATE_FILE");
   	if(trans && strlen(trans) != 0){
   	    strncpy(g_conf.translate_plugin, trans, MAX_FILE_LEN);
   	} else {
   	    printf("read TRANSLATE_FILE failed, configure file:%s\n", g_configure_file);
   	    return -1;
   	}

    return 0;
}


//信号量注册
int register_signal(){
    //退出
    if(my_signal(SIGTERM, Signal::SigTerm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM, strerror(errno));
        return -1;
    }

    //退出
    if(my_signal(SIGINT, Signal::SigTerm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGINT, strerror(errno));
        return -1;
    }

    //重读配置
    if(my_signal(SIGHUP, Signal::SigHup, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGHUP, strerror(errno));
        return -1;
    }

    //刷新日志
    if(my_signal(SIGUSR2, Signal::SigUsr2, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR2, strerror(errno));
        return -1;
    }

    /* 忽略  */
    if(my_signal(SIGALRM, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGALRM, strerror(errno));
        return -1;
    }

    /* 忽略 */
    if(my_signal(SIGPIPE, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGPIPE, strerror(errno));
        return -1;
    }

    //忽略
    if(my_signal(SIGCHLD, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD, strerror(errno));
        return -1;
    }

    //忽略
    if(my_signal(SIGUSR1, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR1, strerror(errno));
        return -1;
    }

    return 0;
}


int init(struct query_param& param, share_mem& mem, Csem& sem){
    /*连接共享内存*/
	if(mem.attach(g_conf.shm_file) < 0){
        LOG_ERROR("attach share memory failed, err = %d, file = %s\n",
            mem.error(), g_conf.shm_file);
		return -1;
	}

	/*连接信号量*/
	if(sem.attach(g_conf.sem_file) < 0){
		LOG_ERROR("attach sem failed, err = %d, file = %s\n",
		    sem.error(), g_conf.sem_file);
		return -1;
	}

//	//连接自己用的PIPE, 加上进程号  "/tmp/query_process_pipe"
//    umask(0);
//    pid_t pid=getpid();
//    char pipe_name[MAX_FILE_LEN + 1]="";
//    snprintf(pipe_name, sizeof(pipe_name),"%s_%d",g_conf.local_pipe,pid);
//    if (-1==(param.p_local = mkfifo(pipe_name, S_IRUSR|S_IWUSR|S_IRGRP | S_IWGRP)))
//    {
//        if (errno!=EEXIST)
//        {
//            LOG_ERROR("attach pipe fail: %s\n",strerror(errno));
//            perror("mkfifo");
//            return -1;
//        }
//    }
//    if(-1 == (param.p_local = open(pipe_name, O_RDONLY|O_NONBLOCK)))
//    {
//        LOG_ERROR("open local pipe fail: %s\n",strerror(errno));
//        perror("open");
//        return -1;
//    }

    //稽核日志
    g_logmgr.SetWorkPath(g_conf.lmgr_work);
    g_logmgr.SetBakPath(g_conf.lmgr_bak);
    g_logmgr.SetTargetPath(g_conf.lmgr_target);
    g_logmgr.SetCdrHeader(g_conf.lmgr_head);

//    //连接RECV的PIPE
//    param.p_recv = open(g_conf.recv_pipe, O_WRONLY|O_NONBLOCK);
//    if (param.p_recv == -1)
//    {
//        LOG_ERROR("open RECV fifo (%s) failure: %s\n",g_conf.recv_pipe,strerror(errno));
//        return -1;
//    }
//    //if(0>=write (param.p_recv, "hello", 6))
//    //    LOG_ERROR("send hello faild\n");

	/*初始化插件(动态库)*/
	if(init_protocol(param.conf_file, g_conf.protocol_plugin, &g_r5_log) < 0){
	    LOG_ERROR("initialize protocol lib failed, file = %s\n", g_conf.protocol_plugin);
	    return -1;
	}

	if(init_route(param.conf_file, g_conf.route_plugin, &g_r5_log) < 0){
	    LOG_ERROR("initialize route lib failed, file = %s\n", g_conf.route_plugin);
	    return -1;
	}

	if(init_query(param.conf_file, g_conf.query_plugin, &g_r5_log) < 0){
	    LOG_ERROR("initialize query lib failed, file = %s\n", g_conf.query_plugin);
	    return -1;
	}

	if(init_translate(param.conf_file, g_conf.translate_plugin, &g_r5_log) < 0){
	    LOG_ERROR("initialize translate lib failed, file = %s\n", g_conf.translate_plugin);
	    return -1;
	}

	g_billbuf = (char*)malloc(32*1024*1024);
	if(NULL == g_billbuf){
	    LOG_ERROR("malloc failed!\n");
	    return -1;
	}

	g_translated = (char*)malloc(16*1024*1024);
	if(NULL == g_translated){
	    LOG_ERROR("malloc failed!\n");
	    return -1;
	}

	return 0;
}


int read_message(int index, buffer& buff, share_mem& mem, char* msgbuf, int& outlen, Block_Head &bh){
    int ret = -1;
    ///上锁
    if(buff.lock() < 0){
        ///强制解锁判断
        if(1 != force_unlock(index, g_conf.lock_time, buff, mem)){
            //SEND_DEBUG("read buff %d locked!\n", nIndex);
            return 2;
        }

        if(buff.lock() < 0){
            LOG_DEBUG("read buff %d lock failed!\n", index);
            return 2;
        }
    }

    ///更新上锁时间
    gettimeofday((timeval * )&(mem.m_pblock[index].pheader->last_lock), 0);
    //LOG_DEBUG("read buff %d locked!\n", index);

    //sleep(1000);

    //LOG_DEBUG("readpos = %d writepos = %d\n", buff.m_read, buff.m_write);
    int datasize = buff.get_data_size();

    //LOG_DEBUG("datasize = %d\n", datasize);
    //LOG_DEBUG("get_data_size readpos = %d writepos = %d\n", buff.m_read, buff.m_write);

    //数据小于消息头长度
    if(datasize < PROTOCOL_HEAD_LEN){
        if(buff.unlock()<0)
            LOG_ERROR("index %d unlock failed!\n", index);

        return 1;
    }

    char all_head[512] = {0};
    ///从缓冲区读取消息头 + Block_Head
    ret = buff.get_head((char*)all_head, PROTOCOL_HEAD_LEN + sizeof(Block_Head));
    if(ret != 0){
        if(buff.unlock()<0)
            LOG_ERROR("index %d unlock failed!\n", index);

        LOG_DEBUG("get_head index %d no message!\n", index);
        return 1;
    }

    ///得到Block_Head
    memcpy (&bh, all_head, sizeof(Block_Head));

    ///得到包头
    char head[128] = {0};
    memcpy (head, all_head+sizeof(Block_Head), PROTOCOL_HEAD_LEN);

    ///从包头中得到消息包长度
    char tmp[16] = {0};
    memcpy(tmp, &(head[18]), 8);
    int msglen = atoi(tmp);

    if(msglen < PROTOCOL_HEAD_LEN || msglen > 4096){
        LOG_ERROR("msglen error, len = %d\n", msglen);
        //跳过错误数据
        buff.set_write_ptr(msglen+sizeof(Block_Head));

        if(buff.unlock()<0)
            LOG_ERROR("index %d unlock failed!\n", index);

        return -1;
    }

    //跳过block_head
    buff.set_read_ptr(sizeof(Block_Head));
    if(msglen < buff.get_data_size())
        return 1;

    //读取真正的消息包
    ret = buff.read((char *)msgbuf, msglen);
    if(ret < 0){
        if(buff.unlock() < 0)
            LOG_ERROR("index %d unlock failed!\n", index);

        //SEND_INFO(" message not enough to read, nIndex %d unlock \n", nIndex);
        return 1;
    }
    //HexDump((char *)msgbuf, msglen);

    buff.set_read_ptr(msglen);
    ///更新缓冲区读时间
    //gettimeofday(&(g_Smem.m_pblock[nIndex].pheader->read_time), 0);

    ///释放锁
    ret = buff.unlock();
    if(ret < 0)
         LOG_ERROR("index %d unlock failed!\n", index);

    //LOG_DEBUG("read buff %d UNlocked!\n", index);
    outlen = msglen;

    return 0;

}


int process_msg(share_mem& mem, Csem& sem, char* msgbuf, int msglen, char* response, int* resplen, Block_Head& bh){
    int ret = -1;
    route_info_list* proute = (route_info_list*)malloc(sizeof(route_info_list));
    query_protocol* pro = (query_protocol*)malloc(sizeof(query_protocol));

    if(NULL == proute || NULL == pro){
        LOG_ERROR("process_msg, malloc failed.\n");
        return -1;
    }

    memset(pro, 0, sizeof(query_protocol));

    //find_random_code(mem, sem, msgbuf, pro);
    find_random_code(mem, sem, bh.index, pro);


    proute->count = 0;

    *resplen = 0;

    do{
        //s1:协议解析
        ret = protocol_proc(msgbuf, msglen, (void*)pro, response, resplen);
        if(ret < 0){
            LOG_ERROR("protocol process failed!\n");
            break;
        }

        if(strcmp(pro->header.command, CMD_BIND_REQ) == 0){
            if(insert_random_code(mem, sem, pro, bh.index) < 0){
                LOG_ERROR("route msg failed.\n");
                create_response((void*)pro, response, resplen);
            }
        }

        LOG_DEBUG("result_code:%d\n", pro->result_code);

        if(0 != pro->result_code){
            clear_random_code(mem, sem, pro, bh.index);
        }

        if(*resplen > 0){
            //非查询请求，直接生成了回应报文
            LOG_DEBUG("resplen = %d\n", *resplen);
            break;
        }

        //取IP信息
        IP_MSG msg;
        //(pro->header.decompresslen); //该字段int(11)
        //get_ip_info(atoi(pro->header.decompresslen), msg);
        strncpy(msg.ip, bh.ip, sizeof(msg.ip));
        msg.port = bh.port;

        //s2:路由查询
        ret = route_msg(pro->sub_no, (void*)proute, 3);
        if(ret < 0){
            LOG_ERROR("route msg failed.\n");
            create_response((void*)pro, response, resplen);
            write_log (&msg, pro);
            break;
        }

        //s3:清单查询
        g_billlen = 32*1024*1024;
        ret = bill_query((void*)pro, (void*)proute, g_billbuf, &g_billlen);
        if(ret < 0){
            LOG_ERROR("bill query failed.\n");
            create_response((void*)pro, response, resplen);
            write_log (&msg, pro);
            break;
        }

        //s4:清单翻译
        int tranlen = 16*1024*1024;
        LOG_ERROR("begin bill translate.........\n");
        ret = bill_translate(g_billbuf, g_billlen, (void*)pro, g_translated, &tranlen);
        if(ret < 0){
            LOG_ERROR("bill translate failed,\n");
            create_response((void*)pro, response, resplen);
            write_log (&msg, pro);
            break;
        }

        //s5:对查询结果加密\拆分报文
        g_billlen = 0;
        ret = package_msg(g_translated, tranlen, (void*)pro, g_billbuf, &g_billlen);
        if(ret < 0){
            LOG_ERROR("bill translate back failed,\n");
            create_response((void*)pro, response, resplen);
            write_log (&msg, pro);
            break;
        }

        // @todo 输出稽核日志
        write_log (&msg, pro);
    }while(0);

    free(proute);
    free(pro);

    return ret;
}

int get_ip_info(int index, IP_MSG &msg)
{
    int ret = -1;

    /*
    //把协议头中的备用字段内的IP索引发到recv中查询其相关信息
    msg.client_pid = getpid();
    msg.index = index;
    if(0 >= (ret = write (param.p_recv, &msg, sizeof(IP_MSG))))
        return -1;


    //从本地管道中取回结果
    if(0 >= (ret = ReadTimeout (param.p_local, (char*)&msg, sizeof(IP_MSG), 3)))
    {
        return -1;
    }
*/
    return 0;
}

int ReadTimeout(int fd, char *pBuff, int nSize, int nTimeout)
{
    /// 放文件符到监控列表中
    fd_set socks;
    FD_ZERO(&socks);
    FD_SET(fd, &socks);

    // 当EINTER中断发生时结束;
    int nRet = 0;

    do
    {
        /// 设置超时时间
        struct timeval tv;
        tv.tv_sec  = nTimeout;
        tv.tv_usec = 0;

        nRet = select(fd+1, &socks, NULL, NULL, &tv);
        if (nRet > 0)
        {
            // 超时前接收到数据
            nRet = read(fd, pBuff, nSize);
        }
        else
        {
            // 超时了
        }
    } while (nRet == -1 && errno == EINTR);

    // FD_ZERO从fdset中清除所有的文件描述符
    FD_ZERO(&socks);

    return nRet;
}

int write_log(const IP_MSG* msg, const query_protocol* pro)
{
   char buf[255]="";
   snprintf(buf,sizeof(buf),"%s|%s|%s|%d|%s|%s|%s|%c|%d\n",
               pro->header.system, //帐号
               msg->ip,//用户连接IP
               pro->operator_id, //工号
               msg->port, //端口号
               pro->query_time, //用户查询时间
               pro->sub_no, //查询号码
               pro->begin_date, //查询时间
               pro->brand, //品牌
               pro->result_code //查询结果
   );

   return g_logmgr.Write(buf,strlen(buf));
}
int handle_msg(int index, buffer* pbuff, share_mem& mem, Csem& sem, char* response, int* resplen, int& cnt){
    int ret = -1;
    int msglen = 0;
    buffer& buff = pbuff[index];
    //采用google的tcmalloc库进行内存分配，提高性能 防止内存泄漏
    //char* buf = (char*)malloc(1024);
    char *buf = (char*)malloc(1024*4);
    //if(NULL == buf){
    //    LOG_ERROR("in handle_msg malloc failed.\n");
    //    return -1;
    //}

    Block_Head bh;
    ret = read_message(index, buff, mem, (char*)buf, msglen, bh);

    ///判断上述结果处理
    do{
        if(1 == ret){
            //无消息
            ret = 0;
            break;
        } else if(2 == ret) {
            //缓冲区被锁
            //LOG_DEBUG("buff %d index locked!\n", index);
            ret = 0;
            break;
        } else if(0 > ret) {
            LOG_ERROR("error happened on read buff %d\n", index);
            break;
        } else if(0 == ret){
            cnt++;
            ret = process_msg(mem, sem, buf, msglen, response, resplen, bh);
        }

        if(0 < *resplen){
            // 只有应答包则把BLOCK_HEAD 与数据应答包一起发回,并结束
            bh.size = *resplen + BLOCKLEN;
            LOG_DEBUG("resplen = %d, ret = %d\n", *resplen, ret);
            //HexDump((char*)response, (size_t)*resplen);

            send_data(index, pbuff, mem, response, *resplen, bh);
            break;
        }

        if(0 == ret){
            // 有处理数据,把BLOCK_HEAD 与数据结果包一起发回
            bh.size = g_billlen + BLOCKLEN;

            send_data(index, pbuff, mem, g_billbuf, g_billlen, bh);
            memset(g_billbuf, 0, g_billlen);
            break;
        }
    }while(0);
    free(buf);
    return ret;
}

int clear_random_code(share_mem& mem, Csem& sem, query_protocol* pro, int unique_id){
    //int unique_id = atoi(pro->header.decompresslen);
    if(unique_id < 0 || unique_id > FD_SIZE)
        return -1;

    connection_info* ptr = mem.m_info[unique_id].pinfo;
    if(ptr->unique_id > 0){
        //memset(ptr, 0, sizeof(connection_info));
        ptr->status = 1;
        LOG_DEBUG("clear random_code, fd = %d\n", unique_id);
    }

    return 0;
}


int insert_random_code(share_mem& mem, Csem& sem, query_protocol* pro, int index){
    int times = 0;
    for(int i = 0; i < FD_SIZE; ++i){
        connection_info* ptr = mem.m_info[i].pinfo;
        if(ptr->unique_id > 0 && strcmp(pro->header.system, ptr->system) == 0)
            times++;
    }

    if(times > 5){//5要求可配置
        pro->result_code = 1;
        return -2;
    }

    //int unique_id = atoi(pro->header.decompresslen);
    int unique_id = index;
    if(unique_id < 0 || unique_id > FD_SIZE)
        return -1;


    if(sem.p_wait(BLOCK_CNT_MAX, 20) < 0){
        //强制解锁
        sem.v(BLOCK_CNT_MAX);
    }

    connection_info* ptr = mem.m_info[unique_id].pinfo;
    if(ptr->unique_id <= 0){
        ptr->unique_id = unique_id;
        ptr->status = 0;
        memcpy(ptr->system, pro->header.system, PRO_SYSTEM_LEN);
        memcpy(ptr->random_code, pro->random_code, PRO_RANDOM_CODE_LEN);
        memcpy(ptr->login_time, pro->login_time, PRO_DATETIME_LEN);
        LOG_DEBUG("insert random_code:%s login_time:%s unique_id:%d\n", pro->random_code,
            pro->login_time, unique_id);
    }

    sem.v(BLOCK_CNT_MAX);

    return 0;
}

//int find_random_code(share_mem& mem, Csem& sem, const char* msgbuf, query_protocol* pro){
int find_random_code(share_mem& mem, Csem& sem, int unique_id, query_protocol* pro){
    LOG_DEBUG("in find_random_code\n");
    /*
    char tmp[PRO_DECOM_LEN + 1] = {0};
    memcpy(tmp, msgbuf + 49, PRO_DECOM_LEN);

    int unique_id = atoi(tmp);
    */

    LOG_DEBUG("unique_id:%d\n", unique_id);

    if(unique_id < 0 || unique_id > FD_SIZE)
        return -1;


    connection_info* ptr = mem.m_info[unique_id].pinfo;
    if(ptr->unique_id > 0){
        memcpy(pro->random_code, ptr->random_code, PRO_RANDOM_CODE_LEN);
        memcpy(pro->header.system, ptr->system, PRO_SYSTEM_LEN);
        memcpy(pro->login_time, ptr->login_time, PRO_DATETIME_LEN);

        LOG_DEBUG("find random_code:%s login_time:%s unique_id = %d\n", pro->random_code,
            pro->login_time, unique_id);
    }

    return 0;
}

int query_process(share_mem& mem, Csem& sem){
    buffer buff[BLOCK_CNT_MAX];
    //struct route_info_list route_list;
    //struct protocol stpro;
    char respbuf[256];
    int resplen = 0;

    int ret = -1;

	//初始化缓冲区
    shm_header *header = mem.get_shm_header();
    if(NULL != header){
        for(int i = 0; i < header->block_cnt; ++i){
            if(buff[i].set_sem(&sem)<0){
                LOG_ERROR("buff set_sem failed!\n");
                return -1;
            }

            //连接对应缓冲块
            if(buff[i].attach_shm(&mem, i) < 0){
                LOG_ERROR("attach_shm %d failed!\n", i);
                return -1;
            }
        }
    }

    LOG_INFO("Program running!\n");

    struct block_header *phead=NULL;
    int dealcnt = 0;
    while(!g_exit){
        for(int i = 0; i < header->block_cnt; i++){
            ///信号处理
            ret = Signal::HandleSignal();
            if(ret < 0){
                LOG_ERROR("HandleSignal failed!\n");
                return -1;
            }

            ///根据程序处理类型判断
            phead = mem.m_pblock[i].pheader;
            if(phead && NET_RECV != phead->type)
            {
                continue;
            }

            //LOG_DEBUG("type is %d\n", phead->type);

            ret = handle_msg(i, buff, mem, sem, respbuf, &resplen, dealcnt);
            if(ret < 0)
            {
                LOG_ERROR("Handle_Buf %d failed!\n", i);
                if(-1 == ret)
                {
                    LOG_ERROR("FATAL_ERROR, process exit!\n");
                    return ret;
                }
            }

            if(g_exit)
            {
                break;
            }

        }

        status_check(mem, sem);

        //路由心跳,如果超过一定的时间没有报文
        //路由模块主动发起心
        route_heartbit();

        if(0 == dealcnt)
            usleep(1);
        else
            dealcnt = 0;
    }

    return 0;
}


void status_check(share_mem& mem, Csem& sem){
    for(int i = 0; i < FD_SIZE; ++i){
        connection_info* ptr = mem.m_info[i].pinfo;
        if(ptr->unique_id > 0 && ptr->status == 3){
            LOG_DEBUG("status_check, clear unique_id = %d\n", ptr->unique_id);
            if(sem.p_wait(BLOCK_CNT_MAX, 30) < 0){
                //强制解锁
                sem.v(BLOCK_CNT_MAX);
            }
            memset(ptr, 0, sizeof(connection_info));
            sem.v(BLOCK_CNT_MAX);
        }
    }
}

int force_unlock(int index, int waittime, buffer& buff, share_mem& mem){
    if(index < 0 || waittime <= 0){
        LOG_ERROR("force_unlock input param wrong!\n");
        return -1;
    }
    ///判断时间间隔
    struct timeval tp_local;
    gettimeofday(&tp_local, 0);
    struct timeval volatile *tp_past = &(mem.m_pblock[index].pheader->last_lock);
    //单位：毫秒
    int diff = (tp_local.tv_sec - tp_past->tv_sec)*1000 + (tp_local.tv_usec - tp_past->tv_usec)/1000;

    if( diff >= waittime){
        ///强制解锁
        if(buff.unlock() < 0)
        {
            LOG_ERROR("nIndex %d force unlock failed!\n", index);
            return -1;
        }
        LOG_INFO("index %d unlock force, difftime %d, past time %d : %d, now time %d : %d!\n",\
         index, diff, tp_past->tv_sec, tp_past->tv_usec, tp_local.tv_sec, tp_local.tv_usec);
        return 1;
    }
    ///是否重置状态

    return 0;
}

int send_data(int index, buffer* pbuff, share_mem& mem, const char* data, int datalen, Block_Head &bh){

    if(datalen < PROTOCOL_HEAD_LEN){
        LOG_DEBUG("datalen: %d\n", datalen);
        return -1;
    }

    shm_header *memhead = mem.get_shm_header();
    int idx = (index + 1) % memhead->block_cnt;

    int need_send = datalen;
    char* psend = (char*)data;
    char *buf = (char*)malloc(4096+BLOCKLEN);
    while(need_send > 0){
        struct block_header *phead = mem.m_pblock[idx].pheader;

        if(phead && NET_SEND == phead->type){

            buffer& buff = pbuff[idx];

            if(buff.lock() < 0){
                ///强制解锁判断
                if(1 != force_unlock(idx, g_conf.lock_time, buff, mem))
                {
                    LOG_WARN("force unlock failed.\n");
                    idx += 2;
                    idx = idx % memhead->block_cnt;
                    continue;
                }

                if(buff.lock() < 0)
                {
                    LOG_DEBUG("read buff %d locked!\n", idx);
                    idx += 2;
                    idx = idx % memhead->block_cnt;
                    continue;
                }
            }

            ///更新上锁时间
            gettimeofday((timeval * )&(phead->last_lock), 0);

            int this_pack_len = (need_send<4096)?need_send:4096;
            int freesize = buff.get_free_size();
            if(freesize < this_pack_len){//缓冲区空间不够存放一个包
                buff.unlock();
                LOG_ERROR("buffer is full, index = %d\n", idx);
                free(buf);
                return -1;
            }

            // 加上block_head再发送,只发能放的入的长度
            Block_Head tmpbh = bh;
            tmpbh.size = this_pack_len + BLOCKLEN; //改长度
            memcpy (buf, &tmpbh, BLOCKLEN); //拷块头
            memcpy (buf + BLOCKLEN, psend, this_pack_len); //拷合适长度的包体

            buff.write(buf, tmpbh.size);
            buff.set_write_ptr(tmpbh.size);

            buff.unlock();

            LOG_DEBUG("send data success! index = %d len = %d\n", idx, tmpbh.size);
            HexDump((char*)buf, (size_t)tmpbh.size);
            psend += this_pack_len;
            need_send -= this_pack_len;
        }
    }
    free(buf);

    return 0;
}

/*
int send_data(int index, buffer* pbuff, share_mem& mem, const char* data, int datalen, Block_Head &bh){

    if(datalen < PROTOCOL_HEAD_LEN){
        LOG_DEBUG("datalen: %d\n", datalen);
        return -1;

    }

    shm_header *memhead = mem.get_shm_header();
    int idx = (index + 1) % memhead->block_cnt;

    while(1){
        struct block_header *phead = mem.m_pblock[idx].pheader;

        if(phead && NET_SEND == phead->type){

            buffer& buff = pbuff[idx];

            if(buff.lock() < 0){
                ///强制解锁判断
                if(1 != force_unlock(idx, g_conf.lock_time, buff, mem))
                {
                    LOG_WARN("force unlock failed.\n");
                    idx += 2;
                    idx = idx % memhead->block_cnt;
                    continue;
                }

                if(buff.lock() < 0)
                {
                    LOG_DEBUG("read buff %d locked!\n", idx);
                    idx += 2;
                    idx = idx % memhead->block_cnt;
                    continue;
                }
            }

            ///更新上锁时间
            gettimeofday((timeval * )&(phead->last_lock), 0);

            int freesize = buff.get_free_size();
            if(freesize < datalen){//缓冲区空间不够的情况还需要解决
                buff.unlock();
                LOG_ERROR("buffer is full, index = %d\n", idx);
                return -1;
            }

            // 加上block_head再发送
            char *buf = (char*)malloc(2048);
            memcpy (buf, &bh, BLOCKLEN);
            memcpy (buf+BLOCKLEN, data, datalen);
            printf("send data: \n");
            HexDump((char*)buf, (size_t)bh.size);
            buff.write(buf, bh.size);
            buff.set_write_ptr(bh.size);

            buff.unlock();
            free(buf);

            LOG_DEBUG("send data success! index = %d len = %d\n", idx, datalen);
            break;
        }

    }

    return 0;
}
*/

void exit(){

    //清理动态库
    pro_destory();

    route_destroy();

    query_destroy();

    tran_destroy();

    if(NULL != g_billbuf){
        free(g_billbuf);
        g_billbuf = NULL;
    }

    if(NULL != g_translated){
        free(g_translated);
        g_translated = NULL;
    }

    /*
    close(param.p_local);
    close(param.p_recv);

    pid_t pid=getpid();
    char pipe_name[MAX_FILE_LEN + 1]="";
    snprintf(pipe_name,sizeof(pipe_name),"%s_%d",g_conf.local_pipe,pid);
    unlink(pipe_name);
    unlink(g_conf.recv_pipe);
    */
    g_logmgr.Flush();
    g_logmgr.Close();

}



int main(int argc, char* argv[]){

    share_mem mem;
    Csem sem;

    memset(&param, 0, sizeof(param));
    if(read_arg(argc, argv, param) < 0){
        fprintf(stderr, "read arg failed.\n");
        return -1;
    }

    if(load_conf() < 0){
        fprintf(stderr, "load configure file failed.\n");
        return -1;
    }

    if(init(param, mem, sem) < 0){
        fprintf(stderr, "initialize failed.\n");
        return -1;
    }

    if(register_signal() < 0){
        LOG_ERROR("register signal failed.\n");
        return -1;
    }

    if(param.is_deamon)
        daemon(0, 0);

    query_process(mem, sem);

    exit();
    mem.destroy();
    LOG_INFO("Progran Exit!\n");
}



int DoSigTerm(){
    LOG_WARN("interruptted by SIGTERM.\n");

    g_exit = 1;
    return 0;
}

int DoSigChild(){
    LOG_WARN("interruptted by SIGCHLD.\n");

    return 0;
}

int DoSigHup(){
    LOG_WARN("interruptted by SIGHUP.\n");

    return load_conf(true);
}

int DoSigUsr2(){
    LOG_WARN("interruptted by SIGUSR2.\n");

    g_r5_log.flush();
    g_logmgr.Flush();
    return 0;
}

int DoSigAlarm(){
    LOG_WARN("interruptted by SIGALRM.\n");
    return 0;
}

int DoSigPipe(){
    LOG_WARN("interruptted by SIGPIPE.\n");
    return -1;
}

