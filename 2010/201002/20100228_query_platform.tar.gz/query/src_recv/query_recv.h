#ifndef __QUERY_RECV_H__
#define __QUERY_RECV_H__
/*
* date:2010-05-13
* author:lqb
*/

#include "query_type.h"

#define RECV_DEBUG(...)\
    R5_DEBUG((&g_r5_log), ("[recv] " __VA_ARGS__))
#define RECV_INFO(...)\
    R5_INFO((&g_r5_log), ("[recv] " __VA_ARGS__))
#define RECV_ERROR(...)\
    R5_ERROR((&g_r5_log), ("[recv] " __VA_ARGS__))
#define RECV_WARN(...)\
    R5_WARN((&g_r5_log), ("[recv] " __VA_ARGS__))
#define RECV_TRACE(...)\
    R5_TRACE((&g_r5_log), ("[recv] " __VA_ARGS__))


//#define MAX_CONNECTION 224
//#define PXY_BUF_SIZE 4096

struct recv_param
{
	char exec_file[MAX_FILE_LEN + 1];
	char conf_file[MAX_FILE_LEN + 1];
	int sockfd;  //父亲传的socketpair
    //int recv_pipe; //侦听用的pipe
    //int clientfd;  //客户连接的socket
};

struct recv_conf
{
	int file_level;
	int term_level;
	int recv_buf_size;
	int lock_time;
	char shm_file[MAX_FILE_LEN + 1];
	char sem_file[MAX_FILE_LEN + 1];
	char log_path[MAX_FILE_LEN + 1];
	//char pipe_file[MAX_FILE_LEN + 1];
};


class share_mem;
class buffer;
class Csem;
class CEpoll;

int read_arg(int argc, char* argv[], struct recv_param& param);

int load_conf(bool is_reload = false);

void usage(struct recv_param& param);

void show_version();

int init(struct recv_param& param, share_mem& mem, Csem& sem);

int register_signal();

int accept_fd(int fd, int block_cnt, CEpoll* pep, share_mem& mem);

int recv_data(int fd, share_mem& mem, buffer& buff);

int recv(int fd);

int process_message(int fd, share_mem& mem, buffer& buff);

int force_unlock(int index, int waittime, buffer& buff, share_mem& mem);

int recv_process(struct recv_param& param, share_mem& mem, Csem& sem);

void clear_socket(CEpoll * pep);

void status_check(share_mem& mem, CEpoll* pepoll);
void exit();
//int start_deal_process(struct proc_status& status);

#endif
