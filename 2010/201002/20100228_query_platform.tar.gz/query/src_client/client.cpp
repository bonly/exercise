/*
*
*
*/

#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include "hexdump.h"
#include "encrypt.h"

int Send(int fd, char* buf, int len);

struct stconf{
    char ip[20];
    char sub_no[20];
    char file_name[128];
    int port;
};

struct stnumber{
    char sub_no[20];
    char begin_time[16];
    char end_time[16];
};

struct stconf g_conf;

const char* const CMD_LOGIN_REQ = "000";
const char* const CMD_LOGIN_RSP = "000";

const char* const CMD_QUERY_REQ = "100";
const char* const CMD_QUERY_RSP = "200";

timeval query_tv;

int read_arg(int argc, char* argv[])
{
    memset(&g_conf, 0, sizeof(g_conf));
    int optch;
    extern char *optarg;
    const char optstring[] = "vt:p:P:h:H:e:n:N:L:l:";

    while((optch = getopt(argc, argv, optstring)) != -1)
    {
        switch(optch)
        {
            case 'v':   /* 显示版本号 */
                exit(0);

			case 'h':
            case 'H':   /* 配置文件 */
                strncpy(g_conf.ip, optarg, 19);
                break;

            case 'p':
            case 'P':
                g_conf.port = atoi(optarg);

            case 'n':
            case 'N':
                strncpy(g_conf.sub_no, optarg, 19);
                break;

            case 'L':
            case 'l':
                strncpy(g_conf.file_name, optarg, 128);
                break;

            default:
                break;
        }
    }


	return 0;
}


int connect_to_server(){

	struct sockaddr_in servaddr;

	int confd = socket(AF_INET, SOCK_STREAM, 0);
	if(confd < 0)
	{
		int iErrno = errno;
		printf("create server socket failed![%d, %s]", iErrno, strerror(iErrno));
		return -1;
	}

	memset(&servaddr, 0 , sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(g_conf.port);
	if (inet_pton(AF_INET, g_conf.ip, &servaddr.sin_addr) <= 0)
	{
		int iErrno = errno;
		printf("inet_pton failed![%d, %s]\n", iErrno, strerror(iErrno));
		close(confd);
		confd = 0;
		return -1;
	}

	if (connect(confd, (sockaddr *) &servaddr, sizeof(servaddr)) < 0)
	{
		int iErrno = errno;
		printf("connect failed![%d, %s]\n", iErrno, strerror(iErrno));
		close(confd);
		confd = 0;
		return -1;
	}

    return confd;
}

char *get_timestr(char *time14, time_t t)
{
	struct tm m;
	localtime_r(&t, &m);

	sprintf(time14, "%04d%02d%02d%02d%02d%02d",
			m.tm_year + 1900, m.tm_mon + 1, m.tm_mday,
			m.tm_hour, m.tm_min, m.tm_sec);

	return time14;
}


int login(char* buf, int& len){

    char tmp[64] = {0};
    const char* passwd = "12345";
    char* p = buf;
    char timestr[16];
    time_t time_now = time(NULL);

    get_timestr(timestr, time_now);

    int n = snprintf(tmp, sizeof(tmp), "DateTime=%s&RandomCode=1234567890", timestr);

    Encrypt::crypt(tmp, n, (char*)passwd, strlen(passwd));

    len = 60 + n;

    strncpy(p, CMD_LOGIN_REQ, 9);
    p += 10;

    strncpy(p, "0000000", 7);
    p +=  8;

    snprintf(p, 7, "%d", len);
    p += 8;

    strncpy(p, "ocs", 19);
    p += 20;

    *p = '1';
    p++;

    *p = '0';
    p++;

    *p = '0';
    p++;

    p += 11;

    memcpy(p, tmp, n);

    return 0;
}


int Recv(int fd, char* buf, int len){
    int ret = 0;
    if(len <= 0)
        return 0;

    while(1){
        int rlen = recv(fd, buf + ret, len - ret, 0);
        if(rlen == 0)
            return -1;

        if(rlen < 0 ){
            if(errno == EINTR)
                continue;
			else if(errno == EAGAIN || errno == EWOULDBLOCK)
				break;
			else
			{
				int iErrno = errno;
				printf("recv data error:[%d, %s]\n",  iErrno, strerror(iErrno));
				return 0;
			}
        }

        ret += rlen;
        if(ret == len)
            break;
    }

    printf("recv len = %d ret = %d:\n", len, ret);
    HexDump(buf,len);
    return ret;
}

int query_request(int fd, struct stnumber& number){
    char buf[512] = {0};
    char tmp[256] = {0};
    char* random_code = "1234567890";

    char* p = buf;
    char timestr[16] = {0};
    char timestr1[16] = {0};
    char timestr2[16] = {0};

    time_t time1 = time(NULL);

    get_timestr(timestr2, time1);

    int n = snprintf(tmp, sizeof(tmp), "SubNo=%s&BillPeriod=201105&CDRType=1&OperatorID=12345&SwitchFlag=1&District=2&Brand=A&BeginDate=%s&EndDate=%s&QueryTime=%s",
     number.sub_no, number.begin_time, number.end_time, timestr2);

    //printf("n = %d query str:%s\n", n, tmp);

    Encrypt::crypt(tmp, n, random_code, strlen(random_code));

    int len = 60 + n;

    strncpy(p, CMD_QUERY_REQ, 9);
    p += 10;

    strncpy(p, "0000000", 7);
    p +=  8;

    snprintf(p, 7, "%d", len);
    p += 8;

    strncpy(p, "ocs", 19);
    p += 20;

    *p = '1';
    p++;

    *p = '0';
    p++;

    *p = '0';
    p++;

    p += 11;

    memcpy(p, tmp, n);

    int ret = Send(fd, buf, len);
    if(ret < 0){
        printf("send failed.\n");
        return -1;
    }

    gettimeofday(&query_tv, NULL);
    printf("query time:%d:%06d, sub_no:%s\n", query_tv.tv_sec, query_tv.tv_usec, number.sub_no);


    return 0;
}


int query_response(int fd, struct stnumber& number){

    char header[64] = {0};
    char buffer[10240] = {0};
    char* random_code = "1234567890";
    char *bigbuf = (char*)malloc(32*10240);
    memset(bigbuf, 0, 32*10240);	 
    char *big = (char*)bigbuf;

    int flag = 1;
    int j = 0;
    timeval tv;

    int sum = 0;
    while(1){
        int ret = Recv(fd, header, 60);
        if(ret < 0){
            printf("recv failed.\n");
            return -1;
        }

        char* p = header + 18;
        char tmp2[16];
        memcpy(tmp2, p, 8);

        int len = atoi(tmp2);
        sum = len;

        if(flag){
            flag = 0;

            //gettimeofday(&tv, NULL);
            //printf("response time:%d:%06d\n", tv.tv_sec, tv.tv_usec);
        }

        if(len < 60){
            printf("len error. len = %d\n", len);
            return -1;
        } else if(len == 60){
	        //printf("len == 60\n");
	        break;
        }




        len -= 60;
        int rlen = 0;
        while(len > 0){
            if(len > sizeof(buffer))
                rlen = sizeof(buffer);
            else
                rlen = len;
            len -= rlen;

            //memset(buffer, 0, sizeof(buffer));
            ret = Recv(fd, buffer, rlen);
            if(ret < 0){
                printf("recv failed.\n");
                return -1;
            }

            memcpy(big, buffer, rlen);
            big += rlen;
            //p = buffer;

            //Encrypt::crypt(p, len - 60, random_code, strlen(random_code));

        }
        //printf("bill count:%d\n", j);
        HexDump(bigbuf,sum);
        p = header + 48;
        if(*p == '0')
            break;
    }

gettimeofday(&tv, NULL);

    //计算有多少条话单
    char *str1;
    char *str2;

    for (str1 = bigbuf; ; j++, str1 = NULL) {
        str2 = strtok(str1, "\n");
        if (str2 == NULL)
            break;
    }

    int usec = 0;
    int sec = 0;
    if(tv.tv_usec >= query_tv.tv_usec)
        usec = tv.tv_usec - query_tv.tv_usec;
    else{
        tv.tv_sec -= 1;
        usec = tv.tv_usec + 1000000 - query_tv.tv_usec;
    }

    sec = tv.tv_sec - query_tv.tv_sec;

    printf("sub_no: %s  bill_count: %4d  query_time: %2d.%06d s\n", number.sub_no, j, sec, usec);

    if(usec == 0 && sec == 0)
        printf("begin:%d.%06d  end:%d.%06d\n", query_tv.tv_sec, query_tv.tv_usec, tv.tv_sec, tv.tv_usec);


    if(bigbuf)
        free(bigbuf);

    return 0;
}



int Send(int fd, char* buf, int len)
{
    printf("Send:\n");
    HexDump(buf,len);
	int ret = 0;
	if(len <= 0)
		return 0;

	while(1)
	{
		int slen = send(fd, buf+ret, len-ret,  0);
		if(slen < 0)
		{
			if(errno == EINTR)
				continue;
			else if(errno == EAGAIN || errno == EWOULDBLOCK)
				break;
			else
			{
				int iErrno = errno;
				printf("send data error:[%d, %s]\n",  iErrno, strerror(iErrno));
				return 0;
			}
		}

		ret += slen;
		if(ret == len)
			break;
	}
	//printf("send len = %d\n", ret);

	return ret;
}


int fill_number(stnumber& number, char* line){
    //sub_no
	char * p = strtok(line, "|");
	strncpy(number.sub_no, p, sizeof(number.sub_no));

	//biegn_time
	p = strtok(NULL, "|");
	strncpy(number.begin_time, p, sizeof(number.begin_time));

    //end_time
	p = strtok(NULL, "|");
	strncpy(number.end_time, p, sizeof(number.end_time));

	return 0;
}

int main(int argc, char* argv[]){

    int ret = 0;
    read_arg(argc, argv);

    int fd = connect_to_server();
    if(fd < 0){
        printf("fd error!\n");
        return -1;
    }

    char buffer[1024] = {0};
    int length = 0;

    login(buffer, length);

    ret = Send(fd, buffer, length);
    if(ret < 0){
        printf("send failed.\n");
        return -1;
    }

    ret = Recv(fd, buffer, 60);
    if(ret < 0){
        printf("recv failed.\n");
        return -1;
    }

    char* p = buffer + 18;
    char tmp[16];
    memcpy(tmp, p, 8);

    int len = atoi(tmp);

    if(len < 60){
        printf("len error. len = %d\n", len);
        return -1;
    }

    ret = Recv(fd, buffer + 60, len - 60);
    if(ret < 0){
        printf("recv failed.\n");
        return -1;
    }

    FILE* fp = fopen(g_conf.file_name, "r");
    if(NULL == fp){
        printf("open file failed, err = %s\n", strerror(errno));
        return -1;
    }
    char line[128] = {0};
    struct stnumber number;
    while(1){
		memset(line, 0, sizeof(line));

		// 从清单文件中顺序读入记录
		if (fgets(line, sizeof(line), fp) == NULL)
			break;

        fill_number(number, line);

        if(query_request(fd, number) < 0)
            return -1;

        if(query_response(fd, number) < 0)
            return -1;

	}

    sleep(10);

    return 0;
}


