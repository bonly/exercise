#!/bin/sh
ps -ef|grep query |awk '{print $2}'|xargs kill 

