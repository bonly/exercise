#ifndef __ENCRYPT_H
#define __ENCRYPT_H



class Encrypt {
	public:
		Encrypt(void);
		~Encrypt(void);

		/**
		 * @brief  加密、解密
		 * @param inp 需要加密、解密的数据
		 * @param inplen 数据长度
		 * @param key 密码
		 * @param keylen 密码长度
		 */
		static void crypt(char *inp, int inplen, char* key = "", int keylen = 0);
};

#endif
