/*
*date:2011-05-05
*author:lqb
*/

#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/epoll.h>

#include"query_recv.h"
#include"type.h"
#include"cepoll.h"
#include"share_mem.h"
#include"buffer.h"
#include"tools.h"
#include"public_signal.h"
#include"net_buffer.h"

//from base lib
#include"iniconfig.h"
#include"r5api.h"

#include "comm_structs.h"
#include "encrypt.h"

recv_param g_param;
recv_conf  g_conf;
CEpoll* pepoll = NULL;
char g_configure_file[MAX_FILE_LEN + 1];

R5_Log g_r5_log;

int g_exit = 0;

FDList g_fd[FD_SIZE];
int g_fdmap[FD_SIZE];


int read_arg(int argc, char* argv[], struct recv_param& param)
{
	strncpy(param.exec_file, argv[0], sizeof(param.exec_file));

    int optch;
    extern char *optarg;
    const char optstring[] = "hvt:c:C:S:s:";

    while((optch = getopt(argc, argv, optstring)) != -1)
    {
        switch(optch)
        {
            case 'h':   /* 打印帮助信息 */
                usage(param);
                exit(0);

            case 'v':   /* 显示版本号 */
				show_version();
                exit(0);

			case 'C':
            case 'c':   /* 配置文件 */
                strcpy(param.conf_file, optarg);
                break;

            case 'S':
            case 's':  /* socket描述符*/
                param.sockfd = atoi(optarg);
                break;

            default:
                break;
        }
    }

    if('\0' == param.conf_file[0]){
    	usage(param);
    	return -1;
    } else {
        strncpy(g_configure_file, param.conf_file, MAX_FILE_LEN);
        g_configure_file[strlen(param.conf_file)] = '\0';
    }


	return 0;
}


int load_conf(bool is_reload){
	if(!is_reload)
		memset(&g_conf, 0, sizeof(g_conf));


    IniConfig config;
    if(config.open(g_configure_file) < 0){
        printf("open %s failed:%s\n", g_configure_file, strerror(errno));
        return -1;
    }

	const char* comm = "COMM";


    /* 日志路径 */
    const char* log_path = config.getValue(comm, "LOG_PATH");
    if(log_path && strlen(log_path) != 0){
        if(0 != path_string(log_path, g_conf.log_path, sizeof(g_conf.log_path))){
            printf("read LOG_PATH item failed, configure file: '%s', LOG_PATH: '%s'.\n",
                   g_configure_file, log_path);
            return -1;
        }
    } else {
        printf("read LOG_PATH item failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }


    /* 文件日志级别 */
    const char* file_level = config.getValue(comm, "LOG_LEVEL_FILE");
    if(file_level && strlen(file_level) != 0){
    	g_conf.file_level = atoi(file_level);
    	if(g_conf.file_level < 0 || g_conf.file_level > 120){
    		printf("LOG_LEVEL_FILE = %d error! use default-----info level\n", g_conf.file_level);
    		g_conf.file_level = 40;
    	}
    } else {
    	printf("read LOG_LEVEL_FILE failed, use default-----info level\n");
    	g_conf.file_level = 40;
    }


    /* 终端日志级别 */
    const char* term_level = config.getValue(comm, "LOG_LEVEL_TERM");
    if(term_level && strlen(term_level) != 0){
    	g_conf.term_level = atoi(term_level);
    	if(g_conf.term_level < 0 || g_conf.term_level > 120){
    		printf("LOG_LEVEL_TERM = %d error! use default-----info level\n", g_conf.term_level);
    		g_conf.term_level = 40;
    	}
    } else {
    	printf("read LOG_LEVEL_TERM failed, use default-----info level\n");
    	g_conf.term_level = 40;
    }

    //初始化日志
	INIT_LOG((&g_r5_log), g_conf.log_path, "query_recv", g_conf.file_level,
             g_conf.term_level);


    RECV_INFO("LOG_LEVEL_FILE:%d LOG_LEVEL_TERM =%d\n", g_conf.file_level, g_conf.term_level);

    /* 共享内存文件 */
    const char* shm = config.getValue(comm, "SHM_FILE");
    if(shm && strlen(shm) != 0){
    	strncpy(g_conf.shm_file, shm, sizeof(g_conf.shm_file) - 1);
    } else {
    	printf("read SHM_FILE failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }

    //@todo 加载接收地址查询的PIPE
    strncpy(g_conf.pipe_file, "/tmp/query_recv_pipe", sizeof(g_conf.pipe_file));

    /* 信号灯文件 */
    const char* sem = config.getValue(comm, "SEM_FILE");
    if(sem && strlen(sem) != 0) {
        char tmp[256] = {0};
        strncpy(g_conf.sem_file, sem, sizeof(g_conf.sem_file) - 1);

    } else {
        printf("read SEM_FILE failed, configure file:%s.\n", g_configure_file);
        return -1;
    }

   	/*recv  buf size*/
   	const char *recv_buf_size = config.getValue(comm, "RECV_BUFF_SIZE");
   	if(recv_buf_size && 0 != strlen(recv_buf_size)) {
        g_conf.recv_buf_size = atoi(recv_buf_size);
        g_conf.recv_buf_size *= 1024;
        if(g_conf.recv_buf_size < 4096 || g_conf.recv_buf_size > 16*1024*1024) {
            printf("recv buf size too small ro too large.size = %d\n", g_conf.recv_buf_size);
            printf("set to default size:10k\n");
            g_conf.recv_buf_size = 10*1024;
        }
   	} else {
        printf("set recv buff size to default:10k\n");
        g_conf.recv_buf_size = 10*1024;
   	}

   	//强制解锁时间 单位：毫秒  默认30毫秒
    const char* lock_time = config.getValue(comm, "LCOK_TIME");
    if(lock_time && strlen(lock_time) != 0)
    {
    	g_conf.lock_time = atoi(lock_time);
    	if(g_conf.lock_time < 0 || g_conf.lock_time > 1000){
    	    printf("lock_time's value valid, set to default 30ms\n");
    	    g_conf.lock_time = 30;
    	}
    }
    else
    {
        g_conf.lock_time = 30;
    }

    return 0;
}


void usage(struct recv_param& param)
{
    printf("usage : %s [-c configure filename] [-s sockfd] [-h] [-v]\n", param.exec_file);
    printf("        -h show help, optional\n");
    printf("        -v show version, optional\n");
    printf("        -c configure filename, must\n");
    printf("        -s socketpair fd, must\n");
    printf("-----------------------------------------------\n");
    printf("example:\n");
    printf("%s -c ../etc/query_conf.conf -s 4\n", param.exec_file);
}


void show_version()
{
#ifdef PROGRAM_VERSION
    printf("Program version:%s\n\n", PROGRAM_VERSION);
#else
    printf("No version\n");
#endif
}


int init(struct recv_param& param, share_mem& mem, Csem& sem){
    /*连接共享内存*/
	if(mem.attach(g_conf.shm_file) < 0){
        RECV_ERROR("attach share memory failed, err = %d, file = %s\n",
            mem.error(), g_conf.shm_file);
		return -1;
	}


	/*连接信号量*/
	if(sem.attach(g_conf.sem_file) < 0){
		RECV_ERROR("attach sem failed, err = %d, file = %s\n",
		    sem.error(), g_conf.sem_file);

		return -1;
	}

    //初始化epoll
    pepoll = new CEpoll(10, 10, 10/*毫秒*/);
    if(NULL == pepoll){
        RECV_ERROR("new epoll failed.\n")
        return RE_FAILED;
    }

    if(RE_SUCCESS != pepoll->init()){
        RECV_ERROR("poll init failed!\n");
        return RE_FAILED;
    }

    //连接管道  "/tmp/query_recv_pipe"
    umask(0);
    //if (-1==(g_param.recv_pipe = mkfifo(g_conf.pipe_file, S_IRUSR|S_IWUSR|S_IRGRP | S_IWGRP)))
    if (-1==(g_param.recv_pipe = mkfifo(g_conf.pipe_file, 0777)))
    {
        if (errno!=EEXIST)
        {
            RECV_ERROR("create pipe fail: %s\n",strerror(errno));
            perror("mkfifo");
            return -1;
        }
    }
    if(-1 == (g_param.recv_pipe = open(g_conf.pipe_file, O_RDONLY|O_NONBLOCK)))
    {
        RECV_ERROR("open pipe fail: %s\n",strerror(errno));
        perror("open");
        return -1;
    }

    if(RE_SUCCESS != pepoll->add_fd(g_param.recv_pipe, EPOLLIN|EPOLLET|EPOLLERR)) {
        RECV_ERROR("add recv pipe to poll failed! fd = %d \n", g_param.recv_pipe);
        return RE_FAILED;
    }
    g_fd[g_param.recv_pipe].user_con.status = Con::Connected;

	return 0;
}

//信号量注册
int register_signal(){
    //退出
    if(my_signal(SIGTERM, Signal::SigTerm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM, strerror(errno));
        return -1;
    }

    //退出
    if(my_signal(SIGINT, Signal::SigTerm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGINT, strerror(errno));
        return -1;
    }

    //重读配置
    if(my_signal(SIGHUP, Signal::SigHup, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGHUP, strerror(errno));
        return -1;
    }

    //刷新日志
    if(my_signal(SIGUSR2, Signal::SigUsr2, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR2, strerror(errno));
        return -1;
    }

    /* ALARM中断应立即返回  */
    if(my_signal(SIGALRM, Signal::SigAlarm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGALRM, strerror(errno));
        return -1;
    }

    /* PIPE中断应该立即返回 */
    if(my_signal(SIGPIPE, Signal::SigPipe, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGPIPE, strerror(errno));
        return -1;
    }

    //忽略
    if(my_signal(SIGCHLD, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD, strerror(errno));
        return -1;
    }

    //忽略
    if(my_signal(SIGUSR1, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR1, strerror(errno));
        return -1;
    }

    return 0;
}

int accept_fd(int fd, int block_cnt, CEpoll* pep, share_mem& mem){

    char buf[32] = {0};
    int len = sizeof(buf);
    int newsock = -1;

    int ret = recv_fd(fd, buf, len, &newsock);
    if(ret < 0 || newsock < 0){
        int  err = errno;
        RECV_ERROR("recvfd failed.\n");
        //if(EAGAIN != err && EINTR != err){
            pep->delete_fd(fd);
        //}

        return -1;
    }

	if(RE_SUCCESS != pep->add_fd(newsock, EPOLLIN|EPOLLET|EPOLLERR)) {
		RECV_ERROR("add newsock to poll failed! fd = %d \n", newsock);
		return RE_FAILED;
	}

	if(newsock >= FD_SIZE){
	    RECV_ERROR("too many socket connected.\n");
	    return RE_FAILED;
	}


	//recv使用偶数编号的缓冲区
	static int index = 0;
	FDList& hfd = g_fd[newsock];
	hfd.buf_index = index;
	index += 2;
	index %= block_cnt;

	block_header* header = mem.m_pblock[hfd.buf_index].pheader;
	if(NULL == header){
	    RECV_INFO("get block_header failed, index = %d\n", hfd.buf_index);
	    return RE_FAILED;
	}

	if(0 == header->is_use){
	    header->is_use = 1;
	    header->type = NET_RECV;
    }

	hfd.unique_id = atoi(buf);
	hfd.user_con.status = Con::Connected;

    g_fdmap[hfd.unique_id] = newsock;

	RECV_INFO("receive fd success! fd = %d, unique_id = %d index = %d\n", newsock, hfd.unique_id, hfd.buf_index);

    return RE_SUCCESS;
}


int recv_data(int fd, share_mem& mem, buffer& buff){

    RECV_DEBUG("IN recv_data!\n");

	Con& hcon = g_fd[fd].user_con;

	if(hcon.cbuf.is_deny == true)
		return RE_FAILED;

	if(recv(fd) < 0)
		return RE_FAILED;

	while(1){
		int ret = process_message(fd, mem, buff);
		if(ret == RE_FAILED){
			//消息头长度错误,断开连接
			hcon.status = Con::Broken;
			return RE_FAILED;
		} else if(ret == 1){
			//没有消息处理
			break;
		}
	}

	return RE_SUCCESS;
}


int recv(int fd)
{
    RECV_DEBUG("IN recv!\n");

    Con& hcon = g_fd[fd].user_con;

	char* writeptr = hcon.cbuf.buffer.get_write_ptr();
    int size = hcon.cbuf.buffer.get_free_size();

	int rlen = 0;

	rlen = recv(fd, writeptr , size, 0);
	if(rlen ==0)
	{
		//对方断开连接
		hcon.status = Con::Broken;
		RECV_ERROR("recv data from client len=%d \n", rlen);
		return RE_FAILED;
	}
	else if(rlen < 0)
	{
		RECV_WARN("recv data from client len=%d \n", rlen);
		return RE_FAILED;
	}

	/// 重新计算接收缓冲区大小
    hcon.cbuf.buffer.set_write_size(rlen);

	RECV_DEBUG("in recv [fd=%d]data datalen=%d\n", fd, rlen);

	if(rlen > 0)
	{
		hcon.active_time = time(NULL);
	}

	return rlen;
}

int process_message(int fd, share_mem& mem, buffer& buff){
	Con& hcon = g_fd[fd].user_con;
	int index = g_fd[fd].buf_index;
	//g_param.clientfd = fd;

    //缓冲区的长度
    int data_size = hcon.cbuf.buffer.get_data_size();

    /* 消息头的长度字段未读出 */
    if(26 > data_size)
        return 1;

    const char* readptr = hcon.cbuf.buffer.get_read_ptr();
    char tmp[8] = {0};
    memcpy(tmp, readptr + 18, 8);
    int len = atoi(tmp);

    RECV_DEBUG("msglen = %d, fd = %d index = %d\n", len, fd, index);


    /* 消息的长度不合法 */
    if(PRO_HEAD_LEN > len || len > MAX_MSG_LENGHT){
        RECV_ERROR("Invalid message size %d\n", len);
        return RE_FAILED;
    }

    if(data_size >= len)   {
        /* 缓冲区中已经有一条完整的消息 */
        RECV_DEBUG("have one intact message! unique_id = %d\n", g_fd[fd].unique_id);

        int free_size = buff.get_free_size();
        if(free_size < len){
            RECV_ERROR("buffer is full,index = %d\n", index);
            return -2;
        }

        /// 保留字段用于存放socket的index
        snprintf((char*)readptr + 49, 11, "%d", g_fd[fd].unique_id);

        protocol_head head;
        protocol_head* header = &head;
        header = (protocol_head*)readptr;


        if(buff.lock() < 0){
            ///强制解锁判断
            if(1 != force_unlock(index, g_conf.lock_time * 100, buff, mem))
            {
                RECV_WARN("force_unlock failed! index = %d\n", index);
                return 2;
            }

            if(buff.lock() < 0)
            {
                RECV_DEBUG("read buff %d locked!\n", index);
                return 2;
            }
        }

        ///更新上锁时间
        gettimeofday((timeval * )&(mem.m_pblock[index].pheader->last_lock), 0);

        buff.write(readptr, len);
        buff.set_write_ptr(len);

        buff.unlock();

        RECV_DEBUG("write one message to buffer success!\n");

        hcon.cbuf.buffer.set_read_size(len);  /* 重新计算接收缓冲区大小 */
    }

    return RE_SUCCESS;
}


int force_unlock(int index, int waittime, buffer& buff, share_mem& mem)
{
    if(index < 0 || waittime <= 0)
    {
        RECV_ERROR("force_unlock input param wrong!\n");
        return -1;
    }
    ///判断时间间隔
    struct timeval tp_local;
    gettimeofday(&tp_local, 0);
    struct timeval volatile *tp_past = &(mem.m_pblock[index].pheader->last_lock);
    //单位：毫秒
    int diff = (tp_local.tv_sec - tp_past->tv_sec)*1000 + (tp_local.tv_usec - tp_past->tv_usec)/1000;

    if( diff >= waittime)
    ///强制解锁
    {
        if(buff.unlock() < 0)
        {
            RECV_ERROR("nIndex %d force unlock failed!\n", index);
            return -1;
        }
        RECV_INFO("index %d unlock force, difftime %d, past time %d : %d, now time %d : %d!\n",\
         index, diff, tp_past->tv_sec, tp_past->tv_usec, tp_local.tv_sec, tp_local.tv_usec);
        return 1;
    }
    ///是否重置状态

    return 0;
}



//接收处理流程
int recv_process(struct recv_param& param, share_mem& mem, Csem& sem)
{
    RECV_DEBUG();

    buffer buff[BLOCK_CNT_MAX];
    //CTcp tcp;

	if(RE_SUCCESS != pepoll->add_fd(param.sockfd, EPOLLIN|EPOLLET|EPOLLERR)) {
		RECV_ERROR("add socket fd to poll failed! fd = %d \n", param.sockfd);
		return RE_FAILED;
	}
	g_fd[param.sockfd].user_con.status = Con::Connected;

	//初始化缓冲区
    shm_header *header = mem.get_shm_header();
    if(NULL != header){
        for(int i = 0; i < header->block_cnt; ++i){
            if(buff[i].set_sem(&sem)<0){
                RECV_ERROR("buff set_sem failed!\n");
                return -1;
            }

            //连接对应缓冲块
            if(buff[i].attach_shm(&mem, i) < 0){
                RECV_ERROR("attach_shm %d failed!\n", i);
                return -1;
            }
        }
    }

    RECV_INFO("Program running!\n");

    vector<CEpoll::EpollEve> EV;

    while(1)
    {
        if(g_exit)
            break;

        if(RE_SUCCESS != pepoll->wait(EV)){
            int err = errno;
			RECV_WARN("epoll failed,err:%s\n", strerror(err));

			if(Signal::HandleSignal() < 0)
            	return RE_FAILED;

        	if(err != EINTR)
        	    break;
        }

        //RECV_DEBUG("EV.size() = %d\n", EV.size());

		vector<CEpoll::EpollEve>::iterator iter; 
		for(iter = EV.begin(); iter != EV.end(); ++iter){

		    RECV_DEBUG("EV.fd = %d\n", iter->fd);

			if(iter->fd == param.sockfd)  //父亲传进的socketpair
			{
                accept_fd(param.sockfd, header->block_cnt, pepoll, mem);
                IP_MSG msg;
                if (0 >= read(param.sockfd, &msg, sizeof(IP_MSG)))
                {
                    RECV_ERROR("recv IP info faild\n");
                }
                else
                {
                    g_fd[g_fdmap[msg.index]].port = msg.port;
                    strncpy(g_fd[g_fdmap[msg.index]].ip, msg.ip, sizeof(IP_MSG::ip));
                }
                RECV_ERROR("client info: %s:%d\n", g_fd[g_fdmap[msg.index]].ip, g_fd[g_fdmap[msg.index]].port);
			}
			else if(iter->fd == param.recv_pipe) //侦听process处理的pipe
			{
			    IP_MSG msg;
			    char ipbuf[255]="";
                read(param.recv_pipe, &msg, sizeof(msg));
                RECV_ERROR("recv from %d: %d\n", msg.client_pid, msg.index);
                snprintf(ipbuf, sizeof(ipbuf), "%s_%d", "/tmp/process_pipe",msg.client_pid);
                int back_pipe = open(ipbuf, O_WRONLY|O_NONBLOCK);
                if (back_pipe <= 0)
                {
                    RECV_ERROR("process pipe not open: %d\n", msg.client_pid);
                }

                strncpy(msg.ip, g_fd[g_fdmap[msg.index]].ip, sizeof(msg.ip));
                msg.port = g_fd[g_fdmap[msg.index]].port;
                if (0 >= write(back_pipe, &msg, sizeof(IP_MSG)))
                {
                    RECV_ERROR("send ip back to process %d fail!\n", msg.client_pid);
                }
			}
			else  //网络连接的socket
			{
                FDList& hfd = g_fd[iter->fd];
                if(iter->events & EPOLLIN)
                {
                    recv_data(iter->fd, mem, buff[hfd.buf_index]);
                }

                if(iter->events & EPOLLERR || hfd.user_con.status == Con::Broken){
                    pepoll->delete_fd(iter->fd);
                    connection_info* ptr = mem.m_info[g_fd[iter->fd].unique_id].pinfo;
                    g_fdmap[ptr->unique_id] = 0;
                    if(0 == ptr->status)
                        ptr->status = 1;

                    RECV_WARN("socket error! fd = %d\n", iter->fd);
                }
			}
		}

        EV.clear();
        status_check(mem, pepoll);
    }

    clear_socket(pepoll);

    if(NULL != pepoll){
        delete pepoll;
        pepoll = NULL;
    }

    return 0;
}

void status_check(share_mem& mem, CEpoll* pepoll){
    for(int i = 0; i < FD_SIZE; ++i){
        connection_info* ptr = mem.m_info[i].pinfo;
        if(ptr->unique_id > 0 && ptr->status == 1){
            int fd = g_fdmap[ptr->unique_id];
            if(fd > 0){
                pepoll->delete_fd(fd);
                close(fd);
                g_fdmap[ptr->unique_id] = 0;
            }
            //这里不加锁，因为只有一个recv或send进程
            ptr->status = 2;

            RECV_WARN("close socket, unique_id = %d\n", ptr->unique_id);
        }
    }
}

void clear_socket(CEpoll * pep){
    for(int i = 0; i < FD_SIZE; ++i){
        if(g_fd[i].user_con.status != Con::Broken){
            pep->delete_fd(i);
            close(i);
            g_fd[i].user_con.status = Con::Broken;
        }
    }
}
/*
int start_deal_process(struct proc_status& status)
{
    for (int i = 0; i < g_conf.proc_num; ++i)
    {
        //创建socketpair，用于传递日志
        int fd_pair[2];

        if(socketpair(AF_UNIX, SOCK_STREAM, 0, fd_pair) != 0)
        {
            LIS_ERROR("socketpair failed:%s\n", strerror(errno));
            return -1;
        }

        LIS_DEBUG("fd[0] = %d fd[1] = %d \n", fd_pair[0], fd_pair[1]);

        //启动接收子进程
        pid_t pid = fork();

        if(-1 == pid)
        {
            LIS_ERROR("fork: %s\n", strerror(errno));
            //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
            return -1;
        }
        else if(0 == pid)   // 子进程
        {
            g_r5_log.logOnlyClose();

            close(fd_pair[FD_WRITE]);

            char proc_exe[256]   = {'\0'};
            char proc_name[256]  = {'\0'};
            char rfd[12] = "";

            snprintf(proc_exe, sizeof(proc_exe), "%s", g_conf.proc_file);
            snprintf(proc_name, sizeof(proc_name), "%s", g_conf.proc_file);
            snprintf(rfd, 12, "%d", status.recv_fd);

            int retval = execl(proc_exe,
                               proc_name,
                               "-c", status.conf_file,
                               "-w",rfd,
                               (char*)NULL);

            if(-1 == retval)
            {
                perror("execl");
                //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
                exit(0);
            }
        }
        else
        {
            close(fd_pair[FD_READ]);
            status.proc_fd[i] = fd_pair[FD_WRITE];
            status.proc_pid[i] = pid;
            //LIS_INFO("New send process pid = %d.\n", plc->send_child_pid[0]);
        }
    }

    return 0;
}
*/

int main(int argc, char* argv[])
{
    share_mem mem;
    Csem sem;

    struct recv_param& param=g_param;

    memset(&param, 0, sizeof(param));
    if(read_arg(argc, argv, param) < 0){
        fprintf(stderr, "read args failed.\n");
        return -1;
    }

    if(load_conf() < 0){
        fprintf(stderr, "load configure failed.\n");
        return -1;
    }

    if(init(param, mem, sem) < 0){
        fprintf(stderr, "init failed.\n");
        return -1;
    }


    if(register_signal() < 0){
        RECV_ERROR("register signal failed.\n");
        return -1;
    }

    recv_process(param, mem, sem);

    mem.destroy();
    exit();
    RECV_INFO("Program Exit.\n");

    return 0;
}



int DoSigTerm(){
    RECV_WARN("interruptted by SIGTERM.\n");

    g_exit = 1;
    return 0;
}

int DoSigChild(){
    RECV_WARN("interruptted by SIGCHLD.\n");

    return 0;
}

int DoSigHup(){

    RECV_WARN("interruptted by SIGHUP.\n");

    return load_conf(true);
}

int DoSigUsr2(){
    RECV_WARN("interruptted by SIGUSR2.\n");

    g_r5_log.flush();
    return 0;
}

void exit()
{
   close(g_param.recv_pipe);
   unlink(g_conf.pipe_file);
}

int DoSigAlarm(){
    RECV_WARN("interruptted by SIGALRM.\n");

    return 0;
}

int DoSigPipe(){
    RECV_WARN("interruptted by SIGPIPE.\n");

    return -1;
}

