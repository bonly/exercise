
// create by derek 20070420

//modify by jiangyan

/**
*1,����1M �Ļ��������ڱ�����־��Ϣ������1K����ʱ�ַ����ڱ���ÿһ�ε���־���ݣ���Ҫһ������¼��ǰ�������С��
*2,�����ύ�����ύ������Ҫ�߱����¹��ܣ���ָʾ�ύ��ʲô�ļ��к�ָʾ�Ƿ���ջ�����
*3,�������ô�����־�ļ�����ˢ����־flushʱ����Ҫ�����������Ϣд���ļ��С�
*4,�������˴�����־�ļ�����ˢ����־flushʱ���򲻴���д�ļ��������ȴ���־�ύ��
*5,ÿ��д��־��ʱ�򣬽�������snprint д����ʱ�ַ��У���ȡ��������־��size���жϻ�����ʣ�����Ƿ��㹻���ɱ�����־��Ϣ��
*6,�绺�����С���㹻���ɱ�����־��Ϣ�����ύ�����ļ��У���ջ������ٽ�������־��Ϣ�Ž�����
*7,Ϊ�����ܣ���ջ�������Ҫmemset ��ֻ��Ҫ����¼��ǰ�������С�ı��� =0 ���ɡ�
*/

#include "r5log.h"
#include <sys/time.h>
#include <string.h>
const char *LOG_HEAD[] =
{
    "[T] ",
    "[D] ",
    "[I] ",
    "[W] ",
    "[E] ",
    "[F] "
};


R5_Log::R5_Log (): line(0), file(0), level(log_trace), level_file(-1), level_term(-1),
                os_log(NULL), os_err_log(NULL), log_size(0), isdefalutpath(0),log_count(0), m_IsErr(false),
                m_log_realsize(0), m_bAutoWrap(false)
{
    memset(name, 0, PATH_MAX);
    memset(&m_date, 0, sizeof(m_date));
    memset(prefix, 0, sizeof(prefix));
    memset(subdir, 0, sizeof(subdir));
    memset(fulldir, 0, sizeof(fulldir));
    memset(errprefix, 0, sizeof(errprefix));        
    memset(errfulldir, 0, sizeof(errfulldir));
    memset(m_logBuf, 0, sizeof(m_logBuf));

    //modify by cyx
    time_t  t;
    struct  tm  tt;
    time(&t);
    localtime_r(&t, &tt);
    memcpy(&m_date, &tt, sizeof(m_date));
    tt.tm_hour = 0;
    tt.tm_min = 0;
    tt.tm_sec = 0;
    t = mktime(&tt);
    m_nSwitchTime = t + ONE_DAY_SECONDS;

    //modify by cyx
    //Modified by Yyx. Set default to no buffer
    m_nBufferSize = 0;
    m_szBuf = NULL;
    m_err_szBuf = NULL;
    /*
    m_nBufferSize = IO_BUFFER_SIZE;
    m_szBuf = new char[m_nBufferSize];
    memset(m_szBuf, 0, m_nBufferSize);
    m_err_szBuf = new char[m_nBufferSize];
    memset(m_err_szBuf, 0, m_nBufferSize);
    */
}


R5_Log::~R5_Log()
{
    logNormalClose ( );

    if(m_szBuf != NULL)
    {
        delete [] m_szBuf;
    }
    if(m_err_szBuf != NULL)
    {
        delete [] m_err_szBuf;
    } 
}


int R5_Log::setErrLoginfo(const char *errLogpath)
{
	m_IsErr = true;
	sprintf(errprefix, "err_%s", prefix);
	if (os_err_log != NULL )
    {
        fflush(os_err_log);
        fclose(os_err_log);
        os_err_log = NULL;
    }
    if( setErrLogDir(errLogpath) < 0)
    {
        fprintf(stderr, "Log Path is error:%s\n",errLogpath);
        return -1;
    }

    return 0;
}


void R5_Log::setLogNameHead(const char *nm)
{
    // ��־���ļ���������r5log_ʱ��_���ID_��־����.log
    int len = strlen(nm);
    if(len != 0)
    {
        strcpy(prefix, nm);
        log_count = 0;
        if (os_log != NULL )
        {
            fflush(os_log);
            fclose(os_log);
            os_log = NULL;
        }
    }
}

void R5_Log::setLogSubDir(const char *dir)
{
    int len = strlen(dir);
    if ( len <= 0 || len >= sizeof(subdir) )
    {
        fprintf(stderr,"setLogSubDir failed to get lenth of dir %s\n", dir);
        return ;
    }

    strncpy ( subdir, dir, sizeof(subdir) );
}

int R5_Log::chkDir ( const char *dir )
{
    int len = strlen(dir);

    if ( len <= 0 || len >= PATH_MAX )
    {
        fprintf(stderr,"chkDir failed to get lenth of dir %s\n", dir);
        return -1;
    }

#ifndef _WIN32
    DIR *pdir = NULL;
    if((pdir = opendir(dir)) == NULL )
    {
        if( mkdir(dir, LOG_DIR_MODE) == -1)
        {
            fprintf(stderr,"setLogDir failed to make sub directory %s\n", dir);
            return -1;
        }
    }
    else
    {
        if (closedir(pdir) < 0)
        {
            fprintf(stderr,"Unable to close directory %s\n", dir);
        }
        pdir = NULL;
    }
#endif

    if(access(dir, W_OK) < 0)
    {
        fprintf(stderr,"The dir access permissions do not allow! %s\n", dir);
        return -1;
    }

    return 0;
}

int R5_Log::setLogDir(const char *dir)
{
    int nRet = chkDir ( dir );
    if ( nRet < 0 )
        return nRet;

    isdefalutpath = 1;
    strncpy ( fulldir, dir, sizeof(fulldir) );

    return 0;
}

int R5_Log::setErrLogDir(const char *dir)
{
    int nRet = chkDir ( dir );
    if ( nRet < 0 )
        return nRet;

    strncpy ( errfulldir, dir, sizeof(errfulldir) );

    return 0;
}

int R5_Log::logFileName()
{
    if (isdefalutpath == 0)
    {
        fprintf(stderr, "please set the log path\n");
        return -1;
    }
    else if (isdefalutpath == 1)
    {
        snprintf(name, PATH_MAX, "%s%s%s_%d_%04d%02d%02d_%d.log", fulldir, "/", prefix, getpid(),
                m_date.tm_year + 1900, m_date.tm_mon + 1, m_date.tm_mday, log_count);

        if (m_IsErr)
        {
            snprintf(errname, PATH_MAX, "%s%s%s_%d_%04d%02d%02d_%d.log", errfulldir, "/",
                    errprefix, getpid(), m_date.tm_year + 1900, m_date.tm_mon + 1, m_date.tm_mday,
                    log_count);
        }
    }
    return 0;
}


int R5_Log::logOpen()
{
    logNormalClose ( );
    /*time_t  t;
    struct  tm  date;
    time(&t);
    localtime_r(&t, &date);*/

    if ( logFileName ( ) < 0 )
        return -1;

    char name2[PATH_MAX] = { 0 };
    snprintf(name2, PATH_MAX, "%s.tmp", name);
	if( logOpen(&os_log, name2) < 0)
		return -1;

	///�����ļ�����
    if ( m_nBufferSize > 0 )
    {
    	if ( setvbuf(os_log, m_szBuf, _IOFBF, m_nBufferSize) < 0 )
        {
			fprintf(stderr, "I/O (setvbuf size=%d) (%s)  error!  %d--%s\n", m_nBufferSize, name2, errno, strerror(errno));
        }
    }

    log_count++;

	char errname2[PATH_MAX] = { 0 };
	if(m_IsErr)
    {
    	snprintf(errname2, PATH_MAX, "%s.tmp", errname);
    	if(logOpen(&os_err_log, errname2) < 0)
    		return -1;
		///�����ļ�����
        if ( m_nBufferSize > 0 )
        {
	    	if ( setvbuf(os_err_log, m_err_szBuf, _IOFBF, m_nBufferSize) < 0 )
            {
			    fprintf(stderr, "I/O (setvbuf size=%d) (%s) error!  %d--%s\n", m_nBufferSize, errname2, errno, strerror(errno));
            }
       }
    }

    return 0;
}

int R5_Log::logOpen(FILE * *log_fd, const char *name)
{
  // to do
  // ���ԭ�ļ������ԭ�ļ�����
    *log_fd = fopen(name, "w");

    if (*log_fd == NULL)
    {
		fprintf(stderr, "I/O (fopen) (%s) error! %d--%s\n", name, errno, strerror(errno));
    	return -1;
    }

    return 0;
}

void R5_Log::logOnlyClose()
{
    if(os_log != NULL)    
    {        
        fflush(os_log);        
        fclose(os_log);    
        os_log = NULL;    
    }    
    if(os_err_log != NULL)    
    {        
        CommitLog();        
        fflush(os_err_log);        
        fclose(os_err_log);    
        os_err_log = NULL;    
    }    
/*
    memset(m_szBuf, 0, m_nBufferSize);    
    memset(m_err_szBuf, 0, m_nBufferSize);
*/
}

void R5_Log::logNormalClose()
{
    CommitLog();

    if ( os_log != NULL )
    {
        char name2[PATH_MAX] = { 0 };

        if ( fflush(os_log) < 0 )
        {
			fprintf(stderr, "I/O (fflush) error! %d--%s\n", errno, strerror(errno));
        }
        fclose(os_log);
        os_log = NULL;
        snprintf(name2, sizeof(name2), "%s.tmp", name);
        if ( rename(name2, name) < 0 )
        {
			fprintf(stderr, "I/O (rename) (%s) error! %d--%s\n", name2, errno, strerror(errno));
        }
    }
	if ( os_err_log != NULL )
    {
        char errname2[PATH_MAX] = { 0 };

        if ( fflush(os_err_log) < 0 )
        {
			fprintf(stderr, "I/O (fflush) error! %d--%s\n", errno, strerror(errno));
        }
        fclose(os_err_log);
        os_err_log = NULL;
        snprintf(errname2, sizeof(errname2), "%s.tmp", errname);
        if ( rename(errname2, errname) < 0 )
        {
			fprintf(stderr, "I/O (rename) (%s) error! %d--%s\n", errname2, errno, strerror(errno));
        }
    }
}

int R5_Log::log1(const char *format, ...) //д��־
{
    struct timeval now;
    struct tm ts;
    char dateinfo[128];

    if ( os_log == NULL )
    {
        if ( logOpen() < 0 ) 
            return -1;
    }
    else if ( log_size>=LOG_SIZE )
    {
        if ( logOpen() < 0 ) 
            return -1;
        log_size = 0;
    }

    gettimeofday(&now, 0);
    memset(dateinfo, 0 ,sizeof(dateinfo));
    memset(&ts, 0, sizeof(ts));
    localtime_r(&now.tv_sec, &ts);
    sprintf(dateinfo, "%02d%02d%02d%02d", ts.tm_mday,ts.tm_hour,ts.tm_min,ts.tm_sec);

    //modify by cyx
    if (m_date.tm_year!=ts.tm_year||m_date.tm_mon!=ts.tm_mon||m_date.tm_mday!=ts.tm_mday)
    {
        // ���ڸı䣬���¼���
        log_count = 0;
        memcpy(&m_date, &ts, sizeof(m_date));
    }
    
    if(now.tv_sec >  m_nSwitchTime)
    {
        // �л���
        //log_count = 0;
        //memcpy(&date, &ts, sizeof(date));
        time_t i = (now.tv_sec - m_nSwitchTime) % ONE_DAY_SECONDS;
        if(i == 0)
        {
            i = (now.tv_sec - m_nSwitchTime) / ONE_DAY_SECONDS ;
        }
        else
        {
            i = ((now.tv_sec - m_nSwitchTime) / ONE_DAY_SECONDS) + 1;
        }
        
        m_nSwitchTime = m_nSwitchTime + (ONE_DAY_SECONDS * i);

        if ( logOpen() < 0 ) 
            return -1;
        log_size = 0;
    }

    log_size++;

	//���ָ���˴����ļ�������־����ҵ����whileѭ���ڵ�����ҵ����־
	if(m_IsErr) //  && pro_loop_flag)
	{
        // ÿ����־���ܳ���4096, ����дʧ��
		char tmplogBuf[4096];
		int n = 0;
		int tmpsize = 0;

        //Rem By Yyx  snprintf would set '\0' to string end.
        //Check buffer size when finish writing buffer
//		memset(tmplogBuf, 0, sizeof(tmplogBuf));
//		HandleOverBuffer();   //��Ҫ�ж����һ����m_logBuf�������Ϣ�Ƿ񳬳���С�������ύ

		if (level>=log_trace && level<=log_fatal)
		{
			n = snprintf(tmplogBuf, sizeof(tmplogBuf),  "%s[%s:%06d]", LOG_HEAD[level/20], dateinfo, now.tv_usec);
			if( n < 0 )
			{
			    fprintf(stderr, "MEM (snprintf) error! %d--%s\n", errno, strerror(errno));
                return -1;
			}
		}
		else
		{
			n = snprintf(tmplogBuf, sizeof(tmplogBuf), "%06d[%s:%06d]", level, dateinfo, now.tv_usec);
			if( n < 0 )
			{
			    fprintf(stderr, "MEM (snprintf) error! %d--%s\n", errno, strerror(errno));
                return -1;
			}
		}
		tmpsize += n;

        // ��־����
		va_list argp;
	    va_start (argp, format);
	    n = vsnprintf(tmplogBuf+tmpsize, sizeof(tmplogBuf)-tmpsize, format, argp);
	    if( n < 0 )
		{
		    fprintf(stderr, "MEM (vsnprintf) error! %d--%s\n", errno, strerror(errno));
            return -1;
		}
		
	    va_end (argp);
	    tmpsize += n;
	    
        
        //�ж��Ƿ�ӻ��з�
	    if( m_bAutoWrap )
	    {
	    	n = snprintf(tmplogBuf+tmpsize,sizeof(tmplogBuf)-tmpsize, "\n");
            if( n < 0 )
			{
			    fprintf(stderr, "MEM (snprintf) error! %d--%s\n", errno, strerror(errno));
                return -1;
			}
	    	tmpsize += n;
	    }	    

	    HandleOverBuffer(tmpsize);
		memcpy(m_logBuf+m_log_realsize, tmplogBuf, tmpsize);

		m_log_realsize += tmpsize;
	}
	//ֱ�Ӱ����Ϸ���д��־�ļ�
	else
	{
		if (level>=log_trace&&level<=log_fatal)
	    {
	    	fprintf(os_log, LOG_HEAD[level/20]);
	    }
	    else
	    {
	    	fprintf(os_log, "%06d", level);
	    }


	    if(fprintf(os_log, "[%s:%06d] ", dateinfo, now.tv_usec) <= 0)
	    {
	        fclose(os_log);
			fprintf(stderr, "I/O (fprintf) error! %d--%s\n", errno, strerror(errno));

            return -1;
	    }

	    va_list argp;
	    va_start (argp, format);
	    vfprintf(os_log, format, argp);
	    
	    va_end (argp);
	    
	    if( m_bAutoWrap )
	    {
	    	fprintf(os_log, "\n");
	    }	    
	}

    return 0;
}


void R5_Log::ClearBuffer()
{
	m_log_realsize = 0;
}

void R5_Log::HandleOverBuffer(int nSizeCheck)
{
	if(m_log_realsize+nSizeCheck > LOG_BUFFER_SIZE)
	{
		CommitLog();
	}
}


//nCommitType 0--����־ 1--������־
int R5_Log::CommitOnly ( int nCommitType )
{
    //Nothing to commit
    if ( m_log_realsize == 0 )
        return 0;

    FILE *pCommitFile = NULL;

    switch ( nCommitType )
    {
    case 0:
        pCommitFile = os_log;
        break;
    case 1:
        pCommitFile = os_err_log;
        break;
    }

    if ( pCommitFile != NULL ) 
    {
        int nRet = fwrite ( m_logBuf, sizeof(char), m_log_realsize, pCommitFile );
        if ( nRet < 0 )
        {
            fprintf(stderr, "I/O (fwrite) error! %d--%s\n", errno, strerror(errno));
            return -1;
        }
    }
    else
    {
        fprintf ( stderr, "Commit error! FILE pointer=NULL type=%d\n", nCommitType );
        return -1;
    }

    return 0;
}

//���ݾɽӿ�
//bCommitNormal: true��ʾ�ύ��������־�ļ� false��ʾ�ύ��������־��
//bWriteBoth: �����ļ����ύ
int R5_Log::CommitLog (bool bCommitNormal, bool bWriteBoth)
{
    //Nothing to commit
    if ( m_log_realsize == 0 )
        return 0;

    int nRet;
    if ( bCommitNormal || bWriteBoth )
    {
        nRet = CommitOnly ( 0 );
        if ( nRet < 0 )
            return nRet;
    }
	if ( !bCommitNormal || bWriteBoth )
	{
        nRet = CommitOnly ( 1 );
        if ( nRet < 0 )
            return nRet;
	}
	ClearBuffer ();

    return 0;
}


int R5_Log::log2(const char *format, ...) //д�ն�
{
    struct timeval now;
    struct tm ts;
    char dateinfo[128];
 
    gettimeofday(&now, 0);

    // �˴�����־��ʽ������Ҫ����
    if ( level>=log_trace && level<=log_fatal ) 
        fprintf(stdout, LOG_HEAD[level/20]);
    else     
        fprintf(stdout, "%06d", level);

    memset(dateinfo, 0 ,sizeof(dateinfo));
    memset(&ts, 0, sizeof(ts));
    localtime_r(&now.tv_sec, &ts);

    //sprintf(dateinfo, "%04d%02d%02d%02d%02d%02d", ts.tm_year+1900, ts.tm_mon + 1,ts.tm_mday,ts.tm_hour,ts.tm_min,ts.tm_sec);
    sprintf(dateinfo, "%02d%02d%02d%02d", ts.tm_mday,ts.tm_hour,ts.tm_min,ts.tm_sec);
    fprintf(stdout, "[%s:%06d] ", dateinfo, now.tv_usec);

    // Start of variable args section.
    va_list argp;
    va_start (argp, format);
    vfprintf(stdout, format, argp);
    va_end (argp);
    
    if( m_bAutoWrap )
    {
    	fprintf(stdout, "\n");
    }
    
    return 0;
}

void R5_Log::flush( bool bFlushInfo )
{
    if ( os_log != NULL )
    {
        if ( checkLevelFile(log_info) )
        {
            setConditional(log_info, __LINE__, __FILE__);
            if ( bFlushInfo )
                log1("[base] flush log.\n");
        }

        fflush(os_log);
    }
    if ( os_err_log != NULL)
    {
    	if ( checkLevelFile(log_info) )
        {
            setConditional(log_info, __LINE__, __FILE__);
            if ( bFlushInfo )
                log1("[base] flush err log.\n");
        }

        fflush(os_err_log);
    }
}

//modify by cyx 5-12
// ����Ϊ0ʹ��ϵͳĬ��
int R5_Log::setLogBuffer(const char *size)
{
    int nBufferSize = atoi(size);
    if(nBufferSize < 0)
    {
		fprintf(stderr, "SetLogBuffer error! size=%s\n", size);
        return -1;
    }
    //modified by oyy 2010-06-11
    //ɾ���ļ�����ǰ��flush����close�ļ����
    logNormalClose();
    
    m_nBufferSize = nBufferSize;
    
    if(m_szBuf != NULL)
    {
        delete [] m_szBuf;
    }
    if(m_err_szBuf != NULL)
    {
        delete [] m_err_szBuf;
    }
    
    if ( m_nBufferSize > 0 )
    {
        m_szBuf = new char[m_nBufferSize];
        if ( m_szBuf == NULL )
        {
		    fprintf(stderr, "MEM (new) error! %d--%s\n", errno, strerror(errno));
            return -1;
        }
        memset ( m_szBuf, 0, m_nBufferSize );

        m_err_szBuf = new char[m_nBufferSize];
        if ( m_err_szBuf == NULL )
        {
		    fprintf(stderr, "MEM (new) error! %d--%s\n", errno, strerror(errno));
            return -1;
        }
        memset ( m_err_szBuf, 0, m_nBufferSize );
        
    }
    else    //set buffer size 0 == using system default value
    {
        m_szBuf = NULL;
        m_err_szBuf = NULL;
    }
    
    return 0;
}

//modify by cyx 5-12
int R5_Log::setSwitchTime(const char *swith_t)
{
    if(strlen(swith_t) != 6)
    {
		fprintf(stderr, "SwitchTime (strlen) error! %s\n", swith_t );
        return -1;
    }
    
    int hh;
    int mm;
    int ss;
    char ww[8]={0};
    
    strncpy(ww, swith_t, 2);
    hh = atoi(ww);
    if(hh < 0 || hh >=24)
    {
		fprintf(stderr, "SwitchTime (Hour) error! %s\n", swith_t );
        return -1;
    }
    
    strncpy(ww, swith_t+2, 2);
    mm = atoi(ww);
    if(mm < 0 || mm >=60)
    {
		fprintf(stderr, "SwitchTime (Minute) error! %s\n", swith_t );
        return -1;
    }
    
    strncpy(ww, swith_t+4, 2);
    ss = atoi(ww);
    if(ss < 0 || ss >= 60)
    {
		fprintf(stderr, "SwitchTime (Second) error! %s\n", swith_t );
        return -1;
    }
    
    time_t  t;
    struct  tm  date;
    time(&t);
    localtime_r(&t, &date);
    
    date.tm_hour = hh;
    date.tm_min = mm;
    date.tm_sec = ss;
    
    time_t t1;
    t1 = mktime(&date);
    
    if(t >= t1)
    {
        m_nSwitchTime = t1 + ONE_DAY_SECONDS ;
    }
    else
    {
        m_nSwitchTime = t1;
    }
    
    return 0;
}
