
// create by derek 20070420

#include "iniconfig.h"
#include "r5string.h"

//-----------------------------------------------------------------------------
void IniItem::parser()
{
    //::trimLeft((char *)item.data());
    //::trimRight((char *)item.data(), '\n');
    //::trimRight((char *)item.data(), '\r');
    //::trimRight((char *)item.data());
    
    vector<string> v;
   
    ::parser(item.data(), '=', v, 1);
    if ( v.size()>=1 )
    {
        ::trim((char *)(v[0].data()));
        v[0].resize(strlen(v[0].data()));
        //printf("key: |%s|\n", v[0].data());
        key = v[0];
    }
    
    if ( v.size()>=2 )
    {
        ::trim((char *)(v[1].c_str()));
        v[1].resize(strlen(v[1].c_str()));
        //printf("value: |%s|\n", v[1].c_str());
        value = v[1];
    }
}

//-----------------------------------------------------------------------------

const char * IniConfig::getValue(const char *sct, const char *key)
{
    IniSection *sect = getSection(sct);
    if ( sect == 0 ) return 0;
    
    return sect->getValue(key);
}

void IniConfig::release()
{
    iterator it = section.begin();
    for (; it!=section.end(); ++it)
    {
        delete it->second;
    }
}

IniSection *IniConfig::getSection(const char *sct)
{
    if ( sct != 0 )
    {
        iterator it = section.find(sct);
        if ( it != section.end() ) return it->second;
    }
    
    else if ( section.size() == 1 ) return section.begin()->second;
        
    //assert(false);
    return 0;
}

int IniConfig::open(const char *name)
{
    release();
    
    int size = 2048;
    string buf(size, 0);
    FILE *in = fopen(name, "r");
    if ( in == 0 ) return -1;
        
    char *sct = 0;
    IniSection *s = 0;
    int len = 0;
    unsigned int read_pos = 0;
    
    char *p = (char *)buf.data();
    
    while ( fgets(p+read_pos, size-read_pos, in) )
    {            
        if ( strrchr(p+read_pos, '\n') == 0 &&(!feof(in))) // &&(!feof(in)) 当最后一行没有换行的时候不加此条件则被丢弃
        {
            read_pos = size-1; // 文件中读取一行并返回长度最多为length - 1 字节的字符串
            size *= 2;
            buf.resize(size);
            p = (char *)buf.data();
            continue;
        }
        read_pos = 0;
        
        ::trim(p);
       
        ::trimRight(p, '\n');
        ::trimRight(p, '\r');

        

        
                            
        if ( p[0] == ';' || p[0] == '#' ) continue;
        
        if ( p[0] == '[' )
        {
            s = 0; //
            sct = strrchr(p, ']');
            if ( sct == 0 )
            {
                fclose(in);
                fprintf(stderr,"没有找到匹配的]\n");
                return -1;
            }
            len = sct-1-p;
            if ( len<=0 )
            {
                fprintf(stderr,"段为空\n");
                continue;
            }

            string sect(p+1, len);
            if ( getSection(sect.data()) != 0 )
            {
                fclose(in);
                fprintf(stderr,"此段已经存在:%s\n", sect.data());
                return -1;
            }
            //fprintf(stderr,"增加新配置段:%s\n", sect.data());
            s = new IniSection(sect.data());
            section[sect] = s;
            continue;
        }
                    
        if ( p[0] == 0 )
        {
          //fprintf(stderr,"读取空行\n");
            continue;
        }
        if ( s == 0 )
        {
            s = getSection("");
            if ( s == 0 )
            {
                s = new IniSection("");
                section[""] = s;
                //fprintf(stderr,"增加默认配置段\n");
            }
           //fprintf(stderr,"使用默认配置段\n");
            
        }
        s->push(p);
    }
    fclose(in);
    return 0;
}
