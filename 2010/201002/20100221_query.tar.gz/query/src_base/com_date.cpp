//eated by tanjie 20070630
///////////////////////////////////////////
#include "com_date.h"
#include <stdio.h>
static int sg_lastday_of_month[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};

//TIMESTAMP_STRUCTת����long
BASE2_INT64 ts2l(TIMESTAMP_STRUCT &ts)
{    
    struct tm t;    
    
    if( (sizeof(time_t)==4) && (ts.year>2037) )
    {
        t.tm_year = 2037-1900;
    }
    else
    {
        t.tm_year = ts.year -1900;        
    }

    t.tm_mon  = ts.month -1;    
    t.tm_mday  = ts.day;    
    t.tm_hour = ts.hour;
    t.tm_min  = ts.minute;    
    t.tm_sec  = ts.second;    
        
    return mktime(&t);
}

//by tanjie 20081115 �޲���Ĺ��캯��ʹ�õ�ǰʱ���ʼ������
CCommonDate::CCommonDate()
{
    time_t t;
    time(&t);
    CCommonDate(time_t(t));
}

CCommonDate::CCommonDate(const tm &_date_tm)
{
    m_datetm = _date_tm;
    validate();
}
    
CCommonDate::CCommonDate(int _year, int _month, int _date, int _hrs, int _min, int _sec)
{
    m_datetm.tm_year  = _year - 1900;
    m_datetm.tm_mon   = _month - 1;
    m_datetm.tm_mday  = _date;
    m_datetm.tm_hour  = _hrs;
    m_datetm.tm_min   = _min;
    m_datetm.tm_sec   = _sec;
    
    validate();
}

CCommonDate::CCommonDate(const CCommonDate &date)
{
    m_datetm = date.m_datetm;
    m_bIsValid = date.m_bIsValid;
}

CCommonDate::CCommonDate(time_t _timestamp)
{
    localtime_r(&_timestamp,&m_datetm);
    validate();
}

//delete by chensiwei 2008-11-17
//add by jiangyan 20071203
/*
CCommonDate::CCommonDate(const diam_tm _diam_tm)
{
    time_t tmp = _diam_tm - CONV_1900_1970;
#ifdef SunOS
        memcpy(&m_datetm, localtime(&tmp ), sizeof(m_datetm));
#else
    localtime_r(&tmp , &m_datetm);
    validate();
#endif 

    
}
*/


CCommonDate::~CCommonDate()
{
}

int CCommonDate::getYear()
{
    if (!isValid())
    {
        validate();
    }
    return m_datetm.tm_year + 1900;
}

 int CCommonDate::getMonth()
{
    if (!isValid())
    {
        validate();
    }
    return m_datetm.tm_mon + 1;
}

 int CCommonDate::getDay()
{
    if (!isValid())
    {
        validate();
    }
    return m_datetm.tm_mday;
}
    
 int CCommonDate::getHour()
{
    if (!isValid())
    {
        validate();
    }
    return m_datetm.tm_hour;
}

 int CCommonDate::getMinute()
{
    if (!isValid())
    {
        validate();
    }
    return m_datetm.tm_min;
}

 int CCommonDate::getSecond()
{
    if (!isValid())
    {
        validate();
    }
    return m_datetm.tm_sec;
}

int CCommonDate::getWeekDay()
{
    if (!isValid())
    {
        validate();
    }
    return m_datetm.tm_wday;
}


    
 CCommonDate& CCommonDate::setYear(int _year)
{
    //this operation will make the class invalid
    m_datetm.tm_year = _year - 1900;
    validate();
    return *this;
}

 CCommonDate& CCommonDate::setMonth(int _month)
{
    //this operation will make the class invalid
    m_datetm.tm_mon = _month - 1;
    validate();
    return *this;
}

 CCommonDate& CCommonDate::setDay(int _day)
{
    //this operation will make the class invalid
    m_datetm.tm_mday = _day;
    validate();
    return *this;
}
    
    
 CCommonDate& CCommonDate::setHour(int _hour)
{
    //this operation will make the class invalid
    m_datetm.tm_hour = _hour;
    validate();
    return *this;
}
    
 CCommonDate& CCommonDate::setMinute(int _minute)
{
    //this operation will make the class invalid
    m_datetm.tm_min = _minute;
    validate();
    return *this;
}


 CCommonDate& CCommonDate::setSecond(int _second)
{
    //this operation will make the class invalid
    m_datetm.tm_sec = _second;
    validate();
    return *this;
}



 CCommonDate& CCommonDate::addYear(int _yearoffset)
{
    //this operation will make the class invalid
    m_datetm.tm_year += _yearoffset;
    validate();
    return *this;
}
    
 CCommonDate& CCommonDate::addMonth(int _monthoffset)
{
    //this operation will make the class invalid
    m_datetm.tm_mon += _monthoffset;
    validate();
    return *this;
}

 CCommonDate& CCommonDate::addWeek(int _weekoffset)
{
    //this operation will make the class invalid
    return addDay(_weekoffset*7);
}

 CCommonDate& CCommonDate::addDay(int _dayoffset)
{
    //this operation will make the class invalid
    m_datetm.tm_mday += _dayoffset;
    validate();
    return *this;
}
    
 CCommonDate& CCommonDate::addHour(int _houroffset)
{
    //this operation will make the class invalid
    m_datetm.tm_hour += _houroffset;
    validate();
    return *this;
}

 CCommonDate& CCommonDate::addMinute(int _minuteoffset)
{
    //this operation will make the class invalid
    m_datetm.tm_min += _minuteoffset;
    validate();
    return *this;
}

 CCommonDate& CCommonDate::addSecond(int _secondoffset)
{
    //this operation will make the class invalid
    m_datetm.tm_sec += _secondoffset;
    validate();
    return *this;
}

 BASE2_INT64 CCommonDate::getTimeStamp()
{
    return validate();
}

 bool CCommonDate::isValid()
{
    return m_bIsValid;
}

 time_t CCommonDate::validate()
{
    m_bIsValid = true;
    return mktime(&m_datetm);
}

 void CCommonDate::invalidate()
{
    m_bIsValid = false;
}

CCommonDate CCommonDate::operator=(const CCommonDate &right)
{
    m_datetm = right.m_datetm;
    m_bIsValid = right.m_bIsValid;
    return *this;
}


void CCommonDate::getDayPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime)
{
    PeriodStartTime = *this;
    PeriodStartTime.setHour(0);
    PeriodStartTime.setMinute(0);
    PeriodStartTime.setSecond(0);
    PeriodStartTime.validate();
    PeriodEndTime = *this;
    PeriodEndTime.setHour(23);
    PeriodEndTime.setMinute(59);
    PeriodEndTime.setSecond(59);
    PeriodEndTime.validate();
}

void CCommonDate::getWeekPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime)
{
    PeriodStartTime = *this;
    int wday = this->getWeekDay();
    PeriodStartTime.addDay(-1*wday);
    PeriodStartTime.setHour(0);
    PeriodStartTime.setMinute(0);
    PeriodStartTime.setSecond(0);
    PeriodStartTime.validate();
    PeriodEndTime = PeriodStartTime;
    PeriodEndTime.addWeek(1);
    PeriodEndTime.addSecond(-1);
    PeriodEndTime.validate();
}

void CCommonDate::getTensdayPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime)
{
    PeriodStartTime = *this;
    int mday = this->getDay();
    //�������Ѯ�Ŀ�ʼʱ��
    int iTensStartday;
    if (mday <= 10)
    {
        iTensStartday = 1;
    }
    else if (mday <=20)
    {
        iTensStartday = 11;
    }
    else
    {
        iTensStartday = 21;
    }
    PeriodStartTime.addDay(iTensStartday - mday);
    PeriodStartTime.setHour(0);
    PeriodStartTime.setMinute(0);
    PeriodStartTime.setSecond(0);
    PeriodStartTime.validate();
    PeriodEndTime = PeriodStartTime;
    if (iTensStartday < 21)
    {
        //��Ѯ����Ѯ Ѯ��ʼʱ�����10���ټ�һ�����Ѯ����ʱ��
        //��ʱDateTime�Ѿ���Ѯ��ʼʱ��
        PeriodEndTime.addDay(10);
        PeriodEndTime.addSecond(-1);
        PeriodEndTime.validate();
        return;
    }
    else
    {
        //��Ѯ ������¿�ʼʱ��
        PeriodEndTime.setDay(1);
        PeriodEndTime.setHour(0);
        PeriodEndTime.setMinute(0);
        PeriodEndTime.setSecond(0);
        PeriodEndTime.addMonth(1);
        PeriodEndTime.addSecond(-1);
        PeriodEndTime.validate();
        return;
    }
}

void CCommonDate::getMonthPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime)
{
    PeriodStartTime = *this;
    PeriodStartTime.setDay(1);
    PeriodStartTime.setHour(0);
    PeriodStartTime.setMinute(0);
    PeriodStartTime.setSecond(0);
    PeriodStartTime.validate();
    PeriodEndTime = PeriodStartTime;
    PeriodEndTime.addMonth(1);
    PeriodEndTime.addSecond(-1);
    PeriodEndTime.validate();
    return;
}

void CCommonDate::getYearPeriod(CCommonDate &PeriodStartTime, CCommonDate &PeriodEndTime)
{
    PeriodStartTime = *this;
    PeriodStartTime.setMonth(1);
    PeriodStartTime.setDay(1);
    PeriodStartTime.setHour(0);
    PeriodStartTime.setMinute(0);
    PeriodStartTime.setSecond(0);
    PeriodStartTime.validate();
    PeriodEndTime = PeriodStartTime;
    PeriodEndTime.addYear(1);
    PeriodEndTime.addSecond(-1);
    PeriodEndTime.validate();
    return;
}

std::string CCommonDate::getTimeString()
{
    char tmp[15];
    getTimeString(tmp);
    return std::string(tmp);
}
void CCommonDate::getTimeString(char *_ochTimeStr)
{
    sprintf(_ochTimeStr,"%04d%02d%02d%02d%02d%02d",getYear(),getMonth(),getDay(),getHour(),getMinute(),getSecond() );
}

bool CCommonDate::isLeapYear(int _iYear)
{
    return (_iYear %4 == 0 && _iYear %100 != 0) || _iYear % 400 == 0;
}

int CCommonDate::getLastDayByMonth(const int _iYear,const int _iMonth)
{
    if (_iMonth == 2)
    {
        if (isLeapYear(_iYear))
        {
            return 29;
        }
        else
        {
            return 28;
        }
    }
    else
    {
        return sg_lastday_of_month[_iMonth];
    }
}


//add by jiangyan 20071203


diam_tm CCommonDate::getDiamTimeStamp()
{
    time_t  t;    
    time(&t);
    localtime_r(&t, &m_datetm);
    return (BASE2_INT64)mktime(&m_datetm) + CONV_1900_1970;
    
}


void CCommonDate::secondToTimestamp(TIMESTAMP_STRUCT *ts, time_t sec, time_t offset, int nTZ)
{

    time_t tt = sec - CONV_1900_1970 + offset;
    tt += 3600*nTZ;  // ʱ����ת��
    struct tm *tm = gmtime(&tt);
    ts->year   = tm->tm_year + 1900;
    ts->month  = tm->tm_mon + 1;
    ts->day    = tm->tm_mday;        
    ts->hour   = tm->tm_hour;       
    ts->minute = tm->tm_min;     
    ts->second = tm->tm_sec;     
    return;

}

BASE2_INT64 CCommonDate::TimestampToCurrSecond (TIMESTAMP_STRUCT &ts)
{
    return ts2l ( ts );
}

BASE2_INT64 CCommonDate::TimestampToSecond (TIMESTAMP_STRUCT &ts)
{
	struct tm tmTime;

	tmTime.tm_year = ts.year - 1900;
	tmTime.tm_mon  = ts.month - 1;
	tmTime.tm_mday = ts.day;
	tmTime.tm_hour = ts.hour;
	tmTime.tm_min  = ts.minute;
	tmTime.tm_sec  = ts.second;

	return (mktime(&tmTime) + 2208988800UL);
}

