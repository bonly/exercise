
#include "r5api.h"
#include "r5log.h"

#include <sys/time.h> 
#include <time.h> 
#include <stdio.h>
#include <assert.h>
#include <netinet/in.h>
#include <ctype.h>
#include <dlfcn.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>





 

//-----------------------------------------------------------------------------
void* loadLibrary(const char *name)
{
    void * slh = 0;
    //slh = dlopen(name, RTLD_NOW);
    slh = dlopen(name, RTLD_LAZY);
    //slh = dlopen(name, RTLD_GLOBAL);
    if(slh == 0)
    {
        fprintf(stderr,"Load library %s failed!\n", name);
        fprintf(stderr,"%s\n", dlerror());
    }
    return slh;
}

//-----------------------------------------------------------------------------
void closeLibrary(void *library)
{
    ::dlclose(library);
}

//-----------------------------------------------------------------------------
BASE2_UINT64 net_htonll(BASE2_UINT64 hostll)
{
    static int big_endian = -1;
    if ( big_endian == -1 )
    {
        int16_t magic = 0x0102;
        char magicbuf[2];
        memcpy(magicbuf,(char*)&magic,2);
    
        if(magicbuf[0] == 0x01)
        {
            big_endian = 1;
        }
        else
        {
            big_endian = 0;
        }
    }
    if(big_endian == 0)
    {
        BASE2_UINT32 *i1 = (BASE2_UINT32*)&hostll;
        BASE2_UINT32 *i2 = i1 + 1;
      
        *i1 = htonl(*i1);
        *i2 = htonl(*i2);
      
        BASE2_UINT32 i3 = *i1;
        *i1 = *i2;
        *i2 = i3;
    }
    return hostll;
}

BASE2_UINT64 net_ntohll(BASE2_UINT64 netll)
{
    static int big_endian = -1;
    if ( big_endian == -1 )
    {
        int16_t magic = 0x0102;
        char magicbuf[2];
        memcpy(magicbuf,(char*)&magic,2);

        if(magicbuf[0] == 0x01)
        {
            big_endian = 1;
        }
        else
        {
            big_endian = 0;
        }
    }
    if(big_endian == 0)
    {
        BASE2_UINT32 *i1 = (BASE2_UINT32*)&netll;
        BASE2_UINT32 *i2 = i1 + 1;
      
        *i1 = ntohl(*i1);
        *i2 = ntohl(*i2);
      
        BASE2_UINT32 i3 = *i1;
        *i1 = *i2;
        *i2 = i3;
    }
    return netll;
}

//-----------------------------------------------------------------------------
BASE2_INT64 currentTimeSeconds()
{
    struct timeval tp;
    gettimeofday(&tp, 0);
    return (BASE2_INT64)tp.tv_sec;
}

BASE2_INT64 currentTimeMillis()
{
    struct timeval tp;
    gettimeofday(&tp, 0);

    BASE2_INT64  seconds = tp.tv_sec;
    BASE2_INT64  microseconds = tp.tv_usec;

    return ( (seconds * 1000) + (microseconds / 1000));  
}

BASE2_INT64 currentTimeMicroSeconds()
{
    struct timeval tp;
    gettimeofday(&tp, 0);

    BASE2_INT64  seconds = tp.tv_sec;
    BASE2_INT64  microseconds = tp.tv_usec;

    return (seconds * 1000 * 1000) + microseconds;
}

#define MK_TIME(tm) mktime(tm)


time_t getCurrentTime()
{
    time_t  t;
    time(&t);
    return t;
}

//-----------------------------------------------------------------------------
int tmToString(struct tm *time, char *buf, int size)
{
    snprintf(buf, size, "%04d%02d%02d%02d%02d%02d",
             time->tm_year+1900, time->tm_mon+1, time->tm_mday,
             time->tm_hour, time->tm_min, time->tm_sec);
    return 0;
}

int timeToString(time_t tm, char *buf, int size)
{
    struct  tm  tt;
#ifdef SunOS
    memcpy(&tt, localtime(&tm), sizeof(struct tm));
#else
    localtime_r(&tm, &tt);
#endif
  
    return tmToString(&tt, buf, size);
}

//-----------------------------------------------------------------------------
size_t format_hexdump (const char *buffer,
                     size_t size,
                     char *obuf,
                     size_t obuf_sz)
{
    u_char c;
    char textver[16 + 1];

    // We can fit 16 bytes output in text mode per line, 4 chars per byte.
    size_t maxlen = (obuf_sz / 68) * 16;

    if (size > maxlen)
        size = maxlen;

    size_t i;

    size_t lines = size / 16;
    for (i = 0; i < lines; i++)
    {
        size_t j;

        for (j = 0 ; j < 16; j++)
        {
            c = (u_char) buffer[(i << 4) + j];    // or, buffer[i*16+j]
            sprintf (obuf, "%02x ", c);
            obuf += 3;
            if (j == 7)
            {
                sprintf (obuf, " ");
                ++obuf;
            }
            textver[j] = isprint (c) ? c : '.';
        }

        textver[j] = 0;
 
        sprintf (obuf, "  %s\n", textver);

        while (*obuf != '\0')
            obuf++;
    }

    if (size % 16)
    {
        for (i = 0 ; i < size % 16; i++)
        {
            c = (u_char) buffer[size - size % 16 + i];
            sprintf (obuf, "%02x ", c);
            obuf += 3;
            if (i == 7)
            {
                sprintf (obuf, " ");
                ++obuf;
            }
            textver[i] = isprint (c) ? c : '.';
        }
 
        for (i = size % 16; i < 16; i++)
        {
            sprintf (obuf, "   ");
            obuf += 3;
            if (i == 7)
            {
                sprintf (obuf, " ");
                obuf++;
            }
            textver[i] = ' ';
        }

        textver[i] = 0;
        sprintf (obuf, "  %s\n", textver);
    }
    return size;
}



void getQueueFileName(const string &strQueueName ,string &strFileName,string strEtcPath)
{
    strFileName = strEtcPath;
    strFileName += "/queue/";
    strFileName += strQueueName;
}

int connectQueue(const char *wr_name)
{ 
    key_t external_id = ftok(wr_name, 1);
    if(external_id == -1)
    {
        fprintf(stderr,"connectQueue name : %s ����ʧ��\n", wr_name);
        return -1;
    }
    
    int q_id = msgget(external_id, 0666|IPC_CREAT);
    return q_id;
}

//�����������źŴ����������غ�,�Ƿ��ж�,���ǻص��жϴ�,ȱʡΪ�ж�
sigfunc* my_signal(int signo, sigfunc* func , bool interrupt /*= true*/)
{
    struct sigaction act, oact;
    act.sa_handler=func;
    sigemptyset(&act.sa_mask);
    act.sa_flags=0;
    
    if(interrupt == false)  //���жϵ���
    {
        act.sa_flags |= SA_RESTART;
    }
        
    if(sigaction(signo, &act, &oact)<0)
        return SIG_ERR;
        
    return oact.sa_handler;
}


//��ʼ��SFEP��־�ȼ�
void initLogLevel(R5_Log *plog,IniConfig &conf_sfep)
{
    IniSection *sct_log = conf_sfep.getSection("COMMON");
    int level_file = 40;
    int level_term = 40;
    string levf_str = sct_log->getValue("LOG_LEVEL_FILE");
    if(strlen(levf_str.c_str()) != 0)
    {
        level_file = atoi(levf_str.c_str());
    }
   
    string levt_str = sct_log->getValue("LOG_LEVEL_TERM");
    if(strlen(levt_str.c_str()) !=0 )
    {
        level_term = atoi(levt_str.c_str());
    }
	SET_LOG_LEVEL(plog, level_file, level_term);
}


 /**************************************
 *SingleProcBegin()�������:������
 *�����룺1�����Ѿ�����
 *        0 �ɹ�
 *        -1���������ļ�ʧ��
 *        -2����Ľ�����Ϊ��
 *        -3OCS_HOME������·��û����
 *        -4д�����ļ�ʧ��
 *        -5�����ļ����ڵ���ʧ��
 *        -6�������ļ�ʧ�� 
 ******************************************/

//�������ȡ�����ļ�����֤�Ե���������
int SingleProcBegin(const char *szProcName , const char * szPath)
{   
    if(strlen(szProcName) == 0)
    {	
    	printf("the input process name is null!\n");
        return -2;
    }
    
    char szProcFile[MAX_PATH_LEN];   //�ļ�·������
    char szHomeDir[MAX_PATH_LEN];   //��·��
    char szPid[MAX_PID_LEN];  // ���̺�
    
    memset(szProcFile, 0, sizeof(szProcFile));
    memset(szHomeDir, 0, sizeof(szHomeDir));
    memset(szPid, 0, sizeof(szPid));
    
    
    if(szPath== NULL)
    {  
    	printf("szPath is NULL , please set correct path to save single proc run file!\n");
        return -3;
    }
    sprintf(szHomeDir,"%s", szPath);

    sprintf(szProcFile,"%s/%s.pid", szHomeDir, szProcName);
    
    //�жϽ����ļ��Ƿ��Ѿ�����
    if(access(szProcFile, F_OK) == 0)
    {	
        int ret = open(szProcFile, O_RDWR);
    	
        if(ret == -1)
        {	
            printf("failed to open the exsit process file %s!\n", szProcName);
            return -5;
        }
        char read_buf[MAX_PID_LEN];
        char write_buf[MAX_PID_LEN];
        memset(read_buf, 0, sizeof(read_buf));
        memset(write_buf, 0, sizeof(write_buf));
        if(read(ret, read_buf, sizeof(read_buf)) < 0)//�������ļ�      
        {
            close(ret);
            printf("failed to read %s \n", szProcName);
            return -6;	//�������ļ�ʧ��
        }
    	
        int e_pid = atoi(read_buf);
        if( (e_pid!=0) && (kill(e_pid, 0) == 0) )
        {	
            close(ret);
            printf("the process is already exsit!\n");
            return 1;   //�����Ѿ�����
        }
        else	//���̲�������д
        {   
        	close(ret);
        	ret = open(szProcFile, O_RDWR|O_TRUNC);
        	if(ret == -1)
            {	
                printf("failed to open the exsit process file %s!\n", szProcName);
                return -5;
            }
            sprintf(write_buf, "%d\n", getpid());
            if(write(ret, write_buf, sizeof(write_buf)) == -1)
            {   
            	close(ret);
                printf("failed to rewrite process file %s!\n", szProcName);
                return -4;	//��дʧ��
            }
            close(ret);
            return 0;	//��д�ɹ�
        }  

    }
    else
    {
        //���������ļ�
        int ret = open(szProcFile, O_CREAT|O_EXCL|O_RDWR, 0775);
        if(ret == -1)
        {   
    	    printf("failed to create file %s\n", szProcFile);
            return -1;
        }

        ///���ļ�����д���̺�
        sprintf(szPid, "%d\n", getpid());
        if(write(ret, szPid, sizeof(szPid)) == -1)
        {   
        	close(ret);
    	    printf("failed to write to %s", szProcFile);
            return -4;
        }

        //�ر��ļ�
        close(ret);

        return 0;
    }

}

//���ַ�������ַ�ת����Сд��ĸ
//��ϵͳƽ̨�Ѿ����ڣ���������ʵ�ֱ�����
#ifndef HAVE_STRLWR

int strlwr(char *str)
{
    if(str == NULL)
    {
        return -1;
    }    
    while(*str)
    {
        if((*str >=0x41) && (*str<=0x5a))
        {
            *str+=0x20;
        }
        str++;
    }

    return 0;
}

#endif





