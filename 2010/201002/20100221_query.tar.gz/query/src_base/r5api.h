
#ifndef __R5API_H__
#define __R5API_H__

#include <stdlib.h>
#include <string>
#include <assert.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include "iniconfig.h"
#include "base_constants.h"
using namespace std;


typedef void sigfunc(int);
   

//-----------------------------------------------------------------------------
// library operation
extern void* loadLibrary(const char *name);
extern void* getLibFun(void *library, const char *name);
extern void closeLibrary(void *library);


extern void getQueueFileName(const string &strQueueName ,string &strFileName,string strEtcPath);
extern sigfunc* my_signal(int signo, sigfunc* func , bool interrupt = true);
extern int connectQueue(const char *wr_name);

#ifndef HAVE_STRLWR     //当系统平台已经存在，则不用重新实现本函数
extern int strlwr(char *str);
#endif
//

#define MAX_PATH_LEN   1024
#define MAX_PID_LEN    128
#define MAX_PROCNAME   512

extern int SingleProcBegin(const char *szProcName ,const char *szPath);

//初始化日志
//void initLogLevel(IniConfig &conf_sfep);
void initLogLevel(R5_Log *plog,IniConfig &conf_sfep);
//-----------------------------------------------------------------------------
// net operation
extern BASE2_UINT64 net_htonll(BASE2_UINT64 hostll);
extern BASE2_UINT64 net_ntohll(BASE2_UINT64 netll);

//-----------------------------------------------------------------------------
// time operation
extern BASE2_INT64 currentTimeSeconds();
extern BASE2_INT64 currentTimeMillis();
extern BASE2_INT64 currentTimeMicroSeconds();

#define MK_TIME(tm) mktime(tm)

#ifdef SunOS
    #define LOCAL_TIME(tag_t, t_t) memcpy(&tag_t, localtime(&t_t), sizeof(struct tm));
#else
    #define LOCAL_TIME(tag_t, t_t) localtime_r(&t_t, &tag_t);
#endif

extern time_t getCurrentTime();

//-----------------------------------------------------------------------------
extern int tmToString(struct tm *time, char *buf, int size);
extern int timeToString(time_t tm, char *buf, int size);

//-----------------------------------------------------------------------------
// obuf_sz = (size+15)/16*68
size_t format_hexdump (const char *buffer, size_t size, char *obuf, size_t obuf_sz);

struct msgform
{
    long mtype;
    char mtext[1024*4];
};

#endif // __R5API_H__
