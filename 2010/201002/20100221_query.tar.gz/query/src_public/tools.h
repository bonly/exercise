#ifndef __TOOLS_H__
#define __TOOLS_H__
/*
* date:2010-05-11
* author:lqb
*/

/* ʹ��base���ӡ��־ */

#include"r5log.h"


#define INIT_LOG(plog, log_path, log_header, file_level, term_level)\
    if(SET_LOG_DIR(plog, log_path) < 0)\
    {\
        printf("log path can not access:%s\n", log_path);\
        exit(-1);\
    }\
    SET_LOG_LEVEL(plog, file_level, term_level);\
    SET_LOG_NAME_HEAD(plog, log_header);
    
    

static int proc_env(char* env, char* buff, size_t len);

int path_string(const char* envpath, char* path, size_t pathlen);

int get_conf_list(const char* src, char (&list)[32][32]);

int recv_fd(int fd, void* ptr, size_t size, int* recvfd);
	
int send_fd(int fd, void* ptr, size_t size, int sendfd);

#endif
