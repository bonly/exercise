/*
*
*/
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>

#include"share_mem.h"

share_mem::share_mem(){	
}

share_mem::~share_mem(){	
}

int share_mem::create(const char *shmname, int block_cnt,int block_size, int is_froce){
    key_t key = ftok(shmname, 1);
    if(key_t(-1) == key){
    	m_err = FTOK_ERR;
        return -1;
    }

    size_t shmsize = sizeof(shm_header) + sizeof(connection_info) * FD_SIZE
    			  + (sizeof(block_header) + block_size) * block_cnt;
    			  
    m_shmid = shmget(key, 0, 0); //�Ȳ鿴�����ڴ��Ƿ����
    
    if(-1 == m_shmid){
        //��������ڣ����½�һ��
        m_shmid = shmget(key, shmsize, IPC_CREAT | IPC_EXCL | 0660);
    } else {
        if(0 == is_froce){
            //������ڣ���û��ʹ��-Fģʽ���򱨸湲���ڴ��Ѿ����ڵĴ���
            return -1;   
        }else{
            //������ڣ���ʹ����-Fģʽ������ɾ��ԭ�����ڴ棬���½�һ��
   		    struct shmid_ds buf;
		    memset(&buf, 0, sizeof(buf));
		    if(shmctl(m_shmid, IPC_RMID, &buf) < 0)
		    {
			    m_err = SHMDEL_ERR;
			    return -1;
		    }
	
		    m_shmid = shmget(key, shmsize, IPC_CREAT | IPC_EXCL | 0660);

		    if(m_shmid < 0)
		    {
			    m_err = SHMGET_ERR;
			    return -1;
		    }               
        }        
    }			  
	
	m_shmptr = shmat(m_shmid, 0, 0);
    if(0 >= m_shmptr){
    	m_err = SHMAT_ERR;
        return -1;
    }

    memset(m_shmptr, 0, shmsize);

	//����ӳ��
	char* tmpptr = static_cast<char*>(m_shmptr);
	
	m_pheader = reinterpret_cast<shm_header*>(tmpptr);
	
	m_pheader->block_size = block_size;
	m_pheader->block_cnt = block_cnt;
	
	tmpptr += sizeof(shm_header);
	
	
	for(int i = 0; i < FD_SIZE; ++i){
	    m_info[i].pinfo = reinterpret_cast<connection_info*>(tmpptr);
	    tmpptr += sizeof(connection_info);	   
	}

	for(int i = 0; i < m_pheader->block_cnt; i++)
	{
		m_pblock[i].pheader = reinterpret_cast<block_header*>(tmpptr);	
		tmpptr += sizeof(block_header);
		
		m_pblock[i].pbody = tmpptr;
		tmpptr += m_pheader->block_size;
	}


    return 0;
}


int share_mem::attach(const char *shmname)
{
    key_t key = ftok(shmname, 1);
    if(key_t(-1) == key)
    {
        return -1;
    }

    m_shmid = shmget(key, 0, 0);
    if(-1 == m_shmid)
    {
        return -1;
    }

    m_shmptr = shmat(m_shmid, 0, 0);
    if(0 >= m_shmptr)
    {
        return -1;
    }

	//����ӳ��
	char* tmpptr = static_cast<char*>(m_shmptr);
    
	m_pheader = reinterpret_cast<shm_header*>(tmpptr);
	
	int block_size = m_pheader->block_size;
	int block_cnt = m_pheader->block_cnt;
	
	tmpptr += sizeof(shm_header);

	for(int i = 0; i < FD_SIZE; ++i){
	    m_info[i].pinfo = reinterpret_cast<connection_info*>(tmpptr);
	    tmpptr += sizeof(connection_info);	   
	}

	for(int i = 0; i < block_cnt; i++)
	{
		m_pblock[i].pheader = reinterpret_cast<block_header*>(tmpptr);	
		tmpptr += sizeof(block_header);
		
		m_pblock[i].pbody = tmpptr;
		tmpptr += block_size;
	}	
	
	return 0;
}


void share_mem::detach()
{
    if(0 < m_shmptr)
    {
        shmdt(m_shmptr);
        m_shmptr = NULL;
    }
        
    m_pheader = NULL;
    
}

	
void share_mem::destroy(){
    detach();

    if(-1 != m_shmid){
        //ɾ�������ڴ�ǰ���ж��������ӵĽ������Ƿ����0
        //�������0����ɾ�������ڴ棬�����ɾ�������ڴ�
        
        struct shmid_ds buf;
        memset(&buf, 0, sizeof(buf));    
        int ret;
        if((ret = shmctl(m_shmid, IPC_STAT, &buf)) < 0){
			return;
		}

		if (0 != buf.shm_nattch){
			  //printf("Can't delete to share memory,The \"shm_nattch\" != 0!\n");
			  return;
		}
		
        shmctl(m_shmid, IPC_RMID, 0);
        m_shmid = -1;
    }	
}


bool share_mem::is_exist(const char* shmname){
    key_t key = ftok(shmname, 1);
    if(key_t(-1) == key)
    {
        return false;
    }

    m_shmid = shmget(key, 0, 0);
    if(-1 == m_shmid)
    {
        return false;
    }       
    
    m_shmid = -1;
    
    return true;
}

