#ifndef __H_TYPE_H__
#define __H_TYPE_H__

#include "net_buffer.h"

//typedef unsigned long long uint64_t; 

#define MAX_FILE_LEN 256
#define IP_LENGTH 32

#define FD_SIZE 2048
#define BLOCK_CNT_MAX 16
#define PROTOCOL_HEAD_LEN 60

#define LISTENMAX 10
#define MAX_NODE_COUNT 10

#define FD_CLOSE 0
#define FD_SHUTDOWN 1

#define PRO_HEAD_LEN 60
#define MAX_MSG_LENGHT 1024
#define SMPP_MAX_SYSTEM_ID               16
#define SMPP_MAX_PASSWORD                9       //Password最大长度,用于BIND_RECEIVER
#define SMPP_MAX_SYSTEM_TYPE             13      //System_type最大长度,用于BIND_RECEIVER

#define SMPP_MAX_PATH_LEN 					256

#define STAND_MUNBER_LEN 11
#define SMPP_NUMBER_LEN 21


#define RE_SUCCESS 0
#define RE_FAILED -1

const int PRO_COMMAND_LEN = 9;
const int PRO_SEQUENCE_LEN = 7;
const int PRO_LENGTH_LEN = 7;
const int PRO_SYSTEM_LEN = 19;
const int PRO_DECOM_LEN = 10;

const int PRO_SUB_NO_LEN = 11;
const int PRO_BILL_PERIOD_LEN = 6;
const int PRO_OPRID_LEN = 16;
const int PRO_SWITCH_FLAG_LEN = 4;
const int PRO_DISTRICT_LEN = 6;
const int PRO_DATETIME_LEN = 14;
const int PRO_RANDOM_CODE_LEN = 10;


class RecvBuffer;

struct ConBuf
{
	enum 
	{//buf_status
		RecvHead = 0,
		RecvContent = 1,
		SendToSvr = 2,
		BufOk=3,		
		Forbid=4,
		WaitBind=5
	};
	
	int buf_status;
	RecvBuffer buffer;
	bool is_deny;//是否拒绝

};

struct Con
{
	enum
	{
		Broken=0,
		Connected=1
	};
	
	time_t active_time;//上一次收发数据的时间
	short status;      //socket status
	struct ConBuf cbuf;
};

//#define LIS_SOCK 0
#define USER_SOCK 1
#define SOCK_PAIR 2

struct FDList
{
	short type;//描述符类型：USER_SOCK:1，SOCK_PAIR:2
	char ip[32]; //地址
	int port; //端口
	int buf_index;
    int unique_id;
	struct Con user_con;
};



struct SysConfig
{
    SysConfig() :
        version(1),
        heart_interval(15),
        max_np_con(10),
        gs_protocal(0),
        timeout_interval(0),
        file_log_level(0),
		term_log_level(0),
		client_listen_port(0),
		server_port(0),
		recon_inv(0),
		max_client_con(0),
		overload_enable(0),
		max_msg(0),
		cycle_time(0),
		shmkey(0)
    {
        memset(log_path, 0, sizeof(log_path));
        memset(log_header, 0, sizeof(log_header));
        memset(client_bind_ip, 0, sizeof(client_bind_ip));
        memset(server_ip, 0, sizeof(server_ip));
		memset(NumberReangeFile, 0, sizeof(NumberReangeFile));
		memset(HashNumberFile, 0, sizeof(HashNumberFile));
		//memset(&loginInfo, 0, sizeof(loginInfo));
		//memset(&nodeList, 0, sizeof(nodeList));
    }

	int version;//the protocal vertion ....
	int heart_interval;//game server heart packet interval
	int max_np_con;//max game server connection
	int gs_protocal;

	int timeout_interval;//second

	int file_log_level;
	int term_log_level;
	int client_listen_port;//监听端口
	int server_port;//网元端口
	int recon_inv;//重连时间间隔	
	int max_client_con;
	int overload_enable;
	int max_msg;
	int cycle_time;
	char log_path[SMPP_MAX_PATH_LEN];
	char log_header[128];
	char client_bind_ip[32];
	char server_ip[32];        //网元IP 地址
	unsigned int shmkey;
	char forward_shm_file[SMPP_MAX_PATH_LEN];		//分发规则共享内存
	char NumberReangeFile[SMPP_MAX_PATH_LEN];		//号段分发配置文件
	char HashNumberFile[SMPP_MAX_PATH_LEN];		//散号分发配置文件 
	//stLoginInfo loginInfo;					// 登录配置，系统ID ，密码等
	//stNodeConf nodeList[MAX_NODE_COUNT];		// 最多10个节点
};

struct ProcessStatus
{
	int gs_count;
	int user_count;

	int accpt_count;
	int request_count;
};

//@todo 确定值,取消魔数
struct IP_MSG
{
   pid_t client_pid;
   int index;
   int port;
   char ip[32];
   IP_MSG():client_pid(-1),index(-1),port(-1)
   {
       memset (ip, 0, 32);
   }
};

#endif

