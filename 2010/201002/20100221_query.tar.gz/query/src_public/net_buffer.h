#ifndef __NET_BUFFER_H__
#define __NET_BUFFER_H__

#include <string.h>
#include <sys/uio.h>


const int RECV_BUFF_SIZE = 1024 * 4;
//const int SEND_BUFF_COUNT = 128;


class RecvBuffer
{
public:
    RecvBuffer();
    ~RecvBuffer(){}
    
    char* get_write_ptr();

    const char* get_read_ptr();

    int get_data_size() const;

    int get_free_size() const;

    void set_write_size(int size);

    void set_read_size(int size);

    bool is_full() const;

    void clear();

private:
    char        m_buff[RECV_BUFF_SIZE];
    int         m_ptr;
    int         m_size;
    bool        m_dump;
};

#if 0

struct SendMsgInfo
{
    SendMsgInfo(int _type, uint32_t src, const char* _msg, int _size) :
        type(_type), source(src), mesg(_msg), size(_size) {}

    SendMsgInfo(){}

    int         type;               /* ��Ϣ���ͣ�CCR��CCR��CER�� */
    uint32_t    source;             /* Դ���� */
    const char* mesg;               /* ָ���ͻ�������Ϣ����ָ�� */
    int         size;               /* ��Ϣ���Ĵ�С */

};


typedef const SendMsgInfo* SendMsgInfoPtrArray[SEND_BUFF_COUNT + 1];

typedef struct iovec IoVecArray[SEND_BUFF_COUNT + 1];

class SendBuffer
{
private:
    struct BuffStruct
    {
        BuffStruct();
        
        int         sended_size;    /* �ѷ��ͳ��� */
        SendMsgInfo msgInfo;
        char        buff[MAX_MSG_LENGHT];
    };
    
public:
    SendBuffer();

    int get_write_ptr(char*& ptr, int& size);

    bool is_empty();

    bool is_full();

    int write_message(const SendMsgInfo& msgInfo);

    int get_read_ptr(IoVecArray& iov);

    int set_read_size(int size, SendMsgInfoPtrArray& msgInfo);

    int discard_incomplete_msg(const SendMsgInfo*& pMsgInfo);

    int discard_all_msg(SendMsgInfoPtrArray& msgInfo);


private:
    static void move_buffptr(int& ptr, int count = 1);

private:
    BuffStruct  m_buff[SEND_BUFF_COUNT];    /* ���λ��������� */
    int         m_ptr;                      /* ����������ͷ����λ�� */
    int         m_msg_count;                /* �������е���Ϣ�� */
};

#endif

#endif
