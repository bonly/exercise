#ifndef __SHARE_MEM_H__
#define __SHARE_MEM_H__
/*
* auther:lqb
* date:2010-04-29
*/

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/time.h>

#include "type.h"

////针对block_header中type类型定义
#define NET_RECV  1
#define NET_SEND  2
//#define OCS_RECV  3
//#define OCS_SEND  4

//!!!!!!!该结构体需要清理!!!!!##############
struct block_header
{
	int type;                   //1：接收  2：发送
	int is_use;                 //0：未使用  1：使用
	pid_t pid;                  //网络进程PID
	pid_t ppid;                 //父进程ID
	int pair_index;             //与之配对的模块缓冲区的index
	int size;                   //总大小
	volatile int readpos;                //读位置
	volatile int writepos;               //写位置
	char sem_file[128];         //信号灯所关联的文件，每个进程都semget一次
	int status;                 //网络连接状况标识

	int sock_fd;
	time_t  connect_time;       //建立连接的时间
	time_t  disconnect_time;    // 断连时间
	struct timeval read_time;    //query_processor 最后读的时间戳
	struct timeval write_time;   //query_processor 最后写的时间戳
	time_t net_time;			 //网络模块最后读或者写的时间戳
	struct timeval heart_bit_time;      //心跳时间戳
	int heart_bit_failed_times;         //心跳连续失败次数
	uint32_t reconn;                    //重连次数 */
	struct timeval volatile last_lock;           //最后上锁时间
};


struct connection_info{
    int unique_id;
    int status;
    char system[PRO_SYSTEM_LEN + 1];
    char random_code[PRO_RANDOM_CODE_LEN + 1];
    char login_time[PRO_DATETIME_LEN + 1];
};

struct share_info{
    connection_info* pinfo;
};

struct block
{
	block_header *pheader;
	//char *pstatistic;
	char *pbody;
};


struct shm_header{
	int block_cnt;
	int block_size;

};


class share_mem
{

friend class buffer;

public:

	enum
	{
		FTOK_ERR   = 1001,
		SHMGET_ERR = 1002,
		SHMAT_ERR  = 1003,
		SHMDEL_ERR = 1004
	};

    share_mem();
    ~share_mem();

    int create(const char *shmname, int block_cnt, int block_size, int is_froce = 0);

    int attach(const char *shmname);

    bool is_exist(const char *shmname);

    void detach();
    void destroy();

    shm_header *get_shm_header()
    {
        return m_pheader;
    }

    int error(){return m_err;}

    share_info m_info[FD_SIZE];

	block m_pblock[BLOCK_CNT_MAX];

private:
    int         m_shmid;
    void*       m_shmptr;
	shm_header *m_pheader;
	int m_err;
};

#endif


