/*
*
*
*/

#include <string.h>
#include <stdlib.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <fcntl.h>

#include "tools.h"



static int proc_env(char* env, char* buff, size_t len)
{
    char* tmpenv = env;
    size_t envlen = strlen(env);

    if(0 == envlen)     /* 变量名长度为0 */
    {
        return -1;
    }

    if(1 < envlen)      /* 处理花括号 */
    {
        if('{' == env[0])
        {
            if('}' != env[envlen - 1])      /* 花括号不对称 */
            {
                return -1;
            }
        }
        else if('}' == env[envlen - 1])     /* 花括号不对称 */
        {
            return -1;
        }

        /* 去掉花括号 */
        if('}' == env[envlen - 1])
        {
            if(0 >= (envlen - 2))
            {
                return -1;
            }

            env[envlen - 1] = '\0';
            tmpenv = env + 1;
        }
    }

    const char* value = getenv(tmpenv);

    if(NULL == value)   /* 无法取得环境变量的值 */
    {
        return -1;
    }

    size_t valuelen = strlen(value);

    if(valuelen > len)  /* 缓冲区长度不足 */
    {
        return -2;
    }

    memcpy(buff, value, valuelen);
    return valuelen;
}


int path_string(const char* envpath, char* path, size_t pathlen)
{
    char c;
    char env[512];
    int i = 0;
    int retval = 0;
    int envidx = 0;
    int envpos = 0;
    uint32_t pathidx = 0;
    bool read_env = false;

    while('\0' != (c = envpath[i]))
    {
        switch(c)
        {
        case '$':
            if(read_env)                /* 输出当前的环境变量 */
            {
                env[envidx] = '\0';
                retval = proc_env(env, &path[pathidx], pathlen - pathidx);

                if(0 < retval)
                {
                    pathidx += retval;
                }
                else
                {
                    if(-2 == retval)
                    {
                        return -1;
                    }

                    return envpos + 1;
                }
            }

            read_env = true;            /* 环境变量开始 */
            envpos = i;
            envidx = 0;
            break;

        case ' ':
        case '/':
            if(read_env)
            {
                read_env = false;       /* 环境变量结束，输出当前的环境变量 */
                env[envidx] = '\0';
                envidx = 0;
                retval = proc_env(env, &path[pathidx], pathlen - pathidx);

                if(0 < retval)
                {
                    pathidx += retval;
                }
                else
                {
                    if(-2 == retval)
                    {
                        return -1;
                    }

                    return envpos + 1;
                }
            }

            if(pathlen <= pathidx)       /* 缓冲区长度不够 */
            {
                return -1;
            }

            path[pathidx] = c;
            ++pathidx;
            break;

        default:
            if(read_env)                /* 当前正在读环境变量 */
            {
                env[envidx] = c;
                ++envidx;
            }
            else
            {
                if(pathlen <= pathidx)   /* 缓冲区长度不够 */
                {
                    return -1;
                }

                path[pathidx] = c;
                ++pathidx;
            }

            break;
        }

        ++i;
    }

    if(read_env)
    {
        env[envidx] = '\0';
        retval = proc_env(env, &path[pathidx], pathlen - pathidx);

        if(0 < retval)
        {
            pathidx += retval;
        }
        else
        {
            if(-2 == retval)
            {
                return -1;
            }

            return envpos + 1;
        }
    }

    path[pathidx] = '\0';
    
    return 0;
}


int get_conf_list(const char* src, char (&list)[32][32])
{
    char c;
    bool blank_char = true;
    int i = 0;
    int name_idx = 0;
    int item_count = 0;
    char item_name[32];

    while('\0' != (c = src[i]))
    {
        if(isblank(c) && (!blank_char))
        {
            blank_char = true;
            item_name[name_idx] = '\0';
            strcpy(list[item_count], item_name);
            name_idx = 0;
            ++item_count;
        }
        else
        {
            if(blank_char)
            {
                if(item_count == 32)
                {
                    return -1;  /* 超过业务类型的最大数 */
                }

                blank_char = false;
            }

            if(32 - 1 <= name_idx)
            {
                return -1;      /* 业务名字过长 */
            }

            item_name[name_idx] = c;
            ++name_idx;
        }

        ++i;
    }

    if(!blank_char)
    {
        blank_char = true;
        item_name[name_idx] = '\0';
        strcpy(list[item_count], item_name);
        name_idx = 0;
        ++item_count;
    }

    return item_count;
}


int recv_fd(int fd, void* ptr, size_t size, int* recvfd)
{	
	struct msghdr msg;	
	struct iovec iov[1];	
	int ret = 0;		
	msg.msg_name = NULL;	
	msg.msg_namelen = 0;
	iov[0].iov_base = ptr;	
	iov[0].iov_len = size;		
	msg.msg_iov = iov;	
	msg.msg_iovlen = 1;	

#if defined (__WM_IBM_AIX)  || defined (__WM_LINUX)
    union {
        struct cmsghdr cm;
        char control[CMSG_SPACE(sizeof(int))];
    }control_un;
	struct cmsghdr *cmptr;
	
	msg.msg_control = control_un.control;	
	msg.msg_controllen = sizeof(control_un.control);	
	
	
	if((ret = recvmsg(fd, &msg, 0)) <= 0 )	
	{		
		return ret;			
	}
	
	if((cmptr = CMSG_FIRSTHDR(&msg)) != NULL && \
    	cmptr->cmsg_len == CMSG_LEN(sizeof(int)))
    {
        if(cmptr->cmsg_level != SOL_SOCKET)
        {
            return -1;
        }
        if(cmptr->cmsg_type != SCM_RIGHTS)
        {
            return -1;
        }
        
        *recvfd = *((int *)CMSG_DATA(cmptr));
    }
    else
    {
        *recvfd = -1;
    }
#else
	int newfd = 0;	
	msg.msg_accrights = (caddr_t) &newfd;	
	msg.msg_accrightslen = sizeof(int);		
	
	if((ret = recvmsg(fd, &msg, 0)) <= 0 )	
	{		
		return ret;			
	}
	
	if(msg.msg_accrightslen == sizeof(int))	
	{		
		*recvfd = newfd;			
	}
    else	
	{		
		*recvfd = -1;			
	}		
#endif
	
	return ret;
}


int send_fd(int fd, void* ptr, size_t size, int sendfd)
{	
	struct msghdr msg;	
	struct iovec iov[1];			
#if defined (__WM_IBM_AIX)  || defined (__WM_LINUX)
    union {
        struct cmsghdr cm;
        char control[CMSG_SPACE(sizeof(int))];
    }control_un;
	struct cmsghdr *cmptr;
	
	msg.msg_control = control_un.control;	
	msg.msg_controllen = sizeof(control_un.control);
	
	cmptr = CMSG_FIRSTHDR(&msg);
	cmptr->cmsg_len = CMSG_LEN(sizeof(int));
	cmptr->cmsg_level = SOL_SOCKET;
	cmptr->cmsg_type = SCM_RIGHTS;
	*((int *) CMSG_DATA(cmptr)) = sendfd;
#else
	msg.msg_accrights = (caddr_t) &sendfd;	
	msg.msg_accrightslen = sizeof(int);
#endif

	msg.msg_name = NULL;	
	msg.msg_namelen = 0;				

	iov[0].iov_base = ptr;	
	iov[0].iov_len = size;		
	msg.msg_iov = iov;	
	msg.msg_iovlen = 1;	 			

	return sendmsg(fd, &msg, 0);	
}

