#include <stdlib.h>
#include <string.h>
#include "crypt.h"
#include "des.h"
#include "coder.h"


//const char key[]={0,2,0,0,9,3,5,1,9,8,0,0,9,1,7};
const char key[]={0,2,0,0,9,3,5};


bool Crypt::encrypt(char const * const in, char *out, long outlen)
{
	if(in == NULL || in[0] == '\0' || out == NULL || outlen <= 0) return false;

	int deslen =  ((strlen(in) + 7) / 8) * 8; //����3Des��Ҫ�ĳ���
	int baselen = (deslen + 2)/3*4; //����Base64��Ҫ�ĳ���

	if(outlen <= baselen) return false;

	char* ostr = new char[baselen + 1];

	if(false == des_go(ostr, (char*)in, strlen(in), 
				key, sizeof(key), ENCRYPT)) 
		return false;

	/*
	   int len  = Base64Encod(ostr, strlen(ostr), out);
	   out[len] = '\0';
	   */

	Coder::base64_encode(ostr, deslen, out);

	delete [] ostr;

	return true;
}

bool Crypt::decrypt(char const * const in, char *out, long outlen)
{
	if(in == NULL || in[0] == '\0' || out == NULL || outlen <= 0) return false;
	if((size_t)outlen < strlen(in)) return false;

	memset(out, '\0', outlen);

	/*
	   int len = Base64Decod((char*)in, strlen(in), out);
	   out[len] = '\0';
	   */

	int len = Coder::base64_decode((char*)in , strlen(in), out);
	out[len] = '\0';

	if(false == des_go(out, out, len, key, sizeof(key), DECRYPT)) {
		return false;
	}
	return true;
}
