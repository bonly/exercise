/*
*
*
*/

#include <mysql.h>

#include "query_protocol.h"
#include "comm_structs.h"
#include "protocol_helper.h"
#include "encrypt.h"

//from base lib
#include"iniconfig.h"
#include"r5api.h"

R5_Log *g_r5_plog;

MYSQL * g_protocoldb = NULL;

int initialize(const char* conf_file, R5_Log *plog){
    if(NULL == plog){
        fprintf(stderr, "plog is NULL.\n");
        return -1;
    }

    g_r5_plog = plog;

    pro_conf conf;
    memset(&conf, 0, sizeof(pro_conf));

    //读取配置文件
    IniConfig config;
    if (config.open(conf_file) < 0) {
        PRO_ERROR("open file(%s) error!\n", conf_file);
        return -1;
    }

    const char* pro = "PROTOCOL";

    /* db_host */
    const char* db_host = config.getValue(pro, "DB_HOST");
    if(db_host && strlen(db_host) != 0){
        strncpy(conf.db_host, db_host, PRO_DB_LEN);
    } else {
        PRO_ERROR("read DB_HOST item failed, configure file:%s.\n", conf_file);
    	return -1;
    }

    /* db_dbname */
    const char* db_name = config.getValue(pro, "BD_DBNAME");
    if(db_name && strlen(db_name) != 0){
        strncpy(conf.db_dbname, db_name, PRO_DB_LEN);
    } else {
    	PRO_ERROR("read DB_DBNAME failed, configure file:%s\n", conf_file);
    	return -1;
    }

    /* db_username */
    const char* db_username = config.getValue(pro, "DB_USERNAME");
    if(db_username && strlen(db_username) != 0){
        strncpy(conf.db_username, db_username, PRO_DB_LEN);
    } else {
        PRO_ERROR("read DB_USERNAME failed, configure file:%s\n", conf_file);
        return -1;
    }

    /* db_password */
    const char* db_password = config.getValue(pro, "DB_PASSWORD");
    if(db_password && strlen(db_password) != 0){
        strncpy(conf.db_password, db_password, PRO_DB_LEN);
    } else {
        PRO_WARN("read db_password failed, configure file:%s\n", conf_file);
        strcpy(conf.db_password,"");
        //return -1;
    }

    /* db_port */
    const char* db_port = config.getValue(pro, "DB_PORT");
    if(db_port && strlen(db_port) != 0){
        conf.db_port = atoi(db_port);
    } else {
        PRO_ERROR("read db_port failed, configure file:%s\n", conf_file);
        return -1;
    }

    //初始化数据库连接
    g_protocoldb = mysql_init(0);
    if(NULL == g_protocoldb){
        PRO_ERROR("mysql_init failed.\n");
        return -1;
    }

    if (!mysql_real_connect(g_protocoldb, conf.db_host, conf.db_username,
            conf.db_password, conf.db_dbname, conf.db_port, 0, 0)) {
        PRO_ERROR("mysql: error=[%s]\n", mysql_error(g_protocoldb));
        return -1;
    }

    return 0;
}

int destroy(){
    //关闭数据库连接
    if(NULL != g_protocoldb)
        mysql_close(g_protocoldb);

    return 0;
}

int protocol_proc(const void * inmsg, const int inlen, void* protocol,
        void* outmsg, int* outlen){
    if(NULL == inmsg || NULL == protocol){
        PRO_ERROR("params error!");
        return -1;
    }

    query_protocol* qprotocol = (query_protocol*)protocol;

    protocol_head* header = &(qprotocol->header);
    if(parse_header((const char*)inmsg, inlen, header) < 0){
        PRO_ERROR("parse header failed.\n");
        return -1;
    }


    if(0 == strcmp(header->command, CMD_BIND_REQ)){
        bind_request((const char*)inmsg, inlen, qprotocol, outmsg, outlen);
    } else if(0 == strcmp(header->command, CMD_UNBIND_REQ)){
        unbind_request((const char*)inmsg, inlen, qprotocol, outmsg, outlen);
    } else if(0 == strcmp(header->command, CMD_PASSWD_CHANGE_REQ)){
        password_change_request((const char*)inmsg, inlen, qprotocol, outmsg, outlen);
    } else if(0 == strcmp(header->command, CMD_QUERY_REQ)){
        query_request((const char*)inmsg, inlen, qprotocol, outmsg, outlen);
    } else if(0 == strcmp(header->command, CMD_CLIENT_RSP)){
        client_query_response((const char*)inmsg, inlen, qprotocol, outmsg, outlen);
    } else if(0 == strcmp(header->command, CMD_HEARTBIT_EEQ)){
        heartbit_request((const char*)inmsg, inlen, qprotocol, outmsg, outlen);
    } else {
        illegal_command((const char*)inmsg, inlen, qprotocol, outmsg, outlen);
    }


    return 0;
}

int create_response(void* protocol, void* outmsg, int* outlen){
    return create_response_helper(protocol, outmsg, outlen);
}

int package_msg(const void * inmsg, const int inlen, const void* protocol,
        void* outmsg, int* outlen){
    PRO_DEBUG("in package_msg, inlen = %d\n", inlen);

    query_protocol* pro = (query_protocol*)protocol;
    protocol_head* header = &(pro->header);

    int msglen = inlen;

    char *in = (char*)inmsg;
    char *out = (char*)outmsg;

    if(inlen > 4036){
        int i = 0;
        int j = 0;

        while(msglen > 0){
            if(msglen > 4036)
                j = 4036;
            else
                j = msglen;
            msglen -= j;

            memcpy(out, header->command, PRO_COMMAND_LEN);
            out += PRO_COMMAND_LEN;
            *out = '\0';
            out++;

            snprintf(out, PRO_SEQUENCE_LEN + 1, "%07d", i);
            out += PRO_SEQUENCE_LEN;
            *out = '\0';
            out++;

            snprintf(out, PRO_LENGTH_LEN, "%d", j + PROTOCOL_HEAD_LEN);
            out += PRO_LENGTH_LEN;
            *out = '\0';
            out++;

            memcpy(out, header->system, PRO_SYSTEM_LEN);
            out += PRO_SYSTEM_LEN;
            *out = '\0';
            out++;

            //encrypt_flag!! 这里需要修改。正式环境中是加密的
            *out = '0';
            out++;

            *out = '0';
            out++;

            //morepkt
            if(msglen > 0)
                *out = '1';
            else
                *out = '0';
            out++;

            memcpy(out, header->decompresslen, PRO_DECOM_LEN);
            out += PRO_DECOM_LEN;
            *out = '\0';
            out++;

            *outlen += PROTOCOL_HEAD_LEN;

            memcpy(out, in, j);
            //Encrypt::crypt(out, j, protocol->random_code, strlen(protocol->random_code));

            out += j;
            in += j;
            *outlen += j;

            i++;
        }
    } else {
        memcpy(out, header->command, PRO_COMMAND_LEN);
        out += PRO_COMMAND_LEN;
        *out = '\0';
        out++;

        memcpy(out, header->sequence, PRO_SEQUENCE_LEN);
        out += PRO_SEQUENCE_LEN;
        *out = '\0';
        out++;

        snprintf(out, PRO_LENGTH_LEN, "%d", inlen + PROTOCOL_HEAD_LEN);
        out += PRO_LENGTH_LEN;
        *out = '\0';
        out++;

        memcpy(out, header->system, PRO_SYSTEM_LEN);
        out += PRO_SYSTEM_LEN;
        *out = '\0';
        out++;

        //encrypt_flag!! 这里需要修改。正式环境中是加密的
        *out = '0';
        out++;

        *out = '0';
        out++;

        //morepkt 这里只有一个报文
        *out = '0';
        out++;

        memcpy(out, header->decompresslen, PRO_DECOM_LEN);
        out += PRO_DECOM_LEN;
        *out = '\0';
        out++;

        *outlen += PROTOCOL_HEAD_LEN;

        memcpy(out, in, inlen);
        *outlen += inlen;

        //Encrypt::crypt(out, inlen, protocol->random_code, strlen(protocol->random_code));
    }
    PRO_DEBUG("in package_msg, success! outlen = %d\n", *outlen);

    return 0;
}


