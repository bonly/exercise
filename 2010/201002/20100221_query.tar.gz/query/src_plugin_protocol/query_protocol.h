#ifndef __QUERY_PROTOCOL_H__
#define __QUERY_PROTOCOL_H__
/*
*date:2011-05-12(汶川三周年.纪念)
*author:lqb
*/



    
#define PRO_DB_LEN 64
  
struct pro_conf{
    char db_host[PRO_DB_LEN + 1];
    char db_dbname[PRO_DB_LEN + 1];
    char db_username[PRO_DB_LEN + 1];
    char db_password[PRO_DB_LEN + 1];
    int db_port;  
};    
    

class R5_Log;

extern "C" int initialize(const char* conf_file, R5_Log *pLog);

extern "C" int destroy();

extern "C" int protocol_proc(const void * inmsg, const int inlen, void* protocol, 
         void* outmsg, int* outlen);

extern "C" int create_response(void* protocol, void* outmsg, int* outlen);

extern "C" int package_msg(const void * inmsg, const int inlen, const void* protocol, 
        void* outmsg, int* outlen);



#endif
