/*
*date:2011-05-12
*author:lqb
*/


#define PRO_DEBUG(...)\
    R5_DEBUG(g_r5_plog, ("[pro] " __VA_ARGS__))
#define PRO_INFO(...)\
    R5_INFO(g_r5_plog, ("[pro] " __VA_ARGS__))
#define PRO_ERROR(...)\
    R5_ERROR(g_r5_plog, ("[pro] " __VA_ARGS__))
#define PRO_WARN(...)\
    R5_WARN(g_r5_plog, ("[pro] " __VA_ARGS__))
#define PRO_TRACE(...)\
    R5_TRACE(g_r5_plog, ("[pro] " __VA_ARGS__))





struct protocol_head;
struct query_protocol;

int parse_header(const char* message, int msglen, protocol_head* header);

int bind_request(const char* inmsg, const int inlen, query_protocol* protocol, void* outmsg, int* outlen);

int unbind_request(const char* inmsg, const int inlen, query_protocol* protocol, void* outmsg, int* outlen);

int password_change_request(const char* inmsg, const int inlen, query_protocol* protocol, void* outmsg, int* outlen);

int query_request(const char* inmsg, const int inlen, query_protocol* protocol, void* outmsg, int* outlen);

int client_query_response(const char* inmsg, const int inlen, query_protocol* protocol, void* outmsg, int* outlen);

int heartbit_request(const char* inmsg, const int inlen, query_protocol* protocol, void* outmsg, int* outlen);

int illegal_command(const char* inmsg, const int inlen, query_protocol* protocol, void* outmsg, int* outlen);

int get_string(const char* str, char delimit, char* outstr, int* outlen);

int select_password(const char* system, char* password, int buflen);

int create_response_helper(void* protocol, void* outmsg, int* outlen);

int update_password(const char* system, const char* new_password);


