/*
*
*
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <fstream>
#include <map>
#include <iostream>
#include <mysql.h>
using namespace std;


#include "comm_structs.h"
#include "query_translate.h"


#include"iniconfig.h"
#include"r5api.h"

	
//typedef map<string,string> AreaData;
//AreaData callhappen;
//AreaData g_area;

R5_Log * g_r5_plog;

trans g_conf;
tansmap_conf conf;
translatemap g_config;
translate_map  g_map;
//translate_map *p_transmap;

int initialize(const char* conf_file, R5_Log* plog){
    if(NULL == plog){
        fprintf(stderr, "plog is NULL\n");
        return -1;
    }
    
    g_r5_plog = plog;
  
    
    //加载配置文件
    IniConfig config;
    if(config.open(conf_file) < 0){
        printf("open %s failed:%s\n", conf_file, strerror(errno));
        return -1;
    }
    /*
    const char* comm="COMM";
    const char*query=config.getValue(comm, "QUERY_TRANSLATE");
    if(query&& strlen(query) != 0){
    	strncpy(g_conf.translate_file, query, sizeof(g_conf.translate_file) - 1);
    } else {
    	printf("read QUERY_TRANSLATE failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }
    */
	const char* transmap= "TRANSLATE";
	 /* db_host */
    const char* db_host = config.getValue(transmap, "DB_HOST");
    if(db_host && strlen(db_host) != 0){
        strncpy(conf.db_host, db_host, PRO_DB_LEN);
    } else {
        printf("read DB_HOST item failed, configure file:%s.\n", conf_file);
    	return -1;
    }

    /* db_dbname */
    const char* db_name = config.getValue(transmap, "BD_DBNAME");
    if(db_name && strlen(db_name) != 0){
        strncpy(conf.db_name, db_name, PRO_DB_LEN);
    } else {
    	printf("read DB_DBNAME failed, configure file:%s\n", conf_file);
    	return -1;
    }

    /* db_username */
    const char* db_username = config.getValue(transmap, "DB_USERNAME");
    if(db_username && strlen(db_username) != 0){
        strncpy(conf.db_username, db_username, PRO_DB_LEN);
    } else {
        printf("read DB_USERNAME failed, configure file:%s\n", conf_file);
        return -1;
    }

    /* db_password */
    const char* db_password = config.getValue(transmap, "DB_PASSWORD");
    if(db_password && strlen(db_password) != 0){
        strncpy(conf.db_password, db_password, PRO_DB_LEN);
    } else {
        TRANS_WARN("read db_password failed, configure file:%s\n", conf_file);
        strcpy(conf.db_password,"");
        //return -1;
    }

    /* db_port */
    const char* db_port = config.getValue(transmap, "DB_PORT");
    if(db_port && strlen(db_port) != 0){
        conf.db_port = atoi(db_port);
    } else {
        printf("read db_port failed, configure file:%s\n", conf_file);
        return -1;
    }
    //Load_AreaData(query);
    table_to_map(transmap);
    return 0;
    
}

int destroy(){
    return 0;
}


/*
 Count=2&Row=4
 &TYPE =时间,使用周期,套餐及固定费名称,费用
 &CDR=06-30 23:24:33, 06-01—06-30, 98新商旅套餐, 98.00
 & Row=9&TYPE =时间,通信地点, 通信方式,对方号码, 通信时长,通信类型,套餐优惠,实收费用&CDR=09-01 17:41:03,香港万众PeoplesPhone , 被叫,861066174709,21秒,港澳台漫游,,,2.19&MSG=success
 E:\unicom\CDPP\trunk\10代码\platform\src\Classify\SortBill\Bill_Struct.h

 语音清单样例：
 Count=1&Row=9
 &TYPE=时间,通信地点,通信方式,对方号码,通信时长,通信类型,套餐优惠,优惠或减免,实收费用
 &CDR=2011-06-30 23:24:33,020,call,13719360007,30,call,,,98.00
 &MSG=success
 inmsg样例：
 01|0|00|   1000002|GD46|46|13700414106|||20110621100655|00||                   0|03|01|A|03|||CC||||       0|       0|       0||||       0|       0|||||||||       0|       0|       0|       0|       0||1|0000199902950|52|01|4||2|03|0|0|89|90|A5|#|1|     0|      0| 1|0661518|||||          10661518|          010220902950|            BZXX||||06| 0|||                   12|345|67|8901234567890123|456|7|89012345|67|89012340|67890120|&01|0|00|   1000002|GD46|46|13700414106|||20110621100635|00||                   0|03|01|A|03|||CC||||       0|       0|       0||||       0|       0|||||||||       0|       0|       0|       0|       0||1|0000199902950|52|01|4||2|03|0|0|89|90|A5|#|1|     0|      0| 1|0661518|||||          10661518|          010220902950|            BZXX||||06| 0|||                   12|345|67|8901234567890123|456|7|89012345|67|89012340|67890120|&
 */
 
/*
int Load_AreaData(const char* file_name)
{
    FILE *in;
    if((in=fopen(file_name,"r")) ==NULL)
    {
        fprintf(stderr,"Cannot open file for area map\n");
        return -1;
    }
    int ret = 0;
    do
    {
        char key[8]="";
        char value[20]="";
        ret = fscanf (in, "%[^=]=%s\n", key, value);
	      //取值正确
        if (ret == 2) 
        {
            g_area.insert(make_pair((string)key,(string)value));
        }
        else
        {
            break;
        }
    }while(true);
    fclose(in);
    return 0;
}
*/

int table_to_map(const char* connect_str)
{
	//连接数据库
    string str_con(connect_str);
    char *str = (char*)connect_str;
   // tansmap_conf config;
   // memset(&conf, 0, sizeof(conf));
	 //初始化数据库连接
    MYSQL* db = mysql_init(0);
    if(NULL == db){
        printf("mysql_init failed.\n");
        return -1;
    }

    if (!mysql_real_connect(db,conf.db_host, conf.db_username,
            conf.db_password, conf.db_name, conf.db_port, 0, 0)){
        TRANS_ERROR("mysql: error=[%s]\n", mysql_error(db));
        return -1;
    }
	TRANS_INFO("connect to mysql success! constr = %s\n", connect_str);
	
	char query[256];
	const int len = snprintf(query, sizeof(query),"select callnum,area from callhappen ");
    TRANS_DEBUG("SQL:%s\n", query);
	
	const int r = mysql_real_query(db, query, len > 0 ? len : 0);
    if (r != 0){
       TRANS_ERROR ("mysql: error=[%s]\n", mysql_error(db));
        return -1;
    }

	MYSQL_ROW rows=0;
	//MYSQL connect_; //< mysql连接
    MYSQL_RES *res = mysql_store_result(db);
	if(res!=0)
	{
   		 while (NULL != (rows= mysql_fetch_row (res)))
   		 {
        /// @todo strcpy
      	g_map.call.insert(make_pair(string(rows[0]),string(rows[1])));
       	++rows;//记录行数
    	}
	}
	  //断开数据库连接
	  mysql_close(db);
	  mysql_free_result(res);	
      return 0;	
}

///处理各个字段的转换
int process_voice_field(const int ind, char* key, TVoice& vd)
{
    switch (ind)
    {
        case 9: ///时间
        {
            sprintf(vd.start_time, "%2.2s-%2.2s-%2.2s %2.2s:%2.2s:%2.2s",
                        key + 2, key + 4, key + 6, key + 8, key + 10, key + 12);
            break;
        }
        case 17: ///通信地点
        {
            strncpy(vd.Visit_Area, key, 8);
            map<string, string>::iterator pcall = g_map.call.find(string(vd.Visit_Area));
            if(pcall!=g_map.call.end())
            {
               strcpy(vd.Visit_Area,pcall->second.c_str());
            }
            break;
        }
        case 18: ///对方号码
        {
            strncpy(vd.B_subno, key, 24);
            break;
        }
        case 19: ///帐单类型
        {
            strncpy(vd.Bill_type, key, 2);
            break;
        }
        case 23: ///移动费
        {
            strncpy(vd.Mob_fee, key, 8);
            break;
        }
        case 24: ///长途费
        {
            strncpy(vd.Toll_fee, key, 8);
            break;
        }
        case 25: ///信息费
        {
            strncpy(vd.Inf_fee, key, 8);
            break;
        }
        case 47: /// 通信业务类型
        {
            strncpy(vd.bus_type, key, 2);
            break;
        }
        case 48: ///子业务类型
        {
            strncpy(vd.subbus_type, key, 2);
            break;
        }
        case 51: ///方向类型
        {
            strncpy(vd.direct_type, key, 1);
            break;
        }
        case 53: ///漫游类型
        {
            strncpy(vd.roam_type, key, 1);
            break;
        }
        case 54: ///长途类型
        {
            strncpy(vd.toll_type, key, 1);
            break;
        }
        case 55: ///承载类型
        {
            strncpy(vd.carry_type, key, 2);
            break;
        }
        case 63: ///通信时长
        {
            long ltime = atol(key);
            long hour = ltime / 3600;
            long min = (ltime - hour * 3600) / 60;
            long sec = ltime % 60;
            sprintf(vd.duration, "%ld小时%ld分%ld秒", hour, min, sec);
            break;
        }
        case 87: ///最后一个字段
        {
            break;
        }

    }
    return 0;
}

int judge_Communication_Mode(TVoice& vd);

/**
 计算 实收费用 = 移动费+长途费+信息费
 推导 通信类型 通信方式
 */
int finish_field_process(TVoice& vd, char* outmsg, int* outlen)
{
    ///计算  实收费用=移动费+长途费+信息费
    sprintf(
                vd.fee,
                "%.2f",
                (atoi(vd.Mob_fee) + atoi(vd.Toll_fee) + atoi(vd.Inf_fee))
                            / 100.00);

    ///推导  通信类型 Communication_Type
    /** @note  通信类型
     通信类型    名称翻译依据
     本地  长途类型为0/1/2/3/4/5
     国内长途    长途类型为6/7/8/9
     港澳台长途   长途类型为A/B/C
     国际长途    长途类型为D
     省内漫游    漫游类型为2
     国内漫游    漫游类型为3
     国际漫游    漫游类型为4
     */
    if (vd.toll_type[0] >= '0' && vd.toll_type[0] <= '5') // 0 1 2 3 4 5
    {
        strcpy(vd.Communication_Type, "本地");
    }
    else if (vd.toll_type[0] >= '6' && vd.toll_type[0] <= '9') // 6 7 8 9
    {
        strcpy(vd.Communication_Type, "国内长途");
    }
    else if (vd.toll_type[0] >= 'A' && vd.toll_type[0] <= 'C') // A B C
    {
        strcpy(vd.Communication_Type, "港澳台长途");
    }
    else if (vd.toll_type[0] == 'D')
    {
        strcpy(vd.Communication_Type, "国际长途");
    }
    if (vd.toll_type[0] < '0' || vd.toll_type[0] > '5') //非本地时
    {
        char my_name[8 + 1] = "";
        if (vd.roam_type[0] == '2')
            strcpy(my_name, "省内漫游");
        else if (vd.roam_type[0] == '3')
            strcpy(my_name, "国内漫游");
        else if (vd.roam_type[0] == '4')
            strcpy(my_name, "国际漫游");

        if (strlen(my_name) > 0)
        {
            strcat(vd.Communication_Type, "(");
            strcat(vd.Communication_Type, my_name);
            strcat(vd.Communication_Type, ")");
        }
    }

    judge_Communication_Mode(vd);

    return 0;
}
///推导 通信方式
/**
 通信方式    名称翻译依据
 DATA/FAX主叫  通信业务类型02，方向类型3
 DATA/FAX被叫  通信业务类型02，方向类型4
 主叫(可视电话)    通信业务类型为0K，子业务类型为0I，方向类型为0 1 3
 被叫(可视电话)    通信业务类型为0K，子业务类型为0I，方向类型为2 4
 无条件及不可及前转呼转主叫   方向类型是5，通信业务类型不为0K，并且子业务类型不为0I
 无条件及不可及前转呼转被叫   方向类型是7，通信业务类型不为0K，并且子业务类型不为0I
 有条件呼转主叫 方向类型是6，通信业务类型不为0K，并且子业务类型不为0I
 有条件呼转被叫 方向类型是8，通信业务类型不为0K，并且子业务类型不为0I
 无条件及不可及前转呼转主叫(可视电话) 方向类型是5，通信业务类型为0K，并且子业务类型为0I
 无条件及不可及前转呼转被叫(可视电话) 方向类型是7，通信业务类型为0K，并且子业务类型为0I
 有条件呼转主叫(可视电话)   方向类型是6，通信业务类型为0K，并且子业务类型为0I
 有条件呼转被叫(可视电话)   方向类型是8，通信业务类型为0K，并且子业务类型为0I
 主叫付费业务  帐单类型为QB
 被叫付费业务  帐单类型为RB
 中国电信ip(可视电话)    方向类型为3，承载类型为31，通信业务类型为0K，并且子业务类型为0I
 网通ip(可视电话)  方向类型为3，承载类型为3A，通信业务类型为0K，并且子业务类型为0I
 中国电信ip  方向类型为3，承载类型为31，通信业务类型不为0K，并且子业务类型为0I
 网通ip    方向类型为3，承载类型为3A，通信业务类型不为0K，并且子业务类型不为0I
 集团IP后付费/IP直通车   方向类型为3，承载类型为11，帐单类型不为IB，通信业务类型为09/0A
 中国移动ip  方向类型为3，承载类型为11，帐单类型不为IB，通信业务类型不为09/0A
 主叫（139） 通信业务类型以0打头，子业务类型为0G
 代MID付费  通信业务类型为01/0K，子业务类型为29
 主叫  通信业务类型以0打头，并且不是语音类列举特殊翻译业务的，方向类型为0/1/3
 被叫  通信业务类型以0打头，并且不是语音类列举特殊翻译业务的，方向类型为2/4
 */
int judge_Communication_Mode(TVoice& vd)
{
    ///初始化通信方式
    memset(vd.Communication_Mode, 0, sizeof(vd.Communication_Mode));

    ///1.根据付费类型判断
    if (strcmp(vd.Bill_type, "QB") == 0) //帐单类型为QB
    {
        strcpy(vd.Communication_Mode, "主叫付费业务");
    }
    else if (strcmp(vd.Bill_type, "RB") == 0) //帐单类型为RB
    {
        strcpy(vd.Communication_Mode, "被叫付费业务");
    }
    if (strlen(vd.Communication_Mode) > 0) //有匹配,即返回
        return 0;

    ///2.根据通信业务类型判断
    if (strcmp(vd.bus_type, "02") == 0) //通信业务类型02
    {
        if (vd.direct_type[0] == '3') //方向类型3
            strcpy(vd.Communication_Mode, "DATA/FAX主叫");
        else if (vd.direct_type[0] == '4') //方向类型4
            strcpy(vd.Communication_Mode, "DATA/FAX被叫");
    }
    else if (strcmp(vd.bus_type, "0K") == 0) //通信业务类型为0K
    {
        if (strcmp(vd.subbus_type, "0I") == 0) //子业务类型为0I
        {
            if (vd.direct_type[0] == '0' || vd.direct_type[0] == '1'
                        || vd.direct_type[0] == '3')//方向类型为0 1 3
                strcpy(vd.Communication_Mode, "主叫(可视电话)");
            else if (vd.direct_type[0] == '2' || vd.direct_type[0] == '4')//方向类型为2 4
                strcpy(vd.Communication_Mode, "被叫(可视电话)");
        }
    }
    else if (strcmp(vd.bus_type, "01") == 0 || strcmp(vd.bus_type, "0K") == 0) //通信业务类型为 01 0K
    {
        if (strcmp(vd.subbus_type, "29") == 0) //子业务类型 29
            strcpy(vd.Communication_Mode, "代MID付费");
    }
    if (strlen(vd.Communication_Mode) > 0) //有匹配,即返回
        return 0;

    ///3.根据方向类型判断  @todo 确认与前面的优先判断类型不冲突覆盖
    if (vd.direct_type[0] == '5') //方向类型是5
    {
        //通信业务类型为0K，并且子业务类型为0I
        if (strcmp(vd.bus_type, "0K") == 0 && strcmp(vd.subbus_type, "0I") == 0)
        {
            strcpy(vd.Communication_Mode, "无条件及不可及前转呼转主叫(可视电话)");
        }
        else if (strcmp(vd.bus_type, "0K") != 0 && //通信业务类型不为0K，并且子业务类型不为0I
                    strcmp(vd.subbus_type, "0I") != 0)
            strcpy(vd.Communication_Mode, "无条件及不可及前转呼转主叫");
    }
    else if (vd.direct_type[0] == '7') //方向类型是7
    {
        //通信业务类型为0K，并且子业务类型为0I
        if (strcmp(vd.bus_type, "0K") == 0 && strcmp(vd.subbus_type, "0I") == 0)
        {
            strcpy(vd.Communication_Mode, "无条件及不可及前转呼转被叫(可视电话)");
        }
        else if (strcmp(vd.bus_type, "0K") != 0 && //通信业务类型不为0K，并且子业务类型不为0I
                    strcmp(vd.subbus_type, "0I") != 0)
            strcpy(vd.Communication_Mode, "无条件及不可及前转呼转被叫");
    }
    else if (vd.direct_type[0] == '6') //方向类型是6
    {
        //通信业务类型为0K，并且子业务类型为0I
        if (strcmp(vd.bus_type, "0K") == 0 && strcmp(vd.subbus_type, "0I") == 0)
        {
            strcpy(vd.Communication_Mode, "有条件呼转主叫(可视电话)");
        }
        else if (strcmp(vd.bus_type, "0K") != 0 && strcmp(vd.subbus_type, "0I")
                    != 0)//通信业务类型不为0K，并且子业务类型不为0I
            strcpy(vd.Communication_Mode, "有条件呼转主叫");
    }
    else if (vd.direct_type[0] == '8') //方向类型是8

    {
        //通信业务类型为0K，并且子业务类型为0I
        if (strcmp(vd.bus_type, "0K") == 0 && strcmp(vd.subbus_type, "0I") == 0)
        {
            strcpy(vd.Communication_Mode, "有条件呼转被叫(可视电话)");
        }
        else if (strcmp(vd.bus_type, "0K") != 0 && //通信业务类型不为0K，并且子业务类型不为0I
                    strcmp(vd.subbus_type, "0I") != 0)
            strcpy(vd.Communication_Mode, "有条件呼转被叫");
    }
    else if (vd.direct_type[0] == '3') //方向类型是3
    {
        if (strcmp(vd.carry_type, "31") == 0) //承载类型为31
        {
            //通信业务类型为0K，并且子业务类型为0I
            if (strcmp(vd.bus_type, "0K") == 0 && strcmp(vd.subbus_type, "0I")
                        == 0)
            {
                strcpy(vd.Communication_Mode, "中国电信ip(可视电话)");
            }
            else if (strcmp(vd.bus_type, "0K") != 0 && //通信业务类型不为0K，并且子业务类型不为0I
                        strcmp(vd.subbus_type, "0I") != 0)
                strcpy(vd.Communication_Mode, "中国电信ip");
        }
        else if (strcmp(vd.carry_type, "3A") == 0) //承载类型为3A
        {
            //通信业务类型为0K，并且子业务类型为0I
            if (strcmp(vd.bus_type, "0K") == 0 && strcmp(vd.subbus_type, "0I")
                        == 0)
            {
                strcpy(vd.Communication_Mode, "网通ip(可视电话)");
            }
            else if (strcmp(vd.bus_type, "0K") != 0 && //通信业务类型不为0K，并且子业务类型不为0I
                        strcmp(vd.subbus_type, "0I") != 0)
                strcpy(vd.Communication_Mode, "网通ip");
        }
        else if (strcmp(vd.carry_type, "11") == 0) //承载类型为11
        {
            if (strcmp(vd.Bill_type, "1B") != 0) //帐单类型不为1B
            {
                //通信业务类型为09 0A
                if (strcmp(vd.bus_type, "09") == 0 || strcmp(vd.subbus_type,
                            "0A") == 0)
                {
                    strcpy(vd.Communication_Mode, "集团IP后付费/IP直通车");
                }
                else if (strcmp(vd.bus_type, "09") != 0 && //通信业务类型为!(09 0A)
                            strcmp(vd.subbus_type, "0A") != 0)
                    strcpy(vd.Communication_Mode, "中国移动ip");
            }
        }
    }
    if (strlen(vd.Communication_Mode) > 0) //有匹配,即返回
        return 0;

    ///4.再次根据通信业务类型补遗
    if (vd.Bill_type[0] == '0') //通信业务类型以0开头

    {
        if (strcmp(vd.subbus_type, "0G") == 0) //子业务类型为0G

        {
            strcpy(vd.Communication_Mode, "主叫(139)");
        }
        else //不是语音列举特殊翻译业务

        {
            if (vd.direct_type[0] == '0' || //方向 0
                        vd.direct_type[0] == '1' || //方向 1
                        vd.direct_type[0] == '3') //方向 3

            {
                strcpy(vd.Communication_Mode, "主叫");
            }
            else if (vd.direct_type[0] == '2' || vd.direct_type[0] == '4') //方向 2 4

            {
                strcpy(vd.Communication_Mode, "被叫");
            }
        }
    }
    if (strlen(vd.Communication_Mode) > 0) //有匹配,即返回
        return 0;
    else
        return -1;
}

/// 转换语音类数据
int voice(const char* inmsg, int inlen, void* outmsg, int* outlen)
{
    char* row = 0;
    vector<char*> vrow;
    ///读入所有记录数
    while (true)
    {
        ///根据'&'定位划分记录
        if (row == 0)
        {
            row = strtok((char*) inmsg, "&");
        }
        else
        {
            row = strtok(NULL, "&");
        }
        if (!row)
            break;
        vrow.push_back(row);
    }

    /*
     Count=1&Row=9
     &TYPE=时间,通信地点,通信方式,对方号码,通信时长,通信类型,套餐优惠,优惠或减免,实收费用
     */
    int rows = vrow.size(); ///记录总数
    sprintf(
                (char*) outmsg,
                "Count=%d&Row=9&TYPE=时间,通信地点,通信方式,对方号码,通信时长,通信类型,套餐优惠,优惠或减免,实收费用&CDR=",
                rows);
    for (int rs = 0; rs < rows; ++rs)
    {
        char* key = 0;
        char** str = &vrow[rs];
        TVoice vd;
        memset(&vd, 0, sizeof(TVoice));
        for (int i = 0; i < 88; ++i)
        {
            ///根据'|'捡取单个字段处理
            key = strsep(str, "|");

            if (key)
            {
                printf("field[%d]: %s\n", i, key);
            }

            ///根据记录顺序数处理内容
            if (0 != process_voice_field(i, key, vd))
            {
                //TRANS_DEBUG("Error in %dth field\n", ind);
                continue; ///跳过这一行记录
            }
        }
        ///结束一行记录,做整理工作
        finish_field_process(vd, (char*) outmsg, outlen);
        /*
         &CDR=2011-06-30 23:24:33,020,call,13719360007,30,call,,,98.00
         */
        if (rs == 0)
            sprintf((char*) outmsg + strlen((char*) outmsg),
                        "%s,%s,%s,%s,%s,%s,%s,%s,%s", vd.start_time,
                        vd.Visit_Area, vd.Communication_Mode, vd.B_subno,
                        vd.duration, vd.Communication_Type, "", "", vd.fee);
                        
        else
            sprintf((char*) outmsg + strlen((char*) outmsg),
                        ",%s,%s,%s,%s,%s,%s,%s,%s,%s", vd.start_time,
                        vd.Visit_Area, vd.Communication_Mode, vd.B_subno,
                        vd.duration, vd.Communication_Type, "", "", vd.fee);
    }
    //&MSG=success
    strcat((char*) outmsg, "&MSG=success");

    *outlen = strlen((char*) outmsg);
    fprintf(stderr, "outmsg: %s\n", (char*) outmsg);
    return 0;
}

///转换入口,判断需转换的类型
int  bill_translate(const char* inmsg, int inlen, const void* protocol,
            void* outmsg, int* outlen)
{
	//translate_map *pmap = p_transmap;
    outmsg = (void*)inmsg;
    *outlen = inlen;
    int ret = 0;
    
    /*
    ///通过switch protocol.xd_type 类型来调相应的转换函数
    query_protocol* pro = reinterpret_cast<query_protocol*>(const_cast<void*>(protocol));
    switch (pro->cdr_type)
    {
    	case '1': ///通话详单
    		ret = voice(inmsg, inlen, outmsg, outlen);
    		break;
    	case '2': ///短、彩信详单
    		ret = -1;
    		break;
    	case '3': ///上网详单
    		ret = -1;
    		break;
    	default:
    		ret = -1;
    		break;
    }
    */

    //TRANS_DEBUG("in bill_translate, success!\n");
    return ret;
}

