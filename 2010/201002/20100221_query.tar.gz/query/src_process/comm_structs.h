#ifndef __COMM_STRUCTS_H__
#define __COMM_STRUCTS_H__

#include "type.h"
/*
*date:2011-05-09
*author:lqb
*/

#define LOG_DEBUG(...)\
    R5_DEBUG((&g_r5_log), ("[query] " __VA_ARGS__))
#define LOG_INFO(...)\
    R5_INFO((&g_r5_log), ("[query] " __VA_ARGS__))
#define LOG_ERROR(...)\
    R5_ERROR((&g_r5_log), ("[query] " __VA_ARGS__))
#define LOG_WARN(...)\
    R5_WARN((&g_r5_log), ("[query] " __VA_ARGS__))
#define LOG_TRACE(...)\
    R5_TRACE((&g_r5_log), ("[query] " __VA_ARGS__))


const char* const CMD_BIND_REQ = "000";
const char* const CMD_BIND_RSP = "000";

const char* const CMD_UNBIND_REQ = "001";
const char* const CMD_UNBIND_RSP = "001";

const char* const CMD_PASSWD_CHANGE_REQ = "002";
const char* const CMD_PASSWD_CHANGE_RSP = "002";

const char* const CMD_QUERY_REQ = "100";
const char* const CMD_QUERY_RSP = "200";
const char* const CMD_CLIENT_RSP = "101";

const char* const CMD_HEARTBIT_EEQ = "999";
const char* const CMD_HEARTBIT_ESP = "999";

 
//协议结构头
struct protocol_head{
    char command[PRO_COMMAND_LEN + 1];       //
    char sequence[PRO_SEQUENCE_LEN + 1];
    char length[PRO_LENGTH_LEN + 1];
    char system[PRO_SYSTEM_LEN + 1];
    char encrypt_flag;		              //传送内容是否加密。’1’：已加密
    char errcode;               	      //出错代码，响应连接使用
    char morepkt;                         //是否还有后续包，1：有，0：无
    char decompresslen[PRO_DECOM_LEN + 1];        //保留。在使用proxy的时候，改字段由proxy设置回路信息，并在proxy发给客户端之前清除。
};




//协议体
struct query_protocol{
    struct protocol_head header; 
    char   sub_no[PRO_SUB_NO_LEN + 1];            //用户号码
    char   bill_period[PRO_BILL_PERIOD_LEN + 1];    //YYYYMM的格式
    char   cdr_type;
    char   operator_id[PRO_OPRID_LEN + 1];         //工号，与移动分配的实际工号相符
    char   switch_flag[PRO_SWITCH_FLAG_LEN + 1];    //交换局代码，01-24，目前只有21个交换局号可用
    char   district[PRO_DISTRICT_LEN + 1];	      //行政区代码，参见移动参数定义，取值为全数字
    char   brand;	                             //品牌，A全球通，B神州行，C动感地带，D神州大众卡
    char   begin_date[PRO_DATETIME_LEN + 1];
    char   end_date[PRO_DATETIME_LEN + 1];
    char   query_time[PRO_DATETIME_LEN + 1]; 
    char   login_time[PRO_DATETIME_LEN + 1];
    char   random_code[PRO_RANDOM_CODE_LEN + 1];   //10位整数，做为后续传输数据的加密密码
    char   errmsg[128];
    int    result_code;                            //处理结果码，不属于协议本身 
}; 


//路由信息结构体
struct route_info{
    char instance_name[8+1];
    char connect_string[64+1];
} ;

struct route_info_list{
	int count;
	struct route_info route_item[8];   //最多存储8个
};


#endif

