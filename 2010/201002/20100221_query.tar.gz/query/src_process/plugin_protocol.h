#ifndef __PLUGIN_PROTOCOL_H__
#define __PLUGIN_PROTOCOL_H__
/*
date:2011-05-09
author:lqb
*/

class R5_Log;

int init_protocol(const char* conf_file, const char* lib_file, R5_Log* plog);

int pro_initialize(const char* conf_file, R5_Log *pLog);

int pro_destory();

int protocol_proc(const void * inmsg, const int inlen, void* protocol, 
        void* outmsg, int* outlen);
        
int create_response(void* protocol, void* outmsg, int* outlen);

int package_msg(const void * inmsg, const int inlen, const void* protocol, 
        void* outmsg, int* outlen);

#endif
