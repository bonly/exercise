/**
 * testcase.cpp
 * @file
 * @brief
 *
 * @date 2011-4-20 created
 * @author bonly
 */
#include <boost/lexical_cast.hpp>
#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <signal.h>
#include "head.hpp"
#include "service_handler.hpp"
#include "service_handler_pool.hpp"
#include "server.hpp"
#include "Protocal.h"
#include "myhs.hpp"
class server_work_allocator;

class server_work
{
   public:

      typedef bas::service_handler<server_work> server_handler_type;

      server_work()
      {
      }

      void on_clear(server_handler_type& handler)
      {
      }

      void on_open(server_handler_type& handler)
      {
         std::cout << "client ["
                  << handler.socket().remote_endpoint().address().to_string()
                  << "] connect" << "\n";
         std::cout.flush();

         _conf["port"] = "9998";
         _conf["host"] = "127.0.0.1";
         _arg.set(_conf);
         _hs.init(_arg);

         if (0 != hs_heartbeat())
         {
            std::cerr << "连接mysql失败\n";
            handler.close();
         }

         handler.async_read_pack();
      }

      void on_read(server_handler_type& handler, std::size_t bytes_transferred)
      {
         std::string phone_num(handler.protocal().data()->phoneNum);
         handler.protocal().Reset();
         handler.protocal() << "0" << phone_num.c_str() << "2" // 结果,号码段,节点数
                  << "inst1" << "abc/ok@testdb1" << "0" << "100000" //第1个节点
                  << "inst2" << "abc/no@testdb2" << "0" << "100000" //第2个节点
                  << 2; //命令码

         char *buf = 0;
         int ret = handler.protocal().Encode(buf); // ret 返回整个数据的包长度,-1表示失败
         std::cout << "encoded ans: " << handler.protocal() << std::endl;

         handler.async_write(boost::asio::buffer(buf, ret));
      }

      void on_write(server_handler_type& handler, std::size_t bytes_transferred)
      {
         //std::cout << "send " << bytes_transferred
         //         << " bytes ok ...............\n";
         //std::cout.flush();

         handler.async_read_pack();
         //    handler.close();
      }

      void on_close(server_handler_type& handler,
               const boost::system::error_code& e)
      {
         switch (e.value())
         {
            // 成功关闭
            case 0:
            case boost::asio::error::eof:
               std::cout << "close ok ...............\n";
               std::cout.flush();
               break;

               // 连接破坏
            case boost::asio::error::connection_aborted:
            case boost::asio::error::connection_reset:
            case boost::asio::error::connection_refused:
               break;

               // 其它错误
            case boost::asio::error::timed_out:
            case boost::asio::error::no_buffer_space:
            default:
               std::cout << "server error " << e << " message " << e.message()
                        << "\n";
               std::cout.flush();
               break;
         }
         ///关闭 mysql
         _hs.response_buf_remove();
         _hs.close();
      }

      void on_parent(server_handler_type& handler, const bas::event event)
      {
      }

      void on_child(server_handler_type& handler, const bas::event event)
      {
      }

      int hs_heartbeat()
      {
         if (0 != _hs.reconnect())
         {
            std::cerr << "reconnet:" << _hs.get_error_code() << _hs.get_error()
                     << std::endl;
            return -1;
         }

         /// 请求打开索引
         _hs.request_buf_open_index(1, "test", "testm", "PRIMARY", "k,v", 0);
         if (0 != _hs.request_send())
         {
            std::cerr << "index:" << _hs.get_error_code() << _hs.get_error()
                     << std::endl;
            return -1;
         }

         /// 读取应答结果
         size_t len = 0;
         _hs.response_recv(len);
         int ret = _hs.get_error_code();
         if (ret != 0)
            std::cerr << "resp:" << _hs.get_error_code() << _hs.get_error()
                     << std::endl;

         _hs.response_buf_remove();
         return ret;
      }
   private:
      dena::socket_args _arg; //< hs的连接参数
      dena::config _conf; //< hs的配置
      dena::hstcpcli _hs; //< hs实例
};

class server_work_allocator
{
   public:
      typedef PROTOCAL socket_type;

      server_work_allocator()
      {
      }
      /// 为适应service_handler 调用的模板模式
      socket_type* make_socket(boost::asio::io_service& io_service)
      {
         return new socket_type(io_service);
      }

      server_work* make_handler()
      {
         return new server_work();
      }
};

int main(int argc, char* argv[])
{
   try
   {
      /// 检查命令行参数
      if (argc != 9)
      {
         std::cerr
                  << "Usage: echo_server <address> <port> <io_pool_size> <thread_pool_size> <preallocated_handler_number> <data_buffer_size> <timeout_seconds> <closed_wait>\n";
         std::cerr << "  For IPv4, try:\n";
         std::cerr << "    echo_server 0.0.0.0 1000 4 4 500 256 0 1\n";
         std::cerr << "  For IPv6, try:\n";
         std::cerr << "    echo_server 0::0 1000 4 4 500 256 0 1\n";
         return 1;
      }

      /// 初始化 server.
      unsigned short port = boost::lexical_cast<unsigned short>(argv[2]);
      std::size_t io_pool_size = boost::lexical_cast<std::size_t>(argv[3]);
      std::size_t thread_pool_size = boost::lexical_cast<std::size_t>(argv[4]);
      std::size_t preallocated_handler_number =
               boost::lexical_cast<std::size_t>(argv[5]);
      std::size_t read_buffer_size = boost::lexical_cast<std::size_t>(argv[6]);
      std::size_t timeout_seconds = boost::lexical_cast<std::size_t>(argv[7]);
      std::size_t closed_wait = boost::lexical_cast<std::size_t>(argv[8]);

      typedef bas::server<server_work, server_work_allocator> server;
      typedef bas::service_handler_pool<server_work, server_work_allocator>
               server_handler_pool;

      server s(
               argv[1],
               port,
               io_pool_size,
               thread_pool_size,
               new server_handler_pool(new server_work_allocator(),
                        preallocated_handler_number, read_buffer_size, 0,
                        timeout_seconds, closed_wait));

      // 阻塞所有信号,不传递给新创建的线程
      sigset_t new_mask;
      sigfillset(&new_mask);
      sigset_t old_mask;
      pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

      // 创建线程后台运行
      boost::thread t(boost::bind(&server::run, &s));

      // 恢复原来的信号
      pthread_sigmask(SIG_SETMASK, &old_mask, 0);

      // 等待特定的信号
      sigset_t wait_mask;
      sigemptyset(&wait_mask);
      sigaddset(&wait_mask, SIGINT);
      sigaddset(&wait_mask, SIGQUIT);
      sigaddset(&wait_mask, SIGTERM);
      sigaddset(&wait_mask, SIGUSR2);
      pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
      int sig = 0;
      int ret = -1;
      while (-1 != (ret = sigwait(&wait_mask, &sig)))
      {
         printf("Receive signal. %d\n", sig);
         if (sig == SIGUSR2)
            continue;
         if (sig == SIGTERM || sig == SIGQUIT || sig == SIGINT)
            break;
      }
      if (ret == -1)
      {
         printf("sigwaitinfo() returned err: %d; %s\n", errno, strerror(errno));
      }

      // 停止服务器
      s.stop();
      t.join();
   }
   catch (std::exception& e)
   {
      std::cerr << "exception: " << e.what() << "\n";
   }

   return 0;
}

