#!/usr/bin/python
#-*-coding:utf-8-*-
'''
Created on 2011-5-19

@author: bonly
'''
##@ingroup testcase
##@package testdata
##@file
##@brief 生成测试数据到文件的脚本

def create_data11():
   fil = open("./route11.txt","w")
   count = 5000
   basenum = 1370000
   for num in range(count):
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum*10000+num, "paas","172.16.200.101|3311|paas|root|111", "0", "10000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum*10000+num, "paas","172.16.200.102|3311|paas|root|111", "0", "10000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum*10000+num, "pass","172.16.200.103|3311|paas|root|111", "0", "10000"))
   fil.close()
         
def create_data12():
   fil = open("./route12.txt","w")
   count = 4000
   basenum = 1370000.6
   for num in range(count):
      fil.write("%s\t%s\t%s\t%s\t%s\n" %
                (basenum*10000+num, "paas","172.16.200.101|3312|paas|root|111", "0", "5000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" %
                (basenum*10000+num, "paas","172.16.200.102|3312|paas|root|111", "0", "5000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" %
                (basenum*10000+num, "pass","172.16.200.103|3312|paas|root|111", "0", "5000"))
   fil.close()

def create_data21():
   fil = open("./route_p1.txt","w")
   count = 5
   basenum = 13700000
   for num in range(count):
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "paas","172.16.200.101|3311|paas|root|111", "0", "10000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "paas","172.16.200.102|3311|paas|root|111", "0", "10000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "pass","172.16.200.103|3311|paas|root|111", "0", "10000"))
   fil.close()

def create_data22():
   fil = open("./route_p2.txt","w")
   count = 4
   basenum = 13700005
   for num in range(count):
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "paas","172.16.200.101|3312|paas|root|111", "0", "5000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "paas","172.16.200.102|3312|paas|root|111", "0", "5000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "pass","172.16.200.103|3312|paas|root|111", "0", "5000"))
   fil.close()

if __name__ == '__main__':
   #create_data11()
   #create_data12()
   create_data21()
   create_data22()
   
'''
mysqlimport test /home/hadoop/Router/route
'''


