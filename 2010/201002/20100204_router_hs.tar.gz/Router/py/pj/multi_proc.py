'''
Created on 2011-5-31

@author: bonly
'''
import subprocess;
import threading;

def run():
   subprocess.call(["/home/hadoop/Router/nClient/Debug/client","172.16.200.104","4560"])
   
if __name__ == '__main__':
   thrs = []
   for i in range(10):
      thread = threading.Thread(target=run)
      thread.start()
      thrs.append(thread)
   for i in range(10):
      thrs[i].join()
      
