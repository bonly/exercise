/**
 * @file
 * @brief 启动参数管理
 *
 * @date 2009-4-10 created
 * @author bonly
 */

#include <fstream>
#include <iostream>
#include "profile_config.h"

shared_ptr<Config> Config::_config;
void Config::help()
{
  cout << _desc_cfg;
}
int Config::clear()
{
  _cfg.reset();
  _cfg = shared_ptr<program_options::variables_map>(new program_options::variables_map);
  return 0;
}

int Config::parse(int argc, char* argv[])
{
  try
  {
    clear();
    if(argc!=0 || argv!=0)
    {
      this->argc=argc;
      this->argv=argv;
    }

    string brief(
"程序为客户端提供号码段路由服务"
    );

    _desc_cfg.add_options ()
      ("help,h", brief.data())
      ("version,v", "version ")
      ("config-file,c", program_options::value<std::string>(),"use config file")
      ("route.daemon,e",program_options::value<bool>()->default_value(true),"run as daemon")
      ("route.port,p",program_options::value<int>()->default_value(4560),"service port")
      ("route.ip,a", program_options::value<std::string>()->default_value("0.0.0.0"),"service ip")
      ("route.ios,i", program_options::value<int>()->default_value(1),"io pool size")
      ("route.threads,r",program_options::value<int>()->default_value(1),"thread pool size")
      ("route.handlers,j",program_options::value<int>()->default_value(1),"preallocated handler number")
      ("route.buffer,b",program_options::value<int>()->default_value(256),"data buffer size")
      ("route.timeout,t",program_options::value<int>()->default_value(120),"timeout seconds")
      ("route.wait,w",program_options::value<int>()->default_value(1),"closed wait")
      ("route.prePoint,o",program_options::value<int>()->default_value(4),"telno pre point for search")
      ("route.sufPoint,O",program_options::value<int>()->default_value(4),"telno suf point for search")

      ("mysql.port,P",program_options::value<int>()->default_value(9998),"mysql handler socket port")
      ("mysql.ip,I", program_options::value<std::string>()->default_value("127.0.0.1"),"mysql handler socket ip")
      ("mysql.db,D", program_options::value<std::string>()->default_value("test"),"mysql database name")
      ("mysql.table,A", program_options::value<std::string>()->default_value("route"),"mysql table name")
      ("mysql.index_name,x", program_options::value<std::string>()->default_value("idx_subno"),"mysql index name")
      ("mysql.fields,f", program_options::value<std::string>()->default_value("subno,instance_name,connect_string,status,threshold"),"mysql fields")

      ("log.path,l",program_options::value<string>()->default_value("./"),"log file path")
      ("log.level,L",program_options::value<int>()->default_value(1),"log file level")
      ("log.head,g",program_options::value<string>()->default_value(argv[0]),"log file prefix")
      ("log.term,T",program_options::value<bool>()->default_value(false),"log to stderr")
      ("log.max_size,m",program_options::value<int>()->default_value(180),"max log size")
       ;

    program_options::positional_options_description p;
    p.add("config-file", -1);
    store (
        program_options::command_line_parser(this->argc,this->argv).options(_desc_cfg).positional(p).run(),
        *_cfg);

    notify(*_cfg);

    if ((*_cfg).count("help")||(*_cfg).count("version"))
      return 0;

    if (!(*_cfg).count("config-file"))
    {
      cerr << "usage: " << argv[0] << " <config-file> \n";
      exit(EXIT_FAILURE);
    }

    ifstream ifs((*_cfg)["config-file"].as<std::string>().c_str());
    store(parse_config_file(ifs,_desc_cfg),*_cfg );
    ifs.close();
    notify(*_cfg);
  }
  catch(std::exception& e)
  {
    cout << e.what() << "\n";
    exit(EXIT_FAILURE);
  }
  return 0;
}

Config& Config::instance()
{
  if (Config::_config.get() == 0)
  {
    Config::_config.reset(new Config);
  }
  return *Config::_config;
}



