#include "Get_Bill.h"





int getBillMsg(char *pLine, int len, BillMsg &stBM)
{
	int nPos = 0;
	//���Ȼ�ȡ��������
	memcpy(stBM.stBill.EventFormatType, pLine+nPos, 2);
	nPos += 2;
	if(atoi(stBM.stBill.EventFormatType) < 6)
	{	    	    
	    memcpy(stBM.stBill.roll_flag, pLine+nPos, 1);
	    nPos += 1;
	    
	    memcpy(stBM.stBill.roll_count, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.file_id, pLine+nPos, 10);
	    nPos += 10;
	    
	    memcpy(stBM.stBill.exc_id, pLine+nPos, 4);
	    nPos += 4;
	    
	    memcpy(stBM.stBill.FileType, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.subno, pLine+nPos, 24);
	    nPos += 24;
	    
	    memcpy(stBM.stBill.IMSI, pLine+nPos, 15);
	    nPos += 15;
	    
	    memcpy(stBM.stBill.IMEI, pLine+nPos, 15);
	    nPos += 15;
	    
	    memcpy(stBM.stBill.start_time, pLine+nPos, 14);
	    nPos += 14;
	    
	    memcpy(stBM.stBill.special_flag, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.proc_time, pLine+nPos, 14);
	    nPos += 14;
	    
	    memcpy(stBM.stBill.event_id, pLine+nPos, 20);
	    nPos += 20;
	    
	    memcpy(stBM.stBill.Switch_flag, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.District, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.Brand, pLine+nPos, 1);
	    nPos += 1;
	    
	    memcpy(stBM.stBill.User_Type, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.Visit_Area, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.B_subno, pLine+nPos, 24);
	    nPos += 24;
	    
	    memcpy(stBM.stBill.Bill_type, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.ACCT_Mob, pLine+nPos, 14);
	    nPos += 14;
	    
	    memcpy(stBM.stBill.ACCT_Toll, pLine+nPos, 14);
	    nPos += 14;
	    
	    memcpy(stBM.stBill.ACCT_Inf, pLine+nPos, 14);
	    nPos += 14;
	    
	    memcpy(stBM.stBill.Mob_fee, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.Toll_fee, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.Inf_fee, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.Pay_mode, pLine+nPos, 1);
	    nPos += 1;
//----------------------------------------------------------------
///�޸Ĳ���	 
/*   
	    memcpy(stBM.stBill.Be_Payed, pLine+nPos, 1);
	    nPos += 1;
	    
	    memcpy(stBM.stBill.deducted, pLine+nPos, 1);
	    nPos += 1;
	    
	    memcpy(stBM.stBill.acct_balance_a, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.acct_balance_b, pLine+nPos, 8);
	    nPos += 8;
*/	    
	    memcpy(stBM.stBill.dis_id, pLine+nPos, 64);
	    nPos += 64;
	    
	    memcpy(stBM.stBill.reserve, pLine+nPos, 36);
	    nPos += 36;
//-----------------------------------------------------------------
///��������
        memcpy(stBM.stBill.cbe_flag, pLine+nPos, 1);
        nPos += 1;
        
        memcpy(stBM.stBill.period_flag, pLine+nPos, 1);
        nPos += 1;
        
        memcpy(stBM.stBill.SubsID, pLine+nPos, 14);
        nPos += 14;

        memcpy(stBM.stBill.A_pay_type, pLine+nPos, 1);
        nPos += 1;
        
        memcpy(stBM.stBill.A_pay_subno, pLine+nPos, 24);
        nPos += 24;
        
        memcpy(stBM.stBill.A_pay_switch_flag, pLine+nPos, 2);
        nPos += 2;
        
        memcpy(stBM.stBill.A_pay_district, pLine+nPos, 2);
        nPos += 2;
        
        memcpy(stBM.stBill.A_pay_brand, pLine+nPos, 1);
        nPos += 1;
        
        memcpy(stBM.stBill.A_pay_user_type, pLine+nPos, 2);
        nPos += 2;
        
        memcpy(stBM.stBill.A_AcctID, pLine+nPos, 14);
        nPos += 14;
        
        memcpy(stBM.stBill.A_deducted, pLine+nPos, 1);
        nPos += 1;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE, pLine+nPos, 12);
        nPos += 12;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE_ID1, pLine+nPos, 18);
        nPos += 18;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE_AMT1, pLine+nPos, 8);
        nPos += 8;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE_ID2, pLine+nPos, 18);
        nPos += 18;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE_AMT2, pLine+nPos, 8);
        nPos += 8;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE_ID3, pLine+nPos, 18);
        nPos += 18;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE_AMT3, pLine+nPos, 8);
        nPos += 8;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE_ID4, pLine+nPos, 18);
        nPos += 18;
        
        memcpy(stBM.stBill.A_ACCT_BALANCE_AMT4, pLine+nPos, 8);
        nPos += 8;
        
        memcpy(stBM.stBill.B_pay_type, pLine+nPos, 1);
        nPos += 1;
        
        memcpy(stBM.stBill.B_pay_subno, pLine+nPos, 24);
        nPos += 24;
        
        memcpy(stBM.stBill.B_pay_switch_flag, pLine+nPos, 2);
        nPos += 2;
        
        memcpy(stBM.stBill.B_pay_district, pLine+nPos, 2);
        nPos += 2;
        
        memcpy(stBM.stBill.B_pay_brand, pLine+nPos, 1);
        nPos += 1;
        
        memcpy(stBM.stBill.B_pay_user_type, pLine+nPos, 2);
        nPos += 2;
        
        memcpy(stBM.stBill.B_AcctID, pLine+nPos, 14);
        nPos += 14;
        
        memcpy(stBM.stBill.B_deducted, pLine+nPos, 1);
        nPos += 1;
        
        memcpy(stBM.stBill.B_ACCT_BALANCE, pLine+nPos, 12);
        nPos += 12;
        
        memcpy(stBM.stBill.B_ACCT_BALANCE_ID1, pLine+nPos, 18);
        nPos += 18;
        
        memcpy(stBM.stBill.B_ACCT_BALANCE_AMT1, pLine+nPos, 8);
        nPos += 8;
        
        memcpy(stBM.stBill.B_ACCT_BALANCE_ID2, pLine+nPos, 18);
        nPos += 18;
        
        memcpy(stBM.stBill.B_ACCT_BALANCE_AMT2, pLine+nPos, 8);
        nPos += 8;
        
        memcpy(stBM.stBill.B_ACCT_BALANCE_ID3, pLine+nPos, 18);
        nPos += 18;
        
        memcpy(stBM.stBill.B_ACCT_BALANCE_AMT3, pLine+nPos, 8);
        nPos += 8;

//-----------------------------------------------------------------
///ɾ������
/*	    
	    memcpy(stBM.stBill.pay_switch_flag, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.pay_district, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.pay_brand, pLine+nPos, 1);
	    nPos += 1;
	    
	    memcpy(stBM.stBill.pay_user_type, pLine+nPos, 2);
	    nPos += 2;
	    
	    memcpy(stBM.stBill.pay_subno, pLine+nPos, 24);
	    nPos += 24;
	    
	    memcpy(stBM.stBill.pay_account, pLine+nPos, 14);
	    nPos += 14;
	    
	    memcpy(stBM.stBill.pay_acct_balance_a, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.pay_acct_balance_b, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.pay_mob_fee, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.pay_toll_fee, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.pay_inf_fee, pLine+nPos, 8);
	    nPos += 8;
	    
	    memcpy(stBM.stBill.pay_deducted, pLine+nPos, 1);
	    nPos += 1;
*/

///�ǹ̶�����	    
	    memcpy(stBM.stBill.xd_type, pLine+nPos, 1);
	    //nPos += 1;
	    	    
	    switch(atoi(stBM.stBill.xd_type))
	    {
	    	case CS:
	    		memcpy(stBM.stBill.change_part, pLine+nPos, CS_BILL_LEN-FIXED_BILL_LEN);
	    		break;
	    	case PS:
	    		memcpy(stBM.stBill.change_part, pLine+nPos, PS_BILL_LEN-FIXED_BILL_LEN);
	    		break;
	    	case GPRS:
	    		memcpy(stBM.stBill.change_part, pLine+nPos, GPRS_BILL_LEN-FIXED_BILL_LEN);
	    		break;
	    	case SB:
	    		memcpy(stBM.stBill.change_part, pLine+nPos, SB_BILL_LEN-FIXED_BILL_LEN);
	    		break;
	    	case WLAN:
	    		memcpy(stBM.stBill.change_part, pLine+nPos, WLAN_BILL_LEN-FIXED_BILL_LEN);
	    		break;
	    	default:
	    		LOG_SERVICE_ERROR("Can not identify the type of business(%s)\n", stBM.stBill.xd_type);
	    		return -1;
	    }
	}
	else
	{
		memcpy(stBM.stBill.subno,      pLine+19,  24);
		memcpy(stBM.stBill.start_time, pLine+43, 14);
		memcpy(stBM.stBill.xd_type,    pLine+130, 1);
		
		if(atoi(stBM.stBill.xd_type) == FF)
		{
		    memcpy(stBM.stBill.change_part,  pLine, FF_BILL_LEN);
		}
		else if(atoi(stBM.stBill.xd_type) == OF)
		{
			memcpy(stBM.stBill.change_part,  pLine, OF_BILL_LEN);
		}
		else
		{
			LOG_SERVICE_ERROR("Can not identify the type of business(%s)\n", stBM.stBill.xd_type);
	    	return -1;
		}
			
	}
	
	return 0;	
}

















