#ifndef _SORT_SIGNAL_H_
#define _SORT_SIGNAL_H_






extern bool g_bSigTerm;             //SIGTERM�źű��
extern bool g_bSigChild;            //SIGCHILD�źű��
extern bool g_bSigHup;              //SIGHUP�źű��
extern bool g_bSigUsr2;             //SIGUSR2�źű��
extern bool g_bSigAlarm;            //SIGALARM�źű��
extern bool g_bSigPipe;             //SIGPIPE�źű��




int HandleSortSignal();

int DoSortSigTerm();
int DoSortSigChild();
int DoSortSigHup();
int DoSortSigUsr2();
int DoSortSigAlarm();
int DoSortSigPipe();


void SigTerm(int signo);
void SigChild(int signo);
void SigHup(int signo);
void SigUsr2(int signo);
void SigAlarm(int signo);
void SigPipe(int signo);




#endif




