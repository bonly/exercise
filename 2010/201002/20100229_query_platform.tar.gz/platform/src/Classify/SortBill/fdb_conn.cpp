#include "fdb_conn.h"
#include "Service_Common.h"
#include <ssqls.h>

using namespace std;
using namespace mysqlpp;

CFdbConn::CFdbConn():m_iReConnTimes(3)
{
	m_strLocalDB="";
	m_strHost="";
	m_strUser="";
	m_strPdw="";
	m_iPort=3306;
}
 
CFdbConn::~CFdbConn()
{
    Destory();
}

bool CFdbConn::CheckFarDBConn(mysqlpp::Connection* pConn)
{
	if(NULL == pConn)
	{
		return false;
	}
	return pConn->ping();
}

int CFdbConn::CreateConnString(const char* db, char* szConnstr, int len, const char* server, const char* user,
			const char* password, unsigned int port)
{
	snprintf(szConnstr, len, "%s|%d|%s|%s|%s", server, port, db, user, password);
	LOG_SERVICE_DEBUG("connstr=%s\n", szConnstr);
	return 0;
}

bool CFdbConn::AnalyConnString(const char* strConnString,std::string &strdb,std::string &strserver,
			std::string &struser,std::string &strpwd,int &iport)
{
	char szConnstr[1024];
	memset(szConnstr, 0, sizeof(szConnstr));
	strncpy(szConnstr, strConnString, sizeof(szConnstr));
	
	strserver = strtok(szConnstr, "|");
	char* sPort = strtok(NULL, "|");
	iport = atoi(sPort);
	strdb = strtok(NULL, "|");
	struser = strtok(NULL, "|");
	strpwd = strtok(NULL, "|");
	LOG_SERVICE_DEBUG("server=%s,p=%d,db=%s,usr=%s,pwd=%s\n",strserver.c_str(), iport, strdb.c_str(), struser.c_str(), strpwd.c_str());
	return true;
}

int CFdbConn::Init(char* sLocaldb,char* sHost,char* sUser,char* sPdw,int iPort,int iReConnTimes)
{
	m_strLocalDB=sLocaldb;
	m_strHost=sHost;
	m_strUser=sUser;
	m_strPdw=sPdw;
	m_iPort=iPort;
	m_iReConnTimes=iReConnTimes;
	mysqlpp::Connection conn(false);
	mysqlpp::Connection* pConnFarDB = NULL;
	bool bConnSuc=false;	
	int iSize = 0;
	int iReConnT=m_iReConnTimes;
	char szConnstr[1024];
	
	
	LOG_SERVICE_DEBUG("Init!\n");	
	if(!m_mapConnect.empty())
	{
		Destory();
	}

    if (conn.connect(m_strLocalDB.c_str(), m_strHost.c_str(), m_strUser.c_str(), m_strPdw.c_str(),m_iPort))
    {    	
    	mysqlpp::Query query = conn.query("select ip,port,usr,psw,sqldb from conntab");   
 		LOG_SERVICE_DEBUG("Query begin!\n");
      	mysqlpp::StoreQueryResult res;
	    try
		{
			res = query.store();
		}
	 	catch (const BadQuery& er)
	    {
	    	LOG_SERVICE_ERROR("Query error: %s\n", er.what() );
	    	return FDB_SELECTFAIL_ERROR;
	    }
	    catch (const BadConversion& er)
	    {
	  		LOG_SERVICE_ERROR("Conversion error: %s\n", er.what() );
	  		LOG_SERVICE_ERROR("tretrieved data size: %s, actual size: %d\n", er.retrieved, er.actual_size);
	  		return FDB_SELECTFAIL_ERROR;
	    }
	    catch (const Exception& er)
		{
		  	LOG_SERVICE_ERROR("Error: %s\n", er.what());
		  	return FDB_SELECTFAIL_ERROR;
		}
	    catch (...)
	    {
	   		LOG_SERVICE_ERROR("unknow err!\n");
		   	return FDB_SELECTFAIL_ERROR;
	    }		
		if (res)
      	{         	      		
         	for (size_t i =0; i < res.num_rows(); ++i)
         	{            	
            	pConnFarDB = new mysqlpp::Connection(false);
            	if(NULL != pConnFarDB)
            	{
            		while(iReConnT > 0)
            		{
            			iReConnT--;
            			bConnSuc=pConnFarDB->connect(res[i]["sqldb"],res[i]["ip"],res[i]["usr"],res[i]["psw"],res[i]["port"]);
	            		if(bConnSuc)
            			{
            				LOG_SERVICE_WARN("[Init]%s|%s|%s|%s|%s, connect error\n", res[i]["sqldb"].c_str(),res[i]["ip"].c_str(),
            				                             res[i]["usr"].c_str(),res[i]["psw"].c_str(),res[i]["port"].c_str());
            				continue;
            			}            			
            		}
            		if(bConnSuc)
            		{
            			//��map�����¼           			
            			std::pair< std::map<std::string,mysqlpp::Connection*>::iterator,bool> instret;
            			memset(szConnstr, 0 , sizeof(szConnstr));
            			CreateConnString(res[i]["sqldb"].c_str(),szConnstr, sizeof(szConnstr),res[i]["ip"].c_str(),res[i]["usr"].c_str(), res[i]["psw"].c_str(),res[i]["port"]);
					    instret=m_mapConnect.insert( std::pair<std::string,mysqlpp::Connection*>(szConnstr,pConnFarDB));
					    if(!instret.second)
            			{
            				//�����¼����
            				LOG_SERVICE_ERROR("Insert Map err!\n");
            				Destory();
            				delete pConnFarDB;
            				pConnFarDB=NULL;
      						return FDB_INSERTMAP_ERROR;
            			}
            		}
            		else
            		{
            			Destory();
            			LOG_SERVICE_ERROR("Far DB connection failed: %s\n", pConnFarDB->error());
            			delete pConnFarDB;
            			pConnFarDB=NULL;
      					return FDB_MORETHANTIMES_ERROR;
            		}
            	}
            	else
            	{            		
            		return FDB_APPMEN_ERROR;
            	}
          	}
      	}
     	else
      	{
         	LOG_SERVICE_ERROR("Failed to get item list: %s\n", query.error());
         	return FDB_SELECTFAIL_ERROR;
      	}
 
      	LOG_SERVICE_DEBUG("Query finish!\n");
      	iSize = m_mapConnect.size();
      	return iSize;
   }
   
    LOG_SERVICE_ERROR("local DB connection failed: %s\n", conn.error());
    return FDB_CONNECTDB_ERROR;
}

void CFdbConn::Destory(void)
{
	if(m_mapConnect.empty())
	{
		return;
	}	
	std::map<std::string, mysqlpp::Connection*>::iterator iter;
	for(iter = m_mapConnect.begin(); iter != m_mapConnect.end(); iter++)
	{
	    //cout<<iter->first<<endl;
	    delete iter->second;
	    iter->second=NULL;
	    //m_mapConnect.erase(iter);
	}
	m_mapConnect.clear();
}

int CFdbConn::GetDbConn(char* skey, mysqlpp::Connection** pConn)
{
	int iRetCode=FDB_FAILED;
	if(skey == NULL)
	{
		return iRetCode;
	}
	int iReConnT=m_iReConnTimes;//ʧ����������
	bool bConnSuc=false;
	std::map<std::string, mysqlpp::Connection*>::iterator iter;	
	//std::string strkey=skey;
	std::string strIP,strUsr,strPwd,strDB;
	int iPort=3306;
	*pConn=NULL;
	
	if(!AnalyConnString(skey,strDB,strIP,strUsr,strPwd,iPort))
	{
		return FDB_ANALYCONNSTRING_ERROR;
	}
	
	string sConnstr = skey;
	
    iter = m_mapConnect.find(sConnstr);
	if(iter != m_mapConnect.end())
	{
	    if(CheckFarDBConn(iter->second))
	    {
	    	LOG_SERVICE_DEBUG("Get Suc!\n");
	    	*pConn=iter->second;
	    	iRetCode=FDB_SUCCESS;
	    }
	    else
	    {
    		//����ʧЧ����ָ��
		    if(iter->second != NULL)
	    	{
	    		iter->second->disconnect();
	    		delete iter->second;
	    		iter->second=NULL;
	    	}
	    	
	    	iter->second = new mysqlpp::Connection(false);
            if(NULL != iter->second)
            {
            	while(iReConnT > 0)
            	{
            		iReConnT--;
            		bConnSuc=(iter->second)->connect(strDB.c_str(), strIP.c_str(), strUsr.c_str(), strPwd.c_str(),iPort);
	            	if(bConnSuc)
            		{
            			if(CheckFarDBConn(iter->second))
					    {
					    	break;
					    } 
					    else
						{	
							delete iter->second;
	    					iter->second=NULL;
	    					iter->second = new mysqlpp::Connection(false);
	    					if(NULL == iter->second)
	    					{
            					return FDB_APPMEN_ERROR;
	    					}
						}	
            		}            			
            	}
            	if(bConnSuc)
            	{
            		LOG_SERVICE_DEBUG("Get Suc!\n");
					*pConn=iter->second;
					iRetCode=FDB_SUCCESS;
            	}
            	else
            	{            		
            		LOG_SERVICE_ERROR("Far DB connection failed: %s\n", (iter->second)->error() );
            		delete iter->second;
            		iter->second=NULL;
      				return FDB_MORETHANTIMES_ERROR;
            	}            		
            }
            else
            {
            	
            	    return FDB_APPMEN_ERROR;
            	
            }
	    }
	}
	else
	{
		mysqlpp::Connection* pConnNext = new mysqlpp::Connection(false);
        if( RemoteConnectDb(skey, *pConnNext) )
        {
            LOG_SERVICE_ERROR("[GetDbConn]%s, connect error\n",  skey);    
            delete pConnNext;
            return FDB_CONNECTDB_ERROR;
        }
        m_mapConnect.insert(pair<std::string,mysqlpp::Connection*>(skey, pConnNext));
        *pConn = pConnNext;
        iRetCode=FDB_SUCCESS;
	}
	LOG_SERVICE_DEBUG("iRetCode=%d\n", iRetCode);
	return iRetCode;
}



int CFdbConn::RemoteConnectDb(const char* strConnString, mysqlpp::Connection &conn)
{
	std::string strIP,strUsr,strPwd,strDB;
	int iPort=3306;

	if(!AnalyConnString(strConnString,strDB,strIP,strUsr,strPwd,iPort))
	{
		return FDB_ANALYCONNSTRING_ERROR;
	}

	if(conn.connect(strDB.c_str(), strIP.c_str(), strUsr.c_str(), strPwd.c_str(), iPort))
	{
		return FDB_SUCCESS;
	}
	else
	{
		LOG_SERVICE_ERROR("remote db connect failed!(%s|%s|%s|%s|%d|%s)\n", strDB.c_str(), strIP.c_str(), strUsr.c_str(), strPwd.c_str(), iPort, conn.error());
		return FDB_CONNECTDB_ERROR;
	}	
}
