#ifndef _FILETOCACHE_H_
#define _FILETOCACHE_H_




#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include "Service_Common.h"
#include "Protocal.h"

using namespace bas;



int    Treat_File(char *szFileName);

int    FillInCache(Protocal &p, BillMsg &stBM);








#endif


