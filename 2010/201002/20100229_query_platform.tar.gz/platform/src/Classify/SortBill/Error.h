#ifndef _ERROR_H_
#define _ERROR_H_



#define                 SUCCESS                                       0

#define                 ER_NET_SEND_ERROR                          7001
#define                 ER_RE_MSG_HEAD_LENGTH_ERROR                7002
#define                 ER_PRO_DECODEANS_ERROR                     7003
#define                 ER_PRO_ANS_CODE_ERROR                      7004
#define                 ER_NET_SOCKET_CLOSED                       7005
#define                 ER_NET_RECV_ERROR_READMSG                  7006
#define                 ER_BFS_RECV_TIME_OUT                       7007
#define                 ER_NET_RECV_ERROR_SELECT                   7008


#define                 ER_BILL_FILE_EXCEPTION                     8001
#define                 ER_NO_FILE_TO_GET                          8002
#define                 ER_FILE_IS_PROCESSED_OR_TRANSFER           8003
#define                 ER_CHECK_FILE_ERROR                        8004

#define                 ER_ALL_NODE_IS_NOT_ALLOW_TO_LOAD           9001









#endif



