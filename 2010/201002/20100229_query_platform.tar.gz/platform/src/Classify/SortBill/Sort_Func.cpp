#include "Sort_Func.h"
#include "Sort_Signal.h"
#include "Sort_File.h"
#include "Error.h"
#include "Sort_Signal.h"
#include "../Load/Load_Process.h"
#include "Db_sql.h"
#include "FileToCache.h"
#include "DataAccess_Mysql.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>






map<int, DataList *> *g_pTotalMsg;
NumList                 *pNL;




void PrintBillMsg()
{
	DataList    *pDL;
	ConnectInfo *pCI;
	BillList    *pBL;
	std::map<int, DataList *>::iterator iter;
	std::map<int, BillList *>::iterator iter2;
	for(iter=g_pTotalMsg->begin(); iter != g_pTotalMsg->end(); iter++)
	{
		LOG_SERVICE_DEBUG("groupID: %d\n", iter->first);
		pDL = iter->second;
		LOG_SERVICE_DEBUG("bill file: %s, deal month: %d\n", pDL->filename, pDL->nDealMonth);
		
		for(int i=0; i<pDL->stCl.nCount; i++)
		{
			pCI = &pDL->stCl.stItem[i];
			LOG_SERVICE_DEBUG("====%s|%s|%d|%d\n", pCI->instanceName, pCI->connectStr, pCI->status, pCI->threshold);
		}
		
		for(iter2=pDL->mMonthBillRecord.begin(); iter2!=pDL->mMonthBillRecord.end(); iter2++)
		{
			LOG_SERVICE_DEBUG("========YearMonth: %d\n", iter2->first);
			pBL = iter2->second;
			for(int j=0; j<pBL->nCount; j++)
			{
				LOG_SERVICE_DEBUG("============%s|%s\n", pBL->stItem[j].stBill.subno, pBL->stItem[j].stBill.start_time);
			}
		}
		
	}
	
}


int Service_Process(Service_CONF *pConf)
{
	int nRet = 0;
	char szFileName[MAX_FILE_NAME];
	Load_Process lp(sCreateTableSql, &g_conn);	
	g_pTotalMsg = new map<int, DataList *>();
	pNL         = new NumList;
	stCT.dealNum = 0;
	stCT.time = 0;
	while(!g_bSigTerm)
	{
		///�źŴ���
        nRet = HandleSortSignal();
        if(nRet < 0)
        {
            LOG_SERVICE_ERROR("HandleSortSignal failed!\n");
            CacheDestory();
            delete g_pTotalMsg;
            delete pNL;
            SEND_EVEN_KPI("HandleSortSignal failed", CRITICAL);
            return -1;
        }

	    ///��ȡ�ļ���
	    nRet = Get_File(pConf, szFileName);
	    if(nRet < 0)
	    {
	    	LOG_SERVICE_ERROR("Get_File error!code=%d\n", nRet);
	    	CacheDestory();
	    	delete g_pTotalMsg;
	    	delete pNL;
	    	SEND_EVEN_KPI("Get_File error", CRITICAL);
	    	return -1;
	    }
	    else if(nRet == ER_NO_FILE_TO_GET)
	    {
	    	//�����������ļ�ʱ��Ҫ����״̬�˳�
	    	if( strncmp(pConf->szBillHeader, UNLOAD_BILL_HEAD, 11) == 0) 
	    	{
	    		LOG_SERVICE_WARN("No file to get!\n");
	    		
	    		//���½ڵ�����Ϣ״̬
	    		if( strlen(szUnloadBillPath) != 0 )
	    		{
	    		    nRet = updateNodeGroupStatus(0, szUnloadBillPath);
	    		    if( nRet != 0)
	    		    {
	    		    	LOG_SERVICE_ERROR("updateNodeGroupStatus error\n");
	    		    	SEND_EVEN_KPI("updateNodeGroupStatus error", CRITICAL);
	    		    	return -1;
	    		    }
	    		}
	    		break;
	    	}
	    	sleep(pConf->nScanBPTime);
	    	continue;
	    }
	    else if(nRet == ER_FILE_IS_PROCESSED_OR_TRANSFER)
	    {
	    	continue;
	    }
	    else if(nRet == ER_CHECK_FILE_ERROR)
	    {
	    	SEND_EVEN_KPI("check file failed", CRITICAL);
	    	break;
	    }
	    
	    LOG_SERVICE_INFO("get bill file: %s\n", file_name);
	    	    
	    ///�����ļ�
	    nRet = Treat_File(szFileName);
	    if(nRet != 0)
	    {
	    	if(nRet == ER_BILL_FILE_EXCEPTION)
	    	{
	    		///���ļ�ת��Ŀ¼
				ChangeFilePath(pConf, szFileName);
				snprintf(szKpiMsg, sizeof(szKpiMsg), "File(%s) format exception!", szFileName);
				SEND_EVEN_KPI(szKpiMsg, CRITICAL);
				//�������
                CacheDestory();
				continue;
			}
			else if(nRet == ER_ALL_NODE_IS_NOT_ALLOW_TO_LOAD)
			{
				//���ļ���ԭ����
				char fileNameSrc[256];
				memset(fileNameSrc, 0, sizeof(fileNameSrc));
				strncpy(fileNameSrc, szFileName, strlen(szFileName)-4);
				LOG_SERVICE_DEBUG("file_name:%s, change_name:%s\n", szFileName, fileNameSrc);
				rename_file(szFileName, fileNameSrc);
				//�������
                CacheDestory();
				sleep(10);
				continue;
			}
			else
			{
	    	    LOG_SERVICE_ERROR("Treat_File error!code=%d,file=%s\n", nRet, szFileName);
	    	    snprintf(szKpiMsg, sizeof(szKpiMsg), "Treat File(%s) error!", szFileName);
	    	    SEND_EVEN_KPI(szKpiMsg, CRITICAL);
	    	    break;
	    	}
	    }
	    
	    ///��ӡ������Ϣ
	    PrintBillMsg();
	    
	    ///�������ݿ�
	    nRet = lp.LoadDB();
	    if(nRet != 0)
	    {
	    	LOG_SERVICE_ERROR("Load_Db error! file=%s,errcode=%d\n", szFileName, nRet);
	    	snprintf(szKpiMsg, sizeof(szKpiMsg), "File(%s) Load_Db error!", szFileName);
	    	SEND_EVEN_KPI(szKpiMsg, WARNING);
	    }
	    	    
	    ///��������
	    nRet = Cleanup_file(szFileName);
	    if(nRet != 0)
	    {
	    	LOG_SERVICE_ERROR("Cleanup_file error!code=%d,file=%s\n", nRet, szFileName);
	    	snprintf(szKpiMsg, sizeof(szKpiMsg), "Cleanup File(%s) error!", szFileName);
	    	SEND_EVEN_KPI(szKpiMsg, WARNING);
	    	break;	    	
	    }
	    
	    getCT(stCT);
	    
    }
    //�������
    CacheDestory();
    delete g_pTotalMsg;
    delete pNL;
	return(0);
}




int RounterExchangeTCP(char *InBuf, int nLen, Protocal &p)
{
	int nRealCount = 0;
	int nTmpCount  = 0;
	int nRet = 0;
	
	///send
	while (nRealCount < nLen)
	{
		nTmpCount = ::send(g_nFd, InBuf+nRealCount, nLen-nRealCount, 0);
		if (nTmpCount >= 0)
		{
			nRealCount += nTmpCount;
		}
		else  // -1
		{
			// c1: interrupt
			if (errno == EINTR)  // ����I/O, ���ж�
			{
				continue;
			}
			
			// c2: error
			LOG_SERVICE_ERROR("send is error! error code is %d\n", nTmpCount);
			return ER_NET_SEND_ERROR;
		}
	}
	
	// receiv msg
	fd_set rset;
    struct timeval tv;
    tv.tv_sec  = 3; // 3��
    tv.tv_usec = 0;  
    int nRecvLen = 0;
    char OutBuf[NET_PACKET_LENGTH] = {0};
    
    while (true)
	{
		FD_ZERO(&rset);
		FD_SET(g_nFd, &rset);
		nRet = select(g_nFd+1, &rset, NULL, NULL, &tv);
		if (nRet > 0)
		{
			if (FD_ISSET(g_nFd, &rset))
			{
				memset(OutBuf, 0 , sizeof(OutBuf));
				// read head
				if (nRet = readTCPMsg(g_nFd, OutBuf, PACKET_HEAD_LEN) == 0)
				{
					//len=4
					nRecvLen = ntohl(*((int*)(OutBuf)));
					// �����Ϣ�����Ƿ�Ϸ�
    				if (nRecvLen < PACKET_HEAD_LEN|| nRecvLen > NET_PACKET_LENGTH)
   					{
   						LOG_SERVICE_ERROR("Message len=%d\n", nRecvLen);
   						return ER_RE_MSG_HEAD_LENGTH_ERROR;
   					}
   					
   					// read body
   					if (nRet = readTCPMsg(g_nFd, OutBuf+PACKET_HEAD_LEN, nRecvLen-PACKET_HEAD_LEN) == 0)
   					{
                        p.Reset();
                        nRet = p.DecodeAns(OutBuf);
                        if(nRet != 0)
                        {
                        	LOG_SERVICE_ERROR("Protocal DecodeAns error! ret=%d\n");
                        	return ER_PRO_DECODEANS_ERROR;
                        }
                        if(p.data()->acommand != ANS_CODE)
                        {
                        	LOG_SERVICE_ERROR("not answer code(%d)\n", p.data()->acommand);
                        	return ER_PRO_ANS_CODE_ERROR;
                        }
                        return SUCCESS;
   						
   					} // ~end of if()
 				}
		        if(nRet == -1)
		        {
		            return ER_NET_RECV_ERROR_READMSG;
		        }
		        if(nRet == -2)
		        {
		            return ER_NET_SOCKET_CLOSED;
		        }
		        else
		        {
		            return -4;
		        }
			}
			else
			{
				FD_SET(g_nFd, &rset);
			}
		}
		else if (nRet == 0)
		{
			// time out
			return ER_BFS_RECV_TIME_OUT;
		}
		else if (nRet < 0 && errno == EINTR)
		{
			// error
			continue;
		}
		else
		{
			return ER_NET_RECV_ERROR_SELECT;
		}
	} // ~end of while()

	return nRet;
}




int readTCPMsg(int nSocketfd, char* pBuffer, int nSize)
{
	int nRealCount = 0;
	int nTmpCount  = 0;
	
	while (nRealCount < nSize)
	{	
		// �ֽ������ⲿת��
		nTmpCount = ::recv(nSocketfd, pBuffer + nRealCount, nSize - nRealCount, 0);
		if (nTmpCount > 0)
		{
			nRealCount += nTmpCount;
		}
		else if (nTmpCount == 0)
		{
		    LOG_SERVICE_ERROR("peer socket is closed!\n");
			return -2;  // peer socket is closed
		}
		else  // -1
		{
			// c1: interrupt
			if (errno == EINTR)  // ����IO, ���ж�
			{
				continue;
			}
	
			// c2: error
			LOG_SERVICE_ERROR("recv is error! error code is %d\n", nTmpCount);
			return -1;
		}
	}
	
	return 0;
	
}


//�������
void CacheDestory()
{
	map<int, DataList *>::iterator iter;
	map<int, BillList *>::iterator iter2;
	for(iter = g_pTotalMsg->begin(); iter != g_pTotalMsg->end(); iter++)
	{
		memset(iter->second->filename, 0, sizeof(iter->second->filename));
		memset(&(iter->second->stCl),  0, sizeof(ConnectList));
		iter->second->stCl.nCount = 0;
		for(iter2 = iter->second->mMonthBillRecord.begin(); iter2 != iter->second->mMonthBillRecord.end(); iter2++)
		{
			iter2->second->nCount = 0;
			iter2->second->stItem.clear();
			delete iter2->second;
		}
		iter->second->mMonthBillRecord.clear();
		delete iter->second;
	}
	g_pTotalMsg->clear();
	
}







