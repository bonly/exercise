#ifndef _SORT_FILE_H_
#define _SORT_FILE_H_


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include "Service_Common.h"
#include "Protocal.h"






using namespace bas;




///
extern struct flock fk;



///
int    Get_File(Service_CONF *pConf, char *szFileName);

bool   is_exists(const char* pszfile);

int    fetch_files(const char* pszDir, char* szFileName);

int    Cleanup_file(char *szFileName);

int    get_year_month(long long lDateTime);

bool   rename_file(const char* pszsrc, const char* pszdst);

bool   del_file( const char* pszfile );

int    Check_File();

void   ChangeFilePath(Service_CONF *pConf, char *szFileName);

void   CacheDestory();

void setCT(COUNTER &stCT);
void getCT(COUNTER &stCT);




#endif



