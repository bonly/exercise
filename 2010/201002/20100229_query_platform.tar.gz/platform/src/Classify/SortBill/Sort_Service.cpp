#include "Sort_Service.h"
#include "Service_Common.h"
#include "Service_Init.h"
#include "Sort_Func.h"



R5_Log g_service_log;
char  szUnloadBillPath[MAX_PATH_LEN];



void Help_Message()
{
    printf("Classify [-h] [-c profile] [-e] [-v]\n");
    printf("            -h: Show Help_Message\n");
    printf("            -c: conf file\n");
    printf("            -p: path\n");
    printf("            -e: deamon\n");
    printf("            -v: version\n");
}



void Get_Option(int argc, char *argv[], char *pConfFile, bool &bDaemon)
{

    extern char *optarg;
    int optch;

    static char optstring[] = "hec:p:vV";
    
    char szType[10]={0};
    
    memset(szUnloadBillPath, 0, sizeof(szUnloadBillPath));
    
    while((optch = getopt(argc , argv , optstring)) != -1 ) 
    {
        switch( optch ) 
        {
        case 'h':
            Help_Message();
            exit(-1);
        case 'e':
            bDaemon = true;
            break;
        case 'c':            
            strcpy(pConfFile, optarg);
            break;
        case 'p':
        	strncpy(szUnloadBillPath, optarg, sizeof(szUnloadBillPath));
        	break;
        case 'v':
        case 'V':
            printf("sort_bill version %s\n", PROGRAM_VERSION);
            exit(-1);
        case '?':
            Help_Message();
            printf("unknown parameter: %c\n", optopt);
            exit(-1);
        case ':':
            Help_Message();
            printf("need parameter: %c\n", optopt);
            exit(-1);

        default:
            break;
        }
    }
        
    if(access(pConfFile, F_OK) != 0)
    {
        printf("conf file %s not exist,please check!\n", pConfFile);
        exit(-1);
    }
    
}

void daemon() 
{
    // ��̨����
    int pid = 0;
    pid = fork();
    if(pid < 0)
    {
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return;
    }  
    if (pid  >  0) 
    {
        exit(0);
    }
   
    setsid();
    pid=fork();
    if(pid < 0)
    {
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return;           
    }    
    if(pid > 0) 
    {
        exit(0);
    }
}



int main(int argc, char *argv[])
{
    char szConfFile[MAX_FILE_LEN+1];
    
    memset(szConfFile, 0, sizeof(szConfFile));
    
    int nRet = -1;
    bool bDaemon = false;
	
	///��ȡ�������
    Get_Option(argc, argv, szConfFile, bDaemon);
    
    if(bDaemon)
    {
        daemon();
    }
	
	nRet = Sort_Bill_Service(szConfFile);
	if(nRet != 0)
	{
		printf("Sort_Bill_Service error! ret=%d\n", nRet);
	}
	
	return(0);
}


int Sort_Bill_Service(const char *pConfFile)
{
	int nRet = 0;
	Service_CONF conf;
	memset(&conf, 0, sizeof(Service_CONF));
	
	nRet = Service_Init(pConfFile, &conf);
	if(nRet != 0)
	{
		printf("Service_Init error, code=%d\n", nRet);
		return -1;
	}
	
	///
	nRet = Service_Process(g_pConf);
	if(nRet != 0)
	{
		LOG_SERVICE_ERROR("Service_Process error, code=%d\n", nRet);
	}
	
	///
	nRet = Service_Destroy(g_pConf);
	if(nRet != 0)
	{
		LOG_SERVICE_ERROR("Service_Destroy error, code=%d\n", nRet);
		return -1;
	}
	
	g_service_log.flush();
	return(0);
}












