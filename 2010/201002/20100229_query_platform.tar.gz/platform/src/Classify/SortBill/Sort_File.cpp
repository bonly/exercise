#include "Sort_File.h"
#include "com_date.h"
#include "Sort_Func.h"
#include "DataAccess_Mysql.h"
#include "Error.h"
#include "FileToCache.h"
#include <map>
#include <time.h>
#include <sys/time.h>



using namespace std;










char     file_name[MAX_FILE_NAME];
COUNTER  stCT;
int reload_flag = 0;


struct flock fk;
struct flock* lock_info(short type, short whence)
{
    fk.l_type = type;
    fk.l_start = 0;
    fk.l_whence = whence;
    fk.l_len = 0;
    fk.l_pid = getpid();
    return &fk;
}


int Get_File(Service_CONF *pConf, char *szFileName)
{
	int nRet = 0;
	
	///
	memset(szFileName, 0, MAX_FILE_NAME);
	nRet = fetch_files(pConf->szBillPath, szFileName);
	if(nRet != 0)
	{
		LOG_SERVICE_ERROR("fetch_files error\n");
		return nRet;
	}
	else if( strlen(szFileName) == 0 )
	{
		///Ŀ¼������Ҫ�����ļ�
		return ER_NO_FILE_TO_GET;
	}
	else if( strncmp(file_name, pConf->szBillHeader, strlen(pConf->szBillHeader)) )
	{
	    ///���ļ�ת��Ŀ¼
	    LOG_SERVICE_WARN("filename(%s) is not compliance with the rules, must to change path\n", file_name);
		ChangeFilePath(pConf, szFileName);
		return ER_FILE_IS_PROCESSED_OR_TRANSFER;
    }
	else
	{
		///TODO:�ļ�����
		///����ļ��Ƿ��Ѿ���������
	    nRet = Check_File();
	    if(nRet > 0)
	    {
	    	LOG_SERVICE_INFO("file(%s) have hendled!\n", file_name);
	    	///���ļ���
	    	char szFileBakName[MAX_FILE_NAME] = {0};
	    	snprintf(szFileBakName, MAX_FILE_NAME, "%s.bak", szFileName);
	    	if( !rename_file(szFileName, szFileBakName) )
	    	{
	    		LOG_SERVICE_ERROR("rename_file file(%s) error!\n", szFileName);
	    		del_file( szFileName );
	    	}
	    	return ER_FILE_IS_PROCESSED_OR_TRANSFER;
	    }
	    else if(nRet < 0)
	    {
	    	LOG_SERVICE_ERROR("Check_File error! filename=%s\n", file_name);
	    	return ER_CHECK_FILE_ERROR;
	    }
	}
	
	return(0);	
}



bool is_exists(const char* pszfile)
{
	return ( access(pszfile, F_OK ) == 0 );
}

bool del_file( const char* pszfile )
{
	return ( remove(pszfile) == 0 );
}

bool create_dir( const char* pszdir )
{
	return ( mkdir( pszdir, 0755 ) == 0 );
}

time_t ctime_of_file( const char* pszfile )
{
	struct stat file_info;
	if( stat(pszfile, &file_info) == -1 )
		return 0;
	else
		return file_info.st_ctime;
}

/*void pure_file_name( const char* pszfull, char* pure )
{
	memset( pure, 0, sizeof(pure) );
	const char* p = strrchr(pszfull, DIR_SEP);
	strcpy( pure, p + 1 );
}*/

bool rename_file(const char* pszsrc, const char* pszdst)
{
	if( is_exists(pszdst) )
	{
		return false;
	}

	if( rename(pszsrc, pszdst) == 0 )
	{
		return true;
	}
	else
		return false;
}

bool link_file( const char* pszsrc, const char* pszdst )
{
	if( is_exists(pszdst) )
		return false;

	return ( link(pszsrc, pszdst) == 0 );
}


///���ļ�����---Ȱ����
int lock_file(int fd)
{
	return fcntl(fd, F_SETLKW, lock_info(F_WRLCK, SEEK_SET));	
}

///���ļ�����
int unlock_file(int fd)
{
	return fcntl(fd, F_SETLKW, lock_info(F_UNLCK, SEEK_SET));	
}


bool check_name(char *szFileName)
{
	int len = strlen(szFileName);
	//.tmp
	if (szFileName[len-1] == 'p' && szFileName[len-2] == 'm'
		 && szFileName[len-3] == 't' && szFileName[len-4] == '.')
	{
		return true;
	}
	//.bak
	else if(szFileName[len-1] == 'k' && szFileName[len-2] == 'a'
		 && szFileName[len-3] == 'b' && szFileName[len-4] == '.')
    {
    	return true;
    }
    //.swp
	else if(szFileName[len-1] == 'p' && szFileName[len-2] == 'w'
		 && szFileName[len-3] == 's' && szFileName[len-4] == '.')
    {
    	return true;
    }
    //.J
    else if(szFileName[len-1] == 'J' && szFileName[len-2] == '.')
    {
    	return true;
    }
    else
	{
		return false;
	}
}

int fetch_files(const char* pszDir, char* szFileName)
{
	DIR* pDir = NULL;
	int i = 0;
	struct dirent* pDirent;
	struct stat statinfo;

	if( is_exists(pszDir) )
		pDir = opendir(pszDir);
	else
	{
		return -1;
	}
	if( pDir == NULL )
	{
		return -2;
	}

	char szFullName[256];
	int fd = 0;
	while( ( pDirent = readdir(pDir) ) != NULL )
	{
		if( ( strcmp( pDirent->d_name, "." ) == 0 ) ||
			( strcmp( pDirent->d_name, ".." ) == 0 ) )
			continue;
        
        ///�������ڴ����ļ�,�ų�.bak,.tmp���ļ�
        if(check_name( pDirent->d_name ))continue;
        	
        memset( szFileName, 0, sizeof( szFileName ) );
		memset( szFullName, 0, sizeof( szFullName ) );
		strcpy( szFullName, pszDir );
		strcat( szFullName, "/" );
		strcat( szFullName, pDirent->d_name );
		if( stat( szFullName, &statinfo ) == -1 )
			continue;
		/* is directory */
		if( S_ISDIR( statinfo.st_mode ) )
			continue;
			
	    
        fd = open(szFullName, O_RDWR);
        if( fd == -1)
        {
        	perror("open");
        	continue;
        }
        
        //����
        if( lock_file(fd) != 0)
        {
        	perror("lock_file");
        	close(fd);
        	continue;
        }
        
        //����
        snprintf(szFileName, MAX_FILE_NAME, "%s.tmp", szFullName);
        if( rename_file(szFullName, szFileName) )
        {
        	//����
        	if( unlock_file(fd) == 0)
        	{
        		close(fd);
        		memset(file_name, 0, sizeof(file_name));
        		strncpy(file_name, pDirent->d_name, sizeof(file_name)-1);
        		break;
        	}
        	else
        	{
        		perror("unlock_file");
        		memset(file_name, 0, sizeof(file_name));
        		strncpy(file_name, pDirent->d_name, sizeof(file_name)-1);
        		close(fd);
        		break;
        	}
        	
        }
        else
        {
        	///����
        	unlock_file(fd);
        	close(fd);
        	memset(szFileName, 0, MAX_FILE_NAME);
        	continue;
        }

	}

	closedir(pDir);

	return 0;
}














int get_year_month(long long lDateTime)
{
	CCommonDate comm(lDateTime-CONV_1900_1970);
	
	char ym[7];
	snprintf(ym, sizeof(ym), "%4d%02d", comm.getYear(), comm.getMonth());
	return atoi(ym);
}



int Cleanup_file(char *szFileName)
{
	//��ջ���
	CacheDestory();
		
	///�����ݿ��м�¼�ļ���
	//TODO:
	if(reload_flag == 0)
	{
	    int nRet = insertFileName(file_name);
	    if(nRet != 0)
	    {
		    LOG_SERVICE_ERROR("insertFileName error!filename=%s\n", file_name);
		    return -1;
	    }
	}
	
	//ɾ���ļ�
	if( del_file(szFileName) )
	{
		return(0);
	}
	else
	{
		LOG_SERVICE_ERROR("del file error, file=%s\n", szFileName);
		return -1;
	}

    memset(file_name, 0, sizeof(file_name));
	return(0);
}



int Check_File()
{
	return selectFileName(file_name);	
}



void   ChangeFilePath(Service_CONF *pConf, char *szFileName)
{
	char szFileErrName[MAX_FILE_NAME] = {0};
	snprintf(szFileErrName, sizeof(szFileErrName), "%s/%s", pConf->szErrBillPath, file_name);
	if( !rename_file(szFileName, szFileErrName) )
	{
	    LOG_SERVICE_ERROR("rename_file file(%s) to %s error!\n", szFileName, szFileErrName);
	}
}

