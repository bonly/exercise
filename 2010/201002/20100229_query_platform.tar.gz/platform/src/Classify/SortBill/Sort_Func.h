#ifndef _SORT_FUNC_H_
#define _SORT_FUNC_H_


#include "Service_Common.h"
#include "Protocal.h"



using namespace bas;



int Service_Process(Service_CONF *pConf);
int RounterExchangeTCP(char *InBuf, int nLen, Protocal &p);
int readTCPMsg(int nSocketfd, char* pBuffer, int nSize);



















#endif


