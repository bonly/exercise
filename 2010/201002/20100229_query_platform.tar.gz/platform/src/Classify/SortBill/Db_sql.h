#ifndef _DB_SQL_H_
#define _DB_SQL_H_





/*
string sCreateTableSql = "(EventFormatType char(2), roll_flag char(1), roll_count char(2), \
file_id char(10), exc_id char(4), FileType char(2), subno char(24), IMSI char(15), IMEI char(15), \
start_time char(14), special_flag char(2), proc_time char(14), event_id char(20), Switch_flag char(2), \
District char(2), Brand char(1), User_Type char(2), Visit_Area char(8), B_subno char(24), Bill_type char(2), \
ACCT_Mob char(14), ACCT_Toll char(14), ACCT_Inf char(14), Mob_fee char(8), Toll_fee char(8), Inf_fee char(8), \
Pay_mode char(1), Be_Payed char(1), deducted char(1), acct_balance_a char(8), acct_balance_b char(8), \
dis_id char(64), reserve char(36), pay_switch_flag char(2), pay_district char(2), pay_brand char(1), \
pay_user_type char(2), pay_subno char(24), pay_account char(14), pay_acct_balance_a char(8), pay_acct_balance_b char(8), \
pay_mob_fee char(8), pay_toll_fee char(8), pay_inf_fee char(8), pay_deducted char(1), xd_type char(1),\
bus_code char(15), bus_type char(2), subbus_type char(2), rat_type char(1), dis_code char(16), \
direct_type char(1), visit_switch_flag char(2), roam_type char(1), toll_type char(1), carry_type char(2), \
b_operator char(2), b_switch_flag char(2), b_brand char(1), b_user_type char(2), dis_dura char(7) ,\
dis_fee char(8), relation char(2), duration char(7), net_type char(1), multi_call char(1), call_type char(2), \
call_flag char(2), msisdnB char(24), msisdnC char(24), real_msisdn char(24), msrn char(11), msc_id char(10), \
calling_lac char(4), calling_cellid char(8), called_lac char(4), called_cellid char(8), out_router char(21), \
in_router char(21), service_type char(3), service_code char(2), session_id char(16), session_si char(3), session_type char(1), \
FCI char(8), vpn_call_type char(2), fee_one char(8), fee_two char(8) ) engine innodb DEFAULT CHARSET=latin1 \
PARTITION BY KEY(subno) PARTITIONS 100 ;";
*/

/*
string sCreateTableSql = "( Id Bigint not null, EventFormatType char(2), roll_flag char(1), roll_count char(2), \
file_id char(10), exc_id char(4), FileType char(2), subno char(24), IMSI char(15), IMEI char(15), \
start_time char(14), special_flag char(2), proc_time char(14), event_id char(20), Switch_flag char(2), \
District char(2), Brand char(1), User_Type char(2), Visit_Area char(8), B_subno char(24), Bill_type char(2), \
ACCT_Mob char(14), ACCT_Toll char(14), ACCT_Inf char(14), Mob_fee char(8), Toll_fee char(8), Inf_fee char(8), \
Pay_mode char(1), Be_Payed char(1), deducted char(1), acct_balance_a char(8), acct_balance_b char(8), \
dis_id char(64), reserve char(36), pay_switch_flag char(2), pay_district char(2), pay_brand char(1), \
pay_user_type char(2), pay_subno char(24), pay_account char(14), pay_acct_balance_a char(8), pay_acct_balance_b char(8), \
pay_mob_fee char(8), pay_toll_fee char(8), pay_inf_fee char(8), pay_deducted char(1), xd_type char(1),\
bus_code char(15), bus_type char(2), subbus_type char(2), rat_type char(1), dis_code char(16), \
direct_type char(1), visit_switch_flag char(2), roam_type char(1), toll_type char(1), carry_type char(2), \
b_operator char(2), b_switch_flag char(2), b_brand char(1), b_user_type char(2), dis_dura char(7) ,\
dis_fee char(8), relation char(2), duration char(7), net_type char(1), multi_call char(1), call_type char(2), \
call_flag char(2), msisdnB char(24), msisdnC char(24), real_msisdn char(24), msrn char(11), msc_id char(10), \
calling_lac char(4), calling_cellid char(8), called_lac char(4), called_cellid char(8), out_router char(21), \
in_router char(21), service_type char(3), service_code char(2), session_id char(16), session_si char(3), session_type char(1), \
FCI char(8), vpn_call_type char(2), fee_one char(8), fee_two char(8), primary key(subno,Id)) engine innodb";
*/

/*
string sCreateTableSql = "(EventFormatType char(2), roll_flag char(1), roll_count char(2), \
file_id char(10), exc_id char(4), FileType char(2), subno char(24), IMSI char(15), IMEI char(15), \
start_time char(14), special_flag char(2), proc_time char(14), event_id char(20), Switch_flag char(2), \
District char(2), Brand char(1), User_Type char(2), Visit_Area char(8), B_subno char(24), Bill_type char(2), \
ACCT_Mob char(14), ACCT_Toll char(14), ACCT_Inf char(14), Mob_fee char(8), Toll_fee char(8), Inf_fee char(8), \
Pay_mode char(1), Be_Payed char(1), deducted char(1), acct_balance_a char(8), acct_balance_b char(8), \
dis_id char(64), reserve char(36), pay_switch_flag char(2), pay_district char(2), pay_brand char(1), \
pay_user_type char(2), pay_subno char(24), pay_account char(14), pay_acct_balance_a char(8), pay_acct_balance_b char(8), \
pay_mob_fee char(8), pay_toll_fee char(8), pay_inf_fee char(8), pay_deducted char(1), xd_type char(1),\
bus_code char(15), bus_type char(2), subbus_type char(2), rat_type char(1), dis_code char(16), \
direct_type char(1), visit_switch_flag char(2), roam_type char(1), toll_type char(1), carry_type char(2), \
b_operator char(2), b_switch_flag char(2), b_brand char(1), b_user_type char(2), dis_dura char(7) ,\
dis_fee char(8), relation char(2), duration char(7), net_type char(1), multi_call char(1), call_type char(2), \
call_flag char(2), msisdnB char(24), msisdnC char(24), real_msisdn char(24), msrn char(11), msc_id char(10), \
calling_lac char(4), calling_cellid char(8), called_lac char(4), called_cellid char(8), out_router char(21), \
in_router char(21), service_type char(3), service_code char(2), session_id char(16), session_si char(3), session_type char(1), \
FCI char(8), vpn_call_type char(2), fee_one char(8), fee_two char(8), KEY idx_subno (subno) ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
*/

/*
string sCreateTableSql = "(EventFormatType char(2), roll_flag char(1), roll_count char(2), \
file_id char(10), exc_id char(4), FileType char(2), subno char(24), IMSI char(15), IMEI char(15), \
start_time char(14), special_flag char(2), proc_time char(14), event_id char(20), Switch_flag char(2), \
District char(2), Brand char(1), User_Type char(2), Visit_Area char(8), B_subno char(24), Bill_type char(2), \
ACCT_Mob char(14), ACCT_Toll char(14), ACCT_Inf char(14), Mob_fee char(8), Toll_fee char(8), Inf_fee char(8), \
Pay_mode char(1), Be_Payed char(1), deducted char(1), acct_balance_a char(8), acct_balance_b char(8), \
dis_id char(64), reserve char(36), pay_switch_flag char(2), pay_district char(2), pay_brand char(1), \
pay_user_type char(2), pay_subno char(24), pay_account char(14), pay_acct_balance_a char(8), pay_acct_balance_b char(8), \
pay_mob_fee char(8), pay_toll_fee char(8), pay_inf_fee char(8), pay_deducted char(1), xd_type char(1),\
change_part text, KEY idx_subno (subno) ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
*/

string sCreateTableSql = "(EventFormatType char(2), roll_flag char(1), roll_count char(2), file_id char(10), \
exc_id char(4), FileType char(2), subno char(24), IMSI char(15), IMEI char(15), start_time char(14), \
special_flag char(2), proc_time char(14), event_id char(20), Switch_flag char(2), District char(2), Brand char(1), \
User_Type char(2), Visit_Area char(8), B_subno char(24), Bill_type char(2), ACCT_Mob char(14), ACCT_Toll char(14), \
ACCT_Inf char(14), Mob_fee char(8), Toll_fee char(8), Inf_fee char(8), Pay_mode char(1), \
dis_id char(64), reserve char(36), \
cbe_flag char(1), period_flag char(1), SubsID char(14), \
A_pay_type char(1), A_pay_subno char(24), A_pay_switch_flag char(2), A_pay_district char(2), A_pay_brand char(1), \
A_pay_user_type char(2), A_AcctID char(14), A_deducted char(1), A_ACCT_BALANCE char(12), \
A_ACCT_BALANCE_ID1 char(18), A_ACCT_BALANCE_AMT1 char(8), \
A_ACCT_BALANCE_ID2 char(18), A_ACCT_BALANCE_AMT2 char(8), \
A_ACCT_BALANCE_ID3 char(18), A_ACCT_BALANCE_AMT3 char(8), \
A_ACCT_BALANCE_ID4 char(18), A_ACCT_BALANCE_AMT4 char(8), \
B_pay_type char(1), B_pay_subno char(24), B_pay_switch_flag char(2), B_pay_district char(2), B_pay_brand char(1), \
B_pay_user_type char(2), B_AcctID char(14), B_deducted char(1), B_ACCT_BALANCE char(12), \
B_ACCT_BALANCE_ID1 char(18), B_ACCT_BALANCE_AMT1 char(8), \
B_ACCT_BALANCE_ID2 char(18), B_ACCT_BALANCE_AMT2 char(8), \
B_ACCT_BALANCE_ID3 char(18), B_ACCT_BALANCE_AMT3 char(8), \
change_part text, KEY idx_subno (subno) ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";





#endif


