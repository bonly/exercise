#include "FileToCache.h"
#include "Get_Bill.h"
#include "com_date.h"
#include "Error.h"
#include "Sort_File.h"
#include "Sort_Func.h"
#include "DataAccess_Mysql.h"
#include <map>
#include <time.h>
#include <sys/time.h>



char file_src_name[MAX_FILE_NAME];
int  deal_month = 0;

void setCT(COUNTER &stCT)
{
	if(stCT.dealNum == 0)
    {
    	struct timeval tp;
        gettimeofday(&tp, 0);
	    stCT.time = tp.tv_sec * 1000000 + tp.tv_usec;
    }
	stCT.dealNum++;	
}

void getCT(COUNTER &stCT)
{
	if( stCT.dealNum%OB_NUM == 0)
	{
		struct timeval tp;
        gettimeofday(&tp, 0);
        
        LOG_SERVICE_ERROR("processed num= %d, Recently dealt with ten thousand of the time = %ld\n", \
              stCT.dealNum, (tp.tv_sec * 1000000 + tp.tv_usec - stCT.time) );
		stCT.time = tp.tv_sec * 1000000 + tp.tv_usec;
	} 
	
}



bool CheckNumRouter(char *phoneNum, Protocal &p)
{
	char *buf = NULL;
	long long num = atoll(phoneNum);
	char szcsnum[8];
	ConnectInfo *pCI;
	char szStatus[8];
	char szThreshold[16];
	char szGroupID[4];
	for(int i=0; i<pNL->nCount; i++)
	{
		if(num >= pNL->stItem[i].phoneNumStart && num < pNL->stItem[i].phoneNumEnd)
		{
			///�˺Ŷ�֮ǰ�Ѿ���ѯ��
			LOG_SERVICE_DEBUG("If this section has been to the router queries\n");
			snprintf(szcsnum, sizeof(szcsnum), "%d", pNL->stItem[i].stCL.nCount);
			p.Reset();
			snprintf(szGroupID, sizeof(szGroupID), "%d", pNL->nGroupID);
			p<<"0"<<"start"<<"end"<<szGroupID<<szcsnum;
            for(int j=0; j<pNL->stItem[i].stCL.nCount; j++)
            {
            	pCI = &(pNL->stItem[i].stCL.stItem[j]);
            	snprintf(szStatus, sizeof(szStatus), "%d", pCI->status);
            	snprintf(szThreshold, sizeof(szThreshold), "%d", pCI->threshold);
			    p<<pCI->instanceName<<pCI->connectStr<<szStatus<<szThreshold;
            }
		    p<<2;
		    p.Encode(buf);
		    p.DecodeAns(buf);
			return true;
		}
	}
	return false;
}



void SaveNumCache(Protocal &p)
{
	//router�޼�¼����Ҫ����
	if(p.data()->nodeMsgNum == 0)
	{
		return;
	}
	pNL->nGroupID      = p.data()->groupID;
	int pos = pNL->nCount;
	pNL->stItem[pos].phoneNumStart = atoll(p.data()->phoneNum);
	pNL->stItem[pos].phoneNumEnd   = atoll(p.data()->phoneNumEnd);	
	pNL->stItem[pos].stCL.nCount   = p.data()->nodeMsgNum;
	for(int i=0; i<p.data()->nodeMsgNum; i++)
	{
		strncpy(pNL->stItem[pos].stCL.stItem[i].instanceName, p.data()->nodes[i].instanceName, sizeof(pNL->stItem[pos].stCL.stItem[i].instanceName));
		strncpy(pNL->stItem[pos].stCL.stItem[i].connectStr,   p.data()->nodes[i].connectStr,   sizeof(pNL->stItem[pos].stCL.stItem[i].connectStr));
        pNL->stItem[pos].stCL.stItem[i].status    = p.data()->nodes[i].status;
        pNL->stItem[pos].stCL.stItem[i].threshold = p.data()->nodes[i].chreshold;
	}
	pNL->nCount++;	
}


void SetNumCache()
{
        int max_num = 51000000;
        pNL->nGroupID      = 0;
        pNL->nCount = 1;
        pNL->stItem[0].phoneNumStart = 0;
        pNL->stItem[0].phoneNumEnd   = 13799999999;
        /*
        pNL->stItem[0].stCL.nCount   = 3;
        strcpy(pNL->stItem[0].stCL.stItem[0].instanceName, "paas");
        strcpy(pNL->stItem[0].stCL.stItem[0].connectStr, "172.16.200.101|3311|paas|root|123");
        pNL->stItem[0].stCL.stItem[0].status    = 0;
        pNL->stItem[0].stCL.stItem[0].threshold = max_num;
 
        strcpy(pNL->stItem[0].stCL.stItem[1].instanceName, "paas");
        strcpy(pNL->stItem[0].stCL.stItem[1].connectStr, "172.16.200.102|3311|paas|root|123");
        pNL->stItem[0].stCL.stItem[1].status    = 0;
        pNL->stItem[0].stCL.stItem[1].threshold = max_num;
 
        strcpy(pNL->stItem[0].stCL.stItem[2].instanceName, "paas");
        strcpy(pNL->stItem[0].stCL.stItem[2].connectStr, "172.16.200.103|3311|paas|root|123");
        pNL->stItem[0].stCL.stItem[2].status    = 0;
        pNL->stItem[0].stCL.stItem[2].threshold = max_num;
        */
        pNL->stItem[0].stCL.nCount   = 1;
        strcpy(pNL->stItem[0].stCL.stItem[0].instanceName, "paas");
        strcpy(pNL->stItem[0].stCL.stItem[0].connectStr, "172.16.200.102|3312|paas|root|123");
        pNL->stItem[0].stCL.stItem[0].status    = 0;
        pNL->stItem[0].stCL.stItem[0].threshold = max_num;
 
}


int Treat_File(char *szFileName)
{
	
	FILE *fp = fopen(szFileName, "r");
	if(fp == NULL)
	{
		LOG_SERVICE_ERROR("open file(%s) error!\n", szFileName);
		return -1;
	}
	
	// seek to the beginning of the file ����
	fseek(fp, 0, SEEK_SET); 
	
	char szLine[2048];
	memset(szLine, 0, sizeof(szLine));
	char szUnloadLine[1024];
	
	Protocal p;
	BillMsg stBM;
	char *buf = NULL;
	int nLen  = 0;
	int nRet  = 0;
	int pos   = 0;
	int err_low = 0;
	pNL->nCount = 0;
	//SetNumCache();
	while( fgets(szLine, sizeof(szLine), fp) != NULL)
	{
		LOG_SERVICE_DEBUG("row_len=%d\n", strlen(szLine));
		if( strlen(szLine) < MIN_BILL_LEN || memcmp(szLine, g_pConf->szTopLineHeader, 11)==0 )
		{
			err_low++;
			//���������ļ���ʱ������
			if(err_low > 1)
			{
				LOG_SERVICE_ERROR("Incomplete documentation,filename=%s\n", szFileName); 
				fclose(fp);
				return ER_BILL_FILE_EXCEPTION;
			}
			else
			{
				if( strncmp(file_name, UNLOAD_BILL_HEAD, 11) == 0 )
				{
					memset(szUnloadLine, 0, sizeof(szUnloadLine));
					strncpy(szUnloadLine, szLine, sizeof(szUnloadLine));
					
					//ԭʼ�ļ������һ�δ�������������
				    memset(file_src_name, 0, sizeof(file_src_name));
				    strncpy(file_src_name, strtok(szUnloadLine, "|"), sizeof(file_src_name));
				    deal_month = atoi(strtok(NULL, "|"));
				    LOG_SERVICE_DEBUG("OriginalFile:%s, month:%d\n", file_src_name, deal_month);
			    }
			    continue;
			}
		}
		memset(&stBM, 0, sizeof(BillMsg));

		//��ȡ������Ҫ��Ϣ
		getBillMsg(szLine, strlen(szLine), stBM);
		setCT(stCT);
		
		//����Ƿ����ڲ�ѯ��������
		if( !CheckNumRouter(stBM.stBill.subno, p) )
		{
            ///���(Ӧ�üƷѺ���)
		    p.Reset();
		    p<<stBM.stBill.subno<<QRY_CODE;
		    LOG_SERVICE_DEBUG("parket send:%s\n", p.Buffer()->GetMsgBody());
		    nLen = p.Encode(buf);  
		    if(nLen <= 0)
		    {
		    	LOG_SERVICE_ERROR("Protocal Encode fail! code=%d\n", nLen);
		    	fclose(fp);
		    	return -1;
		    }
		    		    		
		    //���ͽ�����Ϣ
		    nRet = RounterExchangeTCP(buf, nLen, p);
		    if(nRet != 0)
		    {
		    	LOG_SERVICE_ERROR("RounterExchangeTCP error! code=%d\n", nRet);
		    	fclose(fp);
		    	return -1;
		    }
		    
		    //�����ѯ��������Ϣ
		    SaveNumCache(p);
		}
		
		LOG_SERVICE_DEBUG("parket back:%s\n", p.Buffer()->GetMsgBody());
		
		if( p.data()->resultcode != 0)
		{
			LOG_SERVICE_ERROR("router select error, code=%d\n", p.data()->resultcode);
			fclose(fp);
			return -1;
		}
		
		///���뻺��
	    nRet = FillInCache(p, stBM);
		if(nRet != 0)
		{
			//�����������ļ�����ԭһ��
			if(nRet == ER_ALL_NODE_IS_NOT_ALLOW_TO_LOAD)
			{
				LOG_SERVICE_WARN("This file is not being handled!\n");
				fclose(fp);
				return ER_ALL_NODE_IS_NOT_ALLOW_TO_LOAD;
			}
			else
			{
			    LOG_SERVICE_ERROR("FillInCache error! code=%d\n", nRet);
			    fclose(fp);
			    return -1;
			}
		}
		
	}	
	fclose(fp);
	return(0);
}


//��������ڵ��״̬�Ƿ�����趨---������:0.ȫ������ 1.ȫ���򲿷ֲ�����
int checkNodeGroupStatus(Protocal &p, int status)
{
    for(int i=0; i<p.data()->nodeMsgNum; i++)
    {
    	if(p.data()->nodes[i].status != status)
    	{
    		return 1;
    	}
    }
    
    return 0;
}


int FillInCache(Protocal &p, BillMsg &stBM)
{
	int i=0;
	DataList *pDataList;
	BillList *pBL;
	
	char szNowMonth[7];
	//char connectStr[64+1];
	//memset(connectStr, 0, sizeof(connectStr));	
	int VestingMonth = 0;
	char szVM[6];
	memset(szVM, 0, sizeof(szVM));
	///����Ƿ�����ڵ㶼������������
	int nRet = 0;
	if( strncmp(file_name, UNLOAD_BILL_HEAD, 11) == 0 )
	{
		nRet = checkNodeGroupStatus(p, ALL_NOT_ALLOW);
		//�������ʱ��������״̬--NOT_ALLOW_LOAD,����LOAD�������
		for(i=0; i<p.data()->nodeMsgNum; i++)
	    {
	    	if(p.data()->nodes[i].status == NOT_ALLOW_LOAD)
	    	{
	    	    p.data()->nodes[i].status = ALLOW_LOAD;
	    	}
	    }
	}
	else
	{
	    nRet = checkNodeGroupStatus(p, NOT_ALLOW_LOAD);
	}
	if(nRet == 0)
	{
		LOG_SERVICE_WARN("node group not allow to do this word, please wait!\n");
		return ER_ALL_NODE_IS_NOT_ALLOW_TO_LOAD;
	}
	
	map<int, DataList *>::iterator iter = g_pTotalMsg->find(pNL->nGroupID);
	if(iter != g_pTotalMsg->end())
	{
		//�κ�����£��������һ��������Ӧ�����ݿ�״̬Ϊ׼
		for(i=0; i<p.data()->nodeMsgNum; i++)
	    {
	    	iter->second->stCl.stItem[i].status        = p.data()->nodes[i].status;
	    }
		//������Ϣ
	    strncpy(szVM, stBM.stBill.start_time, 6);
	    VestingMonth = atoi(szVM);
	    
		map<int, BillList *>::iterator iter2 = iter->second->mMonthBillRecord.find(VestingMonth);
		if(iter2 != iter->second->mMonthBillRecord.end())
		{			
			BillList *pBLm           = iter2->second;			
			if(pBLm->nCount < MAX_BILL_NUM)
			{
			    pBLm->stItem.push_back(stBM);
			    pBLm->nCount++;
			}
			else
			{
				LOG_SERVICE_ERROR("BillMsg num too big!\n");
				return -1;
			}
			LOG_SERVICE_DEBUG("pBLm->nCount=%d\n", pBLm->nCount);
		}
		else
		{
			pBL       = new BillList;
			pBL->stItem.clear();
			pBL->stItem.push_back(stBM);
			pBL->nCount = 1;
			
			iter->second->mMonthBillRecord.insert(pair<int, BillList *>(VestingMonth, pBL));
			
		}
	}
	else
	{   	
		pDataList = new DataList;
	    pBL       = new BillList;
	    
	    //�ļ���
	    if( strncmp(file_name, UNLOAD_BILL_HEAD, 11) == 0 )
	    {
	    	reload_flag = 1;
	    	strncpy(pDataList->filename, file_src_name, sizeof(file_src_name));
	    	pDataList->nDealMonth = deal_month;
	    }
	    else
	    {
	    	reload_flag = 0;
	        strncpy(pDataList->filename, file_name, MAX_FILE_NAME-1); 
	        CCommonDate comm_date( time(NULL) );
	        memset(szNowMonth, 0, sizeof(szNowMonth));
	        snprintf(szNowMonth, sizeof(szNowMonth), "%4d%02d", comm_date.getYear(), comm_date.getMonth());
	        pDataList->nDealMonth = atoi(szNowMonth);
	    }
	    LOG_SERVICE_DEBUG("Deal month:%d\n", pDataList->nDealMonth);
	    
	    //δ�����ļ�·��
	    nRet =  selectPathForGroupID(pNL->nGroupID, pDataList->szUnloadPath, sizeof(pDataList->szUnloadPath));
	    if(nRet != 0)
	    {
	    	LOG_SERVICE_ERROR("selectPathForGroupID error\n");
	    	return -1;
	    }
	    LOG_SERVICE_DEBUG("unloadpath:%s\n", pDataList->szUnloadPath);
	
	    //������Ϣ
	    pDataList->stCl.nCount = 0;
	    ConnectInfo *pCI;
	    for(i=0; i<p.data()->nodeMsgNum; i++)
	    {
		    pCI = &pDataList->stCl.stItem[i];
		    strncpy(pCI->instanceName, p.data()->nodes[i].instanceName, sizeof(pCI->instanceName));
		    strncpy(pCI->connectStr, p.data()->nodes[i].connectStr, sizeof(pCI->connectStr));
		    pCI->status        = p.data()->nodes[i].status;
		    pCI->threshold     = p.data()->nodes[i].chreshold;
		    pDataList->stCl.nCount++;
	    }
	
	    //������Ϣ
	    strncpy(szVM, stBM.stBill.start_time, 6);
	    VestingMonth = atoi(szVM);
	    //string sConnectStr = connectStr;
	    	    
		pBL->stItem.clear();
	    pBL->stItem.push_back(stBM);
		pBL->nCount = 1;
	    
	    pDataList->mMonthBillRecord.insert(pair<int, BillList *>(VestingMonth, pBL));
	    g_pTotalMsg->insert(pair<int, DataList *>(pNL->nGroupID, pDataList));

	    
	}
	return 0;
}













