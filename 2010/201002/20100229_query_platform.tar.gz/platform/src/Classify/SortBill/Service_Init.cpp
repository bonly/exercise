#include "Service_Init.h"
#include "Service_Common.h"
#include "Sort_Signal.h"
#include "iniconfig.h"
#include "r5log.h"
#include "r5api.h"
#include "log.h"
#include "DataAccess_Mysql.h"
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <iostream>






int g_nFd;
CFdbConn g_CFdbConn;
Service_CONF *g_pConf;
char szKpiMsg[1024];
char g_szConfFile[MAX_FILE_LEN+1];



int Service_Init(const char *pConfFile, Service_CONF *pConf)
{
	if(NULL == pConfFile || NULL == pConf)
    {
        printf("Service_Init input param wrong !\n");
        return -1;    
    }
    
    int nRet = 0;
    
    ///��ʼ��KPI
    if(INIT_KPI("SORTBILL", pConfFile) != 0)
    {
    	printf("INIT_KPI error!\n");
    	return -1;
    }
    
    ///��ȡ����
    nRet = Load_Service_Conf(pConfFile, pConf);
    if(nRet != 0)
    {
        printf("Load_Service_Conf failed!\n");
        return -1;
    }
    
    ///�ź�ע��
    nRet = Register_Signal();
    if(nRet < 0)
    {
        LOG_SERVICE_ERROR("Register_Signal failed!\n");
        return -1;
    }
    
    ///�������ݿ�����
    nRet = connectDb(g_pConf->szDbName, g_pConf->szDbAddr, g_pConf->szDbUser, g_pConf->szDbPwd, g_pConf->nDbPort);
    if(nRet != 0)
    {
    	LOG_SERVICE_ERROR("connectDb error!\n");
    	SEND_EVEN_KPI("connect billserver DB error", CRITICAL);
    	return -1;
    }
    
    ///���нڵ����������
    g_CFdbConn.Init(g_pConf->szDbName, g_pConf->szDbAddr, g_pConf->szDbUser, g_pConf->szDbPwd, g_pConf->nDbPort);
    
    ///����TCP����
    nRet = InitNet(g_nFd, g_pConf->szIP, g_pConf->nPort);
    if(nRet != 0)
    {
    	LOG_SERVICE_ERROR("InitNet error, code=%d\n", nRet);
    	SEND_EVEN_KPI("InitNet error", CRITICAL);
    	return -1;
    }
    
    return(0);
}



int Load_Service_Conf(const char *pConfFile, Service_CONF *pConf)
{
	if(NULL == pConfFile || NULL == pConf)
        return -1;
    IniConfig Iconf;
    
    IniSection *pSec = NULL;
    
    string sData;
     
    if(Iconf.open(pConfFile) < 0)
    {
        printf("open ConfFile failed!\n");
        return -1;
    }
    
    pSec = Iconf.getSection("SORT");
    if(NULL == pSec)
    {
        printf("get SORT section failed!\n");
        return -1;
    }
    
    //-------------------------------------------
    // set logger path & logger head information
    //-------------------------------------------
    //set log level
    int log_file_lev, log_term_lev;
    sData = pSec->getValue("LOG_LEVEL_FILE");
    if(0 == sData.length())
    {
    	log_file_lev = 40;
    }
    log_file_lev = atoi(sData.c_str());
    sData = pSec->getValue("LOG_LEVEL_TERM");
    if(0 == sData.length())
    {
    	log_term_lev = 40;
    }
    log_term_lev = atoi(sData.c_str());
    SET_LOG_LEVEL(&g_service_log, log_file_lev, log_term_lev);

    //initLogLevel(&g_service_log, Iconf);    // calling r5api.h
    sData = pSec->getValue("LOG_PATH");
    if (0 == sData.length())
    {
        printf("ERROR: read LOG_PATH cfg param failed!\n" );
        return -1;        
    }
    if (SET_LOG_DIR(&g_service_log, sData.c_str())<0) // calling r5log.h
    {
    	printf("ERROR: set log path failed:%s!\n", sData.c_str());
    	return -1;
    }
   
    sData = pSec->getValue("LOG_HEADER");
    if (0 == sData.length())
    {
    	printf("ERROR: read LOG_HEADER cfg param failed!\n");
    	return -1;
    }
    SET_LOG_NAME_HEAD(&g_service_log, sData.c_str());  // calling r5log.h
    
    
    //================��ȡTCP������Ϣ=======================================
    sData = pSec->getValue("PORT");
    if(0 == sData.length())
    {
        printf("SORT: get PORT failed!\n");
        return -1;
    }
	pConf->nPort = atoi(sData.c_str());
	
	sData = pSec->getValue("IP");
    if(0 == sData.length())
    {
        printf("SORT: get PORT failed!\n");
        return -1;
    }
	strncpy(pConf->szIP, sData.c_str(), MAX_IP_LEN);
	
	//========================�����ļ����===================================
	
	///��ȡ����Ŀ¼
	sData = pSec->getValue("BILL_PATH");
	if(0 == sData.length())
    {
        printf("SORT: get BILL_PATH failed!\n");
        return -1;
    }
    strncpy(pConf->szBillPath, sData.c_str(), MAX_PATH_LEN);
    
    
    ///ɨ�軰��Ŀ¼���ʱ��
    sData = pSec->getValue("SCAN_BP_TIME");
	if(0 == sData.length())
    {
        printf("SORT: get SCAN_BP_TIME failed!\n");
        return -1;
    }
    pConf->nScanBPTime = atoi(sData.c_str());
    
    ///�����ļ���ͷ
    sData = pSec->getValue("BILL_HEADER");
	if(0 == sData.length())
    {
        printf("SORT: get BILL_HEADER failed!\n");
        return -1;
    }
    strncpy(pConf->szBillHeader, sData.c_str(), 64);
    
    ///��������ͷ
    sData = pSec->getValue("TOP_LINE_HEADER");
	if(0 == sData.length())
    {
        printf("SORT: get TOP_LINE_HEADER failed!\n");
        return -1;
    }
    strncpy(pConf->szTopLineHeader, sData.c_str(), 12);
    
    ///���󻰵�·��
    sData = pSec->getValue("EXCEPTION_BILL_PATH");
	if(0 == sData.length())
    {
        printf("SORT: get EXCEPTION_BILL_PATH failed!\n");
        return -1;
    }
    strncpy(pConf->szErrBillPath, sData.c_str(), MAX_PATH_LEN);
    
    ///δ�����ļ�·��
    sData = pSec->getValue("RAW_FILE_PATH");
	if(0 == sData.length())
    {
        printf("SORT: get RAW_FILE_PATH failed!\n");
        return -1;
    }
    strncpy(pConf->szRAWFilePath, sData.c_str(), MAX_PATH_LEN);
    
//=============================================================================    
    ///����������Ļ���Ŀ¼��Ҫ���
    if( strncmp(pConf->szBillHeader, UNLOAD_BILL_HEAD, 11) == 0 && strlen(szUnloadBillPath) != 0)
    {
    	strncpy(pConf->szBillPath, szUnloadBillPath, sizeof(pConf->szBillPath));
    	//strncpy(pConf->szRAWFilePath, szUnloadBillPath�� sizeof(pConf->szRAWFilePath));
    }
//=============================================================================    
    //=============================��ȡ���ݿ�������Ϣ===========================
	sData = pSec->getValue("DB_NAME");
	if(0 == sData.length())
    {
        printf("SORT: get DB_NAME failed!\n");
        return -1;
    }
    strncpy( pConf->szDbName, sData.c_str(), sizeof(pConf->szDbName) );
    sData = pSec->getValue("DB_ADDR");
	if(0 == sData.length())
    {
        printf("SORT: get DB_ADDR failed!\n");
        return -1;
    }
    strncpy( pConf->szDbAddr, sData.c_str(), sizeof(pConf->szDbAddr) );
    sData = pSec->getValue("DB_USER");
	if(0 == sData.length())
    {
        printf("SORT: get DB_USER failed!\n");
        return -1;
    }
    strncpy( pConf->szDbUser, sData.c_str(), sizeof(pConf->szDbUser) );
    sData = pSec->getValue("DB_PWD");
	if(0 == sData.length())
    {
        printf("SORT: get DB_PWD failed!\n");
        return -1;
    }
    strncpy( pConf->szDbPwd, sData.c_str(), sizeof(pConf->szDbPwd) );
    sData = pSec->getValue("DB_PORT");
	if(0 == sData.length())
    {
        printf("SORT: get DB_PORT failed!\n");
        return -1;
    }
    pConf->nDbPort = atoi(sData.c_str());
    
    ///����������أ�Ϊˢ�ź��ض�������
    g_pConf = pConf;
    strncpy(g_szConfFile, pConfFile, sizeof(g_szConfFile)-1);
		
	return(0);
}



//-------------------------------------------
// Net connect
//-------------------------------------------
int InitNet(int& nFd, const char* szIP, int nPort)
{	
	if (szIP == NULL)
	{
		return -996;
	}
	
	int nFlag = 1;
    int nBuf = 4096;  // 4k
    
    struct sockaddr_in address;
    struct sockaddr* pServerAddr = NULL;
    
	// 1.create socket
	if ((nFd = ::socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("ERROR: create Sort'client socket fd error!\n");
        goto ERR;
    }
    
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    
    address.sin_port = htons(nPort);  // if = 0, kernel choose the port value
   	if (inet_pton(AF_INET, szIP, &(address.sin_addr)) <= 0)
    {
        printf("ERROR: set Sort'client socket ip addr error!\n");
        goto ERR;
    }
    
    // 2.set socket option
    if (setsockopt(nFd, IPPROTO_TCP, TCP_NODELAY, &nFlag, sizeof(nFlag)) < 0)
    {
    	printf("ERROR: set Sort'client socket option[TCP_NODELAY] error!\n");    	
        goto ERR;
    }
    if (setsockopt(nFd, SOL_SOCKET, SO_KEEPALIVE, &nFlag, sizeof(nFlag)) < 0)
    {
    	printf("ERROR: set Sort'client socket option[SO_KEEPALIVE] error!\n");   	
        goto ERR;
    }
    if (setsockopt(nFd, SOL_SOCKET, SO_SNDBUF, &nBuf, sizeof(nBuf)) < 0)
    {
    	printf("ERROR: set Sort'client socket option[SO_SNDBUF] error!\n");   	
        goto ERR;
    }
    if (setsockopt(nFd, SOL_SOCKET, SO_RCVBUF, &nBuf, sizeof(nBuf)) < 0)
    {
    	printf("ERROR: set Sort'client socket option[SO_RCVBUF] error!\n");    	
        goto ERR;
    }
    
    // 3.connect to server
    pServerAddr = (struct sockaddr*)&(address);
    if (connect(nFd, pServerAddr, sizeof(address)) != 0)  // sucess 0, error -1
    {
    	printf("ERROR: connect to Server[%s:%d] error!\n", szIP, nPort);
        goto ERR;
    }
    
    return 0;
    
ERR:
	CleanupNet(nFd);
	
	return -1;    
}

void CleanupNet(int& nFd)
{
	if (nFd > 0)
	{
		close(nFd);
		nFd = 0;
	}
}



int Service_Destroy(Service_CONF *pConf)
{
	LOG_SERVICE_INFO("Process exit!\n");
	
	///�Ͽ�TCP����
	CleanupNet(g_nFd);
		
	///�ͷ����ݿ�����
	g_CFdbConn.Destory();
	
	///ˢ����־
	g_service_log.flush();
	
	return(0);
}


int Register_Signal()
{
    //ˢ�������ź�,�����ж�,ִ�����źŴ��������,�����ж�ǰ�ĺ���
    if (my_signal(SIGHUP, SigHup, false) == SIG_ERR)
    {
        LOG_SERVICE_ERROR("signal SIGHUP error\n");
        return -1;
    }
    
    //��־��д�ź�,�����ж�,ִ�����źŴ��������,�����ж�ǰ�ĺ���
    if (my_signal(SIGUSR2, SigUsr2, false) == SIG_ERR)
    {
        LOG_SERVICE_ERROR("signal SIGUSR2 error\n");
        return -1;
    }
    
    //��ֹ�ź�,�����ж�,ִ�����źŴ��������,ԭ���������жϷ���EINTR
    if (my_signal(SIGTERM, SigTerm , true) == SIG_ERR)
    {
        LOG_SERVICE_ERROR("signal SIGTERM error\n");
        return -1;
    }
    
    if(my_signal(SIGUSR1, SIG_IGN ,false) == SIG_ERR)
    {
        LOG_SERVICE_ERROR("signal SIGUSR1 error:%s\n", strerror(errno));      
        return -1;
    }
    
    ///�ն��жϷ� ����
    if(my_signal(SIGINT, SigTerm ,true) == SIG_ERR)
    {
        LOG_SERVICE_ERROR("signal SIGINT error:%s\n", strerror(errno));      
        return -1;
    }
    
    /*
    ///SIGALRM �ź�
    if(my_signal(SIGALRM, SigAlarm ,false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGALRM error:%s\n", strerror(errno));      
        return -1;
    }*/
    
    return 0;
        
}















