#ifndef _SORT_SERVICE_H_
#define _SORT_SERVICE_H_







int Sort_Bill_Service(const char *pConfFile);









#endif



