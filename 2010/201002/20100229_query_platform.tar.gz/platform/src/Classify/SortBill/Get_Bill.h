#ifndef _GET_BILL_H_
#define _GET_BILL_H_

#include "Service_Common.h"









int getBillMsg(char *pLine, int len, BillMsg &stBM);









#endif



