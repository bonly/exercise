#include "DataAccess_Mysql.h"
#include "Service_Common.h"
#include <iostream>
#include <vector>





mysqlpp::Connection g_conn(false);
	

sql_create_2(File_Info, 1, 2, mysqlpp::sql_char, filename, mysqlpp::sql_bigint, time)
	
	
	
int connectDb(char *db_name, char *ip_addr, char *user, char *pwd, int nPort)
{
	if(g_conn.connect(db_name, ip_addr, user, pwd, nPort))
	{
		LOG_SERVICE_INFO("connect db sucess!\n");
		return 0;
	}
	else
	{
		LOG_SERVICE_ERROR("db connect failed!(%s|%s|%s|%s|%d|%s)\n", db_name, ip_addr, user, pwd, nPort, g_conn.error());
		return -1;
	}
		
}



unsigned long GetNowTimeString()
{
    time_t  t;
    t=time(NULL);
    struct tm *s_time=localtime(&t);
    
    unsigned long lTime = mktime(s_time) + CONV_1900_1970;
    return     lTime;
}



int insertFileName(char *szFileName)
{
	try
	{
		unsigned int nTime = (unsigned int)GetNowTimeString();
		//vector<File_Info> res;
	    Query query = g_conn.query();
	    File_Info file_info(szFileName, nTime);
	    query.insert(file_info);
	    query.execute();
	}
	catch (const mysqlpp::BadQuery& er) 
	{
        // Handle any query errors
        LOG_SERVICE_ERROR("Query error: %s\n",  er.what() );
        return -1;
    }
    catch (const mysqlpp::BadConversion& er) {
        // Handle bad conversions
        LOG_SERVICE_ERROR("Conversion error: %s\n", er.what());
        LOG_SERVICE_ERROR("\tretrieved data size: %s, actual size: %d\n", er.retrieved, er.actual_size); 
        return -1;
    }
    catch (const mysqlpp::Exception& er) {
        // Catch-all for any other MySQL++ exceptions
        LOG_SERVICE_ERROR("Error: %s\n", er.what());
        return -1;
    }

	return 0;
}




int selectFileName(char *szFileName)
{
	char sql[256]={0};
	snprintf(sql, sizeof(sql), "select count(*) from File_Info where filename = '%s'", szFileName);
	
	Query query = g_conn.query(sql);
	if (StoreQueryResult res = query.store()) 
	{
		/*
		for (size_t i =0; i < res.num_rows(); ++i)
		{
			cout<<"count:"<<res[i][0]<<endl;
		}*/
		return res[0][0]; 
	}
	else
	{
		LOG_SERVICE_ERROR("Failed to get item list: %s\n", query.error() );
		if( !g_conn.ping() )
		{
			if( connectDb(g_pConf->szDbName, g_pConf->szDbAddr, g_pConf->szDbUser, g_pConf->szDbPwd, g_pConf->nDbPort) )
			{
				return -1;
			}
		}
		return 0;
	}
}


//���½ڵ���״̬
int updateNodeGroupStatus(int nStatus, char *unloadPath)
{
	char sql[256]={0};
	snprintf(sql, sizeof(sql), "update Node_Group set status = %d where unloadPath = '%s'", nStatus, unloadPath);
	
	//printf("sql=%s\n", sql);
	
	mysqlpp::Query query = g_conn.query();
	query<<sql;	
	
	if (!query.exec()) 
	{
		LOG_SERVICE_ERROR("Failed to update Node_Group(status=%d,unloadPath=%s), error:%s\n", nStatus, unloadPath, query.error());
		return -1;
	}
	return 0;
}




//����groupID����δ�����ļ�����·��
int selectPathForGroupID(int nGroupID, char *unloadPath, int nLen)
{
	memset(unloadPath, 0, nLen);
	char sql[256]={0};
	snprintf(sql, sizeof(sql), "select unloadPath from Node_Group where groupID = %d", nGroupID);
	
	Query query = g_conn.query(sql);
	if (StoreQueryResult res = query.store()) 
	{		
		if( res.num_rows() == 1)
		{
			strncpy(unloadPath, res[0]["unloadPath"].c_str(), nLen);
		}
		else
		{
			LOG_SERVICE_ERROR("result num(%d) is not right,sql=%s\n", res.num_rows(), sql);
			return -1;
		}
		return 0;
	}
	else
	{
		LOG_SERVICE_ERROR("Failed to get item list: %s\n", query.error());
		return -1;
	}
	
}



