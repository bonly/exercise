/*
 * Load_Tools.h
 *
 *  Created on: 2011-5-20
 *      Author: Administrator
 */

#ifndef LOAD_TOOLS_H_
#define LOAD_TOOLS_H_

#include <time.h>
#include <sys/time.h>
#include <fstream>
#include <iostream>
#include <string>


using namespace std;

void MakeCurTbName_Ex(const int time, const int identifier, const int serial_number, string &table_name);
void MakeHistTbName_Ex(const int time, const int identifier, const int serial_number, string &table_name);


string int2str(int num);
string intud2str(unsigned int  num);
string intll2str(long long num);
string int23str(int num);
string int24str(int num);
string int22str(int num);
int GetCurYearMonth();
bool GetCreateTableSql(const char *file_name, string &sql);
void MakeTableName(const char *head, const int time, const string business_code,  const int identifier, const int serial_number, string &table_name);
void MakeUnhandleBillFilename(const string path,const int year_month, const int process_id, const int time, string &filename);
string intud2str(int num);
int sum(const int arr[], const int len);
int getDay();
int getrecode(int arr[], int size);

#endif /* LOAD_TOOLS_H_ */
