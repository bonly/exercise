#ifndef _LOAD_PROCESS_H
#define _LOAD_PROCESS_H

#include "../SortBill/Service_Common.h"
#include "../SortBill/fdb_conn.h"
#include "Load_Tools.h"
#include <sys/time.h>
#include <unistd.h>
#include <mysql++.h>
#include <time.h>
#include <iostream>
#include <string>
#include <fstream>
#include <mysql.h>

#include "../../../base2/base_constants.h"

#include "../../../base2/cdr_log.h"


#define TABLE_NUM 	5000

#define SUCCESS 0
#define	PARTICAL_SUCCESS 1
#define	ALL_FAILURE 2

#define THRESHOLD 100000


//��������
#define 	TABLE_NAME_DB_NEW				"indb_newtable_record"
#define 	TABLE_NAME_REF_DATA				"NODE_GROUP_DATA_STANDARD"
#define		TABLE_NAME_CHK_LOG				"node_check_log"

#define 	CUR_MON_TB_PREF					"BILL"
#define		HIS_MON_TB_PREF					"BILL_HISTORY"


#define		CONST_TB_NONE					0
#define		CONST_TB_CUR_EXIST				(1)
#define 	CONST_TB_HIST_EXIST 			(1<<1)


//in one instance , the exist status of the history and current tables
 enum{
	INS_TB_BOTH_DISAPEAR  =  0,
	
	INS_TB_BOTH_EXIST  = (CONST_TB_CUR_EXIST | CONST_TB_HIST_EXIST ),//both  exits
	INS_TB_CURMONTB_ONLY =CONST_TB_CUR_EXIST ,		//only current month table exist
	INS_TB_HISMONTB_ONLY = CONST_TB_HIST_EXIST,


	INS_TB_STATUS_MAX

};



//indb_newtable_record 's column 
enum  enmNewTableCol{
	TABLENAME_NTB	=  0  ,
	TIME_NTB			  ,
	STATUS_NTB			  ,
	INS_COUNT_NTB		  ,
	TABLE_NUM_NTB	  , 
	BUSINESS_TYPE_NTB	  ,
	DAY_NTB				  ,

	NEW_TB_MAX_COL	  
};

typedef struct __TABLE_COL_NAME_MAPPING
{
	BASE2_INT32		enmColmID;
	BASE2_CHAR		sColName[MAX_NAME_LEN];

}st_TABLE_COL_MAPPING;

static st_TABLE_COL_MAPPING  stNTbColName[NEW_TB_MAX_COL + 1] =
{

	{	TABLENAME_NTB				,   "tablename"		  },
	{	TIME_NTB					,	"time"				},
	{	STATUS_NTB					,	"status"			},
	{	INS_COUNT_NTB				,	"ins_count" 		},
	{	TABLE_NUM_NTB				,	"table_num" 		},
	{	BUSINESS_TYPE_NTB	  		,   "business_type"	  },
	{	DAY_NTB 					,	"day"				}


};


enum enmRefDBDataCol{
	
	REF_GROUPID = 0		,
	REF_TIME			,
	REF_TABLE_NUM		,
	REF_BILL_TYPE		,
	REF_INS_COUNT		,	
	
	REF_DB_MAX_COL	
};


static st_TABLE_COL_MAPPING stRefTbCol[REF_DB_MAX_COL + 1] = 
{
	
	{ REF_GROUPID		  ,   "groupID"	 },
	{ REF_TIME			  ,   "time"	   },
	{ REF_TABLE_NUM 	  ,   "table_num"  },
	{ REF_BILL_TYPE 	  ,   "bill_type"  },
	{ REF_INS_COUNT 	  , 	"ins_count"  }		 


};




//the tables info of the instance
typedef struct __INS_TB_INFO
{
	BASE2_INT32			nHasHisTb;
	BASE2_INT32			nHasCurMoTb;
	
	BASE2_INT32		nCurMonTbBatch;

	BASE2_INT32		enmTbStatus;
}ST_INS_TB_INFO;





class Load_Process {

private:
	CFdbConn conn;		
	string bcode;		// no use
	string create_sql;			// if tables do not exist , creat  5000 tables
	string path;				// no use
	mysqlpp::Connection 	* m_pRefDbCon;		//  the connection info of  reference database	

public:
	Load_Process();
//	Load_Process( const string create_sql, const string bcode );

	Load_Process( const string create_sql, mysqlpp::Connection * pConn ,  string bcode= "01" ) ;
//
	~Load_Process();
	int LoadDB();
	int 	LoadDB_Ex();

protected:

	bool	UpdateRefTbWithCurMon(BASE2_INT32 nGroupId, mysqlpp::Query & query, BASE2_INT32	nCurYearMon, BASE2_INT64 lnCurInsCount, BASE2_INT32 nBatchNum);


	bool	MapTheTbCoWithPoint( vector<const char *> & vpBillColSet,const  Bill & oneBill);
	
	bool WriteUnhandleBill_Ex(string sFullPathFile,const BillList &bills) ;

	bool	WritExceptFileHead(string sFulPathFile,string sSrcFileName , string sBillFileName, BASE2_INT32	nCurTime);


	bool GetExceptFileName(string path,BASE2_INT32 process_id , string & sFulPathFile );

	bool	RecordData2RefDb_Ex(DataList* pDataLst,BASE2_INT32 nCurYearMon,BASE2_INT32 nBatchNum,  mysqlpp::Connection *pRefCon, BASE2_INT32	nGroupId);

	bool LoadDataToGroup_Ex(BASE2_INT32 nCurYearMon, BASE2_INT32 nGroupId,	DataList* pDataLst);

	bool	GetTableStatusOfIns(ST_INS_TB_INFO	& stInsTbInfo, ConnectInfo & stItem, BASE2_INT32	nCurYearMon);

	bool	GetTbInfoOfGroup(DataList* pDataLst, BASE2_INT32	nCurYearMon, BASE2_INT32 & nBatchNum);
	bool	LoadDataToIns_Ex(DataList *pDataList, BASE2_INT32	nBatchName,ConnectInfo stItem, BASE2_INT32 nCurYearMon);
	bool	CreatTbOnIns(BASE2_INT32 nInsTbStat, ConnectInfo & stItem, BASE2_INT32 nCurMonTbBatch, BASE2_INT32 nCurYearMon);
	bool	UpdateRefTbWithHisMon(BASE2_INT32 nGroupId, mysqlpp::Query & query, BASE2_INT32	nCurYearMon, BASE2_INT64 lnHisInsCount);




	bool	WriteExceptionFile(DataList * pDataList,  BASE2_INT32	nCurYearMon);
	
	
	int HandleCurMonthBill(ConnectList &stCl, int time, const BillList &bills,
			const char *file_name);
	int HandleHisMonthBill(ConnectList &stCl, int time, const BillList &bills,
			const char *file_name);
	bool WriteUnhandleBill(const char *file_name, const BillList &bills,
			const string file_name);
	bool InsertBills(const BillList &bills, const int start, const int end,
			mysqlpp::Query &query, const string table_name, const int sn, long long &id);


	bool InsertHisBills_Ex(const BillList &bills, const int start, const int end,
			 mysqlpp::Query &query, const string table_name, const int sn, long long &id);

	bool InsertHisBills(const BillList &bills, const int start, const int end,
			 mysqlpp::Query &query, const string table_name, const int sn, long long &id);
	bool MakeTables(const char *head, const string business_code,
			const int time, const int serial_number, const int type,
			mysqlpp::Query &query);
	bool WriteUnhandleBillsPro(const int year_month, const int process_id,
			const BillList &bills, const string filename);
	bool isHandledFile(const string filename, mysqlpp::Query query, const string strPreTbName);
	bool IsMeetThreshold();
	bool HasAvailableTable(const int time, const string tablename,
			mysqlpp::Query &query, int &sn, long long &inc_count);
	int GetTheMaxSN(const int time, const string tablename,
			mysqlpp::Query &query);
	bool MakeTablesAndRecord(const ConnectInfo &stCl, const char *head, const string bcode,
			const int time, const int sn, const int type,
			mysqlpp::Query &query, const string tablename);
	bool UpdateTableStatus(const string bcode, const string tablename,
			const int time, mysqlpp::Query &query);
	bool InsertAndRecordCur(const BillList &bills, const int start,
			const int end, mysqlpp::Query &query, const string tablename,
			const string bcode, const int sn, long long &inc_count);
	bool InsertAndRecordHis(const BillList &bills, const int start,
			const int end, mysqlpp::Query &query, const string tablename,
			const string bcode, const int sn, long long &inc_count);
	bool MakeLoadHistory(const string filename, const string tablename,
			const int count, mysqlpp::Query query);

	

};




enum{
	//TB_BILL_COL_NONE = 0 ,
	EventFormatType =0	 ,
	roll_flag			 ,
	roll_count			 ,
	file_id 			 ,
	exc_id				 ,
	FileType			 ,
	subno				 ,
	IMSI				 ,
	IMEI				 ,
	start_time			 ,
	special_flag		 ,
	proc_time			 ,
	event_id			 ,
	Switch_flag 		 ,
	District			 ,
	Brand				 ,
	User_Type			 ,
	Visit_Area			 ,
	B_subno 			 ,
	Bill_type			 ,
	ACCT_Mob			 ,
	ACCT_Toll			 ,
	ACCT_Inf			 ,
	Mob_fee 			 ,
	Toll_fee			 ,
	Inf_fee 			 ,
	Pay_mode			 ,
	dis_id				 ,
	reserve 			 ,
	cbe_flag			 ,
	period_flag 		 ,
	SubsID				 ,
	A_pay_type			 ,
	A_pay_subno 		 ,
	A_pay_switch_flag	 ,
	A_pay_district		 ,
	A_pay_brand 		 ,
	A_pay_user_type 	 ,
	A_AcctID			 ,
	A_deducted			 ,
	A_ACCT_BALANCE		 ,
	A_ACCT_BALANCE_ID1	 ,
	A_ACCT_BALANCE_AMT1  ,
	A_ACCT_BALANCE_ID2	 ,
	A_ACCT_BALANCE_AMT2  ,
	A_ACCT_BALANCE_ID3	 ,
	A_ACCT_BALANCE_AMT3  ,
	A_ACCT_BALANCE_ID4	 ,
	A_ACCT_BALANCE_AMT4  ,
	B_pay_type			 ,
	B_pay_subno 		 ,
	B_pay_switch_flag	 ,
	B_pay_district		 ,
	B_pay_brand 		 ,
	B_pay_user_type 	 ,
	B_AcctID			 ,
	B_deducted			 ,
	B_ACCT_BALANCE		 ,
	B_ACCT_BALANCE_ID1	 ,
	B_ACCT_BALANCE_AMT1  ,
	B_ACCT_BALANCE_ID2	 ,
	B_ACCT_BALANCE_AMT2  ,
	B_ACCT_BALANCE_ID3	 ,
	B_ACCT_BALANCE_AMT3  ,
//	xd_type,
	change_part 		 ,
						  
	TB_BILL_COL_MAX

};

static st_TABLE_COL_MAPPING  stBillColName[TB_BILL_COL_MAX + 1] =
{

{ EventFormatType 	 ,		"EventFormatType" 			  },   
{ roll_flag 		   ,   "roll_flag"						},	 
{ roll_count		   ,   "roll_count" 					},	 
{ file_id			   ,   "file_id"						},	 
{ exc_id			   ,   "exc_id" 						},	 
{ FileType			   ,   "FileType"						},	 
{ subno 			   ,   "subno"							},	 
{ IMSI				   ,   "IMSI"							},	 
{ IMEI				   ,   "IMEI"							},	 
{ start_time		   ,   "start_time" 					},	 
{ special_flag		   ,   "special_flag"					},	 
{ proc_time 		   ,   "proc_time"						},	 
{ event_id			   ,   "event_id"						},	 
{ Switch_flag		   ,   "Switch_flag"					},	 
{ District			   ,   "District"						},	 
{ Brand 			   ,   "Brand"							},	 
{ User_Type 		   ,   "User_Type"						},	 
{ Visit_Area		   ,   "Visit_Area" 					},	 
{ B_subno			   ,   "B_subno"						},	 
{ Bill_type 		   ,   "Bill_type"						},	 
{ ACCT_Mob			   ,   "ACCT_Mob"						},	 
{ ACCT_Toll 		   ,   "ACCT_Toll"						},	 
{ ACCT_Inf			   ,   "ACCT_Inf"						},	 
{ Mob_fee			   ,   "Mob_fee"						},	 
{ Toll_fee			   ,   "Toll_fee"						},	 
{ Inf_fee			   ,   "Inf_fee"						},	 
{ Pay_mode			   ,   "Pay_mode"						},	 
{ dis_id			   ,   "dis_id" 						},	 
{ reserve			   ,   "reserve"						},	 
{ cbe_flag			   ,   "cbe_flag"						},	 
{ period_flag		   ,   "period_flag"					},	 
{ SubsID			   ,   "SubsID" 						},	 
{ A_pay_type		   ,   "A_pay_type" 					},	 
{ A_pay_subno		   ,   "A_pay_subno"					},	 
{ A_pay_switch_flag    ,   "A_pay_switch_flag"				},	 
{ A_pay_district	   ,   "A_pay_district" 				},	 
{ A_pay_brand		   ,   "A_pay_brand"					},	 
{ A_pay_user_type	   ,   "A_pay_user_type"				},	 
{ A_AcctID			   ,   "A_AcctID"						},	 
{ A_deducted		   ,   "A_deducted" 					},	 
{ A_ACCT_BALANCE	   ,   "A_ACCT_BALANCE" 				},	 
{ A_ACCT_BALANCE_ID1   ,   "A_ACCT_BALANCE_ID1" 			},	 
{ A_ACCT_BALANCE_AMT1  ,   "A_ACCT_BALANCE_AMT1"			},	 
{ A_ACCT_BALANCE_ID2   ,   "A_ACCT_BALANCE_ID2" 			},	 
{ A_ACCT_BALANCE_AMT2  ,   "A_ACCT_BALANCE_AMT2"			},	 
{ A_ACCT_BALANCE_ID3   ,   "A_ACCT_BALANCE_ID3" 			},	 
{ A_ACCT_BALANCE_AMT3  ,   "A_ACCT_BALANCE_AMT3"			},	 
{ A_ACCT_BALANCE_ID4   ,   "A_ACCT_BALANCE_ID4" 			},	 
{ A_ACCT_BALANCE_AMT4  ,   "A_ACCT_BALANCE_AMT4"			},	 
{ B_pay_type		   ,   "B_pay_type" 					},	 
{ B_pay_subno		   ,   "B_pay_subno"					},	 
{ B_pay_switch_flag    ,   "B_pay_switch_flag"				},	 
{ B_pay_district	   ,   "B_pay_district" 				},	 
{ B_pay_brand		   ,   "B_pay_brand"					},	 
{ B_pay_user_type	   ,   "B_pay_user_type"				},	 
{ B_AcctID			   ,   "B_AcctID"						},	 
{ B_deducted		   ,   "B_deducted" 					},	 
{ B_ACCT_BALANCE	   ,   "B_ACCT_BALANCE" 				},	 
{ B_ACCT_BALANCE_ID1   ,   "B_ACCT_BALANCE_ID1" 			},	 
{ B_ACCT_BALANCE_AMT1  ,   "B_ACCT_BALANCE_AMT1"			},	 
{ B_ACCT_BALANCE_ID2   ,   "B_ACCT_BALANCE_ID2" 			},	 
{ B_ACCT_BALANCE_AMT2  ,   "B_ACCT_BALANCE_AMT2"			},	 
{ B_ACCT_BALANCE_ID3   ,   "B_ACCT_BALANCE_ID3" 			},	 
{ B_ACCT_BALANCE_AMT3  ,   "B_ACCT_BALANCE_AMT3"			},	 
//{ xd_type				,	"xd_type"						},																 
{ change_part		   ,   "change_part"					}	 




};






#endif

