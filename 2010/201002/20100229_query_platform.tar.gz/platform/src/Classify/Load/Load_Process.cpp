#include "Load_Process.h"


//#define  INIT_KPI(a,b)  	(b) 
//#define  SEND_EVEN_KPI(a,b) (b)

//#define  	LOG_ERROR							LOG_SERVICE_ERROR
#define		ERR_EVENT2KPI(const_char_p_msg)	  	SEND_EVEN_KPI((const_char_p_msg),2)

#define 	SQL_LOCK_INS						"select id from locktable where id=99 for update"
#define 	SQL_LOCK_REF_TB						"select * from NODE_GROUP_DATA_STANDARD for update"

//sErrInfo is a string
#define 	COMM_ERR_REPORT(sErrInfo) \
{	\
	LOG_SERVICE_ERROR("ComErr: %s,line =%d,file=%s\r\n",sErrInfo.c_str(), __LINE__, __FILE__) \
	ERR_EVENT2KPI(sErrInfo.c_str()); \
}


#define 	COMM_WARN_REPORT(sErrInfo) \
{	\
	LOG_SERVICE_ERROR("WARN: %s,line =%d,file=%s\r\n",sErrInfo.c_str(), __LINE__, __FILE__) \
	ERR_EVENT2KPI(sErrInfo.c_str()); \
}


#define		DEBUG_LOAD_EX			1


Load_Process::Load_Process( const string create_sql, mysqlpp::Connection * pConn  ,  string bcode ) {
//for test
	this->create_sql = create_sql;
	this->bcode = bcode;	//no use
	m_pRefDbCon = pConn;
}

Load_Process::Load_Process() {
//for test
this->bcode = "01";
}

Load_Process::~Load_Process() {

}


//TODO      to modify
//record data info to ref table
bool	Load_Process::RecordData2RefDb_Ex(DataList* pDataLst,BASE2_INT32 nCurYearMon,BASE2_INT32 nBatchNum,  mysqlpp::Connection *pRefCon, BASE2_INT32	nGroupId)
{
	string 		sErrInfo;
	bool		bRet = true;
	
	if(NULL == pRefCon || NULL == pDataLst)
	{
		sErrInfo = "ref db connection is null";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

 	map<int, BillList *>  & mpBillSet = pDataLst->mMonthBillRecord;

	if(mpBillSet.empty())
	{
		sErrInfo = "billList is empty";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

	map<int, BillList *>::iterator itBillSet = mpBillSet.begin();
	BillList * 		pBillList = NULL;
	BASE2_INT32		nBillTime = 0;
	BASE2_INT64 	lnCurInsCount = 0;
	BASE2_INT64 	lnHisInsCount = 0;

	bool			bCurTbExist  = false;
	bool			bHisTbExist = false;


	mysqlpp::Transaction trans(*pRefCon);
	string		strSql;

	try{
		mysqlpp::Query	query = pRefCon->query();
				

		strSql = SQL_LOCK_REF_TB;
		query << strSql;

		if(!query.store())
		{
			trans.rollback();
			sErrInfo = "failed to lock the ref tb";
			COMM_ERR_REPORT(sErrInfo);		
			return false;
		}

		while(itBillSet != mpBillSet.end())
		{
			nBillTime  = itBillSet->first;
			pBillList = itBillSet->second;

			if(nBillTime == nCurYearMon)
			{
				//load to cur month table			
				lnCurInsCount = pBillList->stItem.size();

				UpdateRefTbWithCurMon(nGroupId, query, nCurYearMon, lnCurInsCount, nBatchNum);
				if(!bRet)
				{
					trans.rollback();
					sErrInfo = "failed to update his data to ref tb";
					COMM_ERR_REPORT(sErrInfo);	
					return false;
				}				
			}
			else
			{
				//load to history month table
				lnHisInsCount = pBillList->stItem.size();

				bRet = UpdateRefTbWithHisMon(nGroupId, query, itBillSet->first, lnHisInsCount);
				if(!bRet)
				{
					trans.rollback();
					sErrInfo = "failed to update his data to ref tb";
					COMM_ERR_REPORT(sErrInfo);	
					return false;
				}		
			}
			
			itBillSet++;
		}

		trans.commit();

	}
	catch(const mysqlpp::BadQuery& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::BadConversion& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::Exception& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}		

	return true;

/*
	mysqlpp::Transaction trans(*pRefCon);
	string		strSql;

	try{		
		mysqlpp::Query	query = pRefCon->query();
				

		strSql = SQL_LOCK_REF_TB;
		query << strSql;

		if(!query.store())
		{
			trans.rollback();
			sErrInfo = "failed to lock the ref tb";
			COMM_ERR_REPORT(sErrInfo);		
			return false;
		}

		//start to  update
		//cur month data
		if(lnCurInsCount > 0)
		{
			strSql = "select * from " + string(TABLE_NAME_REF_DATA) \
				+ string(" where ") \
				+ string(stRefTbCol[REF_GROUPID].sColName) + string(" = ") + int2str(nGroupId)\
				+ string(" and ") + string(stRefTbCol[REF_TIME].sColName) + string("=") + int2str(nCurYearMon)\
				+ string(" and ") + string(stRefTbCol[REF_TABLE_NUM].sColName) + string("=")+ int2str(nBatchNum)\
				+ string(" and ") + string(stRefTbCol[REF_BILL_TYPE].sColName) + string("=0");

#if DEBUG_LOAD_EX
			LOG_SERVICE_DEBUG("RecordData2RefDb_Ex1 sql=%s, line=%d\n", strSql.c_str(), __LINE__);
#endif


			query << strSql;
			mysqlpp::StoreQueryResult resCur = query.store();

			if(resCur)
			{
				if(resCur.num_rows() > 0)
				{
					//exist , to update
					strSql = "update " + string(TABLE_NAME_REF_DATA)\
					+ string(" set ") + string(stRefTbCol[REF_INS_COUNT].sColName) + string("=")\
					+ string(stRefTbCol[REF_INS_COUNT].sColName) +string("+") + intll2str(lnCurInsCount)\
					+ string(" where ") \
					+ string(stRefTbCol[REF_GROUPID].sColName) + string(" = ") + int2str(nGroupId)\
					+ string(" and ") + string(stRefTbCol[REF_TIME].sColName) + string("=") + int2str(nCurYearMon)\
					+ string(" and ") + string(stRefTbCol[REF_TABLE_NUM].sColName) + string("=")+ int2str(nBatchNum)\
					+ string(" and ") + string(stRefTbCol[REF_BILL_TYPE].sColName) + string("=0");				
#if DEBUG_LOAD_EX
				LOG_SERVICE_DEBUG("RecordData2RefDb_Ex2 sql=%s, line=%d\n", strSql.c_str(), __LINE__);
#endif

				}
				else
				{
					//no record ,to insert
					strSql = "insert into " + string(TABLE_NAME_REF_DATA) \
					+ string("(") + string(stRefTbCol[REF_GROUPID].sColName) \
					+ string(", ") + string(stRefTbCol[REF_TIME].sColName) \
					+ string(", ") + string(stRefTbCol[REF_TABLE_NUM].sColName)\
					+ string(", ") + string(stRefTbCol[REF_BILL_TYPE].sColName)\
					+ string(", ") + string(stRefTbCol[REF_INS_COUNT].sColName)\
					+ string(")") + string(" values(") \
					+ int2str(nGroupId) + string(",") \
					+ int2str(nCurYearMon) + string(", ")\
					+ int2str(nBatchNum) + string(", ") \
					+ string(" 0,")\
					+ intll2str(lnCurInsCount) + string(" ) ");

#if DEBUG_LOAD_EX
				LOG_SERVICE_DEBUG("RecordData2RefDb_Ex3 sql=%s, line=%d\n", strSql.c_str(), __LINE__);
#endif
					
				}

				query << strSql;

				if(query.exec())
				{
					//ok
				}
				else
				{
					trans.rollback();
					sErrInfo = "failed to access ref tb";
					COMM_ERR_REPORT(sErrInfo);		
					return false;
				}
				
			}
			else
			{
				trans.rollback();
				sErrInfo = "failed to access ref tb";
				COMM_ERR_REPORT(sErrInfo);		
				return false;
			}			

		}
		
		
		if(lnHisInsCount > 0)
		{
			bRet = UpdateRefTbWithHisMon(nGroupId, query, nCurYearMon, lnHisInsCount);
			if(!bRet)
			{
				trans.rollback();
				sErrInfo = "failed to update his data to ref tb";
				COMM_ERR_REPORT(sErrInfo);	
				return false;
			}
		}
		
		trans.commit();
	}	
	catch(const mysqlpp::BadQuery& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::BadConversion& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::Exception& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}	
	*/

}

bool	Load_Process::UpdateRefTbWithCurMon(BASE2_INT32 nGroupId, mysqlpp::Query & query, BASE2_INT32	nCurYearMon, BASE2_INT64 lnCurInsCount, BASE2_INT32 nBatchNum)
{
	string 		strSql;
	string		sErrInfo;
	
				strSql = "select * from " + string(TABLE_NAME_REF_DATA) \
					+ string(" where ") \
					+ string(stRefTbCol[REF_GROUPID].sColName) + string(" = ") + int2str(nGroupId)\
					+ string(" and ") + string(stRefTbCol[REF_TIME].sColName) + string("=") + int2str(nCurYearMon)\
					+ string(" and ") + string(stRefTbCol[REF_TABLE_NUM].sColName) + string("=")+ int2str(nBatchNum)\
					+ string(" and ") + string(stRefTbCol[REF_BILL_TYPE].sColName) + string("=0");
	
#if DEBUG_LOAD_EX
				LOG_SERVICE_DEBUG("UpdateRefTbWithCurMon sql=%s, line=%d,mon=%d\n", strSql.c_str(), __LINE__,nCurYearMon);
#endif
	
	
				query << strSql;
				mysqlpp::StoreQueryResult resCur = query.store();
	
				if(resCur)
				{
					if(resCur.num_rows() > 0)
					{
						//exist , to update
						strSql = "update " + string(TABLE_NAME_REF_DATA)\
						+ string(" set ") + string(stRefTbCol[REF_INS_COUNT].sColName) + string("=")\
						+ string(stRefTbCol[REF_INS_COUNT].sColName) +string("+") + intll2str(lnCurInsCount)\
						+ string(" where ") \
						+ string(stRefTbCol[REF_GROUPID].sColName) + string(" = ") + int2str(nGroupId)\
						+ string(" and ") + string(stRefTbCol[REF_TIME].sColName) + string("=") + int2str(nCurYearMon)\
						+ string(" and ") + string(stRefTbCol[REF_TABLE_NUM].sColName) + string("=")+ int2str(nBatchNum)\
						+ string(" and ") + string(stRefTbCol[REF_BILL_TYPE].sColName) + string("=0");				
#if DEBUG_LOAD_EX
					LOG_SERVICE_DEBUG("UpdateRefTbWithCurMon2 sql=%s, line=%d\n", strSql.c_str(), __LINE__);
#endif
	
					}
					else
					{
						//no record ,to insert
						strSql = "insert into " + string(TABLE_NAME_REF_DATA) \
						+ string("(") + string(stRefTbCol[REF_GROUPID].sColName) \
						+ string(", ") + string(stRefTbCol[REF_TIME].sColName) \
						+ string(", ") + string(stRefTbCol[REF_TABLE_NUM].sColName)\
						+ string(", ") + string(stRefTbCol[REF_BILL_TYPE].sColName)\
						+ string(", ") + string(stRefTbCol[REF_INS_COUNT].sColName)\
						+ string(")") + string(" values(") \
						+ int2str(nGroupId) + string(",") \
						+ int2str(nCurYearMon) + string(", ")\
						+ int2str(nBatchNum) + string(", ") \
						+ string(" 0,")\
						+ intll2str(lnCurInsCount) + string(" ) ");
	
#if DEBUG_LOAD_EX
					LOG_SERVICE_DEBUG("UpdateRefTbWithCurMon3 sql=%s, line=%d\n", strSql.c_str(), __LINE__);
#endif
						
					}
	
					query << strSql;
	
					if(query.exec())
					{
						//ok
					}
					else
					{
						//trans.rollback();
						sErrInfo = "failed to access ref tb";
						COMM_ERR_REPORT(sErrInfo);		
						return false;
					}
					
				}
				else
				{
					//trans.rollback();
					sErrInfo = "failed to access ref tb";
					COMM_ERR_REPORT(sErrInfo);		
					return false;
				}			

}


//update record content on the ref tb for the history mon data
bool	Load_Process::UpdateRefTbWithHisMon(BASE2_INT32 nGroupId, mysqlpp::Query & query, BASE2_INT32	nCurYearMon, BASE2_INT64 lnHisInsCount)
{
	string 		strSql;
	string		sErrInfo;
	
	strSql = "select * from " + string(TABLE_NAME_REF_DATA) \
		+ string(" where ") \
		+ string(stRefTbCol[REF_GROUPID].sColName) + string(" = ") + int2str(nGroupId)\
		+ string(" and ") + string(stRefTbCol[REF_TIME].sColName) + string("=") + int2str(nCurYearMon)\
		+ string(" and ") + string(stRefTbCol[REF_BILL_TYPE].sColName) + string("=")+ string("1");				
	
	query << strSql;
	mysqlpp::StoreQueryResult resCur = query.store();

#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("UpdateRefTbWithHisMon1,line=%d:mon=%d strSql=%s,\n",__LINE__, nCurYearMon, strSql.c_str());
#endif

	
	if(resCur)
	{
		
		if(resCur.num_rows() > 0)
		{
			//exist , to update
			strSql = "update " + string(TABLE_NAME_REF_DATA)\
			+ string(" set ") + string(stRefTbCol[REF_INS_COUNT].sColName) + string("=")\
			+ string(stRefTbCol[REF_INS_COUNT].sColName) +string("+") + intll2str(lnHisInsCount)\
				+ string(" where ") \
				+ string(stRefTbCol[REF_GROUPID].sColName) + string(" = ") + int2str(nGroupId)\
				+ string(" and ") + string(stRefTbCol[REF_TIME].sColName) + string("=") + int2str(nCurYearMon)\
				+ string(" and ") + string(stRefTbCol[REF_BILL_TYPE].sColName) + string("=") + string("1");					
			
					
#if DEBUG_LOAD_EX
					LOG_SERVICE_DEBUG("UpdateRefTbWithHisMon0,line=%d: strSql=%s,\n",__LINE__, strSql.c_str());
#endif

		}
		else
		{
#if 1	
//no record ,to insert
			strSql = "insert into " + string(TABLE_NAME_REF_DATA) \
			+ string("(") + string(stRefTbCol[REF_GROUPID].sColName) \
			+ string(", ") + string(stRefTbCol[REF_TIME].sColName) \
			+ string(", ") + string(stRefTbCol[REF_BILL_TYPE].sColName)\
			+ string(", ") + string(stRefTbCol[REF_INS_COUNT].sColName)\
			+ string(", ") + string(stRefTbCol[REF_TABLE_NUM].sColName)\			
			+ string(")") + string(" values(") \
			+ int2str(nGroupId) + string(",") \
			+ int2str(nCurYearMon) + string(", ")\
			+ string(" 1,")\
			+ intll2str(lnHisInsCount)+ string(", ") + int2str(1) + string(" ) ");
#endif	

		
#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("UpdateRefTbWithHisMon2,line=%d: strSql=%s,\n",__LINE__, strSql.c_str());
#endif

		}

		query << strSql;
	
		if(query.exec())
		{
			//ok
		}
		else
		{
			//trans.rollback();
			sErrInfo = "failed to access ref tb";
			COMM_ERR_REPORT(sErrInfo);		
			return false;
		}
		
	}
	else
	{
		//trans.rollback();
		sErrInfo = "failed to access ref tb";
		COMM_ERR_REPORT(sErrInfo);		
		return false;
	}	

}


//get the table status such as the exist of cur month table ,the history table ,the batch num,  if has ,return the num;;
bool	Load_Process::GetTableStatusOfIns(ST_INS_TB_INFO	& stInsTbInfo, ConnectInfo & stItem, BASE2_INT32	nCurYearMon)
{
	string 		sCurMonTbName;
	string		sHisMonTbName;
	string		sErrInfo;
	bool		bRet = true;

	stInsTbInfo.enmTbStatus = CONST_TB_NONE;
	stInsTbInfo.nCurMonTbBatch = 0;
	stInsTbInfo.nHasCurMoTb = CONST_TB_NONE;
	stInsTbInfo.nHasHisTb = CONST_TB_NONE;

//	MakeTableName("BILL", nCurYearMon, "01", -1, -1, sCurMonTbName);

	MakeCurTbName_Ex(nCurYearMon,-1,-1,sCurMonTbName);
	MakeHistTbName_Ex(nCurYearMon,-1,-1,sHisMonTbName);

	mysqlpp::Connection* pConn = NULL;
	string 		strSql ;

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("GetTableStatusOfIns1 start....sCurMonTbName=%s,sHisMonTbName=%s....line=%d\n",sCurMonTbName.c_str(), sHisMonTbName.c_str(),__LINE__);
#endif


	if (FDB_SUCCESS != g_CFdbConn.GetDbConn(stItem.connectStr, &pConn)) 
	{
		sErrInfo= "failed to get db connection from conn pool";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

	mysqlpp::Transaction trans(*pConn);
	char    szTime[MAX_NAME_LEN];
	sprintf(szTime,"%d",nCurYearMon);
	string		sBatchNum;
	BASE2_INT32	nBatchNum = 0;
	char     	czBatchNum[MAX_NAME_LEN];
	
	try
	{
		mysqlpp::Query query = pConn->query();		

		strSql = SQL_LOCK_INS;
		query <<strSql;

#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("GetTableStatusOfIns2 sql=%s.line=%d\n",strSql.c_str() ,__LINE__);
#endif

		if(!query.store())
		{
			trans.rollback();
			sErrInfo =("failed to locke the instance");
			COMM_ERR_REPORT(sErrInfo);
			return false;			
		}
		//find history table
		strSql = "select * from " + string(TABLE_NAME_DB_NEW) \
		 + string(" where ") + stNTbColName[TABLENAME_NTB].sColName \
		 + string(" REGEXP '" ) + sHisMonTbName + string("' ") \
		+ string(" and ") + stNTbColName[TIME_NTB].sColName \
		+ string(" = ") + string(szTime);

#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("GetTableStatusOfIns3 sql2=%s.line=%d\n",strSql.c_str() ,__LINE__);
#endif

		query << strSql;

		mysqlpp::StoreQueryResult res = query.store();
		if(!res)
		{
			trans.rollback();
			sErrInfo =("failed to get history table info from instance");
			COMM_ERR_REPORT(sErrInfo);
			return false;			
		}

#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("GetTableStatusOfIns4 res.num_rows()=%d.line=%d\n",res.num_rows() ,__LINE__);
#endif

		if(res.num_rows() <= 0)
		{
			stInsTbInfo.nHasHisTb =CONST_TB_NONE;
		}
		else
		{
			stInsTbInfo.nHasHisTb = CONST_TB_HIST_EXIST;
		}


		//find  cur month table
		strSql = string("select MAX(" ) + stNTbColName[TABLE_NUM_NTB].sColName \
		+ string(") from " + string(TABLE_NAME_DB_NEW) + "  where ") \
		+ stNTbColName[STATUS_NTB].sColName + string(" = 0 ")\
		+ string(" and ") + stNTbColName[TIME_NTB].sColName \
		+ string(" = ") + string(szTime) \
		+ string(" and ") + string(stNTbColName[TABLENAME_NTB].sColName)\
		+ string(" REGEXP '") + sCurMonTbName + string("' ");


#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("GetTableStatusOfIns5 sql3=%s. line=%d\n",strSql.c_str() ,__LINE__);
#endif		
		query << strSql;
		res = query.store();

		if(res)
		{	
			if(res.num_rows() > 0 && res[0][0] != mysqlpp::null )
			{
					//has current month table with status = 0
					stInsTbInfo.nHasCurMoTb = CONST_TB_CUR_EXIST;
					res[0][0].to_string(sBatchNum);
					stInsTbInfo.nCurMonTbBatch = atoi(sBatchNum.c_str());			
#if DEBUG_LOAD_EX
			LOG_SERVICE_DEBUG("GetTableStatusOfIns6 6sBatchNum=%s, line=%d\n",sBatchNum.c_str() ,__LINE__);
#endif						
			}
			else
			{
				stInsTbInfo.nHasCurMoTb = CONST_TB_NONE;
				
				//no table 's status is 0,find the max batch num of current month
				strSql = string("select MAX(" ) + stNTbColName[TABLE_NUM_NTB].sColName \
				+ string(") from " + string(TABLE_NAME_DB_NEW) + "	where ") \
				+ stNTbColName[TIME_NTB].sColName \
				+ string(" = ") + string(szTime) \
				+ string(" and ") + string(stNTbColName[TABLENAME_NTB].sColName)\
				+ string(" REGEXP '") + sCurMonTbName + string("' ");

#if DEBUG_LOAD_EX
				LOG_SERVICE_DEBUG("GetTableStatusOfIns7 sql4=%s. line=%d\n",strSql.c_str() ,__LINE__);
#endif	

				query << strSql;

				mysqlpp::StoreQueryResult resTb = query.store();
				if(resTb)
				{
					if(resTb.num_rows() > 0 && resTb[0][0] != mysqlpp::null)
					{
						resTb[0][0].to_string(sBatchNum);
						nBatchNum = atoi(sBatchNum.c_str()) + 1;

					}
					else
					{
						//sBatchNum = int23str(1);
						nBatchNum = 1;
					}
					
					stInsTbInfo.nCurMonTbBatch = nBatchNum;
#if DEBUG_LOAD_EX
				    LOG_SERVICE_DEBUG("GetTableStatusOfIns nBatchNum=%d, line=%d\n",stInsTbInfo.nCurMonTbBatch ,__LINE__);
#endif						
				}
				else
				{
					trans.rollback();
					sErrInfo =("failed to get current mon table info from instance");
					COMM_ERR_REPORT(sErrInfo);
					return false;					
				}
			}

			//set the status of instance
			stInsTbInfo.enmTbStatus = stInsTbInfo.nHasCurMoTb | stInsTbInfo.nHasHisTb;

		}
		else
		{
			trans.rollback();
			sErrInfo = "error to get data from instance";
			COMM_ERR_REPORT(sErrInfo);
			return false;
		}
		trans.commit();

	}
	catch(const mysqlpp::BadQuery& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::BadConversion& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::Exception& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}

	return bRet;

}


//get the table info to insert , create tables if no exist
bool 	Load_Process::GetTbInfoOfGroup(DataList* pDataLst, BASE2_INT32	nCurYearMon, BASE2_INT32 & nBatchNum)
{
	BASE2_INT32		i = 0;
	string 			sErrInfo;
	bool			bRet = true;
	//BASE2_INT32		nBatchNum = 0;
	bool			bHasTable = false;

//	vector<bool>			vbHasTable;
//	vector<BASE2_INT32> 	vnTbBatchNum;

	vector<ST_INS_TB_INFO>	 vInsTbInfo;
	ST_INS_TB_INFO			 stInsTbInfo;
	
	if(NULL == pDataLst \
		|| pDataLst->stCl.nCount <= 0 \
		)
	{
		sErrInfo = "pDataLst = NULL";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

//	bool			bTbStatEqual = true;
	BASE2_INT32		nPreInsTbStat = INS_TB_BOTH_DISAPEAR;

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("GetTbInfoOfGroup: db num=%d, line=%d\n", pDataLst->stCl.nCount, __LINE__);
#endif


	for(i = 0; i < pDataLst->stCl.nCount; i++)
	{
		bRet = GetTableStatusOfIns(stInsTbInfo, pDataLst->stCl.stItem[i],nCurYearMon);
		if(!bRet)
		{
			sErrInfo  = "ERR:failed to get table info from instance";
			COMM_ERR_REPORT(sErrInfo);
			return false;
		}

		if(0 == i)
		{	
			nPreInsTbStat = stInsTbInfo.enmTbStatus;
		}
		else
		{
			if(nPreInsTbStat != stInsTbInfo.enmTbStatus)
			{
				sErrInfo = "the tables status of eah instance are not the same";
				COMM_ERR_REPORT(sErrInfo);
				return false;
			}
		}		

		vInsTbInfo.push_back(stInsTbInfo);
	}

	//compare the status of all instance
	BASE2_INT32		nCurMonTbBatch = 0;
	bool			bBatchNumEq = true;

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("GetTbInfoOfGroup: nPreInsTbStat=%d ,line =%d, vInsTbInfo.size=%d\n",nPreInsTbStat, __LINE__,vInsTbInfo.size());
#endif

	switch(nPreInsTbStat)
	{	
		case INS_TB_HISMONTB_ONLY:
		case INS_TB_CURMONTB_ONLY:
			{ //maybe only warning,and continue create tables which is lack
				sErrInfo = "the tables info of eah instance are not the same";
				COMM_WARN_REPORT(sErrInfo);
				//return false;			
		}
		case INS_TB_BOTH_DISAPEAR:
		case INS_TB_BOTH_EXIST:
		{			
			//check whether the batch num is the same
			for(i = 0; i < vInsTbInfo.size(); i++)
			{
				if(0 == i)
				{
					nCurMonTbBatch = vInsTbInfo.at(i).nCurMonTbBatch;
				}
				else
				{
					if(nCurMonTbBatch != vInsTbInfo.at(i).nCurMonTbBatch)
					{
						bBatchNumEq = false;
						sErrInfo = "batch num error";
						COMM_ERR_REPORT(sErrInfo);
						return false;
					}
				}			
			}

			//the same batch
			nBatchNum = nCurMonTbBatch;
			//if(INS_TB_BOTH_DISAPEAR == nPreInsTbStat)
			{
				//creat the tables;
				for(i = 0; i < pDataLst->stCl.nCount ;i++)
				{
					bRet = CreatTbOnIns(nPreInsTbStat, pDataLst->stCl.stItem[i], nCurMonTbBatch, nCurYearMon);
					if(!bRet)
					{
						sErrInfo = "failed to creat table";
						COMM_ERR_REPORT(sErrInfo);
						return false;
					}
				}
			}

			break;
		}
		default:
		{
			sErrInfo = "other error";
			COMM_ERR_REPORT(sErrInfo);
			return false;					
		}

	}

	// status are the same ,batch num are the same

	return bRet;	

}



//create tables 
bool	Load_Process::CreatTbOnIns(BASE2_INT32 nInsTbStat, ConnectInfo & stItem, BASE2_INT32 nCurMonTbBatch, BASE2_INT32 nCurYearMon)
{
	string 		sErrInfo;
	bool		bRet = true;
	string		strSql;
	string		sTableName;

	mysqlpp::Connection* pConn = NULL;
	if (FDB_SUCCESS != g_CFdbConn.GetDbConn(stItem.connectStr, &pConn)) {
		sErrInfo = "failed to get db connetion from pool";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

	mysqlpp::Transaction trans(*pConn);

	try{

		strSql = SQL_LOCK_INS;		
		mysqlpp::Query query = pConn->query();
		query << strSql;

		if(!query.store())
		{
			sErrInfo = "failed to lock instance";
			COMM_ERR_REPORT(sErrInfo);
			trans.rollback();
			return false;
		}

		if((nInsTbStat & CONST_TB_HIST_EXIST) <= 0) //lack of history data table
		{				
			MakeHistTbName_Ex(nCurYearMon,-1,-1,sTableName);
			bRet = MakeTablesAndRecord(stItem, HIS_MON_TB_PREF,\
								"01", nCurYearMon, nCurMonTbBatch, 1, query, sTableName);
			
			if(!bRet)
			{
				trans.rollback();
				sErrInfo = "failed to create history table";
				COMM_ERR_REPORT(sErrInfo);
				return false;			
			}
		}		


		if((nInsTbStat & CONST_TB_CUR_EXIST) <= 0) //lack of cur moth table
		{				
			MakeCurTbName_Ex(nCurYearMon,-1,-1,sTableName);
			MakeTablesAndRecord(stItem, CUR_MON_TB_PREF,\
								"01", nCurYearMon, nCurMonTbBatch, 0, query, sTableName);
				
			if(!bRet)
			{
				trans.rollback();
				sErrInfo = "failed to create current year table";
				COMM_ERR_REPORT(sErrInfo);
				return false;			
			}
		}	
		
		trans.commit();

	}
	catch(const mysqlpp::BadQuery& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::BadConversion& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::Exception& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}	

	return bRet;	

}



//load file to one  instance
bool 	Load_Process::LoadDataToIns_Ex(DataList *pDataList, BASE2_INT32	nBatchName,ConnectInfo stItem, BASE2_INT32 nCurYearMon)
{
	//lock the instance ,then load data
	//InsertAndRecordCur

#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("LoadDataToIns_Ex start...nBatchName=%d\n",nBatchName);
#endif
	

	mysqlpp::Connection* pConn = NULL;
	string 		strSql ;
	string 		sErrInfo;
	bool		bRet = true;

	string 		sCurTbName;
	string 		sHisTbName;

//	MakeCurTbName_Ex(nCurYearMon,-1,-1,sCurTbName);
//	MakeHistTbName_Ex(nCurYearMon,-1,-1,sHisTbName);

	if (NULL== pDataList  \
		|| FDB_SUCCESS != g_CFdbConn.GetDbConn(stItem.connectStr, &pConn)) 
	{
		sErrInfo= "failed to get db connection from conn pool";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

	map<int, BillList *>    & mMonthBillRecord = pDataList->mMonthBillRecord;

	mysqlpp::Transaction trans(*pConn);	
	map<int, BillList *>::iterator  itBillSet;
	BASE2_INT64		inc_count;
	try{

		//locke the instance
		strSql = SQL_LOCK_INS;		
		mysqlpp::Query query = pConn->query();
		query << strSql;
		
		if(!query.store())
		{
			sErrInfo = "failed to lock instance";
			COMM_ERR_REPORT(sErrInfo);
			trans.rollback();
			return false;
		}	

		//insert cur month 
		if(mMonthBillRecord.empty())
		{
			sErrInfo = "bill set map is empty";
			COMM_ERR_REPORT(sErrInfo);
			trans.rollback();
			return false;
		}
		
		itBillSet = mMonthBillRecord.begin();

		//check the whether the filename has exist in the instance indicate that load has completed before
		bool	bHasLdInCurTb = false;
		bool 	bHasLdInHisTb = false ;


//		bHasLdInCurTb = isHandledFile(pDataList->filename, query,sCurTbName);
//		bHasLdInHisTb = isHandledFile(pDataList->filename, query,sHisTbName);

#if 1
		LOG_SERVICE_INFO("LoadDataToIns_Ex: bHasLdInCurTb=%d, bHasLdInHisTb=%d\n ",bHasLdInCurTb,bHasLdInHisTb)
#endif

		//TODO
		while(itBillSet != mMonthBillRecord.end())
		{
			//��ͬ�·ݻ������
			if(nCurYearMon != itBillSet->first ) // && !bHasLdInCurTb)
			{
				nBatchName = 1;		
				MakeHistTbName_Ex(itBillSet->first,-1,-1,sHisTbName);
				
				if(1) //nCurYearMon < itBillSet->first)
				{
					//history month large than cur
					bRet =	MakeTablesAndRecord(stItem, HIS_MON_TB_PREF,\
						"01", itBillSet->first,nBatchName, 1, query, sHisTbName);
					
					if(!bRet)
					{
						sErrInfo = "failed to creat history talbe";
						COMM_ERR_REPORT(sErrInfo);
						trans.rollback();
						return false;
					}

				}
				else
				{ // history month  less than cur

				}
				//large than current month , make a history table of the month , and insert the data to the table


				bRet	=	isHandledFile(pDataList->filename, query,sHisTbName);
				if(bRet)
				{
					LOG_SERVICE_INFO("the history bill of file has been excuted before\n");
					continue;
				}				

				bRet = InsertAndRecordHis(*(itBillSet->second),0,itBillSet->second->stItem.size(), query,sHisTbName,"01", nBatchName,	inc_count);
				
				  if(!bRet)
				  {
					  sErrInfo = "failed to insert one billset of one month to cur month table";
					  COMM_ERR_REPORT(sErrInfo);
					  trans.rollback();
					  return false;
				  }
				  if(inc_count > 0)
				  {
					  bRet = MakeLoadHistory(pDataList->filename,sHisTbName,inc_count,query);
					  if(!bRet)
					  {
						  trans.rollback();
						  sErrInfo = "failed to update history month data to indb_load_history table";
						  COMM_ERR_REPORT(sErrInfo);	  
						  return false;
					  }
				  }
				  
			}
			else if(nCurYearMon == itBillSet->first ) // && !bHasLdInCurTb)
			{
				//load to cur month table	
		      MakeCurTbName_Ex(itBillSet->first,-1,-1,sCurTbName);
    		  bRet	=	isHandledFile(pDataList->filename, query,sCurTbName);
   			  if(bRet)
   			 {
   				LOG_SERVICE_INFO("the cur bill of file has been excuted before\n");
   				continue;
   			 } 	
				
			  bRet = InsertAndRecordCur(*(itBillSet->second),0,itBillSet->second->stItem.size(), query,sCurTbName,"01", nBatchName,  inc_count);
			  if(!bRet)
			  {
				  sErrInfo = "failed to insert one billset of one month to cur month table";
				  COMM_ERR_REPORT(sErrInfo);
				  trans.rollback();
				  return false;
			  }

#if 1
			LOG_SERVICE_INFO("LoadDataToIns_Ex: inc_count=%d, line=%d\n", inc_count , __LINE__)
#endif


	//TODO     
			  if(inc_count > 0)
			  {
				  bRet = MakeLoadHistory(pDataList->filename,sCurTbName,inc_count,query);
				  if(!bRet)
				  {
					  trans.rollback();
					  sErrInfo = "failed to update cur month data to indb_load_history table";
					  COMM_ERR_REPORT(sErrInfo);	  
					  return false;
				  }
			  }
			  //lnCurMonCount += inc_count;
			}

			itBillSet++;
		}


		trans.commit();

	}
	catch(const mysqlpp::BadQuery& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::BadConversion& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}
	catch(const mysqlpp::Exception& er)
	{
		trans.rollback();
		sErrInfo = er.what();
		COMM_ERR_REPORT(sErrInfo);		
		bRet = false;
	}

	return bRet;

}

/*

*  @param:
*	sFulPathFile: the exception file 's full path name 
* 	sSrcFileName: the original file name 

*/
bool	Load_Process::WritExceptFileHead(string sFulPathFile,string sSrcFileName , string sBillFileName, BASE2_INT32	nCurTime)
{
	string			sErrInfo;
	
	if(sFulPathFile.empty())
	{
		sErrInfo = "filefullpath is null";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("WritExceptFileHead  fullPath=%s, srcFileName=%s\n", sFulPathFile.c_str(), sSrcFileName.c_str());
#endif	
	
	ofstream outFile(sFulPathFile.c_str());
	

	outFile << sSrcFileName << "|" << int2str(nCurTime) << std::endl;
	outFile.close();
	return true;
}


bool 	Load_Process::WriteExceptionFile(DataList * pDataList, BASE2_INT32	nCurYearMon)
{
	string 		sErrInfo;
	string 		sFulPathFile;
	bool		bRet = true;
	
	GetExceptFileName(pDataList->szUnloadPath, getpid(),sFulPathFile);

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG(" WriteExceptionFile sFulPathFile=%s, nCurYearMon=%d,pDataList->szUnloadPath=%s\n",sFulPathFile.c_str(), nCurYearMon,pDataList->szUnloadPath);
#endif


	BASE2_INT32	i = 0;
	map<int ,BillList *>::iterator itBillSet;

	if(pDataList->mMonthBillRecord.empty())
	{
		sErrInfo = "bill set is empty";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

#if DEBUG_LOAD_EX
			LOG_SERVICE_DEBUG("start WriteExceptionFile size=%d\n", pDataList->mMonthBillRecord.size());
#endif

	itBillSet = pDataList->mMonthBillRecord.begin();

	bRet =	WritExceptFileHead(sFulPathFile, pDataList->filename, pDataList->filename, nCurYearMon);
	if(!bRet)
	{
		sErrInfo = "failed to write the head of the exception file";
		COMM_ERR_REPORT(sErrInfo);
		return false;

	}
	//append data

	while(itBillSet != pDataList->mMonthBillRecord.end())
	{
		bRet =  WriteUnhandleBill_Ex(sFulPathFile, *(itBillSet->second));
		if(!bRet)
		{
			sErrInfo = "failed to append data to exception file";
			COMM_ERR_REPORT(sErrInfo);
			return false;
		}
		itBillSet++;
	}

	return bRet;

}


//insert data from mem to one group, and update the ref data
bool Load_Process::LoadDataToGroup_Ex(BASE2_INT32 nCurYearMon, BASE2_INT32 nGroupId,	DataList* pDataLst)
{
	bool  		bRet = true;
	string 		sErrInfo;
	mysqlpp::Connection *pConn	= m_pRefDbCon;
	BASE2_INT32		i = 0;

	nCurYearMon = pDataLst->nDealMonth;
	
	if(NULL == pConn)
	{
		sErrInfo = "ref db conn is NULL\n";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

//	string		sCurMonTbName;
//	string		sHisMonTbName;
	BASE2_INT32		nBatchNum = 0;

//	MakeCurTbName_Ex(nCurYearMon,-1,-1,sCurMonTbName);
//	MakeHistTbName_Ex(nCurYearMon,-1,-1,sHisMonTbName);

	//get the table info  to insert 
#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("LoadDataToGroup_Ex: nBatchNum=%d ,line =%d\n",nBatchNum, __LINE__);
#endif
	
		bRet = GetTbInfoOfGroup(pDataLst,nCurYearMon, nBatchNum);

#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("LoadDataToGroup_Ex: nBatchNum=%d,bRet=%d ,line =%d\n",nBatchNum,bRet, __LINE__);
#endif		
		if(!bRet)
		{
			//error occured, some table exsit in one instance , and disapear in another
			sErrInfo = "failed to get table info to insert";
			COMM_ERR_REPORT(sErrInfo);
			//trans.commit();
			return false;
		}	
		
		//table exist , so load the data from mem to the group
		if(pDataLst->mMonthBillRecord.empty())
		{
			sErrInfo = "the data for this group is empty";
			COMM_ERR_REPORT(sErrInfo);
			return false;
		}
		
		BASE2_INT32		nErrNum = 0;

		// load data to instances of group
		for(i = 0; i < pDataLst->stCl.nCount; i++)
		{
			if(0 !=pDataLst->stCl.stItem[i].status)
			{
				// the status of the connection of the instance is no zero , do not load data to it
				bRet = false;
			}
			else
			{
				bRet = LoadDataToIns_Ex(pDataLst,nBatchNum, pDataLst->stCl.stItem[i],nCurYearMon);
			}			
			
			if(!bRet)
			{
				nErrNum++;
			}
		}

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("after LoadDataToIns_Ex bRet=%d,nErrNum=%d........\n", bRet,nErrNum);
#endif		
	
		//write excepitonal file
		if(nErrNum > 0)
		{
			if(nErrNum >= pDataLst->stCl.nCount)
			{
				sErrInfo = "ERR: no data load to any of one instance of group";
			}
			else
			{
				sErrInfo = "ERR: some instance loading ok ,some failed";
			}
			COMM_ERR_REPORT(sErrInfo);
			
			if(!WriteExceptionFile(pDataLst,nCurYearMon))
			{
				sErrInfo = "failed to write excetional file";
				COMM_ERR_REPORT(sErrInfo);
			}			
		}
		else
		{// ok
		}


#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("start RecordData2RefDb_Ex nBatchNum=%d\n", nBatchNum);
#endif

		//record the data to ref db after Loading data to group instances 
		bRet = RecordData2RefDb_Ex(pDataLst, nCurYearMon,nBatchNum, m_pRefDbCon, nGroupId);
		if(!bRet)
		{
			bRet  = false;
			sErrInfo  = "failed to record data 2 reference table ";
			LOG_SERVICE_ERROR("WARN: %s,line =%d,file=%s\r\n",sErrInfo.c_str(), __LINE__, __FILE__)
			ERR_EVENT2KPI(sErrInfo.c_str());
			return false;
		}		

#if DEBUG_LOAD_EX
			LOG_SERVICE_DEBUG("end RecordData2RefDb_Ex bRet =%d\n", bRet );
#endif

	return bRet;

}


//load  database
// if sucess return 0 ; else 1
BASE2_INT32 	Load_Process::LoadDB()
{
	bool  			bRet = false;
	BASE2_INT32		nErrNum = 0;
	string 			sErrInfo;

	BASE2_INT32	   nCurYearMon  ;//= GetCurYearMonth();

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("start LoadDb*******************************************\n");
#endif
	

	if(g_pTotalMsg->empty())
	{
		sErrInfo  = "the data is empty";
		LOG_SERVICE_ERROR("WARN: %s; line =%d,file=%s\r\n",sErrInfo.c_str(), __LINE__, __FILE__)
		ERR_EVENT2KPI(sErrInfo.c_str());
		return false;
	}	
	
	std::map<int, DataList*>::iterator itGbMsg = g_pTotalMsg->begin();

//	map<int, BillList*>::iterator itGrpData = NULL; 
		
	while(itGbMsg != g_pTotalMsg->end())
	{
		bRet = LoadDataToGroup_Ex(nCurYearMon, itGbMsg->first, itGbMsg->second);
		if(!bRet)
		{
			nErrNum++;
		}
		itGbMsg++;
	}

	if(nErrNum > 0)
	{
		bRet = false;
		sErrInfo  = "something wrong occurred when Load data to db ";
		LOG_SERVICE_ERROR("ERR: %s, nErrNum= %d,line =%d,file=%s\r\n",nErrNum,sErrInfo.c_str(), __LINE__, __FILE__)
		ERR_EVENT2KPI(sErrInfo.c_str());
	}



#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("end LoadDb*******************************************\n");
#endif
		

	if(bRet)
	{	
		return 0;

	}
	else
	{
		return 1;
	}
	//return bRet;
}


/**
* The big process control which put the map g_mTotalMsg buffer into database.
* @param
* @return
*/

int Load_Process::LoadDB_Ex() {
LOG_SERVICE_DEBUG("[NOTE]Load data start....\n");
//Get the month��such as 201105
int cur_year_month = GetCurYearMonth();

int recode = 0;
//std::map<string, DataList*>::iterator iter = g_pTotalMsg->begin();
std::map<int, DataList*>::iterator iter = g_pTotalMsg->begin();

while (iter != g_pTotalMsg->end()) {
	map<int, BillList*>::iterator it =
			iter->second->mMonthBillRecord.begin();

	long int  timesOfCurMonthSuccess = 0; // times of 		
	long int  timesOfOldMonthSuccess = 0;
	long int  nTotalItemNum  = 0;
	int  nTmp  = 0;

	nTotalItemNum = iter->second->mMonthBillRecord.size();
	
	while (it != iter->second->mMonthBillRecord.end()) {

	//	nTotalItemNum++;
		
		if (cur_year_month == it->first) {

			nTmp = HandleCurMonthBill(iter->second->stCl, it->first,
						*(it->second), iter->second->filename);

			if(0 == nTmp)
			{
				timesOfCurMonthSuccess++;
			}

		}
		else{	// old month 
			
			nTmp = HandleHisMonthBill(iter->second->stCl, it->first,
						*(it->second), iter->second->filename);
			if(0 == nTmp)
			{
				timesOfOldMonthSuccess++;
			}
		}


/*				
			//Handle the bills of the month.				
			if (0 == recode || 2 == recode) {
				//����ֵ��0 ȫ���ɹ��� 2 ȫʧ�ܣ�1����ʧ�
				// there is something wrong here  for the value  to return
				recode = HandleCurMonthBill(iter->second->stCl, it->first,
						*(it->second), iter->second->filename);
			} else {
				HandleCurMonthBill(iter->second->stCl, it->first,
						*(it->second), iter->second->filename);
			}
		

		} else {
			//Handle the  bills  of history month.

			// the same error with the value to return above
			if (0 == recode || 2 == recode) {
				recode = HandleHisMonthBill(iter->second->stCl, it->first,
						*(it->second), iter->second->filename);
			} else {
				HandleHisMonthBill(iter->second->stCl, it->first,
						*(it->second), iter->second->filename);
			}
			
		}
		*/

		if( 0 == timesOfCurMonthSuccess + timesOfOldMonthSuccess){
			recode = 2;
		}
		else{
			if(nTotalItemNum > timesOfCurMonthSuccess + timesOfOldMonthSuccess)
			{
				recode = 1;
			}
			else if(nTotalItemNum == timesOfCurMonthSuccess + timesOfOldMonthSuccess)
			{
				recode = 0;
			}
		}
			
		it++;
	}
	iter++;
}

return recode;
}

/**
* The control process of the month.
* @param stCl Database connection information list
* 		  time The generation time of bills��such as 201105
* 		  bills The bills that will be put into databases.
* 		  file_name The bills file name.
* @return if OK
*/
int Load_Process::HandleCurMonthBill(ConnectList &stCl, int time,
	const BillList &bills, const char *file_name) {
LOG_SERVICE_DEBUG("[NOTE]Load current month data start....\n");

bool iswrite = false; //one node failed , write unhandle files:  
string filename = file_name;

int len = stCl.nCount;

if (len <= 0) {
	iswrite = true;
	LOG_SERVICE_ERROR("[WARN]Connect string is empty!\n");
	if (WriteUnhandleBillsPro(time, getpid(), bills, filename)) {
		LOG_SERVICE_DEBUG("[NOTE]Write unhandled file success\n");
	} else {
		LOG_SERVICE_ERROR("[ERROR]Write unhandled file failure!\n");
	}
	return 2;
}
//single node : 0 success ,  1 full failed
// all nodes:  0 all success,  1 part success , 2 full failed
int *recodes = new int(len);
for (int i = 0; i < len; i++) {
	recodes[i] = 1;
}


//try 2 times  each node

int *status = new int(len);
for (int n = 0; n < len; n++) {
	status[n] = 0;
}

int k = 0;

//maybe loop with out stop,   status[len -1 ] = 2,   sum(status, len) < 2 * len
while (sum(status, len) < len * 2) {
	if (2 == status[k]) {
		k++;
		if (k == len) {
			k = 0;
		}
		continue;
	}
	//Get the database link pointer.
	mysqlpp::Connection* pConn = NULL;
	if (g_CFdbConn.GetDbConn(stCl.stItem[k].connectStr, &pConn)) {
		LOG_SERVICE_ERROR("[ERROR]Link is unavailable! [LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
		iswrite = true;
		status[k] = 2;
		k++;
		if (k == len) {
			k = 0;
		}
		continue;
	}

	//Transaction start to load bills.
	LOG_SERVICE_DEBUG("[NOTE]Transaction start to load data![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
	try {
		mysqlpp::Query query = pConn->query();
		{
			//The transaction starts here. Note that the scope of the transaction is in the Braces.
			mysqlpp::Transaction trans(*pConn);
			LOG_SERVICE_DEBUG("[NOTE]Transaction starts here![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);

			LOG_SERVICE_DEBUG("[NOTE]Try to get the lock.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
			//select ... for update. Lock the first row of the table locktable to reach the target of locking the database node.
			query << "select id from locktable where id=99 for update";
			if (!query.store()) {
				LOG_SERVICE_ERROR("[NOTE]Query time out![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				status[k] += 1;
				if (2 == status[k]) {
					iswrite = true;
				}
				k++;
				if (k == len) {
					k = 0;
				}
				continue;
			}
			LOG_SERVICE_DEBUG("[NOTE]Get the lock successfully![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);


			//Make table name prefix
			string tablename = "";
			MakeTableName("BILL", time, this->bcode, -1, -1, tablename);
			LOG_SERVICE_DEBUG("[NOTE]Table name prefix��%s.[LINK_INFO]%s\n", tablename.c_str(), stCl.stItem[k].connectStr);


			//query if the file is handled in this node.
			//problem exsit
			if (isHandledFile(filename, query, tablename)) {
				LOG_SERVICE_DEBUG("[NOTE]The file %s was handled in this node![LINK_INFO]%s\n", file_name, stCl.stItem[k].connectStr);
				status[k] = 2;
				k++;
				if (k == len) {
					k = 0;
				}
				continue;
			} else {
				LOG_SERVICE_DEBUG("[NOTE]The file %s is not handled.[LINK_INFO]%s\n", file_name, stCl.stItem[k].connectStr);
			}


			//Check if the current available table record number  meets the threshold
			int sn = 0;
			long long inc_count = 0;
			if (HasAvailableTable(time, tablename, query, sn, inc_count)) {
				LOG_SERVICE_DEBUG("[NOTE]The tables are available :inc_count=%ld sn=%d.[LINK_INFO]%s.\n", inc_count, sn, stCl.stItem[k].connectStr);
			} else {
				LOG_SERVICE_DEBUG("[NOTE]The tables are unavailable :inc_count=%ld sn=%d.[LINK_INFO]%s.\n", inc_count, sn, stCl.stItem[k].connectStr);
				sn = GetTheMaxSN(time, tablename, query);
				LOG_SERVICE_DEBUG("[NOTE]The max sn = %d.[LINK_INFO]%s.\n", sn, stCl.stItem[k].connectStr);
				sn++;

				//Make new tables and record in indb_newtable_record.
				LOG_SERVICE_DEBUG("Making tables...[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				if (!MakeTablesAndRecord(stCl.stItem[k], "BILL",
						this->bcode, time, sn, 0, query, tablename)) {
					LOG_SERVICE_ERROR("[ERROR]Make table or record failure![LINK_INFO]%s\n", stCl.stItem[k].connectStr);
					iswrite = true;
					status[k] = 2;
					k++;
					if (k == len) {
						k = 0;
					}
					continue;
				} else {
					LOG_SERVICE_DEBUG("[NOTE]Make table success![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				}
			}

			//Start to load data here.
			LOG_SERVICE_DEBUG("[NOTE]Start to load data��stCl.stItem[i].threshold=%d inc_count=%ld bills.nCount=%d\n", stCl.stItem[k].threshold, inc_count, bills.nCount);
			if (stCl.stItem[k].threshold <= inc_count) {
				//chang status from 0 to 1.
				if (!UpdateTableStatus(this->bcode, tablename, time, query)) {
					LOG_SERVICE_DEBUG("[NOTE]chang status from 0 to 1 failure![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
					iswrite = true;
					status[k] = 2;
					k++;
					if (k == len) {
						k = 0;
					}
					continue;
				} else {
					LOG_SERVICE_DEBUG("[NOTE]chang status from 0 to 1 success![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				}

				sn++;
				//Make new tables and record in indb_newtable_record.
				LOG_SERVICE_DEBUG("Making tables...[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				if (!MakeTablesAndRecord(stCl.stItem[k], "BILL",
						this->bcode, time, sn, 0, query, tablename)) {
					LOG_SERVICE_ERROR("[NOTE]Make tables or record failure![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
					iswrite = true;
					status[k] = 2;
					k++;
					if (k == len) {
						k = 0;
					}
					continue;
				} else {
					LOG_SERVICE_DEBUG("[NOTE]Make tables and record success![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				}
				inc_count = 0;
			}

			//If Meets the threshold
			if (stCl.stItem[k].threshold < inc_count + bills.nCount) {

				int u = 0;
				int count = bills.nCount;
				bool isbreak = false;
				do {
					LOG_SERVICE_DEBUG("[NOTE]Insert the pre half of data into tables inc_count = %ld.[LINK_INFO]%s.\n", inc_count, stCl.stItem[k].connectStr);
					int inum = stCl.stItem[k].threshold - inc_count;

					if (!InsertAndRecordCur(bills, u,
							u + (stCl.stItem[k].threshold - inc_count),
							query, tablename, this->bcode, sn, inc_count)) {

						iswrite = true;
						isbreak = true;
						LOG_SERVICE_ERROR("[ERROR]Insert Failure.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
						break;
					} else {
						LOG_SERVICE_DEBUG("[NOTE]Insert success![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
					}

					if (!UpdateTableStatus(this->bcode, tablename, time,
							query)) {
						LOG_SERVICE_ERROR("[ERROR]Update failsure.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
						iswrite = true;
						isbreak = true;
						break;
					} else {
						LOG_SERVICE_DEBUG("[NOTE]Update success![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
					}

					sn++;
					//Make tables here.
					LOG_SERVICE_DEBUG("Making tables...[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
					if (!MakeTablesAndRecord(stCl.stItem[k], "BILL",
							this->bcode, time, sn, 0, query, tablename)) {
						LOG_SERVICE_ERROR("[ERROR]Make tables or record failure.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
						iswrite = true;
						isbreak = true;
						break;
					} else {
						LOG_SERVICE_DEBUG("[NOTE]Make tables and record:success![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
					}

					count = count - inum;
					u = u + inum;
					inc_count = 0;
					LOG_SERVICE_DEBUG("[NOTE]cout = %d.[LINK_INFO]%s\n", count, stCl.stItem[k].connectStr);
				} while (stCl.stItem[k].threshold < count);

				if (isbreak) {
					status[k] = 2;
					k++;
					if (k == len) {
						k = 0;
					}
					iswrite = true;
					continue;
				}

				LOG_SERVICE_DEBUG("[NOTE]Insert the last half of data into tables.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				if (!InsertAndRecordCur(bills, u, bills.nCount, query,
						tablename, this->bcode, sn, inc_count)) {
					LOG_SERVICE_ERROR("[ERROR]Insert or record failure.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
					iswrite = true;
					status[k] = 2;
					k++;
					if (k == len) {
						k = 0;
					}
					continue;
				}else{
					LOG_SERVICE_DEBUG("[NOTE]Insert and record success.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				}

			} 
			else {
				LOG_SERVICE_DEBUG("[NOTE]Insert all of the data into tables.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				if (!InsertAndRecordCur(bills, 0, bills.nCount, query,
						tablename, this->bcode, sn, inc_count)) {
					LOG_SERVICE_ERROR("[ERROR]Insert or record failure![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
					iswrite = true;
					status[k] = 2;
					k++;
					if (k == len) {
						k = 0;
					}
					continue;
				}else{
					LOG_SERVICE_DEBUG("[NOTE]Insert and record success.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				}
			}

			//Put the load record into indb_load_history
			if (!MakeLoadHistory(filename, tablename, bills.nCount, query)) {
				iswrite = true;
				LOG_SERVICE_ERROR("[ERROR]Make load history record failure![LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
				status[k] = 2;
				k++;
				if (k == len) {
					k = 0;
				}
				continue;
			}else{
				LOG_SERVICE_DEBUG("[NOTE]Make load history record success.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
			}

			recodes[k] = 0;
			status[k] = 2;
			k++;
			if (k == len) {
				k = 0;
			}

			//Transaction commits here.
			LOG_SERVICE_DEBUG("[NOTE]commit.[LINK_INFO]%s.\n", stCl.stItem[k].connectStr);
			trans.commit();
		}
	} catch (const mysqlpp::BadQuery& er) {
		LOG_SERVICE_ERROR("[ERROR]BadQuery Exception:%s.[LINK_INFO]%s\n",er.what(),stCl.stItem[k].connectStr);
	} catch (const mysqlpp::BadConversion& er) {
		LOG_SERVICE_ERROR("[ERROR]BadConversion Exception:%s.[LINK_INFO]%s\n",er.what(),stCl.stItem[k].connectStr);
	} catch (const mysqlpp::Exception& er) {
		LOG_SERVICE_ERROR("[ERROR]Exception:%s.[LINK_INFO]%s\n",er.what(),stCl.stItem[k].connectStr);
	}
}

if (iswrite) {
	if (WriteUnhandleBillsPro(time, getpid(), bills, filename)) {
		LOG_SERVICE_DEBUG("[NOTE]Write unhandled file success.\n");
	} else {
		LOG_SERVICE_ERROR("[ERROR]Write unhandled file failure.\n");
	}
}

//Get the return code: 2 all fail; 1 part failure; 0 all succeed.
int recode = getrecode(recodes, len);

delete status;
delete recodes;

return recode;
}

/**
* The control process of the history month.
* @param stCl Database connection information list
* 		  time The generation time of bills��such as 201105
* 		  bills The bills that will be put into databases.
* 		  file_name The bills file name.
* @return if OK
*/
int Load_Process::HandleHisMonthBill(ConnectList &stCl, int time,
	const BillList &bills, const char *file_name) {
int recode = ALL_FAILURE;
bool sus_flag = false;
bool fal_flag = false;
LOG_SERVICE_DEBUG("[NOTE]Load history month data start....\n");

bool iswrite = false;
string filename = file_name;
for (int i = 0; i < stCl.nCount; i++) {

	//get the link
	mysqlpp::Connection* pConn = NULL;
	if (g_CFdbConn.GetDbConn(stCl.stItem[i].connectStr, &pConn)) {
		LOG_SERVICE_DEBUG("[NOTE]Link is unavailable! [LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
		iswrite = true;
		continue;
	}

	//Transaction start to load data.
	LOG_SERVICE_DEBUG("[NOTE]Make a transaction here! [LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
	try {
		mysqlpp::Query query = pConn->query();
		{
			//start transaction.
			mysqlpp::Transaction trans(*pConn);

			LOG_SERVICE_DEBUG("[NOTE]Transaction starts here![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
			LOG_SERVICE_DEBUG("[NOTE]Trying to get lock![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
			//select ... for update. Lock the table indb_load_history in the transaction.
			query << "select id from locktable where id=99 for update";
			if (!query.store()) {
				iswrite = true;
				continue;
			}
			LOG_SERVICE_DEBUG("[NOTE]Get the lock successfully![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);

			//query if the file is handled in this node.

			//Make table name prefix
			string tablename = "";
			MakeTableName("BILL_HISTORY", time, this->bcode, -1, -1,
					tablename);
			LOG_SERVICE_DEBUG("[NOTE]Table name prefix��%s.[LINK_INFO]%s\n", tablename.c_str(), stCl.stItem[i].connectStr);
			

			if (isHandledFile(filename, query, tablename)) {
				LOG_SERVICE_DEBUG("[NOTE]The file %s has been handled![LINK_INFO]%s.\n", file_name, stCl.stItem[i].connectStr);
				continue;
			} else {
				LOG_SERVICE_DEBUG("[NOTE]The file %s is not handled.[LINK_INFO]%s.\n", file_name, stCl.stItem[i].connectStr);
			}


			//Check the current available table record number of meets the threshold
			int sn = 0;
			long long inc_count = 0;
			if (HasAvailableTable(time, tablename, query, sn, inc_count)) {
				LOG_SERVICE_DEBUG("[NOTE]The tables are available :inc_count=%ld sn=%d.[LINK_INFO]%s\n", inc_count, sn, stCl.stItem[i].connectStr);
			} else {
				LOG_SERVICE_DEBUG("[NOTE]The tables are unavailable :inc_count=%ld sn=%d.[LINK_INFO]%s\n", inc_count, sn, stCl.stItem[i].connectStr);
				sn = GetTheMaxSN(time, tablename, query);
				LOG_SERVICE_DEBUG("[NOTE]The max sn = %d.[LINK_INFO]%s.\n", sn, stCl.stItem[i].connectStr);
				sn++;

				//Make new tables and record in indb_newtable_record.
				LOG_SERVICE_DEBUG("[NOTE]Making table...[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
				if (!MakeTablesAndRecord(stCl.stItem[i], "BILL_HISTORY",
						this->bcode, time, sn, 1, query, tablename)) {
					LOG_SERVICE_ERROR("[ERROR]Make table or record failsure![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
					iswrite = true;
					continue;
				} else {
					LOG_SERVICE_DEBUG("[NOTE]Make table and record success![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
				}
			}

			//Start to load data here.
			LOG_SERVICE_DEBUG("[NOTE]Start to load data��stCl.stItem[i].threshold=%d inc_count=%ld bills.nCount=%d.[LINK_INFO]%s.\n", stCl.stItem[i].threshold, inc_count, bills.nCount, stCl.stItem[i].connectStr);
			if (THRESHOLD <= inc_count) {
				//chang status from 0 to 1.
				if (!UpdateTableStatus(this->bcode, tablename, time, query)) {
					LOG_SERVICE_ERROR("[ERROR]Chang status from 0 to 1 failsure![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
					iswrite = true;
					continue;
				} else {
					LOG_SERVICE_DEBUG("[NOTE]Chang status from 0 to 1 success![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
				}

				sn++;
				//Make new tables and record in indb_newtable_record.
				LOG_SERVICE_DEBUG("[NOTE]Making table...[LINK_INFO]%s.", stCl.stItem[i].connectStr);
				if (!MakeTablesAndRecord(stCl.stItem[i], "BILL_HISTORY",
						this->bcode, time, sn, 1, query, tablename)) {
					LOG_SERVICE_ERROR("[ERROR]Make table or record failure![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
					iswrite = true;
					continue;
				} else {
					LOG_SERVICE_DEBUG("[NOTE]Make table and record success![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
				}
				inc_count = 0;

			}

			//If Meets the threshold
			if (THRESHOLD < inc_count + bills.nCount) {

				int u = 0;
				int count = bills.nCount;

				bool isbreak = false;
				do {
					LOG_SERVICE_DEBUG("[NOTE]Insert the pre half of data into tables inc_count = %d.[LINK_INFO]%s.\n", inc_count, stCl.stItem[i].connectStr);
					int inum = THRESHOLD - inc_count;
					if (!InsertAndRecordHis(bills, u,
							u + (THRESHOLD - inc_count), query, tablename,
							this->bcode, sn, inc_count)) {
						isbreak = true;
						LOG_SERVICE_ERROR("[ERROR]Insert Failure.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
						break;
					} else {
						LOG_SERVICE_DEBUG("[NOTE]Insert success![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
					}

					if (!UpdateTableStatus(this->bcode, tablename, time, query)) {
						LOG_SERVICE_ERROR("[ERROR]Update failsure.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
						isbreak = true;
						break;
					} else {
						LOG_SERVICE_DEBUG("[NOTE]Update success![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
					}

					sn++;
					if (!MakeTablesAndRecord(stCl.stItem[i],
							"BILL_HISTORY", this->bcode, time, sn, 1,
							query, tablename)) {
						LOG_SERVICE_ERROR("[ERROR]Make table or record failure.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
						isbreak = true;
						break;
					} else {
						LOG_SERVICE_DEBUG("[NOTE]Make tables and record success![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
					}

					count = count - inum;
					u = u + inum;
					inc_count = 0;
					LOG_SERVICE_DEBUG("[NOTE]cout = %d.[LINK_INFO]%s.\n", count, stCl.stItem[i].connectStr);
				} while (THRESHOLD < count);

				if (isbreak) {
					iswrite = true;
					continue;
				}

				LOG_SERVICE_DEBUG("[NOTE]Insert the last half of data into tables.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
				if (!InsertAndRecordHis(bills, u, bills.nCount, query,
						tablename, this->bcode, sn, inc_count)) {
					LOG_SERVICE_ERROR("[ERROR]Insert and record failure.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
					iswrite = true;
					continue;
				}


			}
			else {			
				LOG_SERVICE_DEBUG("[NOTE]Insert all of the data into tables.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
				if (!InsertAndRecordHis(bills, 0, bills.nCount, query,
						tablename, this->bcode, sn, inc_count)) {
					LOG_SERVICE_ERROR("[ERROR]Insert and record failure![LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
					iswrite = true;
					continue;
				}
			}

			//Put the load record into indb_load_history
			if (!MakeLoadHistory(filename, tablename, bills.nCount, query)) {
				LOG_SERVICE_ERROR("[ERROR]Put the load record into database failure.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
				iswrite = true;
				continue;
			}else{
				LOG_SERVICE_ERROR("[ERROR]Put the load record into database success.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
			}

			trans.commit();
			LOG_SERVICE_DEBUG("[NOTE]commit.[LINK_INFO]%s.\n", stCl.stItem[i].connectStr);
			sus_flag = true;
		}
	} catch (const mysqlpp::BadQuery& er) {
		LOG_SERVICE_ERROR("[ERROR]BadQuery Exception:%s.[LINK_INFO]%s.\n",er.what(), stCl.stItem[i].connectStr);
	} catch (const mysqlpp::BadConversion& er) {
		LOG_SERVICE_ERROR("[ERROR]BadConversion Exception:%s.[LINK_INFO]%s.\n",er.what(), stCl.stItem[i].connectStr);
	} catch (const mysqlpp::Exception& er) {
		LOG_SERVICE_ERROR("[ERROR]Exception:%s.[LINK_INFO]%s.\n",er.what(), stCl.stItem[i].connectStr);
	}
}

if (iswrite) {
	if (WriteUnhandleBillsPro(time, getpid(), bills, filename)) {
		LOG_SERVICE_DEBUG("[NOTE]Write unhandled file success\n");
	} else {
		LOG_SERVICE_ERROR("[ERROR]Write unhandled file failure!\n");
	}
}

if (sus_flag && fal_flag) {
	return PARTICAL_SUCCESS;
} else if (sus_flag && !fal_flag) {
	return SUCCESS;
} else {
	return ALL_FAILURE;
}
return 0;
}

bool Load_Process::WriteUnhandleBill_Ex(string sFullPathFile,const BillList &bills) 
{

	string		sErrInfo;

#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("WriteUnhandleBill_Ex fullPath = %s,count=%d,%d\n", sFullPathFile.c_str(), bills.nCount,bills.stItem.size());
#endif

	ofstream outfile(sFullPathFile.c_str(), ios::app);
//Open file failure.
	if (!outfile) {
		sErrInfo = "error to open the exception file";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}

	vector<const char *> vPointer;

	BASE2_INT32		i  = 0;
	BASE2_INT32		nCount = 0;

	for(nCount = 0; nCount < bills.stItem.size() ; nCount++)
	{
			vPointer.clear();
			MapTheTbCoWithPoint(vPointer,bills.stItem.at(nCount).stBill);
		
			if(vPointer.size()!= TB_BILL_COL_MAX)
			{
#if DEBUG_LOAD_EX
		
				LOG_SERVICE_ERROR("2failed to map the pointer of bill struct,vpSize=%d,TB_BILL_COL_MAX =%d,line=%d, file=%s\n",vPointer.size(),TB_BILL_COL_MAX,__LINE__, __FILE__)
#endif					
				//source code
				sErrInfo = "failed to map the pointer of bill struct";
				COMM_ERR_REPORT(sErrInfo);	
				return false;
			}
			
			for(i = 0; i < TB_BILL_COL_MAX; i++)	
			{
				outfile << vPointer.at(i);
			}
			outfile << "\r\n";		

	}
	

//The first line.
//outfile << fname << std::endl;
//The content of bill.

/*for (int i = 0; i < bills.nCount; i++) {
	outfile << bills.stItem[i].stBill.EventFormatType;
	outfile << bills.stItem[i].stBill.roll_flag;
	outfile << bills.stItem[i].stBill.roll_count;
	outfile << bills.stItem[i].stBill.file_id;
	outfile << bills.stItem[i].stBill.exc_id;
	outfile << bills.stItem[i].stBill.FileType;
	outfile << bills.stItem[i].stBill.subno;
	outfile << bills.stItem[i].stBill.IMSI;
	outfile << bills.stItem[i].stBill.IMEI;
	outfile << bills.stItem[i].stBill.start_time;
	outfile << bills.stItem[i].stBill.special_flag;
	outfile << bills.stItem[i].stBill.proc_time;
	outfile << bills.stItem[i].stBill.event_id;
	outfile << bills.stItem[i].stBill.Switch_flag;
	outfile << bills.stItem[i].stBill.District;
	outfile << bills.stItem[i].stBill.Brand;
	outfile << bills.stItem[i].stBill.User_Type;
	outfile << bills.stItem[i].stBill.Visit_Area;
	outfile << bills.stItem[i].stBill.B_subno;
	outfile << bills.stItem[i].stBill.Bill_type;
	outfile << bills.stItem[i].stBill.ACCT_Mob;
	outfile << bills.stItem[i].stBill.ACCT_Toll;
	outfile << bills.stItem[i].stBill.ACCT_Inf;
	outfile << bills.stItem[i].stBill.Mob_fee;
	outfile << bills.stItem[i].stBill.Toll_fee;
	outfile << bills.stItem[i].stBill.Inf_fee;
	outfile << bills.stItem[i].stBill.Pay_mode;

	outfile << bills.stItem[i].stBill.Be_Payed;
	outfile << bills.stItem[i].stBill.deducted;
	outfile << bills.stItem[i].stBill.acct_balance_a;
	outfile << bills.stItem[i].stBill.acct_balance_b;
	outfile << bills.stItem[i].stBill.dis_id;
	outfile << bills.stItem[i].stBill.reserve;
	outfile << bills.stItem[i].stBill.pay_switch_flag;
	outfile << bills.stItem[i].stBill.pay_district;
	outfile << bills.stItem[i].stBill.pay_brand;
	outfile << bills.stItem[i].stBill.pay_user_type;
	outfile << bills.stItem[i].stBill.pay_subno;
	outfile << bills.stItem[i].stBill.pay_account;
	outfile << bills.stItem[i].stBill.pay_acct_balance_a;
	outfile << bills.stItem[i].stBill.pay_acct_balance_b;
	outfile << bills.stItem[i].stBill.pay_mob_fee;
	outfile << bills.stItem[i].stBill.pay_toll_fee;
	outfile << bills.stItem[i].stBill.pay_inf_fee;
	outfile << bills.stItem[i].stBill.pay_deducted;
	outfile << bills.stItem[i].stBill.xd_type;
	outfile << bills.stItem[i].stBill.change_part;

	outfile << bills.stItem[i].stBill.bus_code;
	outfile << bills.stItem[i].stBill.bus_type;
	outfile << bills.stItem[i].stBill.subbus_type;
	outfile << bills.stItem[i].stBill.rat_type;
	outfile << bills.stItem[i].stBill.dis_code;
	outfile << bills.stItem[i].stBill.direct_type;
	outfile << bills.stItem[i].stBill.visit_switch_flag;
	outfile << bills.stItem[i].stBill.roam_type;
	outfile << bills.stItem[i].stBill.toll_type;
	outfile << bills.stItem[i].stBill.carry_type;
	outfile << bills.stItem[i].stBill.b_operator;
	outfile << bills.stItem[i].stBill.b_switch_flag;
	outfile << bills.stItem[i].stBill.b_brand;
	outfile << bills.stItem[i].stBill.b_user_type;
	outfile << bills.stItem[i].stBill.dis_dura;
	outfile << bills.stItem[i].stBill.dis_fee;
	outfile << bills.stItem[i].stBill.relation;
	outfile << bills.stItem[i].stBill.duration;
	outfile << bills.stItem[i].stBill.net_type;
	outfile << bills.stItem[i].stBill.multi_call;
	outfile << bills.stItem[i].stBill.call_type;
	outfile << bills.stItem[i].stBill.call_flag;
	outfile << bills.stItem[i].stBill.msisdnB;
	outfile << bills.stItem[i].stBill.msisdnC;
	outfile << bills.stItem[i].stBill.real_msisdn;
	outfile << bills.stItem[i].stBill.msrn;
	outfile << bills.stItem[i].stBill.msc_id;
	outfile << bills.stItem[i].stBill.calling_lac;
	outfile << bills.stItem[i].stBill.calling_cellid;
	outfile << bills.stItem[i].stBill.called_lac;
	outfile << bills.stItem[i].stBill.called_cellid;
	outfile << bills.stItem[i].stBill.out_router;
	outfile << bills.stItem[i].stBill.in_router;
	outfile << bills.stItem[i].stBill.service_type;
	outfile << bills.stItem[i].stBill.service_code;
	outfile << bills.stItem[i].stBill.session_id;
	outfile << bills.stItem[i].stBill.session_si;
	outfile << bills.stItem[i].stBill.session_type;
	outfile << bills.stItem[i].stBill.FCI;
	outfile << bills.stItem[i].stBill.vpn_call_type;
	outfile << bills.stItem[i].stBill.fee_one;
	outfile << bills.stItem[i].stBill.fee_two;
	
	outfile << "\r\n";
}
*/

outfile.close();
return true;





}

/**
* Write unhandled file.
* @param file_name the name of target file.
* 		  bills bills
* 		  conInfo Database connection information
* @return if OK
*/
bool Load_Process::WriteUnhandleBill(const char *file_name,
	const BillList &bills, const string fname) {
ofstream outfile(file_name);
//Open file failure.
if (!outfile) {
	LOG_SERVICE_ERROR("[ERROR]Write Unhandle file failure:Open open file %s failure\n", file_name);
	return false;
}

//The first line.
outfile << fname << std::endl;
//The content of bill.
for (int i = 0; i < bills.nCount; i++) {

/*	outfile << bills.stItem[i].stBill.EventFormatType;
	outfile << bills.stItem[i].stBill.roll_flag;
	outfile << bills.stItem[i].stBill.roll_count;
	outfile << bills.stItem[i].stBill.file_id;
	outfile << bills.stItem[i].stBill.exc_id;
	outfile << bills.stItem[i].stBill.FileType;
	outfile << bills.stItem[i].stBill.subno;
	outfile << bills.stItem[i].stBill.IMSI;
	outfile << bills.stItem[i].stBill.IMEI;
	outfile << bills.stItem[i].stBill.start_time;
	outfile << bills.stItem[i].stBill.special_flag;
	outfile << bills.stItem[i].stBill.proc_time;
	outfile << bills.stItem[i].stBill.event_id;
	outfile << bills.stItem[i].stBill.Switch_flag;
	outfile << bills.stItem[i].stBill.District;
	outfile << bills.stItem[i].stBill.Brand;
	outfile << bills.stItem[i].stBill.User_Type;
	outfile << bills.stItem[i].stBill.Visit_Area;
	outfile << bills.stItem[i].stBill.B_subno;
	outfile << bills.stItem[i].stBill.Bill_type;
	outfile << bills.stItem[i].stBill.ACCT_Mob;
	outfile << bills.stItem[i].stBill.ACCT_Toll;
	outfile << bills.stItem[i].stBill.ACCT_Inf;
	outfile << bills.stItem[i].stBill.Mob_fee;
	outfile << bills.stItem[i].stBill.Toll_fee;
	outfile << bills.stItem[i].stBill.Inf_fee;
	outfile << bills.stItem[i].stBill.Pay_mode;

	outfile << bills.stItem[i].stBill.Be_Payed;
	outfile << bills.stItem[i].stBill.deducted;
	outfile << bills.stItem[i].stBill.acct_balance_a;
	outfile << bills.stItem[i].stBill.acct_balance_b;
	outfile << bills.stItem[i].stBill.dis_id;
	outfile << bills.stItem[i].stBill.reserve;
	outfile << bills.stItem[i].stBill.pay_switch_flag;
	outfile << bills.stItem[i].stBill.pay_district;
	outfile << bills.stItem[i].stBill.pay_brand;
	outfile << bills.stItem[i].stBill.pay_user_type;
	outfile << bills.stItem[i].stBill.pay_subno;
	outfile << bills.stItem[i].stBill.pay_account;
	outfile << bills.stItem[i].stBill.pay_acct_balance_a;
	outfile << bills.stItem[i].stBill.pay_acct_balance_b;
	outfile << bills.stItem[i].stBill.pay_mob_fee;
	outfile << bills.stItem[i].stBill.pay_toll_fee;
	outfile << bills.stItem[i].stBill.pay_inf_fee;
	outfile << bills.stItem[i].stBill.pay_deducted;
	outfile << bills.stItem[i].stBill.xd_type;
	outfile << bills.stItem[i].stBill.change_part;
*/
	/*
	outfile << bills.stItem[i].stBill.bus_code;
	outfile << bills.stItem[i].stBill.bus_type;
	outfile << bills.stItem[i].stBill.subbus_type;
	outfile << bills.stItem[i].stBill.rat_type;
	outfile << bills.stItem[i].stBill.dis_code;
	outfile << bills.stItem[i].stBill.direct_type;
	outfile << bills.stItem[i].stBill.visit_switch_flag;
	outfile << bills.stItem[i].stBill.roam_type;
	outfile << bills.stItem[i].stBill.toll_type;
	outfile << bills.stItem[i].stBill.carry_type;
	outfile << bills.stItem[i].stBill.b_operator;
	outfile << bills.stItem[i].stBill.b_switch_flag;
	outfile << bills.stItem[i].stBill.b_brand;
	outfile << bills.stItem[i].stBill.b_user_type;
	outfile << bills.stItem[i].stBill.dis_dura;
	outfile << bills.stItem[i].stBill.dis_fee;
	outfile << bills.stItem[i].stBill.relation;
	outfile << bills.stItem[i].stBill.duration;
	outfile << bills.stItem[i].stBill.net_type;
	outfile << bills.stItem[i].stBill.multi_call;
	outfile << bills.stItem[i].stBill.call_type;
	outfile << bills.stItem[i].stBill.call_flag;
	outfile << bills.stItem[i].stBill.msisdnB;
	outfile << bills.stItem[i].stBill.msisdnC;
	outfile << bills.stItem[i].stBill.real_msisdn;
	outfile << bills.stItem[i].stBill.msrn;
	outfile << bills.stItem[i].stBill.msc_id;
	outfile << bills.stItem[i].stBill.calling_lac;
	outfile << bills.stItem[i].stBill.calling_cellid;
	outfile << bills.stItem[i].stBill.called_lac;
	outfile << bills.stItem[i].stBill.called_cellid;
	outfile << bills.stItem[i].stBill.out_router;
	outfile << bills.stItem[i].stBill.in_router;
	outfile << bills.stItem[i].stBill.service_type;
	outfile << bills.stItem[i].stBill.service_code;
	outfile << bills.stItem[i].stBill.session_id;
	outfile << bills.stItem[i].stBill.session_si;
	outfile << bills.stItem[i].stBill.session_type;
	outfile << bills.stItem[i].stBill.FCI;
	outfile << bills.stItem[i].stBill.vpn_call_type;
	outfile << bills.stItem[i].stBill.fee_one;
	outfile << bills.stItem[i].stBill.fee_two;
	*/
	outfile << "\r\n";
}

outfile.close();
return true;
}


bool 	Load_Process::MapTheTbCoWithPoint(vector<const char *> & vpBillColSet, const Bill & oneBill)
{
	vpBillColSet.clear();

	vpBillColSet.push_back(oneBill.EventFormatType);					
	vpBillColSet.push_back(oneBill.roll_flag);							
	vpBillColSet.push_back(oneBill.roll_count); 						
	vpBillColSet.push_back(oneBill.file_id);							
	vpBillColSet.push_back(oneBill.exc_id); 							
	vpBillColSet.push_back(oneBill.FileType);							
	vpBillColSet.push_back(oneBill.subno);								
	vpBillColSet.push_back(oneBill.IMSI);								
	vpBillColSet.push_back(oneBill.IMEI);								
	vpBillColSet.push_back(oneBill.start_time); 						
	vpBillColSet.push_back(oneBill.special_flag);						
	vpBillColSet.push_back(oneBill.proc_time);							
	vpBillColSet.push_back(oneBill.event_id);							
	vpBillColSet.push_back(oneBill.Switch_flag);						
	vpBillColSet.push_back(oneBill.District);							
	vpBillColSet.push_back(oneBill.Brand);								
	vpBillColSet.push_back(oneBill.User_Type);							
	vpBillColSet.push_back(oneBill.Visit_Area); 						
	vpBillColSet.push_back(oneBill.B_subno);							
	vpBillColSet.push_back(oneBill.Bill_type);							
	vpBillColSet.push_back(oneBill.ACCT_Mob);							
	vpBillColSet.push_back(oneBill.ACCT_Toll);							
	vpBillColSet.push_back(oneBill.ACCT_Inf);							
	vpBillColSet.push_back(oneBill.Mob_fee);							
	vpBillColSet.push_back(oneBill.Toll_fee);							
	vpBillColSet.push_back(oneBill.Inf_fee);							
	vpBillColSet.push_back(oneBill.Pay_mode);							
	vpBillColSet.push_back(oneBill.dis_id); 							
	vpBillColSet.push_back(oneBill.reserve);							
	vpBillColSet.push_back(oneBill.cbe_flag);							
	vpBillColSet.push_back(oneBill.period_flag);						
	vpBillColSet.push_back(oneBill.SubsID); 							
	vpBillColSet.push_back(oneBill.A_pay_type); 						
	vpBillColSet.push_back(oneBill.A_pay_subno);						
	vpBillColSet.push_back(oneBill.A_pay_switch_flag);					
	vpBillColSet.push_back(oneBill.A_pay_district); 					
	vpBillColSet.push_back(oneBill.A_pay_brand);						
	vpBillColSet.push_back(oneBill.A_pay_user_type);					
	vpBillColSet.push_back(oneBill.A_AcctID);							
	vpBillColSet.push_back(oneBill.A_deducted); 						
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE); 					
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE_ID1); 				
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE_AMT1);				
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE_ID2); 				
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE_AMT2);				
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE_ID3); 				
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE_AMT3);				
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE_ID4); 				
	vpBillColSet.push_back(oneBill.A_ACCT_BALANCE_AMT4);				
	vpBillColSet.push_back(oneBill.B_pay_type); 						
	vpBillColSet.push_back(oneBill.B_pay_subno);						
	vpBillColSet.push_back(oneBill.B_pay_switch_flag);					
	vpBillColSet.push_back(oneBill.B_pay_district); 					
	vpBillColSet.push_back(oneBill.B_pay_brand);						
	vpBillColSet.push_back(oneBill.B_pay_user_type);					
	vpBillColSet.push_back(oneBill.B_AcctID);							
	vpBillColSet.push_back(oneBill.B_deducted); 						
	vpBillColSet.push_back(oneBill.B_ACCT_BALANCE); 					
	vpBillColSet.push_back(oneBill.B_ACCT_BALANCE_ID1); 				
	vpBillColSet.push_back(oneBill.B_ACCT_BALANCE_AMT1);				
	vpBillColSet.push_back(oneBill.B_ACCT_BALANCE_ID2); 				
	vpBillColSet.push_back(oneBill.B_ACCT_BALANCE_AMT2);				
	vpBillColSet.push_back(oneBill.B_ACCT_BALANCE_ID3); 				
	vpBillColSet.push_back(oneBill.B_ACCT_BALANCE_AMT3);
//	vpBillColSet.push_back(oneBill.xd_type);
	vpBillColSet.push_back(oneBill.change_part);						


}
/**
* Inert bills into database.
* @param bills The bills will be put into database.
* 		  start The start position of bills.
* 		  end 	The end position of bills.
* 		  query The instance of mysqlpp::Query
* 		  table_name The prefix of real table name
* 		  sn    Thes serial number of tables.
* 		  id	The reference of inc_count which means the number of inserted bills in the database.
* @return if OK.
*/
bool Load_Process::InsertBills(const BillList &bills, const int start,
	const int end, mysqlpp::Query &query, const string table_name,
	const int sn, long long &id) 
{

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("InsertBills start....sn=%d\n",sn);
#endif


	map<BASE2_INT32	, string> mpSql;
	map<BASE2_INT32	, string>::iterator   itSql;	
	

	string		strTbColSet = "";
	BASE2_INT32		i = 0;
	string			strSql;
	string 			sErrInfo;
	BASE2_INT32		nTbOrder = 0;
	string 			sValueSet;
	BASE2_INT32		j  = 0;
	id = 0;

	//get the table 's  column
	for(i = 0; i < TB_BILL_COL_MAX; i++)
	{
		if(0 == i)
		{
			strTbColSet = "(" + string(stBillColName[i].sColName);
		}
		else
		{
			strTbColSet += stBillColName[i].sColName;
		}

		if(TB_BILL_COL_MAX-1  != i)
		{
			strTbColSet += ", ";
		}
		else
		{
			strTbColSet += ")";
		}
	}

	vector<const char *> vPointer;

	try {
		if(bills.stItem.empty())
		{
			sErrInfo = "billset is empty";
			COMM_ERR_REPORT(sErrInfo);
			return false;
		}

#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("InsertBills:billsize =%d, %d\n", vPointer.size(),bills.stItem.size());
#endif
					
		for(i = 0; i < bills.stItem.size(); i++)
		{
			//find the table order 
			nTbOrder = atol(bills.stItem[i].stBill.subno) % TABLE_NUM;

			itSql = mpSql.find(nTbOrder);			
				
			//get the values set
			vPointer.clear();
			MapTheTbCoWithPoint(vPointer,bills.stItem.at(i).stBill);

			if(vPointer.size()!= TB_BILL_COL_MAX)
			{
#if  0//for debug
				LOG_SERVICE_ERROR("failed to map the pointer of bill struct,vpSize=%d,TB_BILL_COL_MAX =%d,line=%d, file=%s\n",vPointer.size(),TB_BILL_COL_MAX,__LINE__, __FILE__)
#else		
				//source code
				sErrInfo = "failed to map the pointer of bill struct";
				COMM_ERR_REPORT(sErrInfo);
#endif				
				return false;
			}
			
			for(j = 0; j < TB_BILL_COL_MAX; j++)
			{
				if(0 == j)
				{
					sValueSet = string(" ('") + vPointer.at(j);
				}
				else
				{
					sValueSet +=  vPointer.at(j);
				}

				if(TB_BILL_COL_MAX -1 != j)
				{
					sValueSet += "' , '";
				}
				else
				{
					sValueSet += "')";
				}	

			}
			
#if 0 //DEBUG_LOAD_EX
			LOG_SERVICE_DEBUG("InsertBills,tablename=%s,nTbOrder=%d,sn=%d, strTbColSet=%s,sValueSet=%s \n",\
			table_name.c_str(),nTbOrder, sn, strTbColSet.c_str(),sValueSet.c_str());
#endif
	
			if(mpSql.end() != itSql)
			{//check  whether the key exist in the map 
				//has found
				itSql->second += ", "  + sValueSet;
			}
			else
			{ //no found 
				strSql = "insert into " + table_name + "_" + int24str(nTbOrder) + "_"
				+ int23str(sn) + strTbColSet + " values" + sValueSet;

				mpSql.insert(pair<BASE2_INT32, string>(nTbOrder, strSql));
			}			


#if 0	//DEBUG_LOAD_EX
				LOG_SERVICE_DEBUG("InsertBills,sql=%s\n",strSql.c_str());
#endif

			/*
			query <<  strSql;


			if (!query.exec()) {
				LOG_SERVICE_ERROR("[ERROR]sql=%s.error=%s\n", strSql.c_str(), query.error());
				return false;
			}else{
				LOG_SERVICE_DEBUG("[NOTE]sql=%s\n", strSql.c_str());
			}	
			*/
			id++;

		}

		//start to insert
		if(mpSql.empty())
		{
			sErrInfo  = "the data is empty";
			LOG_SERVICE_ERROR("WARN: %s; line =%d,file=%s\r\n",sErrInfo.c_str(), __LINE__, __FILE__)
			ERR_EVENT2KPI(sErrInfo.c_str());
			return true;
		}

		itSql = mpSql.begin();

		strSql = "";
		
		while(itSql != mpSql.end())
		{
			strSql = itSql->second;
			
			query <<  strSql;

			if (!query.exec()) {
				LOG_SERVICE_ERROR("[ERROR]sql=%s.error=%s\n", strSql.c_str(), query.error());
				return false;
			}else{
				//LOG_SERVICE_DEBUG("[NOTE]sql=%s\n", strSql.c_str());
				LOG_SERVICE_DEBUG("[NOTE]sucess to insert one record\n");
			}
			itSql++;
		}	
	}
	catch (const mysqlpp::BadQuery& er) {
		// Something went wrong with the SQL query.
		LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
	} catch (const mysqlpp::Exception& er) {
		// Catch-all for any other MySQL++ exceptions
		LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
	}

/*
for (int i = 0; i < TABLE_NUM; i++) {
	//The heads!
	


//*************************************************************************	
	string	fields =
					"(EventFormatType,roll_flag,roll_count,file_id,exc_id,FileType,subno,IMSI,IMEI,start_time,special_flag,proc_time,event_id,Switch_flag,District,Brand,User_Type,Visit_Area,B_subno,Bill_type,ACCT_Mob,ACCT_Toll,ACCT_Inf,Mob_fee,Toll_fee,Inf_fee,Pay_mode,Be_Payed,deducted,acct_balance_a,acct_balance_b,dis_id,reserve,pay_switch_flag,pay_district,pay_brand,pay_user_type,pay_subno,pay_account,pay_acct_balance_a,pay_acct_balance_b,pay_mob_fee,pay_toll_fee,pay_inf_fee,pay_deducted,xd_type,change_part)";
	sql[i] = "insert into " + tname + "_" + int24str(i) + "_"
			+ int23str(sn) + fields + " values";
}


	string EventFormatType ;
	string roll_flag ;
	string roll_count ;
	string file_id ;
	string exc_id ;
	string FileType;
	string subno;
	string IMSI;
	string IMEI;
	string start_time;
	string special_flag;
	string proc_time;
	string event_id;
	string Switch_flag;
	string District;
	string Brand ;
	string User_Type ;
	string Visit_Area ;
	string B_subno ;
	string Bill_type;
	string ACCT_Mob ;
	string ACCT_Toll ;
	string ACCT_Inf ;
	string Mob_fee ;
	string Toll_fee ;
	string Inf_fee ;
	string Pay_mode;
	string Be_Payed ;
	string deducted ;
	string acct_balance_a ;
	string acct_balance_b ;
	string dis_id ;
	string reserve;
	string pay_switch_flag ;
	string pay_district ;
	string pay_brand ;
	string pay_user_type ;
	string pay_subno ;
	string pay_account;
	string pay_acct_balance_a;
	string pay_acct_balance_b;
	string pay_mob_fee;
	string pay_toll_fee;
	string pay_inf_fee ;
	string pay_deducted ;
	string xd_type ;
	string change_part ;


for (int k = start; k < end; k++) {
	int j = atol(bills.stItem[k].stBill.subno) % TABLE_NUM;
	//char* is transformed to string just for splice.
	 EventFormatType = bills.stItem[k].stBill.EventFormatType;
	 roll_flag = bills.stItem[k].stBill.roll_flag;
	 roll_count = bills.stItem[k].stBill.roll_count;
	 file_id = bills.stItem[k].stBill.file_id;
	 exc_id = bills.stItem[k].stBill.exc_id;
	 FileType = bills.stItem[k].stBill.FileType;
	 subno = bills.stItem[k].stBill.subno;
	 IMSI = bills.stItem[k].stBill.IMSI;
	 IMEI = bills.stItem[k].stBill.IMEI;
	 start_time = bills.stItem[k].stBill.start_time;
	 special_flag = bills.stItem[k].stBill.special_flag;
	 proc_time = bills.stItem[k].stBill.proc_time;
	 event_id = bills.stItem[k].stBill.event_id;
	 Switch_flag = bills.stItem[k].stBill.Switch_flag;
	 District = bills.stItem[k].stBill.District;
	 Brand = bills.stItem[k].stBill.Brand;
	 User_Type = bills.stItem[k].stBill.User_Type;
	 Visit_Area = bills.stItem[k].stBill.Visit_Area;
	 B_subno = bills.stItem[k].stBill.B_subno;
	 Bill_type = bills.stItem[k].stBill.Bill_type;
	 ACCT_Mob = bills.stItem[k].stBill.ACCT_Mob;
	 ACCT_Toll = bills.stItem[k].stBill.ACCT_Toll;
	 ACCT_Inf = bills.stItem[k].stBill.ACCT_Inf;
	 Mob_fee = bills.stItem[k].stBill.Mob_fee;
	 Toll_fee = bills.stItem[k].stBill.Toll_fee;
	 Inf_fee = bills.stItem[k].stBill.Inf_fee;
	 Pay_mode = bills.stItem[k].stBill.Pay_mode;

	 Be_Payed = bills.stItem[k].stBill.Be_Payed;
	 deducted = bills.stItem[k].stBill.deducted;
	 acct_balance_a = bills.stItem[k].stBill.acct_balance_a;
	 acct_balance_b = bills.stItem[k].stBill.acct_balance_b;
	 dis_id = bills.stItem[k].stBill.dis_id;
	 reserve = bills.stItem[k].stBill.reserve;
	 pay_switch_flag = bills.stItem[k].stBill.pay_switch_flag;
	 pay_district = bills.stItem[k].stBill.pay_district;
	 pay_brand = bills.stItem[k].stBill.pay_brand;
	 pay_user_type = bills.stItem[k].stBill.pay_user_type;
	 pay_subno = bills.stItem[k].stBill.pay_subno;
	 pay_account = bills.stItem[k].stBill.pay_account;
	 pay_acct_balance_a = bills.stItem[k].stBill.pay_acct_balance_a;
	 pay_acct_balance_b = bills.stItem[k].stBill.pay_acct_balance_b;
	 pay_mob_fee = bills.stItem[k].stBill.pay_mob_fee;
	 pay_toll_fee = bills.stItem[k].stBill.pay_toll_fee;
	 pay_inf_fee = bills.stItem[k].stBill.pay_inf_fee;
	 pay_deducted = bills.stItem[k].stBill.pay_deducted;
	 xd_type = bills.stItem[k].stBill.xd_type;
	 change_part = bills.stItem[k].stBill.change_part;

	string bus_code = bills.stItem[k].stBill.bus_code;
	string bus_type = bills.stItem[k].stBill.bus_type;
	string subbus_type = bills.stItem[k].stBill.subbus_type;
	string rat_type = bills.stItem[k].stBill.rat_type;
	string dis_code = bills.stItem[k].stBill.dis_code;
	string direct_type = bills.stItem[k].stBill.direct_type;
	string visit_switch_flag = bills.stItem[k].stBill.visit_switch_flag;
	string roam_type = bills.stItem[k].stBill.roam_type;
	string toll_type = bills.stItem[k].stBill.toll_type;
	string carry_type = bills.stItem[k].stBill.carry_type;
	string b_operator = bills.stItem[k].stBill.b_operator;
	string b_switch_flag = bills.stItem[k].stBill.b_switch_flag;
	string b_brand = bills.stItem[k].stBill.b_brand;
	string b_user_type = bills.stItem[k].stBill.b_user_type;
	string dis_dura = bills.stItem[k].stBill.dis_dura;
	string dis_fee = bills.stItem[k].stBill.dis_fee;
	string relation = bills.stItem[k].stBill.relation;
	string duration = bills.stItem[k].stBill.duration;
	string net_type = bills.stItem[k].stBill.net_type;
	string multi_call = bills.stItem[k].stBill.multi_call;
	string call_type = bills.stItem[k].stBill.call_type;
	string call_flag = bills.stItem[k].stBill.call_flag;
	string msisdnB = bills.stItem[k].stBill.msisdnB;
	string msisdnC = bills.stItem[k].stBill.msisdnC;
	string real_msisdn = bills.stItem[k].stBill.real_msisdn;
	string msrn = bills.stItem[k].stBill.msrn;
	string msc_id = bills.stItem[k].stBill.msc_id;
	string calling_lac = bills.stItem[k].stBill.calling_lac;
	string calling_cellid = bills.stItem[k].stBill.calling_cellid;
	string called_lac = bills.stItem[k].stBill.called_lac;
	string called_cellid = bills.stItem[k].stBill.called_cellid;
	string out_router = bills.stItem[k].stBill.out_router;
	string in_router = bills.stItem[k].stBill.in_router;
	string service_type = bills.stItem[k].stBill.service_type;
	string service_code = bills.stItem[k].stBill.service_code;
	string session_id = bills.stItem[k].stBill.session_id;
	string session_si = bills.stItem[k].stBill.session_si;
	string session_type = bills.stItem[k].stBill.session_type;
	string FCI = bills.stItem[k].stBill.FCI;
	string vpn_call_type = bills.stItem[k].stBill.vpn_call_type;
	string fee_one = bills.stItem[k].stBill.fee_one;
	string fee_two = bills.stItem[k].stBill.fee_two;

	
	id++;
	//string ids = intll2str(id);
	string value = "(\'" + EventFormatType + "\'," + "\'" + roll_flag
			+ "\'," + "\'" + roll_count + "\'," + "\'" + file_id + "\',"
			+ "\'" + exc_id + "\'," + "\'" + FileType + "\'," + "\'"
			+ subno + "\'," + "\'" + IMSI + "\'," + "\'" + IMEI + "\',"
			+ "\'" + start_time + "\'," + "\'" + special_flag + "\',"
			+ "\'" + proc_time + "\'," + "\'" + event_id + "\'," + "\'"
			+ Switch_flag + "\'," + "\'" + District + "\'," + "\'" + Brand
			+ "\'," + "\'" + User_Type + "\'," + "\'" + Visit_Area + "\',"
			+ "\'" + B_subno + "\'," + "\'" + Bill_type + "\'," + "\'"
			+ ACCT_Mob + "\'," + "\'" + ACCT_Toll + "\'," + "\'" + ACCT_Inf
			+ "\'," + "\'" + Mob_fee + "\'," + "\'" + Toll_fee + "\',"
			+ "\'" + Inf_fee + "\'," + "\'" + Pay_mode + "\'," + "\'"
			+ Be_Payed + "\'," + "\'" + deducted + "\'," + "\'"
			+ acct_balance_a + "\'," + "\'" + acct_balance_b + "\'," + "\'"
			+ dis_id + "\'," + "\'" + reserve + "\'," + "\'"
			+ pay_switch_flag + "\'," + "\'" + pay_district + "\'," + "\'"
			+ pay_brand + "\'," + "\'" + pay_user_type + "\'," + "\'"
			+ pay_subno + "\'," + "\'" + pay_account + "\'," + "\'"
			+ pay_acct_balance_a + "\'," + "\'" + pay_acct_balance_b
			+ "\'," + "\'" + pay_mob_fee + "\'," + "\'" + pay_toll_fee
			+ "\'," + "\'" + pay_inf_fee + "\'," + "\'" + pay_deducted
			+ "\'," + "\'" + xd_type
			+ "\'," + "\'" + change_part

			+ "\'," + "\'" + bus_code + "\',"
			+ "\'" + bus_type + "\'," + "\'" + subbus_type + "\'," + "\'"
			+ rat_type + "\'," + "\'" + dis_code + "\'," + "\'"
			+ direct_type + "\'," + "\'" + visit_switch_flag + "\'," + "\'"
			+ roam_type + "\'," + "\'" + toll_type + "\'," + "\'"
			+ carry_type + "\'," + "\'" + b_operator + "\'," + "\'"
			+ b_switch_flag + "\'," + "\'" + b_brand + "\'," + "\'"
			+ b_user_type + "\'," + "\'" + dis_dura + "\'," + "\'"
			+ dis_fee + "\'," + "\'" + relation + "\'," + "\'" + duration
			+ "\'," + "\'" + net_type + "\'," + "\'" + multi_call + "\',"
			+ "\'" + call_type + "\'," + "\'" + call_flag + "\'," + "\'"
			+ msisdnB + "\'," + "\'" + msisdnC + "\'," + "\'" + real_msisdn
			+ "\'," + "\'" + msrn + "\'," + "\'" + msc_id + "\'," + "\'"
			+ calling_lac + "\'," + "\'" + calling_cellid + "\'," + "\'"
			+ called_lac + "\'," + "\'" + called_cellid + "\'," + "\'"
			+ out_router + "\'," + "\'" + in_router + "\'," + "\'"
			+ service_type + "\'," + "\'" + service_code + "\'," + "\'"
			+ session_id + "\'," + "\'" + session_si + "\'," + "\'"
			+ session_type + "\'," + "\'" + FCI + "\'," + "\'"
			+ vpn_call_type + "\'," + "\'" + fee_one + "\'," + "\'"
			+ fee_two

			+ "\')";
	//std::cout << value << std::endl;
	if (sql[j].substr(sql[j].length() - 6, 6) == "values") {
		sql[j] += value;
	} else {
		sql[j] += "," + value;
	}
}

try {
	for (int i = 0; i < TABLE_NUM; i++) {
		if (sql[i].substr(sql[i].length() - 6, 6) == "values") {
			//No record.
			continue;
		}

		query << sql[i];
		if (!query.exec()) {
			LOG_SERVICE_ERROR("[ERROR]sql=%s.error=%s\n", sql[i].c_str(), query.error());
			return false;
		}else{
			LOG_SERVICE_DEBUG("[NOTE]sql=%s\n", sql[i].c_str());
		}
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

*/
return true ;
}





bool Load_Process::InsertHisBills(const BillList &bills, const int start,
	const int end, mysqlpp::Query &query, const string table_name,
	const int sn, long long &id) 
{
	
//	string tname = table_name;
//	string sql[TABLE_NUM];
#if DEBUG_LOAD_EX
			LOG_SERVICE_DEBUG("InsertHisBills start....sn=%d\n",sn);
#endif


	string		strTbColSet = "";
	BASE2_INT32		i = 0;
	string			strSql;
	string 			sErrInfo;
//	string 			sTbFullName = table_name;
//	BASE2_INT32		nTbOrder = 0;
	string 			sValueSet;
	BASE2_INT32		j  = 0;
	id  = 0;
	
	//get the table 's  column
	for(i = 0; i < TB_BILL_COL_MAX; i++)
	{
		if(0 == i)
		{
			strTbColSet = "(" + string(stBillColName[i].sColName);
		}
		else
		{
			strTbColSet += stBillColName[i].sColName;
		}

		if(TB_BILL_COL_MAX-1  != i)
		{
			strTbColSet += ", ";
		}
		else
		{
			strTbColSet += ")";
		}
	}

	vector<const char *> vPointer;

	try {
		if(bills.stItem.empty())
		{
			sErrInfo = "billset is empty";
			COMM_ERR_REPORT(sErrInfo);
			return false;
		}

		for(i = 0; i < bills.stItem.size(); i++)
		{
			//find the table order 
			//nTbOrder = atol(bills.stItem[i].stBill.subno) % TABLE_NUM;

			//get the values set
			vPointer.clear();
			MapTheTbCoWithPoint(vPointer,bills.stItem.at(i).stBill);

			if(vPointer.size()!= TB_BILL_COL_MAX)
			{
				sErrInfo = "failed to map the pointer of bill struct";
				COMM_ERR_REPORT(sErrInfo);
				return false;
			}
			
			for(j = 0; j < TB_BILL_COL_MAX; j++)
			{
				if(0 == j)
				{
					sValueSet = string(" ('") + vPointer.at(j);
				}
				else
				{
					sValueSet +=  vPointer.at(j);
				}

				if(TB_BILL_COL_MAX -1 != j)
				{
					sValueSet += "' , '";
				}
				else
				{
					sValueSet += "')";
				}	

			}

			if(0 == i)
			{
				strSql = "insert into " + table_name  + strTbColSet + " values" + sValueSet;

			}
			else
			{				
				strSql += ", " + sValueSet;
			}	

			id++;

		}

		//start to insert the bill set
		query <<  strSql;

		if (!query.exec()) {
			LOG_SERVICE_ERROR("[ERROR]line=%d, sql=%s.error=%s\n",__LINE__, strSql.c_str(), query.error());
			return false;
		}else{
			//LOG_SERVICE_DEBUG("[NOTE]sql=%s\n", sql[i].c_str());
			LOG_SERVICE_DEBUG("success to insert one record to history table\n");
		}			

	}
	catch (const mysqlpp::BadQuery& er) {
		// Something went wrong with the SQL query.
		LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
	} catch (const mysqlpp::Exception& er) {
		// Catch-all for any other MySQL++ exceptions
		LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
	}

/*
for (int i = 0; i < TABLE_NUM; i++) {
	//The heads!
	


//*************************************************************************	
	string	fields =
					"(EventFormatType,roll_flag,roll_count,file_id,exc_id,FileType,subno,IMSI,IMEI,start_time,special_flag,proc_time,event_id,Switch_flag,District,Brand,User_Type,Visit_Area,B_subno,Bill_type,ACCT_Mob,ACCT_Toll,ACCT_Inf,Mob_fee,Toll_fee,Inf_fee,Pay_mode,Be_Payed,deducted,acct_balance_a,acct_balance_b,dis_id,reserve,pay_switch_flag,pay_district,pay_brand,pay_user_type,pay_subno,pay_account,pay_acct_balance_a,pay_acct_balance_b,pay_mob_fee,pay_toll_fee,pay_inf_fee,pay_deducted,xd_type,change_part)";
	sql[i] = "insert into " + tname + "_" + int24str(i) + "_"
			+ int23str(sn) + fields + " values";
}


	string EventFormatType ;
	string roll_flag ;
	string roll_count ;
	string file_id ;
	string exc_id ;
	string FileType;
	string subno;
	string IMSI;
	string IMEI;
	string start_time;
	string special_flag;
	string proc_time;
	string event_id;
	string Switch_flag;
	string District;
	string Brand ;
	string User_Type ;
	string Visit_Area ;
	string B_subno ;
	string Bill_type;
	string ACCT_Mob ;
	string ACCT_Toll ;
	string ACCT_Inf ;
	string Mob_fee ;
	string Toll_fee ;
	string Inf_fee ;
	string Pay_mode;
	string Be_Payed ;
	string deducted ;
	string acct_balance_a ;
	string acct_balance_b ;
	string dis_id ;
	string reserve;
	string pay_switch_flag ;
	string pay_district ;
	string pay_brand ;
	string pay_user_type ;
	string pay_subno ;
	string pay_account;
	string pay_acct_balance_a;
	string pay_acct_balance_b;
	string pay_mob_fee;
	string pay_toll_fee;
	string pay_inf_fee ;
	string pay_deducted ;
	string xd_type ;
	string change_part ;


for (int k = start; k < end; k++) {
	int j = atol(bills.stItem[k].stBill.subno) % TABLE_NUM;
	//char* is transformed to string just for splice.
	 EventFormatType = bills.stItem[k].stBill.EventFormatType;
	 roll_flag = bills.stItem[k].stBill.roll_flag;
	 roll_count = bills.stItem[k].stBill.roll_count;
	 file_id = bills.stItem[k].stBill.file_id;
	 exc_id = bills.stItem[k].stBill.exc_id;
	 FileType = bills.stItem[k].stBill.FileType;
	 subno = bills.stItem[k].stBill.subno;
	 IMSI = bills.stItem[k].stBill.IMSI;
	 IMEI = bills.stItem[k].stBill.IMEI;
	 start_time = bills.stItem[k].stBill.start_time;
	 special_flag = bills.stItem[k].stBill.special_flag;
	 proc_time = bills.stItem[k].stBill.proc_time;
	 event_id = bills.stItem[k].stBill.event_id;
	 Switch_flag = bills.stItem[k].stBill.Switch_flag;
	 District = bills.stItem[k].stBill.District;
	 Brand = bills.stItem[k].stBill.Brand;
	 User_Type = bills.stItem[k].stBill.User_Type;
	 Visit_Area = bills.stItem[k].stBill.Visit_Area;
	 B_subno = bills.stItem[k].stBill.B_subno;
	 Bill_type = bills.stItem[k].stBill.Bill_type;
	 ACCT_Mob = bills.stItem[k].stBill.ACCT_Mob;
	 ACCT_Toll = bills.stItem[k].stBill.ACCT_Toll;
	 ACCT_Inf = bills.stItem[k].stBill.ACCT_Inf;
	 Mob_fee = bills.stItem[k].stBill.Mob_fee;
	 Toll_fee = bills.stItem[k].stBill.Toll_fee;
	 Inf_fee = bills.stItem[k].stBill.Inf_fee;
	 Pay_mode = bills.stItem[k].stBill.Pay_mode;

	 Be_Payed = bills.stItem[k].stBill.Be_Payed;
	 deducted = bills.stItem[k].stBill.deducted;
	 acct_balance_a = bills.stItem[k].stBill.acct_balance_a;
	 acct_balance_b = bills.stItem[k].stBill.acct_balance_b;
	 dis_id = bills.stItem[k].stBill.dis_id;
	 reserve = bills.stItem[k].stBill.reserve;
	 pay_switch_flag = bills.stItem[k].stBill.pay_switch_flag;
	 pay_district = bills.stItem[k].stBill.pay_district;
	 pay_brand = bills.stItem[k].stBill.pay_brand;
	 pay_user_type = bills.stItem[k].stBill.pay_user_type;
	 pay_subno = bills.stItem[k].stBill.pay_subno;
	 pay_account = bills.stItem[k].stBill.pay_account;
	 pay_acct_balance_a = bills.stItem[k].stBill.pay_acct_balance_a;
	 pay_acct_balance_b = bills.stItem[k].stBill.pay_acct_balance_b;
	 pay_mob_fee = bills.stItem[k].stBill.pay_mob_fee;
	 pay_toll_fee = bills.stItem[k].stBill.pay_toll_fee;
	 pay_inf_fee = bills.stItem[k].stBill.pay_inf_fee;
	 pay_deducted = bills.stItem[k].stBill.pay_deducted;
	 xd_type = bills.stItem[k].stBill.xd_type;
	 change_part = bills.stItem[k].stBill.change_part;

	string bus_code = bills.stItem[k].stBill.bus_code;
	string bus_type = bills.stItem[k].stBill.bus_type;
	string subbus_type = bills.stItem[k].stBill.subbus_type;
	string rat_type = bills.stItem[k].stBill.rat_type;
	string dis_code = bills.stItem[k].stBill.dis_code;
	string direct_type = bills.stItem[k].stBill.direct_type;
	string visit_switch_flag = bills.stItem[k].stBill.visit_switch_flag;
	string roam_type = bills.stItem[k].stBill.roam_type;
	string toll_type = bills.stItem[k].stBill.toll_type;
	string carry_type = bills.stItem[k].stBill.carry_type;
	string b_operator = bills.stItem[k].stBill.b_operator;
	string b_switch_flag = bills.stItem[k].stBill.b_switch_flag;
	string b_brand = bills.stItem[k].stBill.b_brand;
	string b_user_type = bills.stItem[k].stBill.b_user_type;
	string dis_dura = bills.stItem[k].stBill.dis_dura;
	string dis_fee = bills.stItem[k].stBill.dis_fee;
	string relation = bills.stItem[k].stBill.relation;
	string duration = bills.stItem[k].stBill.duration;
	string net_type = bills.stItem[k].stBill.net_type;
	string multi_call = bills.stItem[k].stBill.multi_call;
	string call_type = bills.stItem[k].stBill.call_type;
	string call_flag = bills.stItem[k].stBill.call_flag;
	string msisdnB = bills.stItem[k].stBill.msisdnB;
	string msisdnC = bills.stItem[k].stBill.msisdnC;
	string real_msisdn = bills.stItem[k].stBill.real_msisdn;
	string msrn = bills.stItem[k].stBill.msrn;
	string msc_id = bills.stItem[k].stBill.msc_id;
	string calling_lac = bills.stItem[k].stBill.calling_lac;
	string calling_cellid = bills.stItem[k].stBill.calling_cellid;
	string called_lac = bills.stItem[k].stBill.called_lac;
	string called_cellid = bills.stItem[k].stBill.called_cellid;
	string out_router = bills.stItem[k].stBill.out_router;
	string in_router = bills.stItem[k].stBill.in_router;
	string service_type = bills.stItem[k].stBill.service_type;
	string service_code = bills.stItem[k].stBill.service_code;
	string session_id = bills.stItem[k].stBill.session_id;
	string session_si = bills.stItem[k].stBill.session_si;
	string session_type = bills.stItem[k].stBill.session_type;
	string FCI = bills.stItem[k].stBill.FCI;
	string vpn_call_type = bills.stItem[k].stBill.vpn_call_type;
	string fee_one = bills.stItem[k].stBill.fee_one;
	string fee_two = bills.stItem[k].stBill.fee_two;

	
	id++;
	//string ids = intll2str(id);
	string value = "(\'" + EventFormatType + "\'," + "\'" + roll_flag
			+ "\'," + "\'" + roll_count + "\'," + "\'" + file_id + "\',"
			+ "\'" + exc_id + "\'," + "\'" + FileType + "\'," + "\'"
			+ subno + "\'," + "\'" + IMSI + "\'," + "\'" + IMEI + "\',"
			+ "\'" + start_time + "\'," + "\'" + special_flag + "\',"
			+ "\'" + proc_time + "\'," + "\'" + event_id + "\'," + "\'"
			+ Switch_flag + "\'," + "\'" + District + "\'," + "\'" + Brand
			+ "\'," + "\'" + User_Type + "\'," + "\'" + Visit_Area + "\',"
			+ "\'" + B_subno + "\'," + "\'" + Bill_type + "\'," + "\'"
			+ ACCT_Mob + "\'," + "\'" + ACCT_Toll + "\'," + "\'" + ACCT_Inf
			+ "\'," + "\'" + Mob_fee + "\'," + "\'" + Toll_fee + "\',"
			+ "\'" + Inf_fee + "\'," + "\'" + Pay_mode + "\'," + "\'"
			+ Be_Payed + "\'," + "\'" + deducted + "\'," + "\'"
			+ acct_balance_a + "\'," + "\'" + acct_balance_b + "\'," + "\'"
			+ dis_id + "\'," + "\'" + reserve + "\'," + "\'"
			+ pay_switch_flag + "\'," + "\'" + pay_district + "\'," + "\'"
			+ pay_brand + "\'," + "\'" + pay_user_type + "\'," + "\'"
			+ pay_subno + "\'," + "\'" + pay_account + "\'," + "\'"
			+ pay_acct_balance_a + "\'," + "\'" + pay_acct_balance_b
			+ "\'," + "\'" + pay_mob_fee + "\'," + "\'" + pay_toll_fee
			+ "\'," + "\'" + pay_inf_fee + "\'," + "\'" + pay_deducted
			+ "\'," + "\'" + xd_type
			+ "\'," + "\'" + change_part

			+ "\'," + "\'" + bus_code + "\',"
			+ "\'" + bus_type + "\'," + "\'" + subbus_type + "\'," + "\'"
			+ rat_type + "\'," + "\'" + dis_code + "\'," + "\'"
			+ direct_type + "\'," + "\'" + visit_switch_flag + "\'," + "\'"
			+ roam_type + "\'," + "\'" + toll_type + "\'," + "\'"
			+ carry_type + "\'," + "\'" + b_operator + "\'," + "\'"
			+ b_switch_flag + "\'," + "\'" + b_brand + "\'," + "\'"
			+ b_user_type + "\'," + "\'" + dis_dura + "\'," + "\'"
			+ dis_fee + "\'," + "\'" + relation + "\'," + "\'" + duration
			+ "\'," + "\'" + net_type + "\'," + "\'" + multi_call + "\',"
			+ "\'" + call_type + "\'," + "\'" + call_flag + "\'," + "\'"
			+ msisdnB + "\'," + "\'" + msisdnC + "\'," + "\'" + real_msisdn
			+ "\'," + "\'" + msrn + "\'," + "\'" + msc_id + "\'," + "\'"
			+ calling_lac + "\'," + "\'" + calling_cellid + "\'," + "\'"
			+ called_lac + "\'," + "\'" + called_cellid + "\'," + "\'"
			+ out_router + "\'," + "\'" + in_router + "\'," + "\'"
			+ service_type + "\'," + "\'" + service_code + "\'," + "\'"
			+ session_id + "\'," + "\'" + session_si + "\'," + "\'"
			+ session_type + "\'," + "\'" + FCI + "\'," + "\'"
			+ vpn_call_type + "\'," + "\'" + fee_one + "\'," + "\'"
			+ fee_two

			+ "\')";
	//std::cout << value << std::endl;
	if (sql[j].substr(sql[j].length() - 6, 6) == "values") {
		sql[j] += value;
	} else {
		sql[j] += "," + value;
	}
}

try {
	for (int i = 0; i < TABLE_NUM; i++) {
		if (sql[i].substr(sql[i].length() - 6, 6) == "values") {
			//No record.
			continue;
		}

		query << sql[i];
		if (!query.exec()) {
			LOG_SERVICE_ERROR("[ERROR]sql=%s.error=%s\n", sql[i].c_str(), query.error());
			return false;
		}else{
			LOG_SERVICE_DEBUG("[NOTE]sql=%s\n", sql[i].c_str());
		}
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

*/
return true;
}

/**
* Inert bills into database.
* @param bills The bills will be put into database.
* 		  start The start position of bills.
* 		  end 	The end position of bills.
* 		  query The instance of mysqlpp::Query
* 		  table_name The prefix of real table name
* 		  sn    Thes serial number of tables.
* 		  id	The reference of inc_count which means the number of inserted bills in the database.
* @return if OK.
*/
bool Load_Process::InsertHisBills_Ex(const BillList &bills, const int start,
	const int end, mysqlpp::Query &query, const string table_name,
	const int sn, long long &id) {
string tname = table_name;
//insert head!
string
		fields =
				"(EventFormatType,roll_flag,roll_count,file_id,exc_id,FileType,subno,IMSI,IMEI,start_time,special_flag,proc_time,event_id,Switch_flag,District,Brand,User_Type,Visit_Area,B_subno,Bill_type,ACCT_Mob,ACCT_Toll,ACCT_Inf,Mob_fee,Toll_fee,Inf_fee,Pay_mode,Be_Payed,deducted,acct_balance_a,acct_balance_b,dis_id,reserve,pay_switch_flag,pay_district,pay_brand,pay_user_type,pay_subno,pay_account,pay_acct_balance_a,pay_acct_balance_b,pay_mob_fee,pay_toll_fee,pay_inf_fee,pay_deducted,xd_type,change_part)";
string sql = "insert into " + tname + "_" + int23str(sn) + fields
		+ " values";


string EventFormatType ;
string roll_flag ;
string roll_count ;
string file_id ;
string exc_id ;
string FileType;
string subno ;
string IMSI ;
string IMEI;
string start_time;
string special_flag ;
string proc_time ;
string event_id ;
string Switch_flag;
string District ;
string Brand ;
string User_Type;
string Visit_Area;;
string B_subno;
string Bill_type; 
string ACCT_Mob ;
string ACCT_Toll ;
string ACCT_Inf ;
string Mob_fee ;
string Toll_fee ;
string Inf_fee ;
string Pay_mode ;
string Be_Payed ;
string deducted ;
string acct_balance_a ;
string acct_balance_b ;
string dis_id ;
string reserve ;
string pay_switch_flag;
string pay_district ;
string pay_brand ;
string pay_user_type;
string pay_subno ;
string pay_account;
string pay_acct_balance_a;
string pay_acct_balance_b;
string pay_mob_fee ;
string pay_toll_fee ;
string pay_inf_fee ;
string pay_deducted ;
string xd_type ;

string change_part;


for (int k = start; k < end; k++) {
	//char* is transformed to string just for splice.
	 EventFormatType = bills.stItem[k].stBill.EventFormatType;
	 roll_flag = bills.stItem[k].stBill.roll_flag;
	 roll_count = bills.stItem[k].stBill.roll_count;
	 file_id = bills.stItem[k].stBill.file_id;
	 exc_id = bills.stItem[k].stBill.exc_id;
	 FileType = bills.stItem[k].stBill.FileType;
	 subno = bills.stItem[k].stBill.subno;
	 IMSI = bills.stItem[k].stBill.IMSI;
	 IMEI = bills.stItem[k].stBill.IMEI;
	 start_time = bills.stItem[k].stBill.start_time;
	 special_flag = bills.stItem[k].stBill.special_flag;
	 proc_time = bills.stItem[k].stBill.proc_time;
	 event_id = bills.stItem[k].stBill.event_id;
	 Switch_flag = bills.stItem[k].stBill.Switch_flag;
	 District = bills.stItem[k].stBill.District;
	 Brand = bills.stItem[k].stBill.Brand;
	 User_Type = bills.stItem[k].stBill.User_Type;
	 Visit_Area = bills.stItem[k].stBill.Visit_Area;
	 B_subno = bills.stItem[k].stBill.B_subno;
	 Bill_type = bills.stItem[k].stBill.Bill_type;
	 ACCT_Mob = bills.stItem[k].stBill.ACCT_Mob;
	 ACCT_Toll = bills.stItem[k].stBill.ACCT_Toll;
	 ACCT_Inf = bills.stItem[k].stBill.ACCT_Inf;
	 Mob_fee = bills.stItem[k].stBill.Mob_fee;
	 Toll_fee = bills.stItem[k].stBill.Toll_fee;
	 Inf_fee = bills.stItem[k].stBill.Inf_fee;
	 Pay_mode = bills.stItem[k].stBill.Pay_mode;
/*
	 Be_Payed = bills.stItem[k].stBill.Be_Payed;
	 deducted = bills.stItem[k].stBill.deducted;
	 acct_balance_a = bills.stItem[k].stBill.acct_balance_a;
	 acct_balance_b = bills.stItem[k].stBill.acct_balance_b;
	 dis_id = bills.stItem[k].stBill.dis_id;
	 reserve = bills.stItem[k].stBill.reserve;
	 pay_switch_flag = bills.stItem[k].stBill.pay_switch_flag;
	 pay_district = bills.stItem[k].stBill.pay_district;
	 pay_brand = bills.stItem[k].stBill.pay_brand;
	 pay_user_type = bills.stItem[k].stBill.pay_user_type;
	 pay_subno = bills.stItem[k].stBill.pay_subno;
	 pay_account = bills.stItem[k].stBill.pay_account;
	 pay_acct_balance_a = bills.stItem[k].stBill.pay_acct_balance_a;
	 pay_acct_balance_b = bills.stItem[k].stBill.pay_acct_balance_b;
	 pay_mob_fee = bills.stItem[k].stBill.pay_mob_fee;
	 pay_toll_fee = bills.stItem[k].stBill.pay_toll_fee;
	 pay_inf_fee = bills.stItem[k].stBill.pay_inf_fee;
	 pay_deducted = bills.stItem[k].stBill.pay_deducted;
	 xd_type = bills.stItem[k].stBill.xd_type;
	
	 change_part = bills.stItem[k].stBill.change_part;
*/
/*
	string bus_code = bills.stItem[k].stBill.bus_code;
	string bus_type = bills.stItem[k].stBill.bus_type;
	string subbus_type = bills.stItem[k].stBill.subbus_type;
	string rat_type = bills.stItem[k].stBill.rat_type;
	string dis_code = bills.stItem[k].stBill.dis_code;
	string direct_type = bills.stItem[k].stBill.direct_type;
	string visit_switch_flag = bills.stItem[k].stBill.visit_switch_flag;
	string roam_type = bills.stItem[k].stBill.roam_type;
	string toll_type = bills.stItem[k].stBill.toll_type;
	string carry_type = bills.stItem[k].stBill.carry_type;
	string b_operator = bills.stItem[k].stBill.b_operator;
	string b_switch_flag = bills.stItem[k].stBill.b_switch_flag;
	string b_brand = bills.stItem[k].stBill.b_brand;
	string b_user_type = bills.stItem[k].stBill.b_user_type;
	string dis_dura = bills.stItem[k].stBill.dis_dura;
	string dis_fee = bills.stItem[k].stBill.dis_fee;
	string relation = bills.stItem[k].stBill.relation;
	string duration = bills.stItem[k].stBill.duration;
	string net_type = bills.stItem[k].stBill.net_type;
	string multi_call = bills.stItem[k].stBill.multi_call;
	string call_type = bills.stItem[k].stBill.call_type;
	string call_flag = bills.stItem[k].stBill.call_flag;
	string msisdnB = bills.stItem[k].stBill.msisdnB;
	string msisdnC = bills.stItem[k].stBill.msisdnC;
	string real_msisdn = bills.stItem[k].stBill.real_msisdn;
	string msrn = bills.stItem[k].stBill.msrn;
	string msc_id = bills.stItem[k].stBill.msc_id;
	string calling_lac = bills.stItem[k].stBill.calling_lac;
	string calling_cellid = bills.stItem[k].stBill.calling_cellid;
	string called_lac = bills.stItem[k].stBill.called_lac;
	string called_cellid = bills.stItem[k].stBill.called_cellid;
	string out_router = bills.stItem[k].stBill.out_router;
	string in_router = bills.stItem[k].stBill.in_router;
	string service_type = bills.stItem[k].stBill.service_type;
	string service_code = bills.stItem[k].stBill.service_code;
	string session_id = bills.stItem[k].stBill.session_id;
	string session_si = bills.stItem[k].stBill.session_si;
	string session_type = bills.stItem[k].stBill.session_type;
	string FCI = bills.stItem[k].stBill.FCI;
	string vpn_call_type = bills.stItem[k].stBill.vpn_call_type;
	string fee_one = bills.stItem[k].stBill.fee_one;
	string fee_two = bills.stItem[k].stBill.fee_two;
*/
	id++;
	string ids = intll2str(id);

	//string value = "(" + ids + ",\'" + EventFormatType + "\'," + "\'"
	string value = "(" + EventFormatType + "\'," + "\'"
			+ roll_flag + "\'," + "\'" + roll_count + "\'," + "\'"
			+ file_id + "\'," + "\'" + exc_id + "\'," + "\'" + FileType
			+ "\'," + "\'" + subno + "\'," + "\'" + IMSI + "\'," + "\'"
			+ IMEI + "\'," + "\'" + start_time + "\'," + "\'"
			+ special_flag + "\'," + "\'" + proc_time + "\'," + "\'"
			+ event_id + "\'," + "\'" + Switch_flag + "\'," + "\'"
			+ District + "\'," + "\'" + Brand + "\'," + "\'" + User_Type
			+ "\'," + "\'" + Visit_Area + "\'," + "\'" + B_subno + "\',"
			+ "\'" + Bill_type + "\'," + "\'" + ACCT_Mob + "\'," + "\'"
			+ ACCT_Toll + "\'," + "\'" + ACCT_Inf + "\'," + "\'" + Mob_fee
			+ "\'," + "\'" + Toll_fee + "\'," + "\'" + Inf_fee + "\',"
			+ "\'" + Pay_mode + "\'," + "\'" + Be_Payed + "\'," + "\'"
			+ deducted + "\'," + "\'" + acct_balance_a + "\'," + "\'"
			+ acct_balance_b + "\'," + "\'" + dis_id + "\'," + "\'"
			+ reserve + "\'," + "\'" + pay_switch_flag + "\'," + "\'"
			+ pay_district + "\'," + "\'" + pay_brand + "\'," + "\'"
			+ pay_user_type + "\'," + "\'" + pay_subno + "\'," + "\'"
			+ pay_account + "\'," + "\'" + pay_acct_balance_a + "\',"
			+ "\'" + pay_acct_balance_b + "\'," + "\'" + pay_mob_fee
			+ "\'," + "\'" + pay_toll_fee + "\'," + "\'" + pay_inf_fee
			+ "\'," + "\'" + pay_deducted + "\'," + "\'" + xd_type 
			+ "\'," + "\'" + change_part
			


/*			+ "\',"
			+ "\'" + bus_code + "\'," + "\'" + bus_type + "\'," + "\'"
			+ subbus_type + "\'," + "\'" + rat_type + "\'," + "\'"
			+ dis_code + "\'," + "\'" + direct_type + "\'," + "\'"
			+ visit_switch_flag + "\'," + "\'" + roam_type + "\'," + "\'"
			+ toll_type + "\'," + "\'" + carry_type + "\'," + "\'"
			+ b_operator + "\'," + "\'" + b_switch_flag + "\'," + "\'"
			+ b_brand + "\'," + "\'" + b_user_type + "\'," + "\'"
			+ dis_dura + "\'," + "\'" + dis_fee + "\'," + "\'" + relation
			+ "\'," + "\'" + duration + "\'," + "\'" + net_type + "\',"
			+ "\'" + multi_call + "\'," + "\'" + call_type + "\'," + "\'"
			+ call_flag + "\'," + "\'" + msisdnB + "\'," + "\'" + msisdnC
			+ "\'," + "\'" + real_msisdn + "\'," + "\'" + msrn + "\',"
			+ "\'" + msc_id + "\'," + "\'" + calling_lac + "\'," + "\'"
			+ calling_cellid + "\'," + "\'" + called_lac + "\'," + "\'"
			+ called_cellid + "\'," + "\'" + out_router + "\'," + "\'"
			+ in_router + "\'," + "\'" + service_type + "\'," + "\'"
			+ service_code + "\'," + "\'" + session_id + "\'," + "\'"
			+ session_si + "\'," + "\'" + session_type + "\'," + "\'" + FCI
			+ "\'," + "\'" + vpn_call_type + "\'," + "\'" + fee_one + "\',"
			+ "\'" + fee_two
*/
			+ "\')";
	//std::cout << value << std::endl;
	if (sql.substr(sql.length() - 6, 6) == "values") {
		sql += value;
	} else {
		sql += "," + value;
	}
}

try {
	if (sql.substr(sql.length() - 6, 6) == "values") {
		//No record.
		return true;
	}

	query << sql;
	if (!query.exec()) {
		LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
		return false;
	}else{
		LOG_SERVICE_DEBUG("[NOTE]sql=%s\n", sql.c_str());
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

return true;
}

/**
* Make tables.
* @param head The head of table name:indb/indb_history
* 		  business_code The business code
* 		  time Year and month, such as 201106
* 		  serial_number	Serial number
* 		  query The instance of mysql::Query
* @return if OK
*/
bool Load_Process::MakeTables(const char *head, const string business_code,
	const int time, const int serial_number, const int type,
	mysqlpp::Query &query) {
try {
	//type = 1 Make history table.
	if (1 == type) {
		string table_name;
		MakeTableName(head, time, business_code, -1, -1,
				table_name);
		//The sql phrase of making table.
		string sql = "Create table if not exists " + table_name
				+ this->create_sql;
		query << sql;

		
#if DEBUG_LOAD_EX
	//LOG_SERVICE_DEBUG("MakeTables type=%d, sql=%s\n", type, sql.c_str());
#endif

		if (!query.exec()) {
			LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
			return false;
		}
		//LOG_SERVICE_DEBUG("[NOTE]Make table %s success.\n", table_name.c_str());
	} else {
		//Make tables of the month.
		for (int i = 0; i < TABLE_NUM; i++) {
			string table_name;
			MakeTableName(head, time, business_code, i, serial_number,
					table_name);
			string sql_tail;

			string sql = "Create table if not exists " + table_name
					+ this->create_sql;
			query << sql;

					
#if DEBUG_LOAD_EX
		//	LOG_SERVICE_DEBUG("MakeTables2 type=%d, sql=%s\n", type, sql.c_str());
#endif
			

			if (!query.exec()) {
				LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
				return false;
			}else{
				//LOG_SERVICE_DEBUG("[NOTE]Make table %s success.\n", table_name.c_str());
			}
			//				//��������
			//				string index_name = "subno_ix_" + int2str(time) + "_" + business_code+ int23str(serial_number);
			//				sql = "alter table " + table_name + " add index " +  index_name + "(subno)";
			//				query << sql;
			//
			//				if (!query.exec()) {
			//					LOG_SERVICE_ERROR("[WARN]sql=%s, warning=%s\n", sql.c_str(), query.error());
			//				}
		}
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

return true;
}


bool Load_Process::GetExceptFileName(string path,BASE2_INT32 process_id , string & sFulPathFile )
{
		bool 	bRet = true;

		char	czFileName[80];
		time_t		tRawTime;
		struct	tm * pTimeInfo;
		struct	timeval  stEval;
		string	strFileName;	
	
//		sprintf(czFileName, "group%d_", m_nGroupID);
//		strFileName =	czFileName;
		
		time(&tRawTime);
		pTimeInfo = localtime(&tRawTime);
		strftime(czFileName, 80, "%Y%m%d%H%M%S",pTimeInfo);
		strFileName +=	 czFileName;
	
		gettimeofday(&stEval, 0);	
		sprintf(czFileName, "%06d", stEval.tv_usec );
		strFileName += string(czFileName);

		sFulPathFile = path + string("/")+  string(UNLOAD_BILL_HEAD) + string("_") \
			+int2str(process_id) + string("_")+ strFileName;

	return bRet;

}
	
bool Load_Process::WriteUnhandleBillsPro(const int year_month,
	const int process_id, const BillList &bills, const string filename) {
//дδ�����ļ�
string file_name;
//file_name��ʼ���� bill_<mysql_instance_name>_<table_name>_<yyyymm>_����ID_��ǰʱ��(΢��).dat
//������λ�ȡ�أ������ᡣ
struct timeval t;
gettimeofday(&t, NULL);
MakeUnhandleBillFilename(this->path, year_month, process_id, t.tv_usec,
		file_name);
return WriteUnhandleBill(file_name.c_str(), bills, filename);
}

bool Load_Process::isHandledFile(const string filename, mysqlpp::Query query, const string strPreTbName)
{

try {
	string sql =
			"select count(*)  from indb_load_history where filename=\'"
					+ filename + "\'" + " and tablename =\'" + strPreTbName + "\'";
	query << sql;

	LOG_SERVICE_DEBUG("[NOTE]Query if the file is handled: sql=%s\n", sql.c_str());

	if (mysqlpp::StoreQueryResult res = query.store()) {
		if (atoi(res[0][0]) != 0) {
			//�ļ��Ѵ�������
			//�ύ�����������ع��Ĵ����ƺ�ҪСһ��
			LOG_SERVICE_DEBUG("[NOTE]The file is handled\n");
			return true;
		}
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}
return false;
}

bool Load_Process::HasAvailableTable(const int time, const string tablename,
	mysqlpp::Query &query, int &sn, long long &inc_count) 
{
	try {
		string	sql =	"select Ins_count, Table_num from indb_newtable_record where status=0 and time="
								+ int2str(time) + " and Business_type=\'"
								+ this->bcode + "\' and tablename=\'"
								+ tablename + "\'";
		query << sql;
		LOG_SERVICE_DEBUG("[NOTE]Get the number of records and Serial number in the table  sql=%s\n", sql.c_str());
		if (mysqlpp::StoreQueryResult res = query.store()) {
			if (res.num_rows() > 0) {
				inc_count = res[0][0];
				sn = res[0][1];
				return true;
			} else {
				inc_count = 0;
				sn = 1;
				return false;
			}
		} else {
			LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
		}
	} catch (const mysqlpp::BadQuery& er) {
		// Something went wrong with the SQL query.
		LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
	} catch (const mysqlpp::Exception& er) {
		// Catch-all for any other MySQL++ exceptions
		LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
	}

	return false;
}

int Load_Process::GetTheMaxSN(const int time, const string tablename,
	mysqlpp::Query &query) {
try {
	string sql =
			"select max(Table_num) from indb_newtable_record where time="
					+ int2str(time) + " and Business_type=\'" + this->bcode
					+ "\' and tablename=\'" + tablename + "\'";
	query << sql;

	LOG_SERVICE_DEBUG("[NOTE]Get the max Table_num:sql = %s\n", sql.c_str());
	if (mysqlpp::StoreQueryResult res = query.store()) {
		if (res[0][0] != mysqlpp::null) {
			int sn = res[0][0];
			LOG_SERVICE_DEBUG("[NOTE]sn = %d\n", sn);
			return sn;
		}
	} else {
		LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

return 0;
}

// type = 1 : history ; type =0 :current month table
bool Load_Process::MakeTablesAndRecord(const ConnectInfo &stCl,
	const char *head, const string bcode, const int time, const int sn,
	const int type, mysqlpp::Query &query, const string tablename) 
{

	string  		strSql ;
	int day = getDay();
	string			sErrInfo;
	
try {
	//check whether the table is exist

	strSql = "select * from " + string(TABLE_NAME_DB_NEW)  + string(" where ") \
	+string(stNTbColName[TABLENAME_NTB].sColName) + string("= '") + tablename  \
	+ string("' and ") + string(stNTbColName[TIME_NTB].sColName) + string("=")+ int2str(time)  \
	+ string(" and ") + string(stNTbColName[TABLE_NUM_NTB].sColName) + string("=")+ int23str(sn);


	query <<  strSql;
	mysqlpp::StoreQueryResult res = query.store();

#if DEBUG_LOAD_EX
	//	LOG_SERVICE_DEBUG("MakeTablesAndRecord sql=%d\n",strSql.c_str());
#endif

	if(res)
	{
		if(res.num_rows()> 0)
		{
			LOG_SERVICE_INFO("table has exsit, no need to create");
			return true;
		}
	}
	else
	{
		sErrInfo = "failed to access indb_newtable_record";
		COMM_ERR_REPORT(sErrInfo);
		return false;
	}
	
	//����TABLE_NUM�ű�
	LOG_SERVICE_DEBUG("[NOTE]Start to make tables��bcode=%s time=%d sn=%d\n tabelname=%s\n", this->bcode.c_str(), time, sn, tablename.c_str());
	mysqlpp::Connection pconn(false);
	if (0 != g_CFdbConn.RemoteConnectDb(stCl.connectStr, pconn)) {
		LOG_SERVICE_DEBUG("[NOTE]get remote connection failure!\n");
		return false;
	}
	mysqlpp::Query queryc = pconn.query();

	if (!MakeTables(head, bcode, time, sn, type, queryc)) {
		LOG_SERVICE_DEBUG("[NOTE]Make table failsure!\n");
		return false;
	}

	//�������Ҫ��֤
//	LOG_SERVICE_DEBUG("[NOTE]Insert the record to indb_newtable_record\n");
	//��ȡһ���µ���
	
	string
			sql =
					"insert into indb_newtable_record(tablename, time, status, ins_count, table_num, business_type, day) values(\'"
							+ tablename + "\'," + int2str(time) + ","
							+ int2str(0) + "," + int2str(0) + ","
							+ int23str(sn) + ",\'" + bcode + "\',"
							+ int2str(day) + ")";
	query << sql;
	
	LOG_SERVICE_DEBUG("[NOTE]Put make table record into indb_newtable_record sql = %s\n", sql.c_str());
	if (!query.exec()) {
		LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
		return false;
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

return true;
}

bool Load_Process::UpdateTableStatus(const string bcode,
	const string tablename, const int time, mysqlpp::Query &query) {
try {
	string sql =
			"Update indb_newtable_record set status=1 where status=0 and Business_type=\'"
					+ this->bcode + "\' and tablename=\'" + tablename
					+ "\' and time=" + int2str(time);
	LOG_SERVICE_DEBUG("[NOTE]Update sql=%s\n", sql.c_str());
	query << sql;
	if (!query.exec()) {
		LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
		return false;
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}
return true;
}

bool Load_Process::InsertAndRecordCur(const BillList &bills, const int start,
	const int end, mysqlpp::Query &query, const string tablename,
	const string bcode, const int sn, long long &inc_count) {

#if DEBUG_LOAD_EX
	LOG_SERVICE_DEBUG("InsertAndRecordCur start...sn =%d.....\n",sn);
#endif

	
try {
	if (!InsertBills(bills, start, end, query, tablename, sn, inc_count)) {

		
#if DEBUG_LOAD_EX
		LOG_SERVICE_DEBUG("failed to insert bills,line=%d,file=%s\n",__LINE__,__FILE__);
#endif
		return false;
	}

	//add count  to  ins_count 
	string sql = "Update indb_newtable_record set Ins_count=" \
		+ string(stNTbColName[INS_COUNT_NTB].sColName) + string("+")\
		+ intll2str(inc_count) + " where status=0 and Business_type=\'" + bcode \
			+ "\' and tablename=\'" + tablename + "\'";
	query << sql;

	LOG_SERVICE_DEBUG("[NOTE]Update sql=%s\n", sql.c_str());
	if (!query.exec()) {
		LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
		return false;
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

return true;
}

bool Load_Process::InsertAndRecordHis(const BillList &bills, const int start,
	const int end, mysqlpp::Query &query, const string tablename,
	const string bcode, const int sn, long long &inc_count) {
try {
	if (!InsertHisBills(bills, start, end, query, tablename, sn, inc_count)) {
		return false;
	}

	string sql = "Update indb_newtable_record set Ins_count=" \
		+ string(stNTbColName[INS_COUNT_NTB].sColName) + string("+")\
		+ intll2str(inc_count) + " where status=0 and Business_type=\'" + bcode
			+ "\' and tablename=\'" + tablename + "\'";
	query << sql;

	LOG_SERVICE_DEBUG("[NOTE]Update sql=%s\n", sql.c_str());
	if (!query.exec()) {
		LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
		return false;
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

return true;
}

bool Load_Process::MakeLoadHistory(const string filename,
	const string tablename, const int count, mysqlpp::Query query) {
try {
	struct timeval t;
	gettimeofday(&t, NULL);
	unsigned int tm = t.tv_sec + CONV_1900_1970;
	string
			sql =
					"insert into indb_load_history(filename, tablename, ins_time, ins_count) values(\'"
							+ filename + "\',\'" + tablename + "\',"
							+ intud2str(tm) + "," + int2str(count) + ")";
	LOG_SERVICE_DEBUG("[NOTE]Put load file record into the indb_load_history table:sql=%s\n", sql.c_str());
	query << sql;

	if (!query.exec()) {
		LOG_SERVICE_ERROR("[ERROR]sql=%s\nerror=%s\n", sql.c_str(), query.error());
		return false;
	}
} catch (const mysqlpp::BadQuery& er) {
	// Something went wrong with the SQL query.
	LOG_SERVICE_ERROR("[ERROR]BadQuery:%s\n", er.what());
} catch (const mysqlpp::Exception& er) {
	// Catch-all for any other MySQL++ exceptions
	LOG_SERVICE_ERROR("[ERROR]Exception:%s\n", er.what());
}

return true;
}
