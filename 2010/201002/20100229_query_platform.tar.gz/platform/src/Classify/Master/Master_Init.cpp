#include "Master_Init.h"
#include "Master_Signal.h"
#include "iniconfig.h"
#include "r5log.h"
#include "r5api.h"
#include "log.h"
#include <stdio.h>
#include <iostream>




using namespace std;
using namespace Signal;


char g_szConfFile[MAX_FILE_LEN+1];
CLASSIFY_CONF *g_pConf;



int Master_Init(const char *pConfFile, const int nFileLen, CLASSIFY_CONF *pConf)
{
    if(NULL == pConfFile || NULL == pConf)
    {
        printf("Master_Init input param wrong !\n");
        return -1;    
    }
    int nRet = -1;
    
    
    ///��ȡ����
    nRet = Load_Conf(pConfFile, nFileLen, pConf);
    if(nRet < 0)
    {
        printf("Load_Conf failed!\n");
        //write_kpi(KPI_CONFIG_ERROR, KPI_SCALE_EMERGENCY);
        return -1;
    }
    
    
    ///�ź�ע��
    nRet = Register_Signal();
    if(nRet < 0)
    {
        LOG_ERROR("Register_Signal failed!\n");
        return -1;
    }
    
    ///����������أ�Ϊˢ�ź��ض�������
    strncpy(g_szConfFile, pConfFile, sizeof(g_szConfFile)-1);
    g_pConf = pConf;

    return 0;
}


int Load_Conf(const char *pConfFile, const int nFileLen, CLASSIFY_CONF *pConf)
{
    if(NULL == pConfFile || NULL == pConf)
        return -1;
    IniConfig Iconf;
    
    IniSection *pSec = NULL;
    
    string sData;
    
     
    if(Iconf.open(pConfFile) < 0)
    {
        printf("open ConfFile failed!\n");
        return -1;
    }
    
    
    pSec = Iconf.getSection("COMMON");
    if(NULL == pSec)
    {
        printf("get COMM section failed!\n");
        return -1;
    }
    
    //-------------------------------------------
    // set logger path & logger head information
    //-------------------------------------------
    //set log level
    int log_file_lev, log_term_lev;
    sData = pSec->getValue("LOG_LEVEL_FILE");
    if(0 == sData.length())
    {
    	log_file_lev = 40;
    }
    log_file_lev = atoi(sData.c_str());
    sData = pSec->getValue("LOG_LEVEL_TERM");
    if(0 == sData.length())
    {
    	log_term_lev = 40;
    }
    log_term_lev = atoi(sData.c_str());
    SET_LOG_LEVEL(&g_master_log, log_file_lev, log_term_lev);

    //initLogLevel(&g_service_log, Iconf);    // calling r5api.h
    sData = pSec->getValue("LOG_PATH");
    if (0 == sData.length())
    {
        printf("ERROR: read LOG_PATH cfg param failed!\n" );
        return -1;        
    }
    if (SET_LOG_DIR(&g_master_log, sData.c_str())<0) // calling r5log.h
    {
    	printf("ERROR: set log path failed:%s!\n", sData.c_str());
    	return -1;
    }
   
    sData = pSec->getValue("LOG_HEADER");
    if (0 == sData.length())
    {
    	printf("ERROR: read LOG_HEADER cfg param failed!\n");
    	return -1;
    }
    SET_LOG_NAME_HEAD(&g_master_log, sData.c_str());  // calling r5log.h
    
    sData = pSec->getValue("BUSINESS_NUM");
    if (0 == sData.length())
    {
    	printf("ERROR: read BUSINESS_NUM cfg param failed!\n");
    	return -1;
    }
    int nBusinessNum = atoi(sData.c_str());
    if(nBusinessNum > MAX_BUSINESS_NUM)
    {
    	printf("ERROR: BUSINESS_NUM is too big! max is %d\n", MAX_BUSINESS_NUM);
    	return -1;
    }
    
    ///ѭ����ȡҵ����Ϣ
    char szBusinessName[32] = {0};
    for(int i=0; i<nBusinessNum; i++)
    {
    	snprintf(szBusinessName, sizeof(szBusinessName), "BUSINESS%d", i+1);
        pSec = Iconf.getSection(szBusinessName);
        if(NULL == pSec)
        {
            printf("get %s section failed!\n", szBusinessName);
            return -1;
        }
        
        ///ҵ������
        sData = pSec->getValue("BUSINESS_NAME");
        if(0 == sData.length())
        {
    	    printf("ERROR: read BUSINESS_NAME cfg param failed!\n");
    	    return -1;
        }
        if( strcmp(sData.c_str(), "CS") )
        {
            pConf->stBUSINESS_MSG[i].nBusinessType = 1;
        }
        else if( strcmp(sData.c_str(), "PS") )
        {
        	pConf->stBUSINESS_MSG[i].nBusinessType = 2;
        }
        else if( strcmp(sData.c_str(), "GPRS") )
        {
        	pConf->stBUSINESS_MSG[i].nBusinessType = 3;
        }
        else if( strcmp(sData.c_str(), "SB") )
        {
        	pConf->stBUSINESS_MSG[i].nBusinessType = 4;
        }
        else if( strcmp(sData.c_str(), "WLAN") )
        {
        	pConf->stBUSINESS_MSG[i].nBusinessType = 5;
        }
        else if( strcmp(sData.c_str(), "FF") )
        {
        	pConf->stBUSINESS_MSG[i].nBusinessType = 6;
        }
        else if( strcmp(sData.c_str(), "OF") )
        {
        	pConf->stBUSINESS_MSG[i].nBusinessType = 7;
        }
    
        //sortbill�ӽ��̸���
        sData = pSec->getValue("SORT_BILL_NUM");
        if(0 == sData.length())
        {
    	    printf("ERROR: read SORT_BILL_NUM cfg param failed!\n");
    	    return -1;
        }
        pConf->stBUSINESS_MSG[i].nSortBillNum = atoi(sData.c_str());
       
        ///��Ŀ¼·��
        sData = pSec->getValue("ROOT_PATH");
        if(0 == sData.length())
        {
            printf("MASTER: get ROOT_PATH failed!\n");
            return -1;
        }
        strncpy(pConf->stBUSINESS_MSG[i].szRootPath, sData.c_str(), MAX_PATH_LEN);
    
        ///SortBill������
        sData = pSec->getValue("EXE_NAME");
        if(0 == sData.length())
        {
            printf("MASTER: get EXE_NAME failed!\n");
            return -1;
        }
        strncpy(pConf->stBUSINESS_MSG[i].szProName, sData.c_str(), 64);
    
        ///SortBill�����ļ���
        sData = pSec->getValue("CONF_FILE");
        if(0 == sData.length())
        {
            printf("MASTER: get CONF_FILE failed!\n");
            return -1;
        }
        strncpy(pConf->stBUSINESS_MSG[i].szSortConfFile, sData.c_str(), MAX_FILE_LEN);
        
        pConf->nCount++;
   }
    
    return(0);
}



int Register_Signal()
{
    //ˢ�������ź�,�����ж�,ִ�����źŴ��������,�����ж�ǰ�ĺ���
    if (my_signal(SIGHUP, SigHup, false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGHUP error\n");
        return -1;
    }
    
    //��־��д�ź�,�����ж�,ִ�����źŴ��������,�����ж�ǰ�ĺ���
    if (my_signal(SIGUSR2, SigUsr2, false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGUSR2 error\n");
        return -1;
    }
    
    //��ֹ�ź�,�����ж�,ִ�����źŴ��������,ԭ���������жϷ���EINTR
    if (my_signal(SIGTERM, SigTerm , true) == SIG_ERR)
    {
        LOG_ERROR("signal SIGTERM error\n");
        return -1;
    }
    
    if(my_signal(SIGUSR1, SIG_IGN ,false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGUSR1 error:%s\n", strerror(errno));      
        return -1;
    }
    
    ///�ն��жϷ� ����
    if(my_signal(SIGINT, SigTerm ,true) == SIG_ERR)
    {
        LOG_ERROR("signal SIGINT error:%s\n", strerror(errno));      
        return -1;
    }
    
    /*
    ///SIGALRM �ź�
    if(my_signal(SIGALRM, SigAlarm ,false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGALRM error:%s\n", strerror(errno));      
        return -1;
    }*/
    
    return 0;
        
}


int Master_Destroy(CLASSIFY_CONF *pConf)
{
    int nRet = -1;

    LOG_INFO("Process exit!\n");
    
    ///ˢ����־
	g_master_log.flush();
    
    return 0;
}











