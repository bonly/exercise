#include "Master_Func.h"
#include "Master_Common.h"
#include "Master_Signal.h"
#include "../SortBill/Sort_Service.h"
#include <sys/prctl.h>



using namespace Signal;



///int g_pid[128];
R5_Log g_master_log;;



int Master_Process(CLASSIFY_CONF *pconf, const char *pConfFile)
{
	if(NULL == pconf || pConfFile == NULL)
    {
        LOG_ERROR("Master_Process input param wrong!\n");
        return -1;
    }
    
    int nRet = -1;
    int j=0;
    char szSortBin[1024];
    char szConfFile[1024];
    while(!g_bSigTerm)
    {
    	///�źŴ���
        nRet = HandleSignal();
        if(nRet < 0)
        {
            LOG_ERROR("HandleSignal failed!\n");
            return -1;
        }
        
        g_master_log.flush();
        
        int pid = 0;
        int* status;
        for(; j<pconf->nCount; j++)
        {
            for(int i=0; i<pconf->stBUSINESS_MSG[j].nSortBillNum; i++)
            {
            	pid = fork();
            	if(pid < 0)
            	{
            		perror("fork");
            	}
            	else if(pid == 0)
            	{
            		g_master_log.logOnlyClose();
            		
            		//����·��
            		snprintf(szSortBin, sizeof(szSortBin), "%s/bin/%s", pconf->stBUSINESS_MSG[j].szRootPath, pconf->stBUSINESS_MSG[j].szProName);
            		snprintf(szConfFile, sizeof(szConfFile), "%s/etc/%s", pconf->stBUSINESS_MSG[j].szRootPath, pconf->stBUSINESS_MSG[j].szSortConfFile);
            		
            		nRet = execl(szSortBin, 
            		             pconf->stBUSINESS_MSG[j].szProName,
            		             "-c", szConfFile,
            		             (char*)NULL);
            		if(nRet == -1)
            		{
            			perror("execl");
            			printf("%s -c %s\n", pconf->stBUSINESS_MSG[j].szProName, szConfFile);
                        exit(0);	
            		}
            		exit(0);        		             
            	}
            
            }//for
        }
        waitpid(-1, NULL, 0);
        sleep(30);
    }//while
	
	return(0);
}









