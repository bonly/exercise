#include "Master_Main.h"
#include "Master_Init.h"
#include "Master_Func.h"
#include <unistd.h>
#include <stdio.h>
#include <iostream> 




void Help_Message()
{
    printf("Classify [-h] [-c profile] [-e] [-v]\n");
    printf("            -h: Show Help_Message\n");
    printf("            -c: conf file\n");
    printf("            -e: deamon\n");
    printf("            -v: version\n");
}



void Get_Option(int argc, char *argv[], char *pConfFile, int &nProType, bool &bDaemon)
{

    extern char *optarg;
    int optch;

    static char optstring[] = "hec:vV";
    
    //char szType[10]={0};
    
    while((optch = getopt(argc , argv , optstring)) != -1 ) 
    {
        switch( optch ) 
        {
        case 'h':
            Help_Message();
            exit(-1);
        case 'e':
            bDaemon = true;
            break;
        case 'c':            
            strcpy(pConfFile, optarg);
            break;
       case 'v':
       case 'V':
            printf("classify version %s\n", PROGRAM_VERSION);
            exit(-1);
       case '?':
            Help_Message();
            printf("unknown parameter: %c\n", optopt);
            exit(-1);
       case ':':
            Help_Message();
            printf("need parameter: %c\n", optopt);
            exit(-1);

        default:
            break;
        }
    }
        
    if(access(pConfFile, F_OK) != 0)
    {
        printf("conf file %s not exist,please check!\n", pConfFile);
        exit(-1);
    }
    
}

void daemon() 
{
    // ��̨����
    int pid = 0;
    pid = fork();
    if(pid < 0)
    {
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return;
    }  
    if (pid  >  0) 
    {
        exit(0);
    }
   
    setsid();
    pid=fork();
    if(pid < 0)
    {
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return;           
    }    
    if(pid > 0) 
    {
        exit(0);
    }
}







int main(int argc, char *argv[])
{
	CLASSIFY_CONF conf;
    char szConfFile[MAX_FILE_LEN+1];
    
    memset(&conf, 0, sizeof(CLASSIFY_CONF));
    memset(szConfFile, 0, sizeof(szConfFile));
    
    int nProType = -1;
    int nRet = -1;
    bool bDaemon = false;
    
    ///��ȡ�������
    Get_Option(argc, argv, szConfFile, nProType, bDaemon);
    
    if(bDaemon)
    {
        daemon();
    }
    
    
    nRet = Master_Init(szConfFile, strlen(szConfFile), &conf);
    if(nRet != 0)
    {
        printf("Init failed!\n");
        exit(-1);
    }
    
    
    nRet = Master_Process(&conf, szConfFile);
    if(nRet != 0)
    {
    	LOG_ERROR("Master_Process error! ret=%d\n", nRet);
    }
    
    nRet = Master_Destroy(&conf);
    if(nRet < 0)
    {
        LOG_ERROR("Master_Destroy failed!\n");
    }
    
    g_master_log.flush();
	
	return(0);
}
















