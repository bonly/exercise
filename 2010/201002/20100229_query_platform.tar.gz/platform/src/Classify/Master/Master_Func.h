#ifndef _MASTER_FUNC_H_
#define _MASTER_FUNC_H_


#include "Master_Common.h"




//
int Master_Process(CLASSIFY_CONF *pconf, const char *pConfFile);




#endif



