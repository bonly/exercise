#ifndef _MASTER_COMMON_H_
#define _MASTER_COMMON_H_


#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include "r5log.h"




#ifndef PROGRAM_VERSION         
        #define    PROGRAM_VERSION       "1.0"
#endif


#define MAX_PATH_LEN        1024
#define MAX_FILE_LEN         128
#define MAX_BUSINESS_NUM      16




typedef struct _BUSINESS_MSG
{
	///ҵ������
	int nBusinessType;                          
	//��Ŀ¼·��
	char szRootPath[MAX_PATH_LEN+1];
	//�������·��
	//char szBillPath[MAX_PATH_LEN+1];
	//�����ļ���ǰ׺
	//char szBillPre[MAX_FILE_LEN+1];
	//sortbill�ӽ��̸���
	int nSortBillNum;	
	//sortbill������
	char szProName[64];	
	//sortbill�����ļ���
	char szSortConfFile[MAX_FILE_LEN+1];
	
}BUSINESS_MSG;



typedef struct _CLASSIFY_CONF
{	
	int  nCount;
	BUSINESS_MSG stBUSINESS_MSG[8];

}CLASSIFY_CONF;





extern R5_Log g_master_log;
extern char g_szConfFile[MAX_FILE_LEN+1];
extern CLASSIFY_CONF *g_pConf;


#define LOG_DEBUG(...)\
        R5_DEBUG((&g_master_log), ("[m] " __VA_ARGS__)) 
#define LOG_INFO(...)\
        R5_INFO((&g_master_log), ("[m] " __VA_ARGS__)) 
#define LOG_ERROR(...)\
        R5_ERROR((&g_master_log), ("[m] " __VA_ARGS__)) 
#define LOG_WARN(...)\
        R5_WARN((&g_master_log), ("[m] " __VA_ARGS__)) 



#endif



