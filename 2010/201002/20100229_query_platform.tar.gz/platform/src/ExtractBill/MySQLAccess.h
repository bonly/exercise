/*
*@(#)MySQLAccess 0.1 2011/08/22
*
*Copyright(C)2011 CDPP Project
*
*
*
*@version 0.1 22 Aug 2011
*@author Xiao Jiajie
*
*/
#ifndef __MYSQL_ACCESS_A_H__
#define __MYSQL_ACCESS_A_H__

#include <stdint.h>
#include <unistd.h>
#include <map>
#include <string>
#include <string.h>
//#include <algorithm.h>
#include <vector>
#include <vector.h>
#include <iostream>
#include <mysql++.h>
#include "tinyxml.h"    
#include "tinystr.h" 

using   namespace   std; 
  //Error Code
#define MYSQLDB_SUCCESS             	0    //�ɹ�
#define MYSQLDB_FAILED              	-1   //ʧ��
#define MYSQLDB_CONNECTDB_ERROR     	-2   //����ʧ��
#define MYSQLDB_MORETHANTIMES_ERROR 	-3   //������������
#define MYSQLDB_APPMEN_ERROR        	-4   //�ڴ�����ʧ��
#define MYSQLDB_SELECTFAIL_ERROR    	-5   //��ѯʧ��
#define MYSQLDB_INSERTMAP_ERROR     	-6   //ӳ�����ʧ��
#define MYSQLDB_ANALYCONNSTRING_ERROR -7   //���������ַ�������
#define MYSQLDB_ERROR              		-8   //����
#define MYSQLDB_ROW_ZERO              -9   //����Ϊ0
#define MYSQLDB_APPOBJ_ERROR        	-10   //��������ʧ��

const int DBAMaxPageItem= 10000;
const int DBAMaxNumber= 5000;

typedef struct tagNewTAbleConf
{
	string strTablename;					//NewTable����
	string strTBNname;        //�����ֶ��ֶ���
	string strTIMEname;					//ʱ���ֶ��ֶ���
	string strSTATUSname;					//״̬�ֶ��ֶ���
	string strICNTname;          //�����¼���ֶ��ֶ���
	string strTNUMname;  //������ֶ��ֶ���
	string strBILLKEYname; //ѹ���������ؼ���
} recNewTAbleConf;

typedef struct tagCBEitem
{
	string strCBEname;					//CBE����
	int nWidth;               //����
} recCBEitem;

class CNewTableItem
{
private:
		
protected:
public:
		char m_sztablename[32];	
		int m_ntable_num;	
		long m_nIndex;
	  CNewTableItem():m_ntable_num(0),m_nIndex(0){ memset( m_sztablename, 0, sizeof(char)*32 );};
    ~CNewTableItem(){};     
    bool operator<( const CNewTableItem& oCompany ) const
  	{
        return this->m_ntable_num < oCompany.m_ntable_num;
    }
    bool operator==( const CNewTableItem& oCompany ) const
    {
        return this->m_ntable_num == oCompany.m_ntable_num;
    }
};

class CMySQLAccessConn
{
public:
    CMySQLAccessConn(); 
    ~CMySQLAccessConn();     
	
	int DBConnect(const char* sLocaldb, const char* sHost = 0, const char* sUser = 0,
			const char* sPdw = 0, unsigned int iPort = 3306);
  void DBDisconnect();
  int DBQueryNewTable(long nTime);
  int DBQueryAllMyisamTable(vector<CNewTableItem> &NewTableVect);
  int DBQueryTbCount(const char* sSQL,long &nCount);
  int DBQueryOneMyisamTable(const char* sTableName,int nflag);
  int DBQueryMyisamTbOnPage(const char* sTableName, int nbegin, int nEnd,int nflag);
  int DBOutPutResult(mysqlpp::StoreQueryResult & bRes,int nIndex,int nflag);
  int GetTableSetFromXML(const char * sXMLpath);
	int DBQueryOneMyisamTableNotBatch(const char* sTableName,int nflag);
private:
	const char * GetItemStrbuf(mysqlpp::StoreQueryResult & bRes,int nIndex,const char * sItemName,std::string& sTmp,int & nLen);
	int OutItem(char* szbuf,mysqlpp::StoreQueryResult & bRes,int nIndex,const char * sItemName,int nWidth,int & nLen);
	
private:    
	int m_nOutIndex;
	std::string m_strLocalDB;
	std::string m_strHost;
	std::string m_strUser;
	std::string m_strPdw;
	int m_iPort;	
	int m_iReConnTimes;
	mysqlpp::Connection* m_pDBconn;
	vector<CNewTableItem> m_NewTableVect; 
	recNewTAbleConf m_NewTAbleConf;
	vector<recCBEitem> m_CBEcollec;
};

#endif
