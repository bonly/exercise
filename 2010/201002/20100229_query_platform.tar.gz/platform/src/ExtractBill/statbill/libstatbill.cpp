/*

* libstatbill.cpp

* Implementation of function cppadd declared in libstatbill.h

* in c++ language

*/

#include "libstatbill.h"

#define CEXB_SUCCESS             0    //�ɹ�
#define CEXB_FAILED              -1   //ʧ��
#define CEXB_SIGTERM_ERROR       -2   //����SIGTERM�ж�
#define CEXB_SIGALARM_ERROR      -3   //����SIGALARM�ж�
#define CEXB_SIGPIPE_ERROR       -4   //����SIGPIPE�ж�
#define CEXB_DB_ERROR       -5   //

R5_Log * g_pR5Log=NULL;
#define STAT_Debug(...)\
        R5_DEBUG(g_pR5Log, ("[EB] " __VA_ARGS__))

int initialize(const char* conf_file, R5_Log *pLog)
{
	int nRet=CEXB_SUCCESS;	
	cout<<"hello!"<<endl;
	g_pR5Log=pLog;		
	return nRet;
}

int destroy()
{
	int nRet=CEXB_SUCCESS;	
	return nRet;
}


int bill_statistics (const void * inmsg, const int inlen, const int flag)
{
	int nRet=CEXB_FAILED;	
	if(g_pR5Log == NULL)
		return nRet;
	//���
	STAT_Debug("libOut:flag-%d|L%d|%s\n",flag,inlen,(char*)inmsg);	
	nRet=CEXB_SUCCESS;
	return nRet;
}
