#include "MySQLAccess.h"
#include "ExtractBillMain.h"

using namespace std;
using namespace mysqlpp;

extern int (*gfun_bill_statistics)(const void * inmsg, const int inlen, const int flag);
 
//----------------------------------------------------------------------

CMySQLAccessConn::CMySQLAccessConn()
{
	m_iReConnTimes=0;
	m_pDBconn=NULL;
	m_nOutIndex=0;	
}

//----------------------------------------------------------------------

CMySQLAccessConn::~CMySQLAccessConn()
{
  DBDisconnect();
  
}

int CMySQLAccessConn::DBConnect(const char* sLocaldb, const char* sHost, const char* sUser,
			const char* sPdw , unsigned int iPort)
{
	int nRet=MYSQLDB_CONNECTDB_ERROR;
  //cout<<sLocaldb<<endl;
  m_strLocalDB=sLocaldb;
	m_strHost=sHost;
	m_strUser=sUser;
	m_strPdw=sPdw;
	m_iPort=iPort;	
	bool bConnSuc=false;	
	int iSize = 0;
	int iReConnT=m_iReConnTimes;    
	if(!m_pDBconn)
		{
			m_pDBconn=new mysqlpp::Connection;
				if(NULL == m_pDBconn)
					return MYSQLDB_APPOBJ_ERROR;
		}
      	
  if (m_pDBconn->connect(m_strLocalDB.c_str(), m_strHost.c_str(), m_strUser.c_str(), m_strPdw.c_str(),m_iPort))
  {    	
    	nRet=MYSQLDB_SUCCESS;
	}
		 
  return nRet;
}

void CMySQLAccessConn::DBDisconnect()
{
	if(m_pDBconn)
		{
			delete m_pDBconn;
			m_pDBconn=NULL;
		}	
}

int CMySQLAccessConn::DBQueryNewTable(long nTime)
{
	int nRet=MYSQLDB_ERROR;
	if(!m_pDBconn)
		{
			return nRet;
		}
	string str="select ";	
	str.append(m_NewTAbleConf.strTBNname);	
	str.append(",");	
	str.append(m_NewTAbleConf.strTNUMname);	
	str.append(" from ");	
	str.append(m_NewTAbleConf.strTablename);
	str.append(" where ");
	str.append(m_NewTAbleConf.strTBNname);
	str.append(" like '");
	str.append(m_NewTAbleConf.strBILLKEYname);
	str.append("%' and ");
	str.append(m_NewTAbleConf.strTIMEname);
	str.append("=");		
	//std::string str="select tablename,table_num from paas.indb_newtable_record where tablename like 'BILL%' and time=";
  ostringstream stm;
  string strResult;
  stm << str << nTime ;
  strResult = stm.str();
  strResult.append(" and ");
  strResult.append(m_NewTAbleConf.strSTATUSname);
  strResult.append("=2 and ");
  strResult.append(m_NewTAbleConf.strICNTname);
  strResult.append(">10000");  
  //strResult.append(" and status=2 and ins_count>10000");		
  //cout << strResult << endl;	
	//return nRet;
		
	mysqlpp::Query query = m_pDBconn->query((char*)strResult.c_str());    	
      mysqlpp::StoreQueryResult res;
	    try
			{
				res = query.store();
				if(res)
				{						
						long nItemIndex=0;
						// �ӽ������ȡÿ�м�¼
						for (size_t i = 0; i < res.num_rows(); ++i) 
						{
							CNewTableItem aItem;			
							strcpy( aItem.m_sztablename, res[i]["tablename"] );							
						  aItem.m_ntable_num=res[i]["table_num"];
						  nItemIndex++;
						  aItem.m_nIndex=nItemIndex;
						  m_NewTableVect.push_back(aItem);							
						}						
						nRet=DBQueryAllMyisamTable(m_NewTableVect);
						//nRet=DBQueryOneMyisamTable("BILL_201107_01_0000_015",0);
						//nRet=DBQueryOneMyisamTable("BILL_201109_01_0000_004",1);
						//nRet=DBQueryOneMyisamTable("BILL_201109_01_0000_001",1);
						//nRet=DBQueryOneMyisamTableNotBatch("BILL_201109_01_0000_001",1);						
						//nRet=MYSQLDB_SUCCESS; 
				}
			}
		 	catch (const BadQuery& er)
	    {
	    	cout << "Query error: " << er.what() << endl;
	    	return MYSQLDB_SELECTFAIL_ERROR;
	    }
	    catch (const BadConversion& er)
	    {
	  		cout << "Conversion error: " << er.what() << endl << "\tretrieved data size: " << er.retrieved << ", actual size: " << er.actual_size << endl;
	  		return MYSQLDB_SELECTFAIL_ERROR;
	    }
	    catch (const Exception& er)
			{
			  	cout << "Error: " << er.what() << endl;
			  	return MYSQLDB_SELECTFAIL_ERROR;
			}
	    catch (...)
	    {
	   		cout << "unknow err!" << endl;
		   	return MYSQLDB_SELECTFAIL_ERROR;
	    }		
	  return nRet;
}


int CMySQLAccessConn::DBQueryAllMyisamTable(vector<CNewTableItem> &NewTableVect)
{
	int nRet=MYSQLDB_ERROR;
		if(NewTableVect.size() <= 0)
			return nRet;
	vector<CNewTableItem>::iterator iterOut;
	string strTableName;
	char sNo[8] = {0};
	char sTNum[8] = {0}; 	
	for(int i=0;i < DBAMaxNumber;i++)
	{		
		memset(sNo,0, sizeof(char)*8);		
		sprintf(sNo, "%04d" ,i);
						for( iterOut = m_NewTableVect.begin(); iterOut != m_NewTableVect.end(); iterOut++ ) 
						{	    								
									//cout<<(*iterOut).m_sztablename<<endl;
									//�����굥���������磺BILL_201107_01_0000_03
									strTableName=(*iterOut).m_sztablename;
									strTableName.append("_");
									strTableName.append(sNo);
									strTableName.append("_");
									memset(sTNum,0, sizeof(char)*8);
									sprintf(sTNum, "%02d" ,(*iterOut).m_ntable_num);
									strTableName.append(sTNum);
									//cout<<strTableName<<endl;
									if((iterOut+1) == m_NewTableVect.end())
										nRet=DBQueryOneMyisamTable(strTableName.c_str(),1);
									else
										nRet=DBQueryOneMyisamTable(strTableName.c_str(),0);
						}
	}
	//nRet=MYSQLDB_SUCCESS; 			
	return nRet;
}

int CMySQLAccessConn::DBQueryTbCount(const char* sSQL,long &nCount)
{
	int nRet=MYSQLDB_ERROR;
	if(!m_pDBconn)
		{
			return nRet;
		}
		nCount=0;
	mysqlpp::Query query = m_pDBconn->query(sSQL);   			
      mysqlpp::StoreQueryResult res;
	    try
			{
				res = query.store();
				if(res)
				{
					if(res.num_rows() != 1)
						{
							return nRet;
						}
						nCount=res[0]["count(*)"];					
						nRet=MYSQLDB_SUCCESS; 
				}
			}
		 	catch (const BadQuery& er)
	    {
	    	cout << "Query error: " << er.what() << endl;
	    	return MYSQLDB_SELECTFAIL_ERROR;
	    }
	    catch (const BadConversion& er)
	    {
	  		cout << "Conversion error: " << er.what() << endl << "\tretrieved data size: " << er.retrieved << ", actual size: " << er.actual_size << endl;
	  		return MYSQLDB_SELECTFAIL_ERROR;
	    }
	    catch (const Exception& er)
			{
			  	cout << "Error: " << er.what() << endl;
			  	return MYSQLDB_SELECTFAIL_ERROR;
			}
	    catch (...)
	    {
	   		cout << "unknow err!" << endl;
		   	return MYSQLDB_SELECTFAIL_ERROR;
	    }		
	  return nRet;
}

int CMySQLAccessConn::DBQueryOneMyisamTable(const char* sTableName,int nflag)
{	
	int nRet=MYSQLDB_ERROR;
	if(!sTableName)
		{
			return nRet;
		}
	cout<<sTableName<<endl;
	//����굥��������
	string sSQL="select count(*) from ";
	sSQL.append(sTableName);
	long nTotal=0;
	nRet=DBQueryTbCount(sSQL.c_str(),nTotal);
	cout<<nTotal<<endl;
	m_nOutIndex=0;
	//������ѯ
	int nBegin=0; //��ʼ��
	int	nEnd=0; //������
	//int nTotal=nRuleCount; //������
	int nPageCount=0;  //��������
	int nPageSize=DBAMaxPageItem; //����С
	if((nTotal%nPageSize) == 0) 
	{ 
		nPageCount = nTotal/nPageSize; 
	} 
	else   
	{ 
		nPageCount = nTotal/nPageSize+1; 
	} 	
	
	//  
	for(int i=0;i < nPageCount;i++) 
	{ 	
		nBegin=i*nPageSize;
		nEnd=nBegin+nPageSize;		
		//������ѯ���ݿ�		    		        
		if((nflag == 1) && ((i+1)== nPageCount))
    	nRet=DBQueryMyisamTbOnPage(sTableName,nBegin,nEnd,1);
    else
    		nRet=DBQueryMyisamTbOnPage(sTableName,nBegin,nEnd,0);
         
    if(MYSQLDB_SUCCESS != nRet) 
    {     
    	CEXB_Error("DBQueryOneMyisamTable error in \"%s\" line %d\n",  __FILE__, __LINE__);
       return nRet;  
    }   
  }
	
	return nRet;
}
	
int CMySQLAccessConn::DBQueryMyisamTbOnPage(const char* sTableName, int nbegin, int nEnd,int nflag) 
{
	int nRet=MYSQLDB_ERROR;
	if(!sTableName)
		{
			return nRet;
		}
	if(!m_pDBconn)
		{
			return nRet;
		}
	//����������ѯ���
	std::string str="select * from ";
	str.append(sTableName);	
	str.append(" limit ");	
  std::ostringstream stm;
  std::string strResult;
  long lBegin=nbegin;
  long lEnd=nEnd;
  stm << str << lBegin << "," <<lEnd-lBegin;
  strResult = stm.str();  
 // std::cout << strResult << std::endl; 
  //��ʼ��ѯ  
	mysqlpp::Query query = m_pDBconn->query(strResult.c_str());    			
      mysqlpp::StoreQueryResult res;
	    try
			{
				res = query.store();
				if(res)
				{						
						long nItemIndex=0;						
						// �ӽ������ȡÿ�м�¼
						for (size_t i = 0; i < res.num_rows(); ++i) 
						{														 	
						  nItemIndex++;		
						  if((nflag == 1) && ((i+1) == res.num_rows()))				 
						  	nRet=DBOutPutResult(res,i,1);
						  else
						  	nRet=DBOutPutResult(res,i,0);
						  if(nRet != MYSQLDB_SUCCESS)		
						  {
						  	CEXB_Error("DBQueryMyisamTbOnPage error in \"%s\" line %d\n",  __FILE__, __LINE__);
						  	return nRet;			
						  } 				
						}						
						//nRet=MYSQLDB_SUCCESS; 
				}
			}
		 	catch (const BadQuery& er)
	    {
	    	cout << "Query error: " << er.what() << endl;
	    	return MYSQLDB_SELECTFAIL_ERROR;
	    }
	    catch (const BadConversion& er)
	    {
	  		cout << "Conversion error: " << er.what() << endl << "\tretrieved data size: " << er.retrieved << ", actual size: " << er.actual_size << endl;
	  		return MYSQLDB_SELECTFAIL_ERROR;
	    }
	    catch (const Exception& er)
			{
			  	cout << "Error: " << er.what() << endl;
			  	return MYSQLDB_SELECTFAIL_ERROR;
			}
	    catch (...)
	    {
	   		cout << "unknow err!" << endl;
		   	return MYSQLDB_SELECTFAIL_ERROR;
	    }		  
	return nRet;
}

const char * CMySQLAccessConn::GetItemStrbuf(mysqlpp::StoreQueryResult & bRes,int nIndex,const char * sItemName,string& sTmp,int & nLen)
{
		std::ostringstream stm;	
		stm<<bRes[nIndex][sItemName];
		sTmp=stm.str();
		nLen=sTmp.length();
		return sTmp.c_str();
}

int CMySQLAccessConn::OutItem(char* szbuf,mysqlpp::StoreQueryResult & bRes,int nIndex,const char * sItemName,int nWidth,int & nLen)
{
	int nRet=MYSQLDB_ERROR;
	char * pszTmp=NULL;
	string sTemp;
	string sTemp2;	
	if(nWidth == 0)
	{
			sTemp2="%s";
	}
	else
	{
		std::ostringstream stm;  
  	stm << "%" << nWidth << "s" ;
  	sTemp2 = stm.str();    
	}
	pszTmp=(char*)GetItemStrbuf(bRes,nIndex,sItemName,sTemp,nLen);
	if(pszTmp == NULL || nLen == 0)
	{		
		memset(szbuf,' ',nWidth);		
	}
	else
	{
		sprintf(szbuf,sTemp2.c_str(),pszTmp);
	}
	nRet=MYSQLDB_SUCCESS;
	return nRet;
}

int CMySQLAccessConn::DBOutPutResult(mysqlpp::StoreQueryResult & bRes,int nIndex,int nflag)
{
	int nRet=MYSQLDB_ERROR;
	char szOutPut[1024] = {0}; 	
	//string sTemp;
	memset(szOutPut,0,sizeof(char)*1024);	
	int nPos=0;
	int nLen=0;	
	
	vector<recCBEitem>::iterator iterCBE;
	for( iterCBE = m_CBEcollec.begin(); iterCBE != m_CBEcollec.end(); iterCBE++ ) 
	{	    								
			//cout<<(*iterCBE).strCBEname<<endl;
			//			
			OutItem(szOutPut+nPos,bRes,nIndex,(*iterCBE).strCBEname.c_str(),(*iterCBE).nWidth,nLen);
			if((*iterCBE).nWidth == 0)
			{
					nPos+=nLen;
			}
			else
			{
					nPos+=(*iterCBE).nWidth;	
			}		
	}	

	//���	
	//CEXB_Debug("Out:I%d|L%d|%s\n",m_nOutIndex,nPos,szOutPut);
	m_nOutIndex++;	
	if(gfun_bill_statistics)
		nRet=gfun_bill_statistics(szOutPut,nPos,nflag);		
	//nRet=MYSQLDB_SUCCESS;
	return nRet;
}

int CMySQLAccessConn::GetTableSetFromXML(const char * sXMLpath)
{
	int nRet=MYSQLDB_ERROR;
	//����һ��XML���ĵ�����
	TiXmlDocument *myDocument = new TiXmlDocument(sXMLpath);
	if(NULL == myDocument)
		return nRet;
	if(false == myDocument->LoadFile())
	{
		delete myDocument;
		return nRet;
	}
	//��ø�Ԫ�أ���configxml��
	TiXmlElement *RootElement = myDocument->RootElement();   
  //�����Ԫ�����ƣ������configxml��   
  
  string strValue;
  strValue=RootElement->Value();
  //cout<<strValue<<endl;
  if(strValue != "configxml")
  {
  	delete myDocument;
  	return nRet;
  }	
  
	//���newtableItem�ڵ㡣    
	TiXmlElement *newtableItem = RootElement->FirstChildElement();  
	strValue=newtableItem->Value();
	//cout<<strValue<<endl;
  if(strValue != "newtableItem")
  {
  	delete myDocument;
  	return nRet;
  }	
  //���cbeoutItem�ڵ㡣    
	TiXmlElement *cbeoutItem = newtableItem->NextSiblingElement();  
	strValue=cbeoutItem->Value();
	//cout<<strValue<<endl;
  if(strValue != "cbeoutItem")
  {
  	delete myDocument;
  	return nRet;
  }	
    
  TiXmlElement *newItem = newtableItem->FirstChildElement();

  while (newItem != NULL)
  {
    strValue=newItem->Value();
    //cout<<strValue<<endl;
    //cout<<newItem->FirstChild()->Value()<<endl;
    if(strValue == "tablename")
    	m_NewTAbleConf.strTablename=newItem->FirstChild()->Value();
    if(strValue == "TBN")
    	m_NewTAbleConf.strTBNname=newItem->FirstChild()->Value();
    if(strValue == "TIME")
    	m_NewTAbleConf.strTIMEname=newItem->FirstChild()->Value();
    if(strValue == "STATUS")
    	m_NewTAbleConf.strSTATUSname=newItem->FirstChild()->Value();
    if(strValue == "ICNT")
    	m_NewTAbleConf.strICNTname=newItem->FirstChild()->Value();
    if(strValue == "TNUM")
    	m_NewTAbleConf.strTNUMname=newItem->FirstChild()->Value();
    if(strValue == "BILLKEY")
    	m_NewTAbleConf.strBILLKEYname=newItem->FirstChild()->Value();
    newItem = newItem->NextSiblingElement();
  }

	TiXmlElement *cbeitem = cbeoutItem->FirstChildElement();
  while (cbeitem != NULL)
  {
    strValue=cbeitem->Value();
    //cout<<strValue<<endl;
    if(strValue != "cbeitem")
	  {
	  	delete myDocument;
	  	return nRet;
	  }	
    
    TiXmlAttribute *nameAttribute = cbeitem->FirstAttribute();
    //cout<<nameAttribute->Value()<<endl;
    recCBEitem stCBE;
    stCBE.strCBEname=nameAttribute->Value();
    nameAttribute= cbeitem->LastAttribute();
    //cout<<nameAttribute->Value()<<endl;
		stCBE.nWidth=atoi(nameAttribute->Value());    
		m_CBEcollec.push_back(stCBE);		
		
    cbeitem = cbeitem->NextSiblingElement();
  }  
	
	delete myDocument;
	nRet=MYSQLDB_SUCCESS;
	
	//����
	/////////////////////////////////////////////
//	vector<recCBEitem>::iterator iterCBE;
//	int nPos=1;
//	for( iterCBE = m_CBEcollec.begin(); iterCBE != m_CBEcollec.end(); iterCBE++ ) 
//	{	    								
//			cout<<"CBE:"<<(*iterCBE).strCBEname<<";nPos:"<<nPos<<";nWidth:"<<(*iterCBE).nWidth<<endl;
//			//						
//			if((*iterCBE).nWidth == 0)
//			{
//					nPos+=1;
//			}
//			else
//			{
//					nPos+=(*iterCBE).nWidth;	
//			}		
//	}	
	
	/////////////////////////////////////////////
  return nRet;    
}

int CMySQLAccessConn::DBQueryOneMyisamTableNotBatch(const char* sTableName,int nflag)
{
	int nRet=MYSQLDB_ERROR;
	if(!sTableName)
		{
			return nRet;
		}
	if(!m_pDBconn)
		{
			return nRet;
		}
	//����������ѯ���
	std::string strResult="select * from ";
	strResult.append(sTableName);  
  std::cout << strResult << std::endl; 
  //��ʼ��ѯ  
	mysqlpp::Query query = m_pDBconn->query(strResult.c_str());    			
      mysqlpp::StoreQueryResult res;
	    try
			{
				res = query.store();
				if(res)
				{						
						long nItemIndex=0;						
						// �ӽ������ȡÿ�м�¼
						for (size_t i = 0; i < res.num_rows(); ++i) 
						{														 	
						  nItemIndex++;		
						  if((nflag == 1) && ((i+1) == res.num_rows()))				 
						  	nRet=DBOutPutResult(res,i,1);
						  else
						  	nRet=DBOutPutResult(res,i,0);
						  if(nRet != MYSQLDB_SUCCESS)		
						  {
						  	CEXB_Error("DBQueryMyisamTbOnPage error in \"%s\" line %d\n",  __FILE__, __LINE__);
						  	return nRet;			
						  } 				
						}						
						//nRet=MYSQLDB_SUCCESS; 
				}
			}
		 	catch (const BadQuery& er)
	    {
	    	cout << "Query error: " << er.what() << endl;
	    	return MYSQLDB_SELECTFAIL_ERROR;
	    }
	    catch (const BadConversion& er)
	    {
	  		cout << "Conversion error: " << er.what() << endl << "\tretrieved data size: " << er.retrieved << ", actual size: " << er.actual_size << endl;
	  		return MYSQLDB_SELECTFAIL_ERROR;
	    }
	    catch (const Exception& er)
			{
			  	cout << "Error: " << er.what() << endl;
			  	return MYSQLDB_SELECTFAIL_ERROR;
			}
	    catch (...)
	    {
	   		cout << "unknow err!" << endl;
		   	return MYSQLDB_SELECTFAIL_ERROR;
	    }		  
	return nRet;
}