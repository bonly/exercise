#include "ExtractHandle.h"
#include <sstream>
#include <dlfcn.h>

void *g_sohandle=NULL;  
int (*gfun_initialize)(const char* conf_file, R5_Log *pLog);
int (*gfun_destroy)();
int (*gfun_bill_statistics)(const void * inmsg, const int inlen, const int flag);

//#include "libstatbill.h"
//----------------------------------------------------------------------


CExtractHandle::CExtractHandle():m_ExtractCount(0)
{
	gfun_initialize=NULL;
	gfun_destroy=NULL;
	gfun_bill_statistics=NULL;	
	if(CEXB_SUCCESS == Init())
		{
			m_bInit=true;
		}
		else
		{
			CEXB_Error("��ʼ��ʧ�ܣ� \n");
			m_bInit=false;
		}
}

//----------------------------------------------------------------------

CExtractHandle::~CExtractHandle()
{				  
	//m_dbConn.DBDisconnect();		 
	if(gfun_destroy)
		gfun_destroy();	
	if(g_sohandle != NULL)
	  dlclose(g_sohandle);
	gfun_initialize=NULL;
	gfun_destroy=NULL;
	gfun_bill_statistics=NULL;
	g_sohandle=NULL;
}

int CExtractHandle::Loadsolib()
{
	int nRet=CEXB_SUCCESS;	
	const char *errmsg;	
	/* open the library */
  //g_sohandle = dlopen("libstatbill.so", RTLD_LAZY);
  g_sohandle = dlopen("libstatbill.so", RTLD_NOW);
  if(g_sohandle == NULL)
  {
     //fprintf(stderr, "Failed to load libsthc.so: %s\n", dlerror());
     cout<<"Failed to load libstatbill.so:"<<dlerror()<<endl;
     return CEXB_FAILED;
  }
  *(void **)(&gfun_initialize) = dlsym(g_sohandle, "initialize");
  if((errmsg = dlerror()) != NULL)
  {
      //printf("%s\n", errmsg);
      cout<<"L1"<<errmsg<<endl;
      return CEXB_FAILED;
  }  
  *(void **)(&gfun_destroy) = dlsym(g_sohandle, "destroy");
  if((errmsg = dlerror()) != NULL)
  {
      //printf("%s\n", errmsg);
      cout<<"L2"<<errmsg<<endl;
      return CEXB_FAILED;
  }  
  //void* ret=dlsym(g_sohandle, "bill_statistics");  
  //gfun_bill_statistics = (int (*)(const void * , const int , const int))ret;
  *(void **)(&gfun_bill_statistics) = dlsym(g_sohandle, "bill_statistics");
  if((errmsg = dlerror()) != NULL)
  {
      //printf("%s\n", errmsg);
      cout<<"L3"<<errmsg<<endl;
      return CEXB_FAILED;
  }  
  return nRet;
}


int CExtractHandle::Init()
{
		int nRet=CEXB_SUCCESS;			
		nRet=getSystemTime();	 
		if(nRet != CEXB_SUCCESS)
	  	return nRet;
	  nRet=Loadsolib();
	  if(nRet != CEXB_SUCCESS)
	  	return nRet;
	  if(gfun_initialize)	  
	  	nRet=gfun_initialize(g_stuCExpConf.sConfig.c_str(),&g_r5_log);
	  if(nRet != CEXB_SUCCESS)
	  	return nRet;	  	  	
	  nRet=m_dbConn.GetTableSetFromXML(g_stuCExpConf.sDB_DICTpath.c_str());
	  if(nRet != CEXB_SUCCESS)
	  	return nRet;	 
	  nRet=m_dbConn.DBConnect(g_stuCExpConf.sDB_DBName.c_str(),g_stuCExpConf.sDB_Host.c_str(),g_stuCExpConf.sDB_UserName.c_str(),g_stuCExpConf.sDB_Password.c_str(),g_stuCExpConf.nDB_Port);	 
	  return nRet;
}

int CExtractHandle::Run()
{	
	int nRet=CEXB_SUCCESS;
	if(!m_bInit)
		return CEXB_FAILED;
	long nRuleCount=0;
	long nTotalUse=0;
	gettimeofday(&m_stBegin, NULL);
	
//	char* szOutPut="12345"; 	
//	if(gfun_bill_statistics)
//		nRet=gfun_bill_statistics(szOutPut,4,0);
	
	nRet=ExtractBill(g_stuCExpConf.nExtractTime);
	gettimeofday(&m_stEnd, NULL);		
	long nTimeuse = 1000000 * ( m_stEnd.tv_sec - m_stBegin.tv_sec ) + m_stEnd.tv_usec - m_stBegin.tv_usec; 
	double dUseTs=nTimeuse/1000000;
	cout<<"ExtractBill ʱ�䣺"<<nTimeuse<<endl;
	nTotalUse+=nTimeuse;

	return nRet;
}

int CExtractHandle::ExtractBill(long nTime)
{
	int nRet=CEXB_FAILED;
	if(!m_bInit)
		return nRet;				
	
 	nRet=m_dbConn.DBQueryNewTable(nTime);	
 	
 	if(nRet == CEXB_SUCCESS)
 	{
 		//��ʼ�ϴ��ļ�
 		string strcmd;
 		int nRetcmd=0;
 		strcmd="scp -r ";
 		strcmd.append(g_stuCExpConf.sStat_Dir);
 		strcmd.append(" ");
 		strcmd.append(g_stuCExpConf.sRemote_UserName);
 		strcmd.append("@");
 		strcmd.append(g_stuCExpConf.sRemote_IP);
 		strcmd.append(":");
 		strcmd.append(g_stuCExpConf.sRemote_Dir);
 		cout<<"Up cmd:"<<strcmd<<endl; 	 		
 		nRetcmd= system(strcmd.c_str());
 		cout<<"Up ret:"<<nRetcmd<<endl;
 		if((nRetcmd <= 0) || (nRetcmd == 127))
 		{
 			nRet=CEXB_DB_ERROR;
 		} 		
 	}		
	return nRet;	
}

//��ȡ��ǰʱ��
int CExtractHandle::getSystemTime() 
{ 
	int nRet=CEXB_SUCCESS;		
	if(g_stuCExpConf.nExtractTime > 0)
		return nRet;
	time_t timer; 
	struct tm* t_tm; 	
	time(&timer); 	
	t_tm = localtime(&timer); 	
	g_stuCExpConf.nExtractTime=(t_tm->tm_year+1900)*100;
	//g_stuCExpConf.nExtractTime+=t_tm->tm_mon+1;
	g_stuCExpConf.nExtractTime+=t_tm->tm_mon; //Ĭ��ͳ���ϸ��µ��굥
	//printf("Time is %6d\n", g_stuCExpConf.nExtractTime);
	return nRet; 
}
