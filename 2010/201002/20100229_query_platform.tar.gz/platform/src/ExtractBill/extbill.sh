ExtractBill -c /home/hadoop/platform/src/ExtractBill/extractbill.conf
