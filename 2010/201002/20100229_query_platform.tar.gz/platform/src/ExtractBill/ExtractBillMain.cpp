#include "ExtractBillMain.h"
#include "ExtractHandle.h"
recCExtractConf g_stuCExpConf;

R5_Log g_r5_log;

int main(int argc, char** argv)
{
    int nRet=CEXB_SUCCESS;
    g_stuCExpConf.nExtractTime=0;
    g_stuCExpConf.nDB_Port=0;
    nRet=fun_ParamParser(argc,argv);
    if(CEXB_SUCCESS != nRet)
    {
    	exit(-1);
    }
    nRet = fun_loadConfig(g_stuCExpConf.sConfig.c_str());
    if(CEXB_SUCCESS != nRet)
    {    	
    	//printf("loadConfig failed. nRet:%d\n", nRet);
    	cout<<"loadConfig failed. nRet:"<<nRet<<endl;    	
    	return nRet;
    }         

    CExtractHandle exHandle;
  	nRet=exHandle.Run();
  	if(CEXB_SUCCESS != nRet)
		{
			CEXB_Debug("���ʧ�ܣ�nRet:%d\n",nRet);
			return nRet;
		}
		CEXB_Debug("����ɹ���\n");
		return nRet;
}

int fun_printusage()
{
    printf("Usage : ExtractBill [-h] [-c config]\n");
    printf("        -h Show help\n");   
    printf("        -c select config file\n");   
    printf("        -t Extract TIME\n");
    printf("        -i DB HOST\n");
    printf("        -p DB PORT\n");
    printf("        -d DB NAME\n");
    printf("        -u DB USERNAME\n");
    printf("        -s DB PASSWORD\n");
    printf("        -r Remote IP\n");
    printf("        -n Remote Name\n");
    return 0;
}

/*****************************
* ��ȡ������Ϣ��g_stuCEXPpConf
******************************/
int fun_loadConfig(const char *szFile)
{
		IniConfig objfConf;
		const char  *szItem = NULL;
    if(objfConf.open(szFile) <0)
    {
        printf("ERROR: Open %s faild:%s,in \"%s\" line %d\n", szFile, strerror(errno), __FILE__, __LINE__ );
        return -1;
    }

    IniSection *sct_common = objfConf.getSection("COMMON");
    if(sct_common == NULL)
    {
        printf("ERROR: open COMMON section failed in \"%s\" line %d\n", __FILE__, __LINE__ );
        return -1;
    }
//    cout<<szFile<<endl;    
//    vector<IniItem*>::iterator it;
//    	it = sct_common->begin();
//    for ( ; it != sct_common->end(); ++it )
//    {   
//    	cout<<"Key:"<<(*it)->getKey()<<endl;
//    	cout<<"Value:"<<(*it)->getValue()<<endl;            
//    }       
    szItem = sct_common->getValue("LOG_PATH");    
    if(szItem == NULL || strlen(szItem) == 0)
    {    	
        printf("ERROR: read LOG_PATH failed in \"%s\" line %d\n", __FILE__, __LINE__ );
        return -1;
    }    
    g_stuCExpConf.sPathLog = szItem;    
    if(access(g_stuCExpConf.sPathLog.c_str(), F_OK|X_OK|W_OK|R_OK) != 0)
		{
				printf("ERROR: COMMON->LOG_PATH <%s> %s in \"%s\" line %d\n", g_stuCExpConf.sPathLog.c_str(), strerror(errno), __FILE__, __LINE__ );
				return -1;
		}
		
		/* ��־�ļ����� */
    szItem = sct_common->getValue("LOG_LEVEL_FILE");
    if(szItem == NULL || strlen(szItem) == 0)
    {
    	printf("ERROR: LOG_LEVEL_FILE failed in \"%s\" line %d\n", __FILE__, __LINE__ );
        return -1;        
    }
    g_stuCExpConf.nFileLevel = atoi(szItem);

    /* �ն������־���� */
    szItem = sct_common->getValue("LOG_LEVEL_TERM");
    if(szItem == NULL || strlen(szItem) == 0)
    {
    	printf("ERROR: LOG_LEVEL_TERM failed in \"%s\" line %d\n", __FILE__, __LINE__ );
        return -1;          
    }
    g_stuCExpConf.nTermLevel = atoi(szItem);

    szItem =  sct_common->getValue("LOG_MAIN_HEADER");
    if(szItem == NULL || strlen(szItem) == 0)
    {
        printf("ERROR: LOG_MAIN_HEADER failed in \"%s\" line %d\n", __FILE__, __LINE__ );
        return -1;
    }
    g_stuCExpConf.sMainHeader = szItem;

		 /* ��ʼ����־ */
    //INIT_LOG(g_stuCExpConf.sPathLog.c_str(), g_stuCExpConf.sMainHeader.c_str(),g_stuCExpConf.nFileLevel, g_stuCExpConf.nTermLevel);
		
		//������־�ȼ�
    initLogLevel(&g_r5_log, objfConf);
    //������־ͷ��·��
    SET_LOG_NAME_HEAD(&g_r5_log, g_stuCExpConf.sMainHeader.c_str());

    if( SET_LOG_DIR(&g_r5_log, g_stuCExpConf.sPathLog.c_str()) < 0)
    {
        printf("Log Path is error:%s. in \"%s\" line %d\n",g_stuCExpConf.sPathLog.c_str(),__FILE__, __LINE__);
        exit(-1);
    }
    		
	  if(g_stuCExpConf.nExtractTime <= 0)
	  {
		  szItem = sct_common->getValue("EXTRACT_TIME");
		  if(szItem == NULL || strlen(szItem) == 0)
		  {
		    		CEXB_Warn("read EXTRACT_TIME failed!\n");
		    		//return -1;
		    		g_stuCExpConf.nExtractTime = 0;		
		  }
		  else
		  	g_stuCExpConf.nExtractTime = atoi(szItem);
	  }		
	  
	  if(g_stuCExpConf.sStat_Dir.length() == 0)
    {
	    szItem =  sct_common->getValue("STAT_DIR");
	    if(szItem == NULL || strlen(szItem) == 0)
	    {
	        CEXB_Error("ERROR: STAT_DIR failed in \"%s\" line %d\n", __FILE__, __LINE__ );
	        return -1;
	    }
	   	g_stuCExpConf.sStat_Dir = szItem; 
  	}
	  
	  if(g_stuCExpConf.sRemote_IP.length() == 0)
    {
	    szItem =  sct_common->getValue("REMOTE_IP");
	    if(szItem == NULL || strlen(szItem) == 0)
	    {
	        CEXB_Error("ERROR: REMOTE_IP failed in \"%s\" line %d\n", __FILE__, __LINE__ );
	        return -1;
	    }
	   	g_stuCExpConf.sRemote_IP = szItem; 
  	}
  	
  	if(g_stuCExpConf.sRemote_UserName.length() == 0)
    {
	    szItem =  sct_common->getValue("REMOTE_USERNAME");
	    if(szItem == NULL || strlen(szItem) == 0)
	    {
	        CEXB_Error("ERROR: REMOTE_USERNAME failed in \"%s\" line %d\n", __FILE__, __LINE__ );
	        return -1;
	    }
	   	g_stuCExpConf.sRemote_UserName = szItem; 
  	}
  	
  	if(g_stuCExpConf.sRemote_Dir.length() == 0)
    {
	    szItem =  sct_common->getValue("REMOTE_DIR");
	    if(szItem == NULL || strlen(szItem) == 0)
	    {
	        CEXB_Error("ERROR: REMOTE_DIR failed in \"%s\" line %d\n", __FILE__, __LINE__ );
	        return -1;
	    }
	   	g_stuCExpConf.sRemote_Dir = szItem; 
  	}
		    	
    sct_common = objfConf.getSection("BILL_DB");
    if(sct_common == NULL)
    {
        printf("ERROR: open BILL_DB section failed in \"%s\" line %d\n", __FILE__, __LINE__ );
        return -1;
    }
    
//    it = sct_common->begin();
//    for ( ; it != sct_common->end(); ++it )
//    {
//    	cout<<"Key:"<<(*it)->getKey()<<endl;
//    	cout<<"Value:"<<(*it)->getValue()<<endl;            
//    }    
    
    if(g_stuCExpConf.sDB_Host.length() == 0)
    {    	
	    szItem =  sct_common->getValue("DB_HOST");	    
	    if(szItem == NULL || strlen(szItem) == 0)
	    {
	        CEXB_Error("ERROR: DB_HOST failed in \"%s\" line %d\n", __FILE__, __LINE__ );
	        //return -1;
	    }
	   	g_stuCExpConf.sDB_Host = szItem; 
  	}   	   	
   	
		if(g_stuCExpConf.nDB_Port <= 0)
		{
			szItem = sct_common->getValue("DB_PORT");
		  if(szItem == NULL || strlen(szItem) == 0)
		  {
		   	CEXB_Error("read DB_PORT failed!\n");
		  	return -1;
		  }
		  g_stuCExpConf.nDB_Port = atoi(szItem);
		}
		
		if(g_stuCExpConf.sDB_UserName.length() == 0)
		{
			szItem =  sct_common->getValue("DB_DBNAME");
	    if(szItem == NULL || strlen(szItem) == 0)
	    {
	        CEXB_Error("ERROR: DB_DBNAME failed in \"%s\" line %d\n", __FILE__, __LINE__ );
	        return -1;
	    }
	   	g_stuCExpConf.sDB_DBName = szItem; 
  	}
   	
   	if(g_stuCExpConf.sDB_UserName.length() == 0)
   	{
	   	szItem =  sct_common->getValue("DB_USERNAME");
	    if(szItem == NULL || strlen(szItem) == 0)
	    {
	        CEXB_Error("ERROR: DB_USERNAME failed in \"%s\" line %d\n", __FILE__, __LINE__ );
	        return -1;
	    }
	   	g_stuCExpConf.sDB_UserName = szItem; 
  	}
   	
   	if(g_stuCExpConf.sDB_Password.length() == 0)
   	{
   		szItem =  sct_common->getValue("DB_PASSWORD");
	    if(szItem == NULL || strlen(szItem) == 0)
	    {
	        CEXB_Error("ERROR: DB_PASSWORD failed in \"%s\" line %d\n", __FILE__, __LINE__ );
	        return -1;
	    }
	   	g_stuCExpConf.sDB_Password = szItem; 
   	}   	
   	
   	szItem = sct_common->getValue("DB_DICT");    
    if(szItem == NULL || strlen(szItem) == 0)
    {    	      
        CEXB_Error("ERROR: DB_DICT failed in \"%s\" line %d\n", __FILE__, __LINE__ );
        return -1;
    }    
    g_stuCExpConf.sDB_DICTpath = szItem;  
    return 0;
}

int fun_ParamParser(int argc, char** argv)
{
	extern char *optarg;
    char *opts = "hc:t:i:p:d:u:s:r:n:";    
    char szConfFile[128] = {0};
    char szTime[24] = {0}; 
    char szPort[16] = {0}; 
    char szHost[32] = {0};
    char szDBname[48] = {0};
    char szUsername[48] = {0};
    char szPwd[48] = {0};
    
    char szRemoteIP[32] = {0};
    char szRemoteName[48] = {0};
    
    int nRet = CEXB_SUCCESS;
    int   optch;   
    while((optch = getopt(argc , argv , opts)) != -1 )
    {
    	switch( optch )
      {        
				case 'c':
						strcpy(szConfFile, optarg);
						break;
				case 'h':
	          fun_printusage();
	          return CEXB_FAILED;
	      case 't':
	      		strcpy(szTime,optarg);	          
						break;	   
				case 'i': //dc_host			
						strcpy(szHost,optarg);	     	
						break;   
				case 'p': //db_port
						strcpy(szPort,optarg);	
						break;
				case 'd': //db_dbname
						strcpy(szDBname,optarg);
						break;
				case 'u': //db_username
						strcpy(szUsername,optarg);
						break;
				case 's': //db_password
						strcpy(szPwd,optarg);
						break;
				case 'r': //remote_ip
						strcpy(szRemoteIP,optarg);
						break;
				case 'n': //remote_name
						strcpy(szRemoteName,optarg);
						break;
        case '?':
            fun_printusage();
            printf("unknown parameter: %c\n", optopt);
            return CEXB_FAILED;
        case ':':
            fun_printusage();
            printf("need parameter: %c\n", optopt);
            return CEXB_FAILED;
				default:
					printf("need parameter: %c\n", optopt);
					return CEXB_FAILED;
			}
    }
      
    if(szConfFile[0] == '\0')
    {
    	printf("ExtractBill -c file.conf\n");
    	return CEXB_FAILED;
    }       
    g_stuCExpConf.sConfig=szConfFile;    
    
    if(strlen(szTime) > 0)
    {
    	g_stuCExpConf.nExtractTime = atoi(szTime);
    }
    else
    {
    	printf("no Num\n");
    	//return CEXB_FAILED;
    }
    
    if(szHost[0] != '\0')
    {
    	g_stuCExpConf.sDB_Host=szHost;    
    }
    else
    {
    	printf("no Host\n");    	
    }
    
    if(szPort[0] != '\0')
    {
    	g_stuCExpConf.nDB_Port = atoi(szPort); 
    }
    else
    {
    	printf("no Port\n");    	
    }
    
    if(szDBname[0] != '\0')
    {
    	g_stuCExpConf.sDB_DBName = szDBname; 
    }
    else
    {
    	printf("no DB name\n");    	
    }
    
    if(szUsername[0] != '\0')
    {
    	g_stuCExpConf.sDB_UserName = szUsername; 
    }
    else
    {
    	printf("no DB UserName\n");    	
    }
    
    if(szPwd[0] != '\0')
    {
    	g_stuCExpConf.sDB_Password = szPwd; 
    }
    else
    {
    	printf("no DB Password\n");    	
    }
    
    if(szRemoteIP[0] != '\0')
    {
    	g_stuCExpConf.sRemote_IP = szRemoteIP; 
    }
    else
    {
    	printf("no Remote IP\n");    	
    }
    
    if(szRemoteName[0] != '\0')
    {
    	g_stuCExpConf.sRemote_UserName = szRemoteName; 
    }
    else
    {
    	printf("no Remote UserName\n");    	
    }
    return nRet;
}
