/*
*@(#)ExtractHandle 0.1 2011/08/22
*
*Copyright(C)2011 CDPP Project
*
*
*
*@version 0.1 22 Aug 2011
*@author Xiao Jiajie
*
*/

#ifndef __EXTRACT_HANDLE_H__
#define __EXTRACT_HANDLE_H__

#include "MySQLAccess.h"
#include "ExtractBillMain.h"

extern recCExtractConf g_stuCExpConf;

typedef struct tagHandle
{	 	 	
 	
}recHandle;

class CExtractHandle
{
private:
 	CMySQLAccessConn m_dbConn;
 	bool m_bInit; 
 	long m_ExtractCount;
 	struct timeval m_stBegin;
  struct timeval m_stEnd;  
  
protected:
	int getSystemTime();
	int Init();	
	int ExtractBill(long nTime);	
	int Loadsolib();
	
public:
  CExtractHandle();
  ~CExtractHandle(); 
  int Run();  
  
};

#endif

