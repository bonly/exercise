/*
*date:2011-05-09
*author:lqb
*/

#include <dlfcn.h>

#include "r5api.h"
#include "plugin_query.h"
#include "comm_structs.h"

extern R5_Log g_r5_log;

int (*p_resubno_initialize)(const char* conf_file, R5_Log* plog);

int (*p_resubno_destroy)();

int (*p_bill_query)(const void* protocol, const void* route_result, void* bill, int* billlen);


int init_query(const char* conf_file, const char* lib_file, R5_Log* plog){
    /// ���ض�̬��
    char *error = NULL;
    void *p_query = dlopen(lib_file , RTLD_LAZY);
    error=dlerror();
    if(p_query == NULL)
    {
        LOG_ERROR("open library %s failed\n error:%s\n" , lib_file, error);
        return -1;
    }
    dlerror();

    ///���غ���
    p_resubno_initialize = (int(*)(const char*, R5_Log*))::dlsym(p_query , "initialize");
    if ((error = dlerror()) != NULL)
    {
        ///����
        LOG_ERROR("load query_initialize fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();

    p_resubno_destroy = (int(*)())::dlsym(p_query, "destroy");
    if ((error = dlerror()) != NULL)
    {
        ///����
        LOG_ERROR("load query_destroy fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();

    p_bill_query = (int(*)(const void*, const void*, void*, int*))::dlsym(p_query, "bill_query");
    if ((error = dlerror()) != NULL)
    {
        ///����
        LOG_ERROR("load bill_query fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();


    ///��̬���ʼ��
    int nRet = query_initialize(conf_file, plog);
    if(nRet < 0)
    {
        LOG_ERROR("query_initialize failed!\n");
        return -1;
    }

    return 0;
}

int query_initialize(const char* conf_file, R5_Log* plog){
    return p_resubno_initialize(conf_file, plog);
}

int query_destroy(){
    return p_resubno_destroy();
}

int bill_query(const void* protocol, const void* route_result, void* bill, int* billlen){
    return p_bill_query(protocol, route_result, bill, billlen);
}
