/*
*date:2011-08-11
*author:zy
*/
#include "resumbo_process.h"
#include "plugin_protocol.h"
#include "plugin_route.h"
//#include "plugin_resumbo.h"
#include"plugin_query.h"
#include "type.h"
#include "share_mem.h"
#include "buffer.h"
#include "tools.h"
#include "public_signal.h"
#include "comm_structs.h"
#include <time.h>
#include <sys/time.h>

//from base lib
#include"iniconfig.h"
#include"r5api.h"

resumbo_conf  g_conf;
char g_configure_file[MAX_FILE_LEN + 1];

//��ʹ��tcmalloc������£���������ȫ�ֱ�����ȫû�б�Ҫ
char* g_resumbobuf = NULL; //����ѯ����Ϊ5w������Լռ�ڴ�25M
int g_resumbolen = 0;

R5_Log g_r5_log;

int g_exit = 0;


int read_arg(int argc, char* argv[], struct resumbo_param& param)
{
	strncpy(param.exec_file, argv[0], sizeof(param.exec_file));
	param.is_deamon = 1;

    int optch;
    extern char *optarg;
    const char optstring[] = "hvt:c:C:S:s:e";

    while((optch = getopt(argc, argv, optstring)) != -1)
    {
        switch(optch)
        {
            case 'h':   /* ��ӡ������Ϣ */
                usage(param);
                exit(0);

            case 'v':   /* ��ʾ�汾�� */
				show_version();
                exit(0);

			case 'C':
            case 'c':   /* �����ļ� */
                strcpy(param.conf_file, optarg);
                break;

            case 'e':
                param.is_deamon = 0;

            default:
                break;
        }
    }

    if('\0' == param.conf_file[0]){
    	usage(param);
    	return -1;
    } else {
        strncpy(g_configure_file, param.conf_file, MAX_FILE_LEN);
        g_configure_file[strlen(param.conf_file)] = '\0';
    }


	return 0;
}


void usage(struct resumbo_param& param)
{
    printf("usage : %s [-c configure filename] [-e] [-h] [-v]\n", param.exec_file);
    printf("        -h show help, optional\n");
    printf("        -v show version, optional\n");
    printf("        -c configure filename, MUST\n");
    printf("-----------------------------------------------\n");
    printf("example:\n");
    printf("%s -c ../etc/query_conf.conf\n", param.exec_file);
}


void show_version()
{
#ifdef PROGRAM_VERSION
    printf("Program version:%s\n\n", PROGRAM_VERSION);
#else
    printf("No version\n");
#endif
}


int load_conf(bool is_reload){

	if(!is_reload)
		memset(&g_conf, 0, sizeof(g_conf));

    IniConfig config;
    if(config.open(g_configure_file) < 0){
        printf("open %s failed:%s\n", g_configure_file, strerror(errno));
        return -1;
    }
	const char* comm = "COMM";


    /* ��־·�� */
    const char* log_path = config.getValue(comm, "LOG_PATH");
    if(log_path && strlen(log_path) != 0){
        if(0 != path_string(log_path, g_conf.log_path, sizeof(g_conf.log_path))){
            printf("read LOG_PATH item failed, configure file: '%s', LOG_PATH: '%s'.\n",
                   g_configure_file, log_path);
            return -1;
        }
    } else {
        printf("read LOG_PATH item failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }


    /* �ļ���־���� */
    const char* file_level = config.getValue(comm, "LOG_LEVEL_FILE");
    if(file_level && strlen(file_level) != 0){
    	g_conf.file_level = atoi(file_level);
    	if(g_conf.file_level < 0 || g_conf.file_level > 120){
    		printf("LOG_LEVEL_FILE = %d error! use default-----info level\n", g_conf.file_level);
    		g_conf.file_level = 40;
    	}
    } else {
    	printf("read LOG_LEVEL_FILE failed, use default-----info level\n");
    	g_conf.file_level = 40;
    }


    /* �ն���־���� */
    const char* term_level = config.getValue(comm, "LOG_LEVEL_TERM");
    if(term_level && strlen(term_level) != 0){
    	g_conf.term_level = atoi(term_level);
    	if(g_conf.term_level < 0 || g_conf.term_level > 120){
    		printf("LOG_LEVEL_TERM = %d error! use default-----info level\n", g_conf.term_level);
    		g_conf.term_level = 40;
    	}
    } else {
    	printf("read LOG_LEVEL_TERM failed, use default-----info level\n");
    	g_conf.term_level = 40;
    }

	INIT_LOG((&g_r5_log), g_conf.log_path, "query_process", g_conf.file_level,
             g_conf.term_level);

    /* �����ڴ��ļ� */
    const char* shm = config.getValue(comm, "SHM_FILE");
    if(shm && strlen(shm) != 0){
    	strncpy(g_conf.shm_file, shm, sizeof(g_conf.shm_file) - 1);
    } else {
    	printf("read SHM_FILE failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }

    /* �źŵ��ļ� */
    const char* sem = config.getValue(comm, "SEM_FILE");
    if(sem && strlen(sem) != 0) {
        char tmp[256] = {0};
        strncpy(g_conf.sem_file, sem, sizeof(g_conf.sem_file) - 1);

    } else {
        printf("read SEM_FILE failed, configure file:%s.\n", g_configure_file);
        return -1;
    }

   	//ǿ�ƽ���ʱ�� ��λ������  Ĭ��30����
    const char* lock_time = config.getValue(comm, "LCOK_TIME");
    if(lock_time && strlen(lock_time) != 0)
    {
    	g_conf.lock_time = atoi(lock_time);
    	if(g_conf.lock_time < 0 || g_conf.lock_time > 1000){
    	    printf("lock_time's value valid, set to default 30ms\n");
    	    g_conf.lock_time = 30;
    	}
    }
    else
    {
        g_conf.lock_time = 30;
    }


    /* Э�������� */
    const char* protocol = config.getValue(comm, "PROTOCOL_FILE");
    if(protocol && strlen(protocol) != 0){
    	strncpy(g_conf.protocol_plugin, protocol, MAX_FILE_LEN);
    } else {
    	printf("read PROTOCOL_FILE failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }


   	/*·�ɲ��*/
   	const char* route = config.getValue(comm, "ROUTE_FILE");
   	if(route && strlen(route) != 0){
   	    strncpy(g_conf.route_plugin, route, MAX_FILE_LEN);
   	} else {
   	    printf("read ROUTE_FILE failed, configure file:%s\n", g_configure_file);
   	    return -1;
   	}


   	/*�������*/
   	//���� 
   	/*
   	const char* query = config.getValue(comm, "RESUMBO_FILE");
   	if(query && strlen(query) != 0){
   	    strncpy(g_conf.resumbo_plugin, query, MAX_FILE_LEN);
   	} else {
   	    printf("read RESUMBO_FILE failed, configure file:%s\n", g_configure_file);
   	    return -1;
   	}
   	*/
	///	����
	const char* resubno= config.getValue(comm, "RESUMBO_FILE");
   	if(resubno&& strlen(resubno) != 0){
   	    strncpy(g_conf.query_plugin, resubno, MAX_FILE_LEN);
   	} else {
   	    printf("read RESUMBO_FILE failed, configure file:%s\n", g_configure_file);
   	    return -1;
   	}

    return 0;
}


//�ź���ע��
int register_signal(){
    //�˳�
    if(my_signal(SIGTERM, Signal::SigTerm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM, strerror(errno));
        return -1;
    }

    //�˳�
    if(my_signal(SIGINT, Signal::SigTerm, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGINT, strerror(errno));
        return -1;
    }

    //�ض�����
    if(my_signal(SIGHUP, Signal::SigHup, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGHUP, strerror(errno));
        return -1;
    }

    //ˢ����־
    if(my_signal(SIGUSR2, Signal::SigUsr2, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR2, strerror(errno));
        return -1;
    }

    /* ����  */
    if(my_signal(SIGALRM, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGALRM, strerror(errno));
        return -1;
    }

    /* ���� */
    if(my_signal(SIGPIPE, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGPIPE, strerror(errno));
        return -1;
    }

    //����
    if(my_signal(SIGCHLD, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD, strerror(errno));
        return -1;
    }

    //����
    if(my_signal(SIGUSR1, SIG_IGN, true) == SIG_ERR){
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR1, strerror(errno));
        return -1;
    }

    return 0;
}


int init(struct resumbo_param& param, share_mem& mem, Csem& sem){
    /*���ӹ����ڴ�*/
	if(mem.attach(g_conf.shm_file) < 0){
        LOG_ERROR("attach share memory failed, err = %d, file = %s\n",
            mem.error(), g_conf.shm_file);
		return -1;
	}

	/*�����ź���*/
	if(sem.attach(g_conf.sem_file) < 0){
		LOG_ERROR("attach sem failed, err = %d, file = %s\n",
		    sem.error(), g_conf.sem_file);
		return -1;
	}


	/*��ʼ�����(��̬��)*/
	if(init_protocol(param.conf_file, g_conf.protocol_plugin, &g_r5_log) < 0){
	    LOG_ERROR("initialize protocol lib failed, file = %s\n", g_conf.protocol_plugin);
	    return -1;
	}

	if(init_route(param.conf_file, g_conf.route_plugin, &g_r5_log) < 0){
	    LOG_ERROR("initialize route lib failed, file = %s\n", g_conf.route_plugin);
	    return -1;
	}
	/*
	///�������
	if(init_resumbo(param.conf_file, g_conf.resumbo_plugin, &g_r5_log) < 0){
	    LOG_ERROR("initialize query lib failed, file = %s\n", g_conf.resumbo_plugin);
	    return -1;
	}
	*/
	if(init_query(param.conf_file, g_conf.query_plugin, &g_r5_log) < 0){
	    LOG_ERROR("initialize query lib failed, file = %s\n", g_conf.query_plugin);
	    return -1;
	}
	g_resumbobuf = (char*)malloc(32*1024*1024);
	if(NULL == g_resumbobuf){
	    LOG_ERROR("malloc failed!\n");
	    return -1;
	}

	return 0;
}

int read_message(int index, buffer& buff, share_mem& mem, char* msgbuf, int& outlen){
    int ret = -1;
    ///����
    if(buff.lock() < 0){
        ///ǿ�ƽ����ж�
        if(1 != force_unlock(index, g_conf.lock_time, buff, mem)){
            //SEND_DEBUG("read buff %d locked!\n", nIndex);
            return 2;
        }

        if(buff.lock() < 0){
            LOG_DEBUG("read buff %d lock failed!\n", index);
            return 2;
        }
    }

    ///��������ʱ��
    gettimeofday((timeval * )&(mem.m_pblock[index].pheader->last_lock), 0);

    int datasize = buff.get_data_size();

    //����С����Ϣͷ����
    if(datasize < PROTOCOL_HEAD_LEN){
        if(buff.unlock()<0)
            LOG_ERROR("index %d unlock failed!\n", index);

        return 1;
    }

    char head[128] = {0};
    ///�ӻ�������ȡ��Ϣͷ
    ret = buff.get_head((char*)head, PROTOCOL_HEAD_LEN);
    if(ret != 0){
        if(buff.unlock()<0)
            LOG_ERROR("index %d unlock failed!\n", index);

        LOG_DEBUG("get_head index %d no message!\n", index);
        return 1;
	}

    char tmp[16] = {0};
    memcpy(tmp, &(head[18]), 8);
    int msglen = atoi(tmp);

    if(msglen < 60 || msglen > 4096){
        LOG_ERROR("msglen error, len = %d\n", msglen);
        //������������
        buff.set_write_ptr(msglen);

        if(buff.unlock()<0)
            LOG_ERROR("index %d unlock failed!\n", index);

        return -1;
    }

    ret = buff.read((char *)msgbuf, msglen);
    if(ret < 0){
        if(buff.unlock() < 0)
            LOG_ERROR("index %d unlock failed!\n", index);

        //SEND_INFO(" message not enough to read, nIndex %d unlock \n", nIndex);
        return 1;
    }

    buff.set_read_ptr(msglen);
    ///���»�������ʱ��
    //gettimeofday(&(g_Smem.m_pblock[nIndex].pheader->read_time), 0);

    ///�ͷ���
    ret = buff.unlock();
    if(ret < 0)
         LOG_ERROR("index %d unlock failed!\n", index);

    outlen = msglen;

    return 0;

}


int process_msg(int index,buffer* pbuf,share_mem& mem, Csem& sem, char* msgbuf, int msglen, char* response, int* resplen){
    int ret = -1;
    route_info_list* proute = (route_info_list*)malloc(sizeof(route_info_list));
    repair_protocol* pro = (repair_protocol*)malloc(sizeof(repair_protocol));
	buffer& buf = pbuf[index];
    if(NULL == proute || NULL == pro){
        LOG_ERROR("process_msg, malloc failed.\n");
        return -1;
    }
    memset(pro, 0, sizeof(repair_protocol));
    
	
	proute->count = 0;
    *resplen = 0;
    char *key=NULL;
    int keylen=20;
    find_random_code(mem, sem, msgbuf, pro);

    do{
        //s1:Э�����
        ret = protocol_proc(msgbuf, msglen, (void*)pro, response, resplen);
        if(ret < 0){
            LOG_ERROR("protocol process failed!\n");
            break;
        }

        if(strcmp(pro->header.command, CMD_BIND_REQ) == 0){
            if(insert_random_code(mem, sem, pro) < 0){
                LOG_ERROR("route msg failed.\n");
                create_response((void*)pro, response, resplen);
            }
        }

        LOG_DEBUG("result_code:%d\n", pro->result_code);

        if(0 != pro->result_code){
            clear_random_code(mem, sem, pro);
        }

        if(*resplen > 0){
            //�ǲ�ѯ����ֱ�������˻�Ӧ����
            LOG_DEBUG("resplen = %d\n", *resplen);
            break;
        }
		LOG_DEBUG("sub_no:%s\n", pro->sub_no);
		clock_t localtime,result_time,difftime;
		long long i=5000L;
    	key=pro->seqno;
       	LOG_DEBUG("key=%s\n",key);
		///Ԥ�������󣬷�Ӧ����ͻ���
    	if(strcmp(pro->header.command,CMD_PRETREAT_REQ)==0){
    		localtime=clock();
    		
    		///����Ӧ��
    	 	create_response((void*)pro, response, resplen);
         	if (*resplen>0)
         		 send_data(index, pbuf, mem, response, *resplen); 
    	}
    	///ȡ���
       if (strcmp(pro->header.command,CMD_RESULT_REQ)==0){
			result_time=clock();
			if (difftime >= i){
				LOG_ERROR("overtime clear buff!\n");
				memset(g_resumbobuf, 0 , g_resumbolen);
				memset(key, 0, keylen);
				break;
			}else if (key==pro->seqno){
				send_data(index, pbuf, mem, g_resumbobuf, g_resumbolen);
				memset(g_resumbobuf, 0 , g_resumbolen);
				memset(key, 0, keylen);
				break;
			} 
		}
        //s2:·�ɲ�ѯ
        ret = route_msg(pro->sub_no, (void*)proute, 3);
        if(ret < 0){
            LOG_ERROR("route msg failed.\n");
            create_response((void*)pro, response, resplen);
            break;
        }

        //s3:������ѯ
       g_resumbolen = 32*1024*1024;
       /*
       ret = sumbo_query((void*)pro, (void*)proute, g_resumbobuf, &g_resumbolen);
       if(ret < 0){
            LOG_ERROR("bill query failed.\n");
           	create_response((void*)pro, response, resplen);
           	break;
     	}
     	*/
     	ret = bill_query((void*)pro, (void*)proute, g_resumbobuf, &g_resumbolen);
       if(ret < 0){
            LOG_ERROR("bill query failed.\n");
           	create_response((void*)pro, response, resplen);
           	break;
     	}
     	//buf.clear();  
    }while(0);
	
    free(proute);
    free(pro);
    /*
    free(g_resumbobuf);
    if (g_resumbobuf!=NULL){
    	g_resumbobuf=NULL;	
    }
	*/
    return ret;
}


int handle_msg(int index, buffer* pbuff, share_mem& mem, Csem& sem, char* response, int* resplen, int& cnt){
    int ret = -1;
    int msglen = 0;
    buffer& buff = pbuff[index];
    //����google��tcmalloc������ڴ���䣬������� ��ֹ�ڴ�й©
    char* buf = (char*)malloc(1024);
    if(NULL == buf){
        LOG_ERROR("in handle_msg malloc failed.\n");
        return -1;
    }

    ret = read_message(index, buff, mem, buf, msglen);
    hexdump<FormatLine<FormatChar,16> >((uchar*)buf, msglen);

    ///�ж������������
    do{
        if(1 == ret){
            //����Ϣ
            ret = 0;
            break;
        } else if(2 == ret) {
            //����������
            //LOG_DEBUG("buff %d index locked!\n", index);
            ret = 0;
            break;
        } else if(0 > ret) {
            LOG_ERROR("error happened on read buff %d\n", index);
            break;
        } else if(0 == ret){
            cnt++;
            ret = process_msg(index,pbuff,mem, sem, buf, msglen, response, resplen);
            if (ret<0){
            	LOG_ERROR("process_msg failed.\n ");
            	return -1;	
        	}
            break;
        }

        LOG_DEBUG("resplen = %d, ret = %d\n", *resplen, ret);
    }while(0);

    free(buf);

    return ret;
}

int clear_random_code(share_mem& mem, Csem& sem, repair_protocol* pro){
    int unique_id = atoi(pro->header.decompresslen);
    if(unique_id < 0 || unique_id > FD_SIZE)
        return -1;

    connection_info* ptr = mem.m_info[unique_id].pinfo;
    if(ptr->unique_id > 0){
        //memset(ptr, 0, sizeof(connection_info));
        ptr->status = 1;
        LOG_DEBUG("clear random_code, fd = %d\n", unique_id);
    }

    return 0;
}


int insert_random_code(share_mem& mem, Csem& sem, repair_protocol* pro){
    int times = 0;
    for(int i = 0; i < FD_SIZE; ++i){
        connection_info* ptr = mem.m_info[i].pinfo;
        if(ptr->unique_id > 0 && strcmp(pro->header.system, ptr->system) == 0)
            times++;
    }

    if(times > 5){//5Ҫ�������
        pro->result_code = 1;
        return -2;
    }

    int unique_id = atoi(pro->header.decompresslen);
    if(unique_id < 0 || unique_id > FD_SIZE)
        return -1;

    if(sem.p_wait(BLOCK_CNT_MAX, 20) < 0){
        //ǿ�ƽ���
        sem.v(BLOCK_CNT_MAX);
    }

    connection_info* ptr = mem.m_info[unique_id].pinfo;
    if(ptr->unique_id <= 0){
        ptr->unique_id = unique_id;
        ptr->status = 0;
        memcpy(ptr->system, pro->header.system, PRO_SYSTEM_LEN);
        memcpy(ptr->random_code, pro->random_code, PRO_RANDOM_CODE_LEN);
        memcpy(ptr->login_time, pro->login_time, PRO_DATETIME_LEN);
        LOG_DEBUG("insert random_code:%s login_time:%s unique_id:%d\n", pro->random_code,
            pro->login_time, unique_id);
    }

    sem.v(BLOCK_CNT_MAX);

    return 0;
}

int find_random_code(share_mem& mem, Csem& sem, const char* msgbuf, repair_protocol* pro){
    LOG_DEBUG("in find_random_code\n");
    char tmp[PRO_DECOM_LEN + 1] = {0};
    memcpy(tmp, msgbuf + 49, PRO_DECOM_LEN);

    int unique_id = atoi(tmp);

    LOG_DEBUG("unique_id:%d\n", unique_id);

    if(unique_id < 0 || unique_id > FD_SIZE)
        return -1;


    connection_info* ptr = mem.m_info[unique_id].pinfo;
    if(ptr->unique_id > 0){
        memcpy(pro->random_code, ptr->random_code, PRO_RANDOM_CODE_LEN);
        memcpy(pro->header.system, ptr->system, PRO_SYSTEM_LEN);
        memcpy(pro->login_time, ptr->login_time, PRO_DATETIME_LEN);

        LOG_DEBUG("find random_code:%s login_time:%s unique_id = %d\n", pro->random_code,
            pro->login_time, unique_id);
    }

    return 0;
}

int resumbo_process(share_mem& mem, Csem& sem){
    buffer buff[BLOCK_CNT_MAX]; ///BLOCK_CNT_MAX=16
    //struct route_info_list route_list;
    //struct protocol stpro;
    char respbuf[256];
    int resplen = 0;

    int ret = -1;

	//��ʼ��������
    shm_header *header = mem.get_shm_header();
    if(NULL != header){
        for(int i = 0; i < header->block_cnt; ++i){
            if(buff[i].set_sem(&sem)<0){
                LOG_ERROR("buff set_sem failed!\n");
                return -1;
            }

            //���Ӷ�Ӧ�����
            if(buff[i].attach_shm(&mem, i) < 0){
                LOG_ERROR("attach_shm %d failed!\n", i);
                return -1;
            }
        }
    }

    LOG_INFO("Program running!\n");

    struct block_header *phead=NULL;
    int dealcnt = 0;
    while(!g_exit){
        for(int i = 0; i < header->block_cnt; i++){
            ///�źŴ���
            ret = Signal::HandleSignal();
            if(ret < 0){
                LOG_ERROR("HandleSignal failed!\n");
                return -1;
            }

            ///���ݳ����������ж�
            phead = mem.m_pblock[i].pheader;
            if(phead && NET_RECV != phead->type)
            {
                continue;
            }

            //LOG_DEBUG("type is %d\n", phead->type);

            ret = handle_msg(i, buff, mem, sem, respbuf, &resplen, dealcnt);
            if(ret < 0)
            {
                LOG_ERROR("Handle_Buf %d failed!\n", i);
                if(-1 == ret)
                {
                    LOG_ERROR("FATAL_ERROR, process exit!\n");
                    return ret;
                }
            }

            if(g_exit)
            {
                break;
            }

        }

        status_check(mem, sem);

        //·������,�������һ����ʱ��û�б���
        //·��ģ��������������
        route_heartbit();

        if(0 == dealcnt)
            usleep(1);
        else
            dealcnt = 0;
    }

    return 0;
}


void status_check(share_mem& mem, Csem& sem){
    for(int i = 0; i < FD_SIZE; ++i){
        connection_info* ptr = mem.m_info[i].pinfo;
        if(ptr->unique_id > 0 && ptr->status == 3){
            LOG_DEBUG("status_check, clear unique_id = %d\n", ptr->unique_id);
            if(sem.p_wait(BLOCK_CNT_MAX, 30) < 0){
                //ǿ�ƽ���
                sem.v(BLOCK_CNT_MAX);
            }
            memset(ptr, 0, sizeof(connection_info));
            sem.v(BLOCK_CNT_MAX);
        }
    }
}

int force_unlock(int index, int waittime, buffer& buff, share_mem& mem){
    if(index < 0 || waittime <= 0){
        LOG_ERROR("force_unlock input param wrong!\n");
        return -1;
    }
    ///�ж�ʱ����
    struct timeval tp_local;
    gettimeofday(&tp_local, 0);
    struct timeval volatile *tp_past = &(mem.m_pblock[index].pheader->last_lock);
    //��λ������
    int diff = (tp_local.tv_sec - tp_past->tv_sec)*1000 + (tp_local.tv_usec - tp_past->tv_usec)/1000;

    if( diff >= waittime){
        ///ǿ�ƽ���
        if(buff.unlock() < 0)
        {
            LOG_ERROR("nIndex %d force unlock failed!\n", index);
            return -1;
        }
        LOG_INFO("index %d unlock force, difftime %d, past time %d : %d, now time %d : %d!\n",\
         index, diff, tp_past->tv_sec, tp_past->tv_usec, tp_local.tv_sec, tp_local.tv_usec);
        return 1;
    }
    ///�Ƿ�����״̬

    return 0;
}


int send_data(int index, buffer* pbuff, share_mem& mem, const char* data, int datalen){

    if(datalen < PROTOCOL_HEAD_LEN){
        LOG_DEBUG("datalen: %d\n", datalen);
        return -1;

    }

    shm_header *memhead = mem.get_shm_header();

    int idx = (index + 1) % memhead->block_cnt;
    while(1){
    struct block_header *phead = mem.m_pblock[idx].pheader;
    //����Ҳ�������ɱ�����ѯ���һ���������δʵ�֣�
    if(phead && NET_SEND == phead->type){

        buffer& buff = pbuff[idx];

        if(buff.lock() < 0){
            ///ǿ�ƽ����ж�
            if(1 != force_unlock(idx, g_conf.lock_time, buff, mem))
            {
                LOG_WARN("force unlock failed.\n");
                    idx += 2;
                    idx = idx % memhead->block_cnt;
                    continue;
            }

            if(buff.lock() < 0)
            {
                LOG_DEBUG("read buff %d locked!\n", idx);
                    idx += 2;
                    idx = idx % memhead->block_cnt;
                    continue;
            }
        }

        ///��������ʱ��
        gettimeofday((timeval * )&(phead->last_lock), 0);

        int freesize = buff.get_free_size();
        if(freesize < datalen){//�������ռ䲻�����������Ҫ���
            buff.unlock();
            LOG_ERROR("buffer is full, index = %d\n", idx);
            return -1;
        }

        buff.write(data,datalen);
        buff.set_write_ptr(datalen);

        buff.unlock();

        LOG_DEBUG("send data success! index = %d len = %d, date= %s\n", idx, datalen,data);
            break;
        }
    }

    return 0;
}

void exit(){

    /*������̬��*/
    pro_destory();

    route_destroy();

    //resumbo_destroy();
	query_destroy();

    if(NULL != g_resumbobuf){
        free(g_resumbobuf);
        g_resumbobuf = NULL;
    }

    

}



int main(int argc, char* argv[]){
    struct resumbo_param param;
    share_mem mem;
    Csem sem;

    memset(&param, 0, sizeof(param));
    if(read_arg(argc, argv, param) < 0){
        fprintf(stderr, "read arg failed.\n");
        return -1;
    }

    if(load_conf() < 0){
        fprintf(stderr, "load configure file failed.\n");
        return -1;
    }

    if(init(param, mem, sem) < 0){
        fprintf(stderr, "initialize failed.\n");
        return -1;
    }

    if(register_signal() < 0){
        LOG_ERROR("register signal failed.\n");
        return -1;
    }

    if(param.is_deamon)
        daemon(0, 0);

    resumbo_process(mem, sem);

    exit();
    mem.destroy();
    LOG_INFO("Progran Exit!\n");
}



int DoSigTerm(){
    LOG_WARN("interruptted by SIGTERM.\n");

    g_exit = 1;
    return 0;
}

int DoSigChild(){
    LOG_WARN("interruptted by SIGCHLD.\n");

    return 0;
}

int DoSigHup(){
    LOG_WARN("interruptted by SIGHUP.\n");

    return load_conf(true);
}

int DoSigUsr2(){
    LOG_WARN("interruptted by SIGUSR2.\n");

    g_r5_log.flush();
    return 0;
}

int DoSigAlarm(){
    LOG_WARN("interruptted by SIGALRM.\n");
    return 0;
}

int DoSigPipe(){
    LOG_WARN("interruptted by SIGPIPE.\n");
    return -1;
}

