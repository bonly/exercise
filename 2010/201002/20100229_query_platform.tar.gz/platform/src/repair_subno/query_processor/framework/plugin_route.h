#ifndef __PLUGIN_ROUTE_H__
#define __PLUGIN_ROUTE_H__
/*
*date:2011-05-09
*author:lqb
*/

class R5_Log;

int init_route(const char* conf_file, const char* lib_file, R5_Log* plog);

int route_initialize(const char* conf_file, R5_Log* plog);

int route_destroy();

int route_msg(const char* sub_no, void* route_list, int cmdtype);

int route_heartbit();

#endif

