#ifndef __RESUMBO_PROCESS_H__
#define __RESUMBO_PROCESS_H__
/*
*
*
*/


#include "type.h"

struct resumbo_conf{
	int file_level;			//�ļ���־����
	int term_level;			//�ն���־����
	int lock_time;
	char log_path[MAX_FILE_LEN + 1];
	char shm_file[MAX_FILE_LEN + 1];
	char sem_file[MAX_FILE_LEN + 1];
	char protocol_plugin[MAX_FILE_LEN + 1];
	char route_plugin[MAX_FILE_LEN + 1];
	//char resumbo_plugin[MAX_FILE_LEN + 1];
	char query_plugin[MAX_FILE_LEN+1];
	char translate_plugin[MAX_FILE_LEN + 1];
};

struct resumbo_param{
    int is_deamon;
    char conf_file[MAX_FILE_LEN + 1];
    char exec_file[MAX_FILE_LEN + 1];
};


class buffer;
class share_mem;
class Csem;
struct repair_protocol;



int read_arg(int argc, char* argv[], struct resumbo_param & param);

void usage(struct resumbo_param & param);

void show_version();

int load_conf(bool is_reload = false);

int register_signal();

int init(struct resumbo_param& param, share_mem& mem, Csem& sem);

int read_message(int index, buffer& buff, share_mem& mem, char* msgbuf, int& outlen);

int process_msg(int index,buffer* pbuf,char* msgbuf, int msglen, char* response, int* resplen,repair_protocol *pro);

int handle_msg(int index, buffer* pbuff, share_mem& mem, char* response, int* resplen, int& cnt);

int resubbo_process(share_mem& mem, Csem& sem);

int force_unlock(int index, int waittime, buffer& buff, share_mem& mem);

int send_data(int index, buffer* pbuff, share_mem& mem, const char* data, int datalen);

int checkout_pro( repair_protocol *protocol );

void exit();

int insert_random_code(share_mem& mem, Csem& sem, repair_protocol* pro);

int find_random_code(share_mem& mem, Csem& sem, const char* msgbuf, repair_protocol* pro);

int clear_random_code(share_mem& mem, Csem& sem, repair_protocol* pro);

void status_check(share_mem& mem, Csem& sem);


//============================================================================
// Name        : bindump_hex.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#ifndef __HEX_DUMP__
#define _HEX_DUMP__
#include <cstdio>
#include <string.h>
#include <ctype.h>

typedef unsigned char uchar;
struct FormatChar
{
      FormatChar(uchar c, uchar* s)
      {
         sprintf((char*) s, "%02X", c);
         s[2] = ' ';
      }
};

template<typename PRINT = FormatChar, int LINE_SIZE = 16>
class FormatLine
{
   private:
      enum
      {
         REAL_SIZE = LINE_SIZE * 4 + 4
      };
      /// ����һ��buffer
      uchar line[REAL_SIZE];

   public:
      friend struct FormatChar;

      uchar* operator()(uchar* p, size_t& nBegin, size_t& nLeft)
      {
         if (nLeft <= 0)
            return NULL;

         /// ָ���ַ���ʼλ��
         uchar* pt = p + nBegin;

         /// ÿ��ȡn��byte��������
         for (size_t i = 0; i < LINE_SIZE; ++i)
         {
            if (nLeft > 0)
            {
               /// ���ַ���ӡ����
               uchar c = pt[i];
               PRINT(c, line + i * 3);

               /// ת�����ӡ���Ҳ�,�������ַ���ʾΪ'.'
               line[LINE_SIZE * 3 + 3 + i] = isprint(c) ? c : '.';

               /// ʣ��δ��ӡ�ַ���������
               --nLeft;
            }
            else ///��ȫ���ַ��������,��δ���һ�������ַ�ʱ���ո�
            {
               /// �󲿽����󲹿ո�
               line[i * 3] = ' ';
               line[i * 3 + 1] = ' ';

               ///���Ҳ�������Ӳ��ո�
               line[LINE_SIZE * 3 + 3 + i] = ' ';
            }
         }
         /// ��ĩβ��ʾ�ո�
         line[LINE_SIZE * 3] = ' ';
         line[LINE_SIZE * 3 + 1] = ' ';
         line[LINE_SIZE * 3 + 2] = ' ';

         /// �Ҳ�ĩβ��ʾ�ո�
         line[REAL_SIZE - 1] = '\0';
         /// ƫ�Ƽ�¼��ʼ��λ��
         nBegin += LINE_SIZE;
         return line;
      }
};

template<typename LINE>
void hexdump(uchar* p, size_t len)
{
   size_t i = 0;
   size_t j = len;
   uchar* s = 0;
   LINE ft;
   while (0 != (s = ft(p, i, j)))
      printf("%s\n", s);
}

#endif

/*
 g++ -std=c++0x
 */

#endif


                         