/*
*
*
*/
#include <string.h>
#include <mysql.h>

#include "protocol_helper.h"
#include "type.h"
#include "comm_structs.h"


//from base lib
#include"iniconfig.h"
#include"r5api.h"

extern R5_Log* g_r5_plog;
extern MYSQL * g_protocoldb;

//extern int create_response(void* protocol, void* outmsg, int* outlen);

#define STRCASECMP(s1,s2)\
    do{\
        if(strcasecmp(s1, s2) !=  0){\
        PRO_ERROR("%s error!\n", s2);\
        return -1;\
        }\
    }while(0)

int parse_header(const char* message, int msglen, protocol_head* header){
    if(NULL == message || NULL == header || msglen < 60){
        PRO_ERROR("param error!\n");
        return -1;
    }

    memset(header, 0, sizeof(protocol_head));

    char* p = (char*)message;
    memcpy(header->command, p, PRO_COMMAND_LEN);
    p += PRO_COMMAND_LEN;
    p++; //Э����ÿ�����ȴ���1���ֶζ���һ�� '\0' ������

    memcpy(header->sequence, p, PRO_SEQUENCE_LEN);
    p += PRO_SEQUENCE_LEN;
    p++;

    memcpy(header->length, p, PRO_LENGTH_LEN);
    p += PRO_LENGTH_LEN;
    p++;

    memcpy(header->system, p, PRO_SYSTEM_LEN);
    p += PRO_SYSTEM_LEN;
    p++;

    header->encrypt_flag = *p;
    p++;

    header->errcode = *p;
    p++;

    header->morepkt = *p;
    p++;

    memcpy(header->decompresslen, p, PRO_DECOM_LEN);

    if(LOG_CHECK_DEBUG(g_r5_plog)){
        PRO_DEBUG("dump protocol header:\n");
        PRO_DEBUG("%s|%s|%s|%s|%c|%c|%c|%s\n", header->command, header->sequence, header->length,
            header->system, header->encrypt_flag, header->errcode, header->morepkt, header->decompresslen);
    }

    return 0;
}

//Ԥ��������
int pretreat_request(const char* inmsg, const int inlen, repair_protocol* protocol, void* outmsg, int* outlen){
	/*
    bool abc=true;
    while(abc)
    {
    	sleep(1);
    }
    */
    char tmparr[20][32];
    memset(tmparr, 0, 20*32);

    protocol->result_code = 1;
   /*
    if('1' != protocol->header.encrypt_flag){
        protocol->result_code = 1;
        //snprintf(protocol->errmsg, sizeof(protocol->errmsg), "Count=0&MSG=NotEncrypt");
        create_response_helper(protocol, outmsg, outlen);
        PRO_ERROR("Not encrypt!\n");
        return -1;
    }
    */
    char* p = (char*)inmsg + PROTOCOL_HEAD_LEN;
    int datalen = inlen - PROTOCOL_HEAD_LEN;

    PRO_DEBUG("datalen = %d\n", datalen);
    
    //if(strcmp(protocol->random_code, "1234567890") != 0)
    //    return -1;

    //Encrypt::crypt(p, datalen, protocol->random_code, strlen(protocol->random_code));

    if(LOG_CHECK_DEBUG(g_r5_plog))
    {
        char tmp[1024] = {0};
        memcpy(tmp, p, datalen);
        PRO_DEBUG("dump  pretreat_request original string:\n");
        PRO_DEBUG("%s\n", p);
    }

    int tmplen = 0;
    char delimit = '=';
    
    for(int i = 0; i <= 16; ++i)
    {
        if(get_string(p, '=', tmparr[i], &tmplen) < 0)
        {
            snprintf(protocol->errmsg, sizeof(protocol->errmsg), "MEQNO=0&MSG=ErrorSunbo");
            create_response_helper(protocol, outmsg, outlen);
            PRO_WARN("split 1 faield, str = %s\n", p);
            return -1;
        }

        p += tmplen;
        datalen -= tmplen;
        i++;
	    if(get_string(p, '&', tmparr[i], &tmplen) < 0)
	    {
	    	if(strlen(p)>0){
	    		 strncpy(tmparr[i],p,strlen(p));
	    	}
	    	
            break;
        }
        p += tmplen;
        datalen -= tmplen;
    }
    /*
    if(get_string(p, '=', tmparr[18], &tmplen) < 0)
    {
        snprintf(protocol->errmsg, sizeof(protocol->errmsg), "MSG=RequestError");
        create_response_helper(protocol, outmsg, outlen);
        PRO_DEBUG("split 3 faield, str = %s\n", p);
        return -1;
    }

    p += tmplen;
    datalen -= tmplen;
    
	///У��Э��������
    memcpy(tmparr[19], p, datalen);
    */
    do{
        if(0 !=strcasecmp(tmparr[0],"seqno"))
        {
        	 PRO_ERROR("SeqNo error!\n");
             break;		
        }
        
        strncpy(protocol->seqno, tmparr[1], PRO_SEQNO_LEN);
        if(0 != strcasecmp(tmparr[2], "SubNo"))
        {
           // snprintf(protocol->errmsg, sizeof(protocol->errmsg), "Count=0&MSG=SubNoError");
            PRO_ERROR("SubNo error!\n");
            break;
        }
        strncpy(protocol->sub_no, tmparr[3], PRO_SUB_NO_LEN);
        //��Ҫ��������ȷ�Լ�⣿
		if(0 != strcasecmp(tmparr[4], "switch_flag"))
		{
           // snprintf(protocol->errmsg, sizeof(protocol->errmsg), "Count=0&MSG=SwitchFlagError");
            PRO_ERROR("SwitchFlag error!\n");
            break;
        }
         strncpy(protocol->switch_flag, tmparr[5], PRO_SWITCH_FLAG_LEN);
       
        if(0 != strcasecmp(tmparr[6], "Brand"))
        {
           // snprintf(protocol->errmsg, sizeof(protocol->errmsg), "Count=0&MSG=BrandError");
            PRO_ERROR("Brand error!\n");
            break;
        }
         strncpy(protocol->brand, tmparr[7], PRO_BRAND_LEN); 
        if(0 != strcasecmp(tmparr[8], "BeginDate"))
        {
            //snprintf(protocol->errmsg, sizeof(protocol->errmsg), "Count=0&MSG=BeginDateError");
            PRO_ERROR("BeginDate error!\n");
            break;
        }
        strncpy(protocol->begin_date, tmparr[9], PRO_DATETIME_LEN);
        //ʱ��Ϸ��Լ�飿

        if(0 != strcasecmp(tmparr[10], "EndDate"))
        {
            //snprintf(protocol->errmsg, sizeof(protocol->errmsg), "Count=0&MSG=EndDateError");
            PRO_ERROR("EndDate error!\n");
            break;
        }
        strncpy(protocol->end_date, tmparr[11], PRO_DATETIME_LEN);

        if(0 != strcasecmp(tmparr[12], "QueryTime"))
        {
            //snprintf(protocol->errmsg, sizeof(protocol->errmsg), "Count=0&MSG=QueryTimeError");
            PRO_ERROR("QueryTime error!\n");
            break;
        }
        strncpy(protocol->query_time, tmparr[13], PRO_DATETIME_LEN);
   		/*
        //ͨ��ʱ�����ƴ��ڣ��������ڵ���30��
        char *limit=protocol->CallTimeLenLimit;
        if(*limit!=NULL&&*limit>=30)
        {
        	if (0!=strcasecmp(tmparr[14],"CallTimeLenLimit"))
        	{
        		PRO_ERROR(" CallTimeLenLimit error!\n");
           	    break;
             } 
          	strncpy(protocol->query_time, tmparr[15], PRO_CALLTIMELIMIT_LEN);
   	    
         }   
       
       */
        protocol->result_code = 0;
        *outlen = 0;
    }while(0);

    if(0 != protocol->result_code){
        create_response_helper(protocol, outmsg, outlen);
        return -1;
    }

    if(LOG_CHECK_DEBUG(g_r5_plog)){
        PRO_DEBUG("dump query request:\n");
        PRO_DEBUG("%s|%s|%s|%s|%c|%s|%s\n", protocol->seqno,protocol->sub_no,protocol->switch_flag, 
        protocol->brand, protocol->begin_date, protocol->end_date, protocol->query_time);
    }
    //protocol->result_code = 0;
    //*outlen = 0;

    return 0;
}

///�� 
int bind_request(const char* inmsg, const int inlen, repair_protocol* protocol, void* outmsg, int* outlen){

    char tmparr[4][32] = {0};
    char password[32] = {0};
    int ret = 0;

    protocol_head* header = &(protocol->header);

    if('1' != header->encrypt_flag){
        protocol->result_code = 1;
        snprintf(protocol->errmsg, sizeof(protocol->errmsg), "LoginResult=%d", protocol->result_code);
        create_response_helper(protocol, outmsg, outlen);
        PRO_ERROR("Not excrypt!\n");
        return -1;
    }

    ret = select_password(header->system, password, sizeof(password));
    if(ret < 0){
        protocol->result_code = 1;
        snprintf(protocol->errmsg, sizeof(protocol->errmsg), "LoginResult=%d", protocol->result_code);
        PRO_ERROR("select password failed.\n");
        create_response_helper(protocol, outmsg, outlen);
        return -1;
    }
    PRO_DEBUG("system:%s passwprd:%s\n", header->system, password);

    char* p = (char*)inmsg + PROTOCOL_HEAD_LEN;
    int datalen = inlen - PROTOCOL_HEAD_LEN;

   // Encrypt::crypt(p, datalen, password, strlen(password));

    int tmplen = 0;

    get_string(p, '=', tmparr[0], &tmplen);
    p += tmplen;
    datalen -= tmplen;

    get_string(p, '&', tmparr[1], &tmplen);
    p += tmplen;
    datalen -= tmplen;

    get_string(p, '=', tmparr[2], &tmplen);
    p += tmplen;
    datalen -= tmplen;

    memcpy(tmparr[3], p, datalen);
	
    if(0 != strcasecmp(tmparr[0], "DateTime")){
        protocol->result_code = 1;
        snprintf(protocol->errmsg, sizeof(protocol->errmsg), "LoginResult=%d", protocol->result_code);
        create_response_helper(protocol, outmsg, outlen);
        PRO_ERROR("DateTime error!\n");
        return -1;
    }

    if(0 != strcasecmp(tmparr[2], "RandomCode")){
        protocol->result_code = 1;
        snprintf(protocol->errmsg, sizeof(protocol->errmsg), "LoginResult=%d", protocol->result_code);
        create_response_helper(protocol, outmsg, outlen);
        PRO_ERROR("RandomCode error!\n");
        return -1;
    }

    strncpy(protocol->login_time, tmparr[1], PRO_DATETIME_LEN);
    strncpy(protocol->random_code, tmparr[3], PRO_RANDOM_CODE_LEN);

    if(LOG_CHECK_DEBUG(g_r5_plog)){
        PRO_DEBUG("dump bind request body:\n");
        PRO_DEBUG("DateTime=%s&RandomCode=%s\n", protocol->login_time, protocol->random_code);
    }

    protocol->result_code = 0;
    snprintf(protocol->errmsg, sizeof(protocol->errmsg), "LoginResult=%d", protocol->result_code);
    create_response_helper(protocol, outmsg, outlen);

    return 0;
}

///�ǰ�
int unbind_request(const char* inmsg, const int inlen, repair_protocol* protocol,  void* outmsg, int* outlen){

    memcpy(outmsg, inmsg, inlen);
    *outlen = inlen;

    //Ϊ�����������ڴ��е�unique_id����Ϣ
    protocol->result_code = 2;

    PRO_INFO("unbind-request, client = %s\n", protocol->header.system);

    return 0;
}

//�޸���������
int password_change_request(const char* inmsg, const int inlen, repair_protocol* protocol, void* outmsg,
        int* outlen){
    char tmparr[2][32] = {0};
    int ret = 0;
    char errcode = '0';
    char* p = NULL;

    protocol_head* header = &(protocol->header);
    do{
        if('1' != header->encrypt_flag){
            PRO_ERROR("Not Encrypt!\n");
            protocol->result_code = 1;
            errcode = '1';
            break;
        }

        p = (char*)inmsg + PROTOCOL_HEAD_LEN;
        int datalen = inlen - PROTOCOL_HEAD_LEN;
        //Encrypt::crypt(p, datalen, protocol->random_code, strlen(protocol->random_code));
        int tmplen = 0;

        get_string(p, '=', tmparr[0], &tmplen);
        p += tmplen;
        datalen -= tmplen;

        memcpy(tmparr[1], p, datalen);

        if(LOG_CHECK_DEBUG(g_r5_plog)){
            char* p = (char*)inmsg + PROTOCOL_HEAD_LEN;
            PRO_DEBUG("dump change password request:\n");
            PRO_DEBUG("%s|%s|%s|%s|%c|%c|%c|%s:%s\n", header->command, header->sequence, header->length,
                header->system, header->encrypt_flag, header->errcode, header->morepkt, header->decompresslen, p);
        }

        if(strcasecmp(tmparr[0], "NewPassword") != 0){
            PRO_ERROR("update passwd body error, no NewPassword!\n");
            errcode = '1';
            protocol->result_code = 1;
            break;
        }

        if(update_password(protocol->header.system, tmparr[1]) < 0){
            PRO_ERROR("update password failed, system = %s newpasswd = %s\n",
                protocol->header.system, tmparr[1]);
            errcode = '1';
            protocol->result_code = 1;
            break;
        }
    }while(0);

    protocol->result_code = 0;

    memcpy(outmsg, p, PROTOCOL_HEAD_LEN);
    *outlen = PROTOCOL_HEAD_LEN;
    p = (char*)outmsg;
    *(p + 47) = '0';
    *(p + 48) = errcode;

    return 0;
}


//����Ӧ��
int create_response_helper(void* protocol, void* outmsg, int* outlen)
{
    char* p = (char*)outmsg;
    repair_protocol* pro = (repair_protocol*)protocol;
    
    int n = strlen(pro->errmsg);
    /*
    if(n > 0)
        Encrypt::crypt(pro->errmsg, n, pro->random_code, strlen(pro->random_code));

    */
    *outlen =n+ PROTOCOL_HEAD_LEN;
    *outlen+=PROTOCOL_HEAD_LEN;
    protocol_head* header = &(pro->header);

    memcpy(p, header->command, PRO_COMMAND_LEN);
    p += PRO_COMMAND_LEN;
    *p = '\0';
    p++;

    memcpy(p, header->sequence, PRO_SEQUENCE_LEN);
    p += PRO_SEQUENCE_LEN;
    *p = '\0';
    p++;

    snprintf(p, PRO_LENGTH_LEN, "%d", *outlen);
    p += PRO_LENGTH_LEN;
    *p = '\0';
    p++;

    memcpy(p, header->system, PRO_SYSTEM_LEN);
    p += PRO_SYSTEM_LEN;
    *p = '\0';
    p++;

    //encrypt_flag
    *p = '0';
    p++;

    //errcode
    if(0 == pro->result_code){
        *p = '0';
        p++;
    } else {
        *p = '1';
        p++;
    }

    //morepkt
    *p = '0';
    p++;


    memcpy(p, header->decompresslen, PRO_DECOM_LEN);
    p += PRO_DECOM_LEN;
    
    if(n > 0)
        memcpy(p, pro->errmsg, n);
    
    if(LOG_CHECK_DEBUG(g_r5_plog)){
        PRO_DEBUG("dump bind response:\n");
        PRO_DEBUG("%s|%s|%d|%s|%c|%c|%c|%s\n", header->command, header->sequence, *outlen,
            header->system, header->encrypt_flag, header->errcode, header->morepkt, header->decompresslen);
    }
}

///ȡ�������
int result_request(const char* inmsg, const int inlen, repair_protocol* protocol, void* outmsg, int* outlen)
{
	char tmparr[20][32];
    memset(tmparr, 0, 20*32);

    protocol->result_code = 1;
    /*
    if('1' != protocol->header.encrypt_flag){
        protocol->result_code = 1;
        //snprintf(protocol->errmsg, sizeof(protocol->errmsg), "seqno=notonly&MSG=NotEncrypt");
        create_response_helper(protocol, outmsg, outlen);
        PRO_ERROR("Not encrypt!\n");
        return -1;
    }
    */
    char* p = (char*)inmsg + PROTOCOL_HEAD_LEN;
    int datalen = inlen - PROTOCOL_HEAD_LEN;

    PRO_DEBUG("datalen = %d\n", datalen);
    
    //if(strcmp(protocol->random_code, "1234567890") != 0)
    //    return -1;

    //Encrypt::crypt(p, datalen, protocol->random_code, strlen(protocol->random_code));

    if(LOG_CHECK_DEBUG(g_r5_plog)){
        char tmp[1024] = {0};
        memcpy(tmp, p, datalen);
        PRO_DEBUG("dump  result_request original string:\n");
        PRO_DEBUG("%s\n", p);
    }
    int tmplen = 0;
    char delimit = '=';
   
    /*
    for(int i = 0; i <= 16; ++i)
    {
        if(get_string(p, '=', tmparr[i], &tmplen) < 0)
        {
            snprintf(protocol->errmsg, sizeof(protocol->errmsg), "MEQNO=0&MSG=ErrorSunbo");
            create_response_helper(protocol, outmsg, outlen);
            PRO_WARN("split 1 faield, str = %s\n", p);
            return -1;
        }

        p += tmplen;
        datalen -= tmplen;
        i++;
	    if(get_string(p, '&', tmparr[i], &tmplen) < 0)
	    {
	    	if(*p>0){
	    		strncpy(tmparr[i],p,strlen(p));	
	    	}
            break;
        }
        p += tmplen;
        datalen -= tmplen;
    }
    if(get_string(p, '=', tmparr[18], &tmplen) < 0)
    {
        snprintf(protocol->errmsg, sizeof(protocol->errmsg), "MSG=RequestError");
        create_response_helper(protocol, outmsg, outlen);
        PRO_DEBUG("split 3 faield, str = %s\n", p);
        return -1;
    }

    p += tmplen;
    datalen -= tmplen;
    
    memcpy(tmparr[19], p, datalen);
    */
    for(int i = 0;i < 2;++i){
    
    	if (get_string(p,'=',tmparr[i],&tmplen)<0){
    		snprintf(protocol->errmsg, sizeof(protocol->errmsg), "MEQNO=0&MSG=ErrorSunbo");
            create_response_helper(protocol, outmsg, outlen);
            PRO_WARN("split 1 faield, str = %s\n", p);
            return -1;
    	}
    	p += tmplen;
        datalen -= tmplen;
        i++;
        if(get_string(p, '&', tmparr[i], &tmplen) < 0)
	    {
	    	if(*p>0){
	    		strncpy(tmparr[i],p,strlen(p));	
	    	}
            break;
        }
        p += tmplen;
        datalen -= tmplen;
	}
	///�������ֶ�д��Э��
   	do{
		if(0 !=strcasecmp(tmparr[0],"seqno")){
         PRO_ERROR("SeqNo error!\n");
         break;		 
     	}
     	strncpy(protocol->seqno, tmparr[1], PRO_SEQNO_LEN); 
     	protocol->result_code = 0;
        *outlen = 0;
	}while(0);
	
	if(0 != protocol->result_code){
        create_response_helper(protocol, outmsg, outlen);
        return -1;
    }

    if(LOG_CHECK_DEBUG(g_r5_plog)){
        PRO_DEBUG("dump result_request:\n");
        PRO_DEBUG("%s\n", protocol->seqno);
    }
	
	return 0;
}

int get_string(const char* str, char delimit, char* outstr, int* outlen)
{
    char* p = strchr(str, delimit);
    if(p==NULL){ 
    	return -1;
    }
    memcpy(outstr, str, p - str);
    *outlen = p - str + 1;
    return 0;
}

int select_password(const char* system, char* password, int buflen){
    char query[256] = {0};
    int len = snprintf(query, sizeof(query), "select password from bill_user where loginname = '%s'", system);

    PRO_DEBUG("SQL:%s\n", query);
    const int r = mysql_real_query(g_protocoldb, query, len > 0 ? len : 0);
    if (r != 0){
        PRO_ERROR("mysql: error=[%s]\n", mysql_error(g_protocoldb));
        return -1;
    }

    MYSQL_ROW row = 0;
    unsigned long *lengths = 0;
    unsigned int num_flds = 0;
    MYSQL_RES *res = mysql_store_result(g_protocoldb);


    if (res != 0) {
        if((row = mysql_fetch_row(res))){
            lengths = mysql_fetch_lengths(res);
            if(lengths[0] > buflen){
                mysql_free_result(res);
                return -1;
            }
            strncpy(password, row[0], buflen);
        }
    } else {
        mysql_free_result(res);
        PRO_WARN("user %s does not exist!\n");
        return -1;
    }

    mysql_free_result(res);
    return 0;
}

int update_password(const char* system, const char* new_password){
    char query[256] = {0};
    int len = snprintf(query, sizeof(query), "update bill_user set password = '%s' where loginname = '%s'",
        new_password, system);

    PRO_DEBUG("SQL:%s\n", query);
    const int r = mysql_real_query(g_protocoldb, query, len > 0 ? len : 0);
    if (r != 0){
        PRO_ERROR("mysql: error=[%s]\n", mysql_error(g_protocoldb));
        return -1;
    }

    return 0;
}




///ȡ���Ӧ��
int result_response(const char* inmsg, const int inlen, repair_protocol* protocol, void* outmsg, int* outlen)
{
			
	if('1' == protocol->header.errcode){
  		return -1;	
  	}else if('2'==protocol->header.errcode){
  		PRO_INFO( "get response .......");
  	}	
	return 0; 
}



