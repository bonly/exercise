/*
*
*
*/
#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>

#include "query_route.h"
#include "comm_structs.h"
//#include "cepoll.h"
#include "Protocal.h"
//from base lib
#include "iniconfig.h"
#include "r5api.h"


route_conf g_conf;

R5_Log* g_r5_plog = NULL;
time_t g_alive_time;
//CEpoll * g_epoll = NULL;

int g_fd = -1;

int initialize(const char* conf_file, R5_Log* plog){
    if(NULL == plog){
        fprintf(stderr, "plog is NULL.\n");
        return -1;
    }
    g_r5_plog = plog;

    memset(&g_conf, 0, sizeof(route_conf));

    //��ȡ�����ļ�
    IniConfig config;
    if (config.open((const char *) conf_file) < 0) {
        ROUTE_ERROR("open file(%s) error!\n", conf_file);
        return -1;
    }

    const char* route = "ROUTE";

    /* route_ip */
    const char* ip = config.getValue(route, "ROUTE_IP");
    if(ip && 0 != strlen(ip)){
        strncpy(g_conf.route_ip, ip, sizeof(g_conf.route_ip) -1);
    } else {
        ROUTE_ERROR("route ip is NULL.\n");
        return -1;
    }

    //route_port
    const char* port = config.getValue(route, "ROUTE_PORT");
    if(port && 0 != strlen(port)){
        g_conf.route_port = atoi(port);
    } else {
        ROUTE_ERROR("route port is NULL.\n");
        return -1;
    }

    //�������
    const char* heartbit = config.getValue(route, "HEAER_BIT_TIME");
    if(heartbit && 0 != strlen(heartbit)){
        g_conf.heartbit = atoi(heartbit);
        if(g_conf.heartbit <= 0 || g_conf.heartbit > 600){
            ROUTE_WARN("heartbit time error,set to default 30 second, heartbit = %d\n", g_conf.heartbit);
            g_conf.heartbit = 30;
        }
    } else {
        ROUTE_WARN("heartbit time not exist,set to default 30 second\n");
        g_conf.heartbit = 30;
    }

    if(connect_to_route() < 0){
        ROUTE_ERROR("connect to route failed.\n");
        return -1;
    }


    return 0;
}


int connect_to_route(){
    g_alive_time = time(NULL);

	g_fd = socket(AF_INET, SOCK_STREAM, 0);
	if(g_fd < 0)
	{
		int err = errno;
		ROUTE_ERROR("create server socket failed![%d, %s]", err, strerror(err));
		return -1;
	}

    struct sockaddr_in servaddr;
	memset(&servaddr, 0 , sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(g_conf.route_port);
	if (inet_pton(AF_INET, g_conf.route_ip, &servaddr.sin_addr) <= 0)
	{
		int err = errno;
		ROUTE_ERROR("inet_pton failed![%d, %s]\n", err, strerror(err));
		close(g_fd);
		g_fd = -1;
		return -1;
	}

	if (connect(g_fd, (sockaddr *)&servaddr, sizeof(servaddr)) < 0)
	{
		int err = errno;
		ROUTE_ERROR("connect failed![%d, %s]\n", err, strerror(err));
		close(g_fd);
		g_fd = -1;
		return -1;
	}

    ROUTE_INFO("connect to route success! ip = %s port = %d\n", g_conf.route_ip, g_conf.route_port);

    return 0;
}

int destroy(){
    if(g_fd > 0)
        close(g_fd);

    return 0;
}

static int Recv(int fd, char* buf, int len){
    int ret = 0;
    if(len <= 0)
        return 0;

    while(1){
        int rlen = recv(fd, buf + ret, len - ret, 0);
        if(rlen == 0){
            ROUTE_ERROR("peer closed!\n");
            return -1;
        }

        if(rlen < 0 ){
            //����socket�������EANGIN
            if(errno == EINTR)
                continue;
			else
			{
				int err = errno;
				ROUTE_ERROR("recv data error:[%d, %s]\n",  err, strerror(err));
				return -1;
			}
        }

        ret += rlen;
        if(ret == len)
            break;
    }

    return ret;
}

static int Send(int fd, char* buf, int len)
{
	int ret = 0;
	if(len <= 0)
		return 0;

	while(1)
	{
		int slen = send(fd, buf+ret, len-ret, 0);
		if(slen < 0)
		{
		    //����socket�������EANGIN
			if(errno == EINTR)
				continue;
			else
			{
				int err = errno;
				ROUTE_ERROR("send data error:[%d, %s]\n",  err, strerror(err));
				return -1;
			}
		}

		ret += slen;
		if(ret == len)
			break;
	}

	return ret;
}

int route_msg(const char* sub_no, void* route_list, int cmdtype){
    ROUTE_DEBUG("in route_msg\n");

/***********************************
    route_info_list& rl = *(route_info_list*)route_list;
    rl.count = 1;

    strncpy(rl.route_item[0].instance_name, "paas",
        sizeof(rl.route_item[0].instance_name)); //ʵ����

    strncpy(rl.route_item[0].connect_string, "172.16.200.103|3311|paas|root|123",
    sizeof(rl.route_item[0].connect_string)); //���Ӵ�

    ROUTE_DEBUG("instance_name:%s connect_string:%s\n", rl.route_item[0].instance_name,
        rl.route_item[0].connect_string);

    return 0;

//for test!!!!
**************************************/

    if(g_fd < 0){
        if(connect_to_route() < 0){
            ROUTE_ERROR("connect to route failed.\n");
            return -1;
        }
    }
    ROUTE_DEBUG("g_fd = %d\n", g_fd);

    //ѹ���ݰ�
    bas::Protocal p;

    p << sub_no;
    p << cmdtype;

   char *buf = 0;
   int len = p.Encode(buf);

    ROUTE_DEBUG("sub_no:%s len = %d\n", sub_no, len);

    //�������ݰ�
    if (Send(g_fd, buf, len) < 0){
        close(g_fd);
        g_fd = -1;
        ROUTE_DEBUG("send data faield.\n");
        return -1;
    }

    //���հ�ͷ
    char rbuf[256];
    if(Recv(g_fd, rbuf, bas::HEADLEN) < 0){
        close(g_fd);
        g_fd = -1;
        ROUTE_DEBUG("recv data head failed. err = %s\n", strerror(errno));
        return -1;
    }

    if (0 != p.DecodeHead(rbuf)){
        ROUTE_ERROR("decode header failed!\n");
        return -1; //��ͷ����ȷ
    }

    //���հ���
    if((len = Recv(g_fd, rbuf + bas::HEADLEN, (int)p.data()->msgLen - bas::HEADLEN)) < 0){
        close(g_fd);
        g_fd = -1;
        ROUTE_DEBUG("recv data body failed.\n");
        return -1;
    }

    //���һ�ν��ճɹ���ʱ��
    g_alive_time = time(NULL);

    if(len != (int)p.data()->msgLen - bas::HEADLEN){
        ROUTE_ERROR("recv msg body failed, ret = %d\n", len);
        return -1;
    }

    if (0 != p.DecodeAns(rbuf)){
        ROUTE_ERROR("decode msg body failed.\n");
        return -1; //���ʧ��
    }

    if (p.data()->resultcode == 0){ //�����ѯ���Ϊ�ɹ�

        //ȡ�����ֵ
        route_info_list& rl = *(route_info_list*)route_list;
        bas::CR* cr = p.data();
        rl.count = cr->nodeMsgNum;
        ROUTE_DEBUG("resultcode = %d rl.count = %d\n", p.data()->resultcode, rl.count);
        for (int i = 0; i < rl.count; ++i){
            strncpy(rl.route_item[i].instance_name, cr->nodes[i].instanceName,
            sizeof(rl.route_item[i].instance_name)); //ʵ����
            strncpy(rl.route_item[i].connect_string, cr->nodes[i].connectStr,
            sizeof(rl.route_item[i].connect_string)); //���Ӵ�

            ROUTE_DEBUG("instance_name:%s connect_string:%s\n", rl.route_item[i].instance_name, rl.route_item[i].connect_string);
        }
    } else { //��ѯ���Ϊʧ��
        ROUTE_WARN("find route failed, subno = %s\n", sub_no);
        return -1;
    }

    return 0;
}

int route_heartbit(){
    time_t nowtime = time(NULL);
    if(nowtime - g_alive_time < g_conf.heartbit)
        return 0;

    if(g_fd < 0){
        if(connect_to_route() < 0){
            ROUTE_ERROR("connect to route failed.\n");
            return -1;
        }
    }

    //send heartbit
    bas::Protocal p;
    p << "0" << 0; //����������
    char *buf = 0;
    int len = p.Encode(buf);

    //�������ݰ�
    if (Send(g_fd, buf, len) < 0){
        close(g_fd);
        g_fd = -1;
        ROUTE_DEBUG("send heartbit faield.\n");
        return -1;
    }

    //���հ�ͷ
    char rbuf[90];
    if(Recv(g_fd, rbuf, bas::HEADLEN) < 0){
        close(g_fd);
        g_fd = -1;
        ROUTE_DEBUG("recv heartbit head failed. err = %s\n", strerror(errno));
        return -1;
    }

    if (0 != p.DecodeHead(rbuf)){
        ROUTE_ERROR("decode heartbit header failed!\n");
        return -1; //��ͷ����ȷ
    }

    //���հ���
    if ((len = Recv(g_fd, rbuf + bas::HEADLEN, (int)p.data()->msgLen - bas::HEADLEN)) < 0){
        close(g_fd);
        g_fd = -1;
        ROUTE_DEBUG("recv heartbit body failed.\n");
        return -1;
    }

    //����ʧ��
    if (0 != p.DecodeAns(rbuf)){
    	  close(g_fd);
    	  g_fd = -1;
        ROUTE_ERROR("decode heartbit body failed.\n");
        return -1; //���ʧ��
    }

    if (p.data()->resultcode == 1){ //����������Ϊʧ��
        close(g_fd);
        g_fd = -1;
        ROUTE_DEBUG("heartbit failed. need to reconnect\n");
        return -1;
    }

    ROUTE_INFO("%d second no data, send a heart beat.\n", g_conf.heartbit);
    //if heartbit success
    g_alive_time = time(NULL);
    return 0;
}


