#ifndef __QUERY_ROUTE_H__
#define __QUERY_ROUTE_H__

/*
*date:2011-05-18
*author:lqb
*/


#define ROUTE_DEBUG(...)\
    R5_DEBUG(g_r5_plog, ("[route] " __VA_ARGS__))
#define ROUTE_INFO(...)\
    R5_INFO(g_r5_plog, ("[route] " __VA_ARGS__))
#define ROUTE_ERROR(...)\
    R5_ERROR(g_r5_plog, ("[route] " __VA_ARGS__))
#define ROUTE_WARN(...)\
    R5_WARN(g_r5_plog, ("[route] " __VA_ARGS__))
#define ROUTE_TRACE(...)\
    R5_TRACE(g_r5_plog, ("[route] " __VA_ARGS__))


struct route_conf{
    char route_ip[16];
    int route_port;
    int heartbit;
};

class R5_Log;

extern "C" int initialize(const char* conf_file, R5_Log* plog);

extern "C" int destroy();

extern "C" int route_msg(const char* sub_no, void* route_list, int cmdtype);

extern "C" int route_heartbit();

int connect_to_route();

#endif
