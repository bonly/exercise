/*
*date:2011-05-18
*author:lqb
*/

#include <mysql.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>

//先采用string实现？
#include <string>
#include <map>
#include <vector>

#include "bill_query.h"
#include "comm_structs.h"


//from base lib
#include"iniconfig.h"
#include"r5api.h"


using namespace std;

R5_Log* g_r5_plog;
static MYSQL* g_querydb = NULL;
map<string, MYSQL*> g_mysql_map;

vector<table_name> g_table_vec;

int in_queue = 0;
int out_queue = 0;

//vector<table_info> g_table_vec;


static int MyMsgSend(int msqid, struct msgform *msgp, size_t msgsz, int msgflg)
{
    while(true)
    {
        int nRet = msgsnd(msqid, msgp, msgsz, msgflg);
        if(nRet < 0)
        {
            if(errno == EINTR)//被信号中断
            {
                continue;
            }
            else if(errno == EAGAIN)
            {

			return 0;


            }
            else//其他错误
            {
                return -2;
            }
        }
        else
        {
            return 0;
        }
    }
}


static int MyMsgRecv(int msqid, struct msgform *msgp, size_t msgsz, int msgtyp, int msgflg)
{
    int ret = 0;
    timeval t_begin, t_now;
    gettimeofday(&t_begin, 0);

    while (true)
    {
        if (0 >= (ret = msgrcv(msqid, msgp, msgsz, msgtyp, msgflg)))
        {
            gettimeofday(&t_now,0);
            if (t_now.tv_sec - t_begin.tv_sec > 5) //超时
               QUERY_ERROR("msg receive overtime\n");
                return -1;
        }
        else break;
    }
    return ret;
}


int initialize(const char* conf_file, R5_Log* plog){
    if(NULL == plog){
        fprintf(stderr, "plog is NULL!\n");
        return -1;
    }

    g_r5_plog = plog;

    bill_conf conf;
    memset(&conf, 0, sizeof(bill_conf));

    //读取配置文件
    IniConfig config;
    if (config.open(conf_file) < 0) {
        QUERY_ERROR("open file(%s) error!\n", conf_file);
        return -1;
    }

    const char* query = "BILL_QUERY";

    /* db_host */
    const char* db_host = config.getValue(query, "DB_HOST");
    if(db_host && strlen(db_host) != 0){
        strncpy(conf.db_host, db_host, PRO_DB_LEN);
    } else {
        QUERY_ERROR("read DB_HOST item failed, configure file:%s.\n", conf_file);
    	return -1;
    }

    /* db_dbname */
    const char* db_name = config.getValue(query, "BD_DBNAME");
    if(db_name && strlen(db_name) != 0){
        strncpy(conf.db_name, db_name, PRO_DB_LEN);
    } else {
    	QUERY_ERROR("read DB_DBNAME failed, configure file:%s\n", conf_file);
    	return -1;
    }

    /* db_username */
    const char* db_username = config.getValue(query, "DB_USERNAME");
    if(db_username && strlen(db_username) != 0){
        strncpy(conf.db_username, db_username, PRO_DB_LEN);
    } else {
        QUERY_ERROR("read DB_USERNAME failed, configure file:%s\n", conf_file);
        return -1;
    }

    /* db_password */
    const char* db_password = config.getValue(query, "DB_PASSWORD");
    if(db_password && strlen(db_password) != 0){
        strncpy(conf.db_password, db_password, PRO_DB_LEN);
    } else {
        QUERY_WARN("read db_password failed, configure file:%s\n", conf_file);
        //return -1;
    }

    /* db_port */
    const char* db_port = config.getValue(query, "DB_PORT");
    if(db_port && strlen(db_port) != 0){
        conf.db_port = atoi(db_port);
    } else {
        QUERY_ERROR("read db_port failed, configure file:%s\n", conf_file);
        return -1;
    }
       /// 读query_quene_in,失败返回 -1
    const char* query_quene_in = config.getValue(query, "QUERYDB_QUENE_IN");
    if (query_quene_in && strlen(query_quene_in) != 0)
    {
        in_queue = connectQueue(query_quene_in);
        if (in_queue < 0)
        {
            QUERY_ERROR("connect in queue [%s] failed.\n", query_quene_in);
            return -1;
        }
    }
    else
    {
        QUERY_ERROR("read QUERY_QUENE_IN item failed, configure file:%s.\n",
                    conf_file);
        return -1;
    }

    /// 读query_quene_out,失败返回 -1
    const char* query_quene_out = config.getValue(query, "QUERYDB_QUENE_OUT");
    if (query_quene_out && strlen(query_quene_out) != 0)
    {
        out_queue = connectQueue(query_quene_out);
        if (out_queue < 0)
        {
            QUERY_ERROR("connect out queue [%s] failed.\n", query_quene_out);
            return -1;
        }
    }
    else
    {
        QUERY_ERROR("read QUERY_QUENE_OUT item failed, configure file:%s.\n",
                    conf_file);
        return -1;
    }

    QUERY_INFO("in_queue:%d out_queue:%d\n", in_queue, out_queue);

/*
    //初始化数据库连接
    g_querydb = mysql_init(0);
    if(NULL == g_querydb){
        QUERY_ERROR("mysql_init failed.\n");
        return -1;
    }

    if (!mysql_real_connect(g_querydb, conf.db_host, conf.db_username,
            conf.db_password, conf.db_name, conf.db_port, 0, 0)) {
        QUERY_ERROR("mysql: error=[%s]\n", mysql_error(g_querydb));
        return -1;
    }
*/

    return 0;
}

int destroy(){

    //关闭数据库连接
    if(NULL != g_querydb)
        mysql_close(g_querydb);

    map<string, MYSQL*>::iterator it;
    for(it = g_mysql_map.begin(); it != g_mysql_map.end(); ++it){
        if(NULL != it->second)
            mysql_close(it->second);

    }

    return 0;
}


int bill_query(const void* protocol, const void* route_result, void* bill, int* billlen){
    /// 检查入口指针是否为空,空则返回-1
    if(NULL == protocol || NULL == route_result || NULL == bill || NULL == billlen){
        QUERY_ERROR("param error, at least one params NULL!\n");
        return -1;
    }

    /// 把参数转换为对应的数据结构
    repair_protocol* proto = (repair_protocol*)protocol;
    route_info_list* route = (route_info_list*)route_result;

    /// 从协议结构中取出查询的号码
    long long number = strtoll(proto->sub_no, NULL, 10);
    /// 把号码 %100 即号码所在表的索引值
    //int tab_index = (int)(number % 5000);
    int tab_index = (int)(number % 5);
    /// 清空要查询的表名列表
    g_table_vec.clear();

    QUERY_INFO("query user:%s, time:%s\n", proto->sub_no, proto->query_time);

    *billlen = 0;
    char*p = (char*)bill;

    /// 尝试从所有路由服务器中获取数据所在的节点配置,并查询
    for(int i = 0; i < route->count; ++i){
        get_tables(proto, &(route->route_item[i])); /// 拼装所有符合条件的表名
        if(0 == query_bill(p, billlen, proto, &(route->route_item[i]))) /// 写消息队列并取回结果
            break;
    }

    /// 成功则返回0
    return 0;
}

///写消息队列并取回结果
int query_bill(char* buf, int* len, repair_protocol* protocol, route_info* route)
{
    char query[256];
    int n;
   //int seqno_buflen=28;
    char seqno_buf[30]={0};
    snprintf(seqno_buf,sizeof(seqno_buf),"Seqno=%s&Msg=",protocol->seqno);
    printf("seqno_buf=%s\n",seqno_buf);
    char* p = buf+PROTOCOL_HEAD_LEN;
    strcpy(p,seqno_buf);
    printf("frist buff=%s\n",buf+PROTOCOL_HEAD_LEN);
    p+=strlen(seqno_buf);
    int table_count = 0;
    pid_t pid=getpid();

    /// 遍历处理要查询的表
    for(vector<table_name>::iterator it = g_table_vec.begin(); it != g_table_vec.end(); ++it)
    {
        /// 初始化请求结构体
        request_message request;
        memset(&request, 0, sizeof(request));

        /// 填充请求结构体
        strcpy(request.connect_str, route->connect_string);
        strcpy(request.table_name, it->name);
        strcpy(request.sub_no, protocol->sub_no);
        strcpy(request.start_time, protocol->begin_date);
        strcpy(request.end_time, protocol->end_date);

        /// 定义消息队列规定的结构体
        struct msgform ms;

        /// 用进程号填充消息类型
        ms.mtype = pid;

        /// 把请求结构填充到消息体
        memcpy(ms.mtext, &request, sizeof(request));

        /// 发送消息到队列中,失败则返回-1
        if(MyMsgSend(out_queue, &ms, sizeof(request), 0) < 0)
        {
            QUERY_ERROR("MyMsgSend failed. out_queue = %d err = %s\n", out_queue, strerror(errno));
            return -1;
        }
        ++table_count;
        printf("table_count=%d\n",table_count);
    }

    int msglen = 0;
    int flag = 0;
    bool finish = false;
    int count = 0;
    int current_num = 0;

    while(table_count>0)
    {
        if(finish == true)  /// 检查记录结束标志终止循环
            break;

        struct msgform ms;
        
        /// 从队列中接收消息, 失败则返回已收到的消息长度
        int nLen = MyMsgRecv(in_queue, &ms, sizeof(ms.mtext), pid, IPC_NOWAIT);
        if(nLen < 0)
        {
            QUERY_ERROR("msgrcv failed(%d):%s\n", nLen, strerror(errno));
            return nLen;
        }

        /// 把消息中的用户消息体部分的头4位数据复制到flag(标识是否分包)中,并后移4位
        char* ptr = ms.mtext;
        memcpy(&flag, ptr, 4);
        ptr += 4;

        /// 取消息长度,读取后后移4位
        memcpy(&msglen, ptr, 4);
        ptr += 4;

        /// 取总记录数
        memcpy (&count, ptr, 4);
        ptr += 4;

        /// 取当前记录号
        memcpy (&current_num, ptr, 4);
        ptr += 4;

        /// flag标识为0,且是最后一条记录时,则说明是一条完整的请求已完成,1:分包
        if (flag == 0 && (count == current_num))
        {
            --table_count; ///标识完成一个表
            if (table_count==0)
                finish = true; ///如果所有表结果都收完了标识结束
        }

        //QUERY_DEBUG("recv one msg. flag = %d msglen = %d i = %d\n", flag, msglen, i);
        if(msglen == 0)  /// 消息长度为0则重新开始读
            continue;

        /// 把指定长度的消息内容复制到返回缓冲区中
        memcpy(p, ptr, msglen);
        *len += msglen;
        p += msglen;
    }
     QUERY_DEBUG("2 buff:%s\n", buf+PROTOCOL_HEAD_LEN+strlen(seqno_buf));
	 ///添加协议头
	p = buf;
    *len += PROTOCOL_HEAD_LEN;

    protocol_head* header = &(protocol->header);

    memcpy(p, header->command, PRO_COMMAND_LEN);
    p += PRO_COMMAND_LEN;
    *p = '\0';
    p++;

    memcpy(p, header->sequence, PRO_SEQUENCE_LEN);
    p += PRO_SEQUENCE_LEN;
    *p = '\0';
    p++;

    snprintf(p, PRO_LENGTH_LEN, "%d", *len);
    p += PRO_LENGTH_LEN;
    *p = '\0';
    p++;

    memcpy(p, header->system, PRO_SYSTEM_LEN);
    p += PRO_SYSTEM_LEN;
    *p = '\0';
    p++;

    //encrypt_flag
    *p = '0';
    p++;

    //errcode
    if(0 == protocol->result_code){
        *p = '0';
        p++;
    } else {
       *p = '1';
       p++;
    }

    //morepkt
    *p = '0';
    p++;

    memcpy(p, header->decompresslen, PRO_DECOM_LEN);
    p += PRO_DECOM_LEN;
    QUERY_DEBUG("msg:%s\n", buf);
   //free(seqno_buf);
    return 0;  /// 成功则返回0
}

/// 连接数据库产生的心跳
void db_heartbit(){
    /// 遍历ping所有MSQL连接,失败的存放到vector中
    map<string, MYSQL*>::iterator it = g_mysql_map.begin();
    vector<map<string, MYSQL*>::iterator> lost_net;
    for (; it != g_mysql_map.end(); ++it)
    {
        if (0 != mysql_ping (it->second))
        {
           lost_net.push_back(it);
        }
    }
    /// 从map中删除所有失效的连接
    vector<map<string, MYSQL*>::iterator>::iterator plost = lost_net.begin();
    for (; plost != lost_net.end(); ++plost)
    {
        g_mysql_map.erase (*plost);
    }
}

///连接数据库
int connect_mysql(const char* connect_str){
    string str_con(connect_str);
    char *str = (char*)connect_str;
    bill_conf conf;
    memset(&conf, 0, sizeof(conf));

    //default username:'root'
    //default password:null
    strncpy(conf.db_username, "root", PRO_DB_LEN);

    do{
        char* p = strchr(str, '|');
        if(NULL == p){
            return -1;
        }
        memcpy(conf.db_host, str, p - str);
        str = p + 1;

        p = strchr(str, '|');
        if(NULL == p){
            return -1;
        }
        char tmp[8] = {0};
        memcpy(tmp, str, p - str);
        conf.db_port = atoi(tmp);
        str = p + 1;

        p = strchr(str, '|');
        if(NULL == p){
            strncpy(conf.db_name, str, PRO_DB_LEN);
            break;
        }
        memcpy(conf.db_name, str, p - str);
        str = p + 1;

        memset(conf.db_username, 0, sizeof(conf.db_username));
        p = strchr(str, '|');
        if(NULL == p){
            strncpy(conf.db_username, str, PRO_DB_LEN);
            break;
        }
        memcpy(conf.db_username, str, p - str);
        str = p + 1;

        strncpy(conf.db_password, str, PRO_DB_LEN);
    }while(0);

    //初始化数据库连接
    MYSQL* db = mysql_init(0);
    if(NULL == db){
        QUERY_ERROR("mysql_init failed.\n");
        return -1;
    }

    if (!mysql_real_connect(db, conf.db_host, conf.db_username,
            conf.db_password, conf.db_name, conf.db_port, 0, 0)){
        QUERY_ERROR("mysql: error=[%s]\n", mysql_error(db));
        return -1;
    }

    g_mysql_map.insert(make_pair<string, MYSQL*>(str_con, db));
    map<string, MYSQL*>::iterator it = g_mysql_map.find(str_con);
    if(it == g_mysql_map.end())
        return -1;

    QUERY_INFO("connect to mysql success! constr = %s\n", connect_str);

    return 0;
}

int get_tables(repair_protocol* protocol, route_info* route){
    char date_begin[8] = {0};
    char date_end[8] = {0};

    memcpy(date_begin, protocol->begin_date, 6);
    memcpy(date_end, protocol->end_date, 6);
    int d_begin = atoi(date_begin);
    int d_end = atoi(date_end);

    /// 电话号码模分表数,得到号码所在的哈希桶
    long long number = strtoll(protocol->sub_no, NULL, 10);
    int tab_index = (int)(number % 5);

    QUERY_DEBUG("begin:%d end:%d index:%d\n", d_begin, d_end, tab_index);

    /// 从数据库连接池中取出可用的连接,没有就创建并存入池中
    string str(route->connect_string);
    map<string, MYSQL*>::iterator it = g_mysql_map.find(str);
    if(it == g_mysql_map.end()){
        if(connect_mysql(route->connect_string) < 0){
            QUERY_WARN("connect to mysql faield. con_str = %s\n", route->connect_string);
            return -1;
        }
    }

    it = g_mysql_map.find(str);
    MYSQL* db = it->second;

/*
    //MYISAM表
    for(int i = d_begin; i <= d_end; ++i){
        for(int type = 1; type < 8; ++type){
            table_name table;
            snprintf(table.name, sizeof(table.name), "BILL_%06d_%02d_%02d", i, type, tab_index);
            g_table_vec.push_back(table);
            QUERY_DEBUG("table:%s\n", table.name);
        }
    }
*/
    //innodb表中查找库表
    find_innodb_table(d_begin, d_end, tab_index, db);

/*just for test*************************************
//#if 0
            table_name table;
            snprintf(table.name, sizeof(table.name), "BILL_201106_01_%02d",  tab_index);
            g_table_vec.push_back(table);
            QUERY_DEBUG("table:%s\n", table.name);
//#endif
/*just for test*************************************/

    return 0;
}


int find_innodb_table(int begin, int end, int index, MYSQL* db)
{
    char query[256] = {0};

    const int len = snprintf(query, sizeof(query),
        "select tablename, Table_num from indb_newtable_record where status != 2 and time >= %d and time <= %d",
        begin, end);
    QUERY_DEBUG("SQL:%s\n", query);

    const int r = mysql_real_query(db, query, len > 0 ? len : 0);
    if (r != 0){
        QUERY_ERROR("mysql: error=[%s]\n", mysql_error(db));
        return -1;
    }

    MYSQL_ROW row = 0;
    unsigned long *lengths = 0;
    //unsigned int num_rows = 0;
    unsigned int num_flds = 0;
    MYSQL_RES *res = mysql_store_result(db);


    if (res != 0) 
    {
        num_flds = mysql_num_fields(res);

        while ((row = mysql_fetch_row(res)))
        {
            QUERY_DEBUG("num_flds:%d\n", num_flds);
            lengths = mysql_fetch_lengths(res);

            if(2 == num_flds)
            {
                table_name table;
                memset(&table, 0, sizeof(table_name));
                if(0 == strncmp(row[0], "BILL_HISTORY", 12))
                {
                    snprintf(table.name, sizeof(table.name), "%s_%03d", row[0], atoi(row[1]));
                    g_table_vec.push_back(table);
                    QUERY_DEBUG("table:%s\n", table.name);
                } 
                else 
                {
                    snprintf(table.name, sizeof(table.name), "%s_%04d_%03d", row[0],
                        index, atoi(row[1]));
                    g_table_vec.push_back(table);
                    QUERY_DEBUG("table:%s\n", table.name);
                }

            }
        }
    }

    mysql_free_result(res);

    return 0;
}

