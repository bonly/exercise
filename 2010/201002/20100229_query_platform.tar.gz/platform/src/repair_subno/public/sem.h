#ifndef __SEM_H__
#define __SEM_H__
/*
*
*
*/

#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>

#include "type.h"

union semun
{
	int val;
	struct semid_ds *buf;
	unsigned short * ary;
};


class Csem
{
public:

	enum
	{
		TOCK_ERROR = 1001,		//ftok����
		SEMGET_ERR = 1002,		//semget���ô���
		SEMCTL_ERR = 1003,		//semctl���ô���
		SEMID_ERR  = 1004,		//semid С��0������û�г�ʼ����
		INDEX_ERR  = 1005,		//p/v����ʱ��index����
		SEMATTACH_ERR = 1006,

	};


	Csem();
	Csem(const char* sem_file);

	~Csem();

	int create(const char* sem_file);

    int attach(const char* sem_file);

	void destroy();

	bool is_exist(const char* sem_file);

	int p(int index);
	int p_wait(int index, int timeout = 0);
	int v(int index);

    bool operator !()
    {
        return m_err != 0;
    }

	int error()
	{
		return m_err;
	}

	int init();
private:



	int m_semid;
	int m_err;
};

#endif
