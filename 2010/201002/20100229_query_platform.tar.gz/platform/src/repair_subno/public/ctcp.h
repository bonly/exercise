/*


*/

#ifndef __C_TCP_H__
#define __C_TCP_H__

#include "type.h"

//#include "CLog.h"

//using namespace std;


class CTcp
{
public:
	int recv_data(int fd);
	
	int send_data(int fd);	
	
	//void SendErrorData(int fd, int errcode, int closetype=FD_CLOSE);
	void reset_fd(int fd);
	void parse_head(int fd);
	void init_fd(int fd);
private:
	bool recv_head(int fd);
	bool recv_content(int fd);
	

	Con& get_tcp_con(int fd);

	int send(int fd, char* buf, int len);
	int recv(int fd, char* buf, int len);
	void set_fd_status(int fd, int status);
	int get_session_cnt(int fd);
	void discard_data(int fd);

	private:
		short  m_gsid;// game server id 
		int  m_headFlag;
		short  m_ver;
		int  m_dataLen;
};

#endif


