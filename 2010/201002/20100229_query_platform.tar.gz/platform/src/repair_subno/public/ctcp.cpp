/*


create at 24/09/07
*/

#include <string>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <iostream>

#include "type.h"
#include "ctcp.h"

using namespace std;

extern struct FDList g_con[FD_SIZE]; 
extern struct SysConfig g_conf;

//#ifdef _TMP_INT_TEST_
extern struct ProcessStatus g_pstatus;
//#endif


extern CGsp* GetGsConnection(int gsflg);

bool CTcp::RecvData(int fd)
{
	Con& hcon = GetTcpCon(fd);
	if(hcon.SBuf.BufStatus != hcon.SBuf.BufOk && 
		hcon.SBuf.BufStatus != hcon.SBuf.RecvHead && 
			hcon.SBuf.BufStatus != hcon.SBuf.RecvContent || hcon.SBuf.IsDeny == true)
	{
			DiscardData(fd);
			return false;
	}


	if(hcon.SBuf.BufStatus == hcon.SBuf.BufOk)
	{
		hcon.SBuf.RecvPos = 0;
		hcon.SBuf.RecvLen = 0;
		hcon.SBuf.BufStatus = hcon.SBuf.RecvHead;//set init value
	}

	if(hcon.SBuf.BufStatus== hcon.SBuf.RecvHead)
	{//head isn't recv complete; user->cs
		if(!RecvHead(fd)){
			LOG(CLog::log_dbg, "recv head failed:[%s]",  hcon.SBuf.RecvBuf);	
			return false;
		}


		ParseHead(fd);
	
		
		//set head and body (base on CS-GS protocal)
		GSHead* phead = (GSHead*)(hcon.SBuf.RecvBuf);
		phead->cmdType = htons(CMD_USER_DATA);
		phead->ver =  htons(g_conf.version);

	#ifdef _PACK_SESS_
		phead->packsessid = htonl(g_gs_pack_sessid);
		g_gs_pack_sessid++;
	#endif
	
		phead->length = htonl(sizeof(GSDataBody) + hcon.SBuf.RecvLen);
		
		GSDataBody* pbody = (GSDataBody*)(hcon.SBuf.RecvBuf + sizeof(GSHead));
		pbody->fd = fd;
		pbody->sessionid = GetSessionCnt(fd);	
				
		hcon.SBuf.BufStatus = hcon.SBuf.RecvContent;
	}


	if(hcon.SBuf.BufStatus == hcon.SBuf.RecvContent)
	if(RecvContent(fd))
	{//recv all
		g_pstatus.request_count++;
		

		CGsp* pgs = GetGsConnection(hcon.SBuf.Gsid);
		if(pgs == NULL)
		{
		//	LOG(CLog::log_dbg, "send error data to client!game server not exist![%d]", gsflg);	

			SendErrorData(fd, CS_SRV_NOTEXIST, FD_SHUTDOWN);
			return true;
		}
		hcon.SBuf.RecvLen += sizeof(GSHead) + sizeof(GSDataBody);
		hcon.SBuf.BufStatus = hcon.SBuf.SendToGS;
		hcon.SBuf.RecvPos = 0;
		
		//add data to gs fd list
		pgs->InsertClientFd(fd);

	}

	return true;
}


/*

Maybe need some chage !!!!
*/

void CTcp::ParseHead(int fd){
	
	Con& hcon = GetTcpCon(fd);

	int iLen = 0;
	short tmpShort;
	int tmpInt;

		
	memcpy(&tmpInt,hcon.SBuf.RecvBuf + iLen + sizeof(GSDataBody),sizeof(short));
	m_headFlag = ntohl(tmpInt);
		
	if(m_headFlag != 123){
		//LOg
				
		}

	iLen += sizeof(int);
	memcpy(&tmpShort,hcon.SBuf.RecvBuf + iLen + sizeof(GSDataBody),sizeof(short));
	m_ver= ntohs(tmpShort);
	if(m_ver != 1){
		//LOg
				
		}

	iLen+= sizeof(short);
	memcpy(&tmpShort,hcon.SBuf.RecvBuf + iLen + sizeof(GSDataBody),sizeof(short));
	m_gsid = ntohs(tmpShort);
	

	if(m_gsid < 0){
		//LOg
				
		}
	else
		hcon.SBuf.Gsid = m_gsid;
		
	
	iLen+= sizeof(short);
	memcpy(&tmpInt,hcon.SBuf.RecvBuf + iLen + sizeof(GSDataBody),sizeof(int));
	m_dataLen= ntohl(tmpInt);
	
	if(m_dataLen < 0 || m_dataLen > BUFSIZE){
		//LOg
				
		}
	hcon.SBuf.RecvLen = m_dataLen;

	iLen+= sizeof(int);
	hcon.SBuf.HeadLen = iLen;
	
}

bool CTcp::RecvContent(int fd)
{
	int len = 0;
	Con& hcon = GetTcpCon(fd);	

	if(hcon.SBuf.RecvPos >= hcon.SBuf.HeadLen + hcon.SBuf.RecvLen)
		return true;
	
	while(1)
	{
		//len = Recv(fd, hcon.SBuf.RecvBuf + sizeof(GSHead) + sizeof(GSDataBody)  - hcon.SBuf.HeadLen + hcon.SBuf.RecvPos, 
		//	hcon.SBuf.HeadLen + hcon.SBuf.RecvLen  - hcon.SBuf.RecvPos);		

		len = Recv(fd, hcon.SBuf.RecvBuf+hcon.SBuf.RecvPos, 
			hcon.SBuf.HeadLen + hcon.SBuf.RecvLen  - hcon.SBuf.RecvPos);	
			
		if(len <= 0)
		{
			LOG(CLog::log_dbg, "recv [fd=%d]content data error!len=%d", fd, len);
			break;
		}
		hcon.SBuf.RecvPos += len;
		
		
		if(hcon.SBuf.RecvPos >= hcon.SBuf.HeadLen + hcon.SBuf.RecvLen)
		{
			LOG(CLog::log_dbg, "recv [fd=%d]content data len=%d", fd, len);
			
			return true;
		}
		else
		{
			LOG(CLog::log_dbg, "recv [fd=%d]content data len=%d", fd, len);
		}
	}

	return false;
}

bool CTcp::RecvHead(int fd)
{
	Con& hcon = GetTcpCon(fd);
	int rlen = 0; 

	int headlen = sizeof(TcpHead);//TcpHead
	
	if(hcon.SBuf.RecvPos < headlen){
		
	rlen = Recv(fd, hcon.SBuf.RecvBuf+hcon.SBuf.RecvPos + sizeof(GSDataBody), 
		sizeof(hcon.SBuf.RecvBuf)  - hcon.SBuf.RecvPos - sizeof(GSDataBody));

	if(rlen <= 0)
		return false;
	
	hcon.SBuf.RecvPos += rlen;
	
	if(hcon.SBuf.RecvPos  < headlen)
		return false;
	
	}

	return true;
	
}


int CTcp::SendData(int fd)
{
	Con& hcon = GetTcpCon(fd);
	if(hcon.SBuf.BufStatus != hcon.SBuf.SendToUser)
		return 0;
	//for dbg

	//TcpHead * head = (TcpHead*) hcon.SBuf.SendBuf;
	//int tmpi;
	//memcpy(&tmpi,hcon.SBuf.SendBuf + 8,sizeof(int));
	//int dlen = ntohl(tmpi);
	
	//LOG(CLog::log_dbg, "before send , len=%d", dlen);
	int len = Send(fd, hcon.SBuf.SendBuf+hcon.SBuf.SendPos, 
			hcon.SBuf.SendLen-hcon.SBuf.SendPos);
	
	hcon.SBuf.SendPos += len;
	LOG(CLog::log_dbg, "send data to client, len=%d, send size=%d", 
			hcon.SBuf.SendLen, len);

	if(hcon.SBuf.SendPos == hcon.SBuf.SendLen)
	{//send ok
		hcon.SBuf.BufStatus = hcon.SBuf.BufOk;
		hcon.SBuf.SendPos = 0;
		hcon.SBuf.SendLen = 0;
		hcon.SBuf.HeadLen = 0;
		hcon.SBuf.RecvFromGsDataLen = 0;
		hcon.SBuf.RecvLen = 0;
		hcon.SBuf.RecvPos = 0;
		hcon.SBuf.SendLen = 0;
		hcon.SBuf.SendPos = 0;
		
		//if(!hcon.IsKeepAlive)
		//	FdShutDown(fd);
	}

	return 1;
}

Con& CTcp::GetTcpCon(int fd)
{
	return g_con[fd].UserCon;
}

int CTcp::Recv(int fd, char* buf, int len)
{
	int ret = 0, rlen;
	if(len < 0)
		return 0;
	
	Con& hcon = GetTcpCon(fd);

	while(1)
	{
		rlen = recv(fd, buf+ret, len-ret, 0);
#ifdef _PACK_SESS_	
//		if(rlen > 0)
//			LogHex((char*)buf,  rlen, 1);
#endif			
		if(rlen == 0)
		{
			int iErrno = errno;
			LOG(CLog::log_dbg, "recv data error, datalen=0:[%d, %s]",  iErrno, strerror(iErrno));
			SetFdStatus(fd, Con::Broken);
			return 0;
		}
		else if(rlen < 0)
		{
			int iErrno = errno;
			if(iErrno == EINTR)
				continue;
			else if(iErrno == EAGAIN || iErrno == EWOULDBLOCK)
			{
				break;		
			}
			else
			{
				SetFdStatus(fd, Con::Broken);
				LOG(CLog::log_dbg, "recv data error:[%d, %s]",  iErrno, strerror(iErrno));
				break;
			}
		}

		ret += rlen;
		if(ret == len)
			break;
	}


	LOG(CLog::log_dbg, "recv [fd=%d]data datalen=%d", fd, ret);

	if(ret > 0)
	{
	
		hcon.ActiveTime = (int)time(NULL);
	}
	return ret;
}


int CTcp::Send(int fd, char* buf, int len)
{
	int ret = 0;
	if(len <= 0)
		return 0;
	
	while(1)
	{
		int slen = send(fd, buf+ret, len-ret,  0);
		if(slen < 0)
		{
			if(errno == EINTR)
				continue;
			else if(errno == EAGAIN || errno == EWOULDBLOCK)						
				break;
			else
			{
				int iErrno = errno;
				LOG(CLog::log_err, "send data error:[%d, %s]",  iErrno, strerror(iErrno));
				SetFdStatus(fd, Con::Broken);
				return 0;
			}
		}

		ret += slen;
		if(ret == len)
			break;
	}

	if(ret > 0)
		GetTcpCon(fd).ActiveTime = (int)time(NULL);
	return ret;
}


void CTcp::ResetFd(int fd)
{
	close(fd);
	Con& hcon = GetTcpCon(fd);

	g_con[fd].Type = 0;

	hcon.SBuf.Gsid = 0;
	hcon.Status = hcon.Broken;
	hcon.SBuf.BufStatus = hcon.SBuf.BufOk;
	hcon.SBuf.RecvPos = 0;
	hcon.SBuf.SendPos = 0;
	hcon.SBuf.SendLen = 0;
	hcon.SBuf.RecvLen = 0;
	hcon.SBuf.RecvFromGsDataLen = 0;
	hcon.SBuf.HeadLen = 0;
	hcon.SBuf.IsDeny = false;
	LOG(CLog::log_dbg, "reset fd by cs![%d]", fd);	
}


int CTcp::GetSessionCnt(int fd)
{
	return g_con[fd].SessionCnt;
}

void CTcp::SendErrorData(int fd, int errcode, int closetype)
{
	//MakeHead(fd, errcode, 0);
	Con& hcon = GetTcpCon(fd);
	hcon.SBuf.BufStatus = hcon.SBuf.SendToUser;
	hcon.SBuf.RecvPos = 0;
	hcon.SBuf.SendPos = 0;
	//hcon.IsKeepAlive = false;
	
	if(errcode == CS_REQ_IP_LIMIT)
		hcon.SBuf.IsDeny = true;

	LOG(CLog::log_dbg, "send error data to client![%d]", errcode);	

	SendData(fd);

	if(closetype == FD_CLOSE)
	{
		SetFdStatus(fd, Con::Broken);
	}
}


void CTcp::SetFdStatus(int fd, int status)
{
	Con& hcon = GetTcpCon(fd);
	hcon.Status = status;
}

void CTcp::DiscardData(int fd)
{
	int len = 1, rsum= 0;
	char buf[256];
	
	while(len > 0)
	{
		len = Recv(fd, buf, sizeof(buf));
		rsum += len;
		if(rsum > BUFSIZE)
		{
			SetFdStatus(fd, Con::Broken);
			break;
		}
	}
}

void CTcp::InitFd(int fd)
{
	Con& hcon = GetTcpCon(fd);
	hcon.SBuf.BufStatus = hcon.SBuf.BufOk;
	hcon.SBuf.Gsid = 0;
	hcon.SBuf.SendPos = 0;
	hcon.SBuf.SendLen = 0;
	hcon.SBuf.HeadLen = 0;
	hcon.SBuf.RecvFromGsDataLen = 0;
	hcon.SBuf.RecvLen = 0;
	hcon.SBuf.RecvPos = 0;
	hcon.SBuf.SendLen = 0;
	hcon.SBuf.SendPos = 0;
	hcon.SBuf.IsDeny = false;
}

