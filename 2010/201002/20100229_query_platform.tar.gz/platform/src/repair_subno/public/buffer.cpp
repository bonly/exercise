/*
*
*/

#include <string.h>
#include <stdio.h>

#include"buffer.h"
//#include"config.h"

buffer::buffer()
{
	m_base = NULL;
	m_buffsize = 0;
	m_read = 0;
	m_write = 0;
	m_index = -1;
	m_datasize = 0;
	m_freesize = 0;
	m_shm = NULL;
	m_head = NULL;
	memset(m_errbuf, 0, sizeof(m_errbuf));
	m_semaphore = NULL;	
}

buffer::~buffer()
{
}

int buffer::set_sem(Csem *p_sem)
{
    if(p_sem)
    {
        m_semaphore = p_sem;
        return 0;   
    }    
    
    return -1;
}


const char* buffer::error() const
{
	return m_errbuf;
}

//
int buffer::attach_shm(share_mem* shm, int index)
{
	if(NULL == shm)
	{
		memset(m_errbuf, 0, sizeof(m_errbuf));
		snprintf(m_errbuf, sizeof(m_errbuf) - 1 , "in attach_shm, shm is NULL!\n");		
		return -1;	
	}
	
	m_shm = shm;
	
	shm_header *shm_header = m_shm->get_shm_header();
	int block_cnt = shm_header->block_cnt;
	if(block_cnt < BLOCK_CNT_MIN || block_cnt > BLOCK_CNT_MAX)
	{
		memset(m_errbuf, 0, sizeof(m_errbuf));
		snprintf(m_errbuf, sizeof(m_errbuf) -1, "in attach_shm,  blcok_cnt error!cnt = %d\n", block_cnt);	    
	    return -1;           
	}    	
		
	if(index < 0 || index >= block_cnt)
	{
		memset(m_errbuf, 0, sizeof(m_errbuf));
		snprintf(m_errbuf, sizeof(m_errbuf), "in attach_shm, index error, index = %d\n", index);
		return -1;	
	}	
	
	block *pblock = &(m_shm->m_pblock[index]);
	m_head = pblock->pheader;
	
	m_base = pblock->pbody;
	m_head->size = shm_header->block_size;
	
	m_buffsize = shm_header->block_size;
	m_freesize = shm_header->block_size;
	m_index = index;
	
	m_read = m_head->readpos;
	m_write = m_head->writepos;
	
	return 0;
}

int buffer::lock_wait(int timeout)
{
    if(m_semaphore && m_semaphore->p_wait(m_index, timeout) == 0)//lock success
	{
		return 0;
	}	
	
	return -1;
}

int buffer::lock()
{
	if(m_semaphore && m_semaphore->p(m_index) == 0)//lock success
	{
		return 0;
	}	
	
	return -1;
}
	
int buffer::unlock()
{
	if(m_semaphore && m_semaphore->v(m_index) == 0)
	{
		return 0;	
	}	
	
	return -1;
}	
	
//��ȡ�����������ݵĴ�С	
int buffer::get_data_size()
{
	if(NULL == m_shm)
	{
		return -1;	
	}	
    
	m_read = m_head->readpos;
	m_write = m_head->writepos;
	m_buffsize = m_head->size;
	
	m_datasize = (m_write - m_read >= 0) ? m_write - m_read : m_buffsize - (m_read - m_write);
		
	return m_datasize;			
}
	
	
//��ȡ���л�������С	
int buffer::get_free_size()
{
	if(NULL == m_shm)
	{
		return -1;	
	}	

	m_read = m_head->readpos;
	m_write = m_head->writepos;
	m_buffsize = m_head->size;

	m_freesize = m_write - m_read >= 0 ? m_buffsize - (m_write - m_read) : m_read - m_write;
		
	return m_freesize;	
}
	
	
//����Ҫ��Ҫ����һ���ٽ���һ�Σ�	
void buffer::clear()
{
    m_base = NULL;
	m_buffsize = 0;
	m_read = 0;
	m_write = 0;
	m_index = -1;
	m_datasize = 0;
	m_freesize = 0;
	m_shm = NULL;
	m_head = 0;	
	memset(m_errbuf, 0, sizeof(m_errbuf));	
	m_semaphore = NULL;
}	
	

//��ȡЭ��ͷ��ֻ���������ƶ���ָ��
int buffer::get_head(char* dest, int rlen)
{
	if(rlen > m_datasize)
	{
		return -1;	
	}	
	
	if(m_buffsize - m_read >= rlen)
	{
		memcpy(dest, m_base + m_read, rlen);		
	}		
	else
	{
		int tmp = m_buffsize - m_read;
		
		memcpy(dest, m_base + m_read, tmp);
		memcpy(dest + tmp, m_base, rlen - tmp);	
	}	
	
	return 0;
}
	
int buffer::clear_bufdata()
{
    if(NULL == m_base)
        return -1;
        
	shm_header *shm_header = m_shm->get_shm_header();
	if(NULL == shm_header)
	{
	    return -1;   
	}    
	
    m_head->readpos = 0;
    m_head->writepos =0;
    m_read = 0;
	m_write = 0;
	
	m_datasize = 0;
	m_freesize = shm_header->block_cnt;
	
	return 0;
}


//�ӻ�������ȡ���ݣ�ͬʱ�ƶ���ָ��	
//�ú���������get_data_size()����ʹ�������ⲿ����
int buffer::read(char* dest, int rlen)
{   
	if(rlen > m_datasize)
	{
		return -1;	
	}		
	
	if(m_buffsize - m_read >= rlen)
	{
		memcpy(dest, m_base + m_read, rlen);	
	}		
	else
	{
		int tmp = m_buffsize - m_read;
		
		memcpy(dest, m_base + m_read, tmp);
		memcpy(dest + tmp, m_base, rlen - tmp);
	}	
		
	return 0;	
}


//�򻺳���д�����ݣ�ͬʱ�ƶ�дָ��
//�ú���������get_free_size()����ʹ�������ⲿ����
int buffer::write(const char* src, int wlen)
{ 
	if(m_freesize < wlen)
	{
		return -1;
	}	
	
	if(m_buffsize - m_write > wlen)
	{
		memcpy(m_base + m_write, src, wlen);	
	}	
	else
	{
		int tmp = m_buffsize - m_write;
		
		memcpy(m_base + m_write, src, tmp);
		memcpy(m_base, src + tmp, wlen - tmp);
	}
	
	return 0;					
}


//�ı�дָ��λ��
void buffer::set_write_ptr(int size)
{
	if(m_buffsize - m_head->writepos >= size)
	{
		m_head->writepos += size;	
	}	
	else
	{
		int tmp = m_buffsize - m_head->writepos;
		m_head->writepos = size - tmp;
	}   
}

//�ı��ָ��λ��    
void buffer::set_read_ptr(int size)
{
	if(m_buffsize - m_head->readpos >= size)
	{	
		m_head->readpos += size;
	}		
	else
	{
		int tmp = m_buffsize - m_head->readpos;
		m_head->readpos = size - tmp;	
	}    
}
	
int buffer::is_full() const
{
	return 0;	
}	

int buffer::is_empty() const
{
	return 0;
}


