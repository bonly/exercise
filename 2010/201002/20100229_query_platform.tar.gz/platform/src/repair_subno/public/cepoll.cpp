#include <errno.h>
#include <sys/epoll.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <linux/unistd.h>

#include <stdio.h>

#include "r5log.h"

#include "type.h"
#include "cepoll.h"

using namespace std;

CEpoll::CEpoll(int fdsize, int eventsize, int waittime)
:m_fd_size(fdsize),m_event_size(eventsize), m_epoll_wait_time(waittime){
	m_pevent = NULL;
	m_epoll_fd = 0;
}


CEpoll::~CEpoll(){
    if(NULL != m_pevent){
	    delete []m_pevent;
	    m_pevent = NULL;
    }
    
	close(m_epoll_fd);
}

int CEpoll::add_fd(int fd, int event)
{
	if(RE_SUCCESS != set_no_block(fd))
		return RE_FAILED;

	struct epoll_event ev;
	ev.data.fd = fd;
	ev.events=event;
	
	if(epoll_ctl(m_epoll_fd, EPOLL_CTL_ADD, fd, &ev) < 0)
	{
		int err = errno;
		//LOG(CLog::log_err, "CEpoll::AddFd, epoll_ctl error,[%s]", strerror(err));
		return RE_FAILED;
	}

	return RE_SUCCESS;
}

int CEpoll::delete_fd(int fd)
{
	struct epoll_event ev;
	//m_epoll_fd��epoll_create(int size)�ķ���ֵ��size����Ҫ�����ļ�������Ŀһ���ж��
	if(epoll_ctl(m_epoll_fd, EPOLL_CTL_DEL, fd, &ev) < 0)
	{
		int err = errno;
		//LOG(CLog::log_err, "CEpoll::DeleteFd, epoll_ctl errno=%d,[%s]", iErrno,  strerror(err));
		return RE_FAILED;
	}

	return RE_SUCCESS;
}

int CEpoll::wait(vector<EpollEve>& eventVec){
	//�ú���������Ҫ�������¼���Ŀ���緵��0��ʾ�ѳ�ʱ
	int ret = epoll_wait(m_epoll_fd, m_pevent, m_event_size, m_epoll_wait_time);
	if(ret == -1)
	{
	    return RE_FAILED;
	}

	struct EpollEve ev;
	for(int i = 0; i < ret; ++i)
	{
		ev.fd = m_pevent[i].data.fd;
		ev.events = m_pevent[i].events;
		eventVec.push_back(ev);
	}

	return RE_SUCCESS;
}

int CEpoll::init()
{
	m_epoll_fd = epoll_create(m_fd_size);
	int err = errno;
	if(m_epoll_fd <= 0){
		//LOG(CLog::log_err, "CEpoll::Init, epoll_create error,[%s]", strerror(iErrno));
		return RE_FAILED;
	}

	m_pevent = new struct epoll_event[m_event_size];
	err = errno;
	if(NULL == m_pevent){
		//LOG(CLog::log_err, "CEpoll::Init, create epoll_event array error,[%s]", strerror(iErrno));
		return RE_FAILED;
	}

	return RE_SUCCESS;
}

int CEpoll::set_no_block(int fd)
{
	int opts;  
	int err = 0;    
	opts = fcntl(fd, F_GETFL); //�õ��ļ�״̬��־    
	if(opts < 0)     
	{          
	    err = errno;
		//LOG(CLog::log_err, "fd:%d fcntl F_GETFL [%s]", fd, strerror(iErrno));
		return RE_FAILED; 
	}     

	opts = opts|O_NONBLOCK;     
	if(fcntl(fd, F_SETFL, opts) < 0)      
	{     
	    err = errno;     
		//LOG(CLog::log_err, "fd:%d fcntl F_SETFL [%s]", fd, strerror(iErrno)); 
		return RE_FAILED;
	}    

	return RE_SUCCESS;
}


