#ifndef __RECVER_H__
#define __RECVER_H__
/*
* date:2010-05-13
* author:lqb
*/

#include "type.h"

#define SEND_DEBUG(...)\
    R5_DEBUG((&g_r5_log), ("[send] " __VA_ARGS__))
#define SEND_INFO(...)\
    R5_INFO((&g_r5_log), ("[send] " __VA_ARGS__))
#define SEND_ERROR(...)\
    R5_ERROR((&g_r5_log), ("[send] " __VA_ARGS__))
#define SEND_WARN(...)\
    R5_WARN((&g_r5_log), ("[send] " __VA_ARGS__))
#define SEND_TRACE(...)\
    R5_TRACE((&g_r5_log), ("[send] " __VA_ARGS__))


//#define MAX_CONNECTION 224
//#define PXY_BUF_SIZE 4096

struct send_param
{
	char exec_file[MAX_FILE_LEN + 1];
	char conf_file[MAX_FILE_LEN + 1];
	int sockfd;
};

struct send_conf
{
	int file_level;			//�ļ���־����
	int term_level;			//�ն���־����
	int send_buf_size;
	int lock_time;
	char shm_file[MAX_FILE_LEN + 1];
	char sem_file[MAX_FILE_LEN + 1];
	char log_path[MAX_FILE_LEN + 1];
};

class share_mem;
class Csem;
class buffer;
class CEpoll;


int read_arg(int argc, char* argv[]);

int load_conf(bool is_reload = false);

void usage();

void show_version();

int init(share_mem& mem, Csem& sem);

int register_signal();

int accept_fd(int fd, int block_cnt, CEpoll* pep, share_mem& mem);

int read_message(int index, buffer& buff, share_mem& mem);

int send_data(int fd);

int force_unlock(int index, int waittime, buffer& buff, share_mem& mem);

int send_process(share_mem& mem, Csem& sem);

void clear_socket(CEpoll * pep);

void status_check(share_mem& mem);

#endif
