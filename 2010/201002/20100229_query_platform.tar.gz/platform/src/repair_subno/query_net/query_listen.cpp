/*
* date:2011-05-03
* author:lqb
*/

#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <unistd.h>

#include "query_listen.h"
#include "tools.h"
#include "type.h"
#include "share_mem.h"
#include "sem.h"
#include "public_signal.h"
#include "cepoll.h"


//from base lib
#include"iniconfig.h"
#include"r5api.h"


//int g_lsn_sock = 0;
char g_configure_file[MAX_FILE_LEN + 1];

struct listen_conf g_conf;

R5_Log g_r5_log;

int g_exit = 0;

//CPoll* g_pepoll = NULL;


int read_arg(int argc, char **argv, struct proc_status& status){
    memset(&status, 0, sizeof(status));
    strcpy(status.program_name, argv[0]);
    status.is_deamon = 1;

    int optch;
    extern char *optarg;
    const char optstring[] = "hvet:c:C:d:D:Ff";

    while((optch = getopt(argc, argv, optstring)) != -1){
        switch(optch){
            case 'h':   /* ��ӡ������Ϣ */
                usage(status);
                exit(RE_SUCCESS);

            case 'v':   /* ��ʾ�汾�� */
				show_version();
                exit(RE_SUCCESS);

            case 'e':   /* ��̨��ʽ���� */
                status.is_deamon = 0;
                break;

			case 'C':
            case 'c':   /* �����ļ� */
                strncpy(status.conf_file, optarg, MAX_FILE_LEN);
                break;

			case 'f':
			case 'F':  /**/
				status.is_froce = 1;
				break;

			case 'D':
			case 'd':   /*�Ƿ�ɾ�������ڴ�*/
			    status.is_destroy_shm = 1;
			    break;

            default:
                break;
        }
    }

    if(status.conf_file[0] == '\0'){
        fprintf(stderr, "configure file is MUST!\n");
        return RE_FAILED;
    }

    memset(g_configure_file, 0, sizeof(g_configure_file));
    strncpy(g_configure_file, status.conf_file, MAX_FILE_LEN);

    return RE_SUCCESS;
}

int load_conf(bool is_reload){
	if(!is_reload){
		memset(&g_conf, 0, sizeof(g_conf));
	}

    IniConfig config;
    if(config.open(g_configure_file) < 0){
        printf("open %s failed:%s\n", g_configure_file, strerror(errno));
        return RE_FAILED;
    }

	const char* comm = "COMM";


    /* ��־·�� */
    const char* log_path = config.getValue(comm, "LOG_PATH");
    if(log_path && strlen(log_path) != 0){
        if(0 != path_string(log_path, g_conf.log_path, sizeof(g_conf.log_path))){
            printf("read LOG_PATH item failed, configure file: '%s', LOG_PATH: '%s'.\n",
                   g_configure_file, log_path);
            return RE_FAILED;
        }
    } else {
        printf("read LOG_PATH item failed, configure file:%s.\n", g_configure_file);
    	return RE_FAILED;
    }


    /* �ļ���־���� */
    const char* file_level = config.getValue(comm, "LOG_LEVEL_FILE");
    if(file_level && strlen(file_level) != 0){
    	g_conf.file_level = atoi(file_level);
    	if(g_conf.file_level < 0 || g_conf.file_level > 120)
    	{
    		printf("LOG_LEVEL_FILE = %d error! use default-----info level\n", g_conf.file_level);
    		g_conf.file_level = 40;
    	}
    }
    else
    {
    	printf("read LOG_LEVEL_FILE failed, use default-----info level\n");
    	g_conf.file_level = 40;
    }


    /* �ն���־���� */
    const char* term_level = config.getValue(comm, "LOG_LEVEL_TERM");
    if(term_level && strlen(term_level) != 0)
    {
    	g_conf.term_level = atoi(term_level);
    	if(g_conf.term_level < 0 || g_conf.term_level > 120)
    	{
    		printf("LOG_LEVEL_TERM = %d error! use default-----info level\n", g_conf.term_level);
    		g_conf.term_level = 40;
    	}
    }
    else
    {
    	printf("read LOG_LEVEL_TERM failed, use default-----info level\n");
    	g_conf.term_level = 40;
    }

    //��ʼ����־
 	INIT_LOG((&g_r5_log), g_conf.log_path, "query_listen", g_conf.file_level,
             g_conf.term_level);

    //the local_ip is optional
    const char *local_ip = config.getValue(comm, "LISTEN_IP");
    if(local_ip && strlen(local_ip) != 0)
    {
    	strncpy(g_conf.local_ip, local_ip, sizeof(g_conf.local_ip) - 1);
    }


    /* �����˿� */
    const char *port = config.getValue(comm, "LISTEN_PORT");
    if(port && strlen(port) != 0)
    {
    	g_conf.listen_port = atoi(port);
    }
    else
    {
    	printf("read LISTEN_PORT failed, configure file:%s\n", g_configure_file);
    	return RE_FAILED;
    }

    /* �Զ�IP  --optional-- */
    const char *remote_ip = config.getValue(comm, "REMOTE_IP");
    if(remote_ip && strlen(remote_ip) != 0)
	{
		strncpy(g_conf.remote_ip, remote_ip, sizeof(g_conf.remote_ip) - 1);
	}


	/* ��������� */
	/*
	const char * max_conn = config.getValue(comm, "MAX_CONNECT");
	if(strlen(max_conn) != 0)
	{
		g_conf.max_connect = atoi(max_conn);
		if(g_conf.max_connect < 1 || g_conf.max_connect > FD_SIZE)
		{
			printf("max_conn error! read MAX_CONNECT = %s\n", max_conn);
			return RE_FAILED;
		}
	}
    else
    {
    	printf("read MAX_CONNECT failed, configue file:%s\n", g_configure_file);
    	return RE_FAILED;
    }
    */

    /* ���ս����� */
    const char *recv_file = config.getValue(comm, "RECV_FILE");
	if(recv_file && strlen(recv_file) != 0)
	{
	    strncpy(g_conf.recv_file, recv_file, sizeof(g_conf.recv_file) - 1);

	}
	else
	{
	  	printf("read RECV_FILE failed, configure file:%s\n", g_configure_file);
	  	return RE_FAILED;
	}


	/* ���ͽ����� */
	const char *send_file = config.getValue(comm, "SEND_FILE");
	if(send_file && strlen(send_file) != 0)
	{
		strncpy(g_conf.send_file, send_file, sizeof(g_conf.send_file) - 1);
	}
    else
    {
    	printf("read SEND_FILE failed, configure file:%s\n", g_configure_file);
    	return RE_FAILED;
    }


    /* �����ڴ��ļ� */
    const char* shm = config.getValue(comm, "SHM_FILE");
    if(shm && strlen(shm) != 0){
    	strncpy(g_conf.shm_file, shm, sizeof(g_conf.shm_file) - 1);
    } else {
    	printf("read SHM_FILE failed, configure file:%s.\n", g_configure_file);
    	return -1;
    }

    /*�ź����ļ�*/
    const char* sem = config.getValue(comm, "SEM_FILE");
    if(sem && strlen(sem) != 0){
        strncpy(g_conf.sem_file, sem, sizeof(g_conf.sem_file) -1);
    } else {
        printf("read SEM_FILE failed, configure file:%s\n", g_configure_file);
        return -1;
    }

    /*�����ڴ���С����λ��M*/
    const char *block_size = config.getValue(comm, "BLOCK_SIZE");
    if(block_size && strlen(block_size) != 0)
    {
        g_conf.block_size = atoi(block_size);
        if(g_conf.block_size < 1 || g_conf.block_size > 64)
        {
            printf("BLOCK_SIZE error, size = %d\n", g_conf.block_size);
            printf("the correct range is 1 <= block_size <= 64\n");
            return -1;
        }

        //ת�����ֽ�
        g_conf.block_size = g_conf.block_size << 16;
    }
    else
    {
        printf("read BLOCK_SIZE failed, configure file:%s\n", g_configure_file);
        return -1;
    }


    /*block count*/
    const char *block_cnt = config.getValue(comm, "BLOCK_CNT");
    if(block_cnt && strlen(block_cnt) != 0)
    {
        g_conf.block_cnt = atoi(block_cnt);
        if(g_conf.block_cnt < 2 || g_conf.block_cnt > 16)
        {
            printf("BLOCK_CNT error, size = %d\n", g_conf.block_cnt);
            printf("the correct range is 2 <= block_size <= 16\n");
            return -1;
        }
    }
    else
    {
        printf("read BLOCK_CNT failed, configure file:%s\n", g_configure_file);
        return -1;
    }

	return RE_SUCCESS;
}

void usage(struct proc_status& status)
{
    printf("usage : %s (-c configure filename) [-h] [-v]\n", status.program_name);
    printf("        -h show help, optional\n");
    printf("        -v show version, optional\n");
    printf("        -c configure filename, MUST\n");
    printf("-----------------------------------------------\n");
    printf("example:\n");
    printf("%s -c ../etc/query_conf.conf\n", status.program_name);
}


//��ӡ�汾����Ϣ
void show_version()
{
#ifdef PROGRAM_VERSION
    printf("Program version:%s\n\n", PROGRAM_VERSION);
#else
    printf("No version\n");
#endif
}


int register_signal()
{
    //�˳�
    if(my_signal(SIGTERM, Signal::SigTerm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM, strerror(errno));
        return -1;
    }

    //�˳�
    if(my_signal(SIGINT, Signal::SigTerm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGINT, strerror(errno));
        return -1;
    }

    //�ض�����
    if(my_signal(SIGHUP, Signal::SigHup, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGHUP, strerror(errno));
        return -1;
    }


    //ˢ����־
    if(my_signal(SIGUSR2, Signal::SigUsr2, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR2, strerror(errno));
        return -1;
    }

    /* ALARM�ж�Ӧ��������  */
    if(my_signal(SIGALRM, Signal::SigAlarm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGALRM, strerror(errno));
        return -1;
    }


    /* PIPE�ж�Ӧ���������� */
    if(my_signal(SIGPIPE, Signal::SigPipe, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGPIPE, strerror(errno));
        return -1;
    }

    //����
    if(my_signal(SIGCHLD, Signal::SigChild, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD, strerror(errno));
        return -1;
    }

    //����
    if(my_signal(SIGUSR1, SIG_IGN, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR1, strerror(errno));
        return -1;
    }

    return 0;
}


int init(struct proc_status& status, share_mem& shm, Csem& sem){
    //����core�ļ�
	struct rlimit fdlim;
	fdlim.rlim_cur = RLIM_INFINITY;
	fdlim.rlim_max = RLIM_INFINITY;
	setrlimit(RLIMIT_CORE, &fdlim);


    //��ʼ�������ڴ�
	/*��������ڴ治�����򴴽�*/
	if(!shm.is_exist(g_conf.shm_file) || 1 == status.is_froce){
	    if(shm.create(g_conf.shm_file, g_conf.block_cnt, g_conf.block_size, status.is_froce) < 0){
		    LIS_ERROR("create share memory failed, err = %d, str = %s\n", shm.error(), strerror(errno));
		    return RE_FAILED;
	    }
	}

    //��ʼ���ź���
    if(!sem.is_exist(g_conf.sem_file)){
        if(sem.create(g_conf.sem_file) < 0){
            LIS_ERROR("create sem failed, err = %d, str = %s\n", sem.error(), strerror(errno));
            return RE_FAILED;
        }
    }

	return RE_SUCCESS;
}

int start_listen_client(CEpoll* pep){

	struct sockaddr_in server_addr;
	int lsn_fd = 0;

	if(lsn_fd != 0){
		LIS_INFO("reset client listen port!\n");
		pep->delete_fd(lsn_fd);
		close(lsn_fd);
		lsn_fd = 0;
	}

	lsn_fd = socket(AF_INET, SOCK_STREAM, 0);
	if(lsn_fd < 0){
		int err = errno;
		LIS_ERROR("create client Listen port failed![%d, %s]\n", err, strerror(err));
		return RE_FAILED;
	}

	if(RE_SUCCESS != pep->add_fd(lsn_fd, EPOLLIN|EPOLLET|EPOLLERR)) {
		LIS_ERROR("add lsn_fd to epoll failed! fd = %d \n", lsn_fd);
		return RE_FAILED;
	}

	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(g_conf.listen_port);
	if('\0' == g_conf.local_ip[0]){
    	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    } else {
        //int inet_pton(int af, const char *src, void *dst);
    	inet_pton(AF_INET, g_conf.local_ip, &server_addr.sin_addr);
	}
	int opt = 1;
	///��ַ��������
	if(setsockopt(lsn_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0){
	    close(lsn_fd);
		int err = errno;
		LIS_ERROR("[setsockopt SO_REUSEADDR error] client listen sock![%d, %s]\n", err, strerror(err));
		return RE_FAILED;
	}
	
	struct linger slinger;
	slinger.l_onoff = 1;
	slinger.l_linger = 2;
	///��ر�ʱ��δ�������ݣ�����
	if(setsockopt(lsn_fd, SOL_SOCKET, SO_LINGER, &slinger, sizeof(struct linger)) < 0) {
	    close(lsn_fd);
		int err = errno;
		LIS_ERROR("[setsockopt SO_LINGER error] client listen sock![%d, %s]\n", err, strerror(err));
		return RE_FAILED;
	}

	if(bind(lsn_fd, (sockaddr *)&server_addr, sizeof(server_addr)) < 0){
	    close(lsn_fd);
		int err = errno;
		LIS_ERROR("bind client Listen ip![%d, %s]\n", err, strerror(err));
		return RE_FAILED;
	}

	if(listen(lsn_fd, LISTENMAX) < 0){
		close(lsn_fd);
		int err = errno;
		LIS_ERROR("client Listen error![%d, %s]\n", err, strerror(err));
		return RE_FAILED;
	}

	LIS_INFO("Port [%s:%d] Start Listen![cli_lsn fd = %d]\n", g_conf.local_ip,
		g_conf.listen_port, lsn_fd);

//	cout << "Port [" << g_conf.local_ip << ":" <<  g_conf.listen_port
//		<< "] Start Listen![Client]" << endl;

	return lsn_fd;
}


int start_recv_process(struct proc_status& status)
{
	//����socketpair�����ڴ���������
	int fd_pair[2];

	if(socketpair(AF_UNIX, SOCK_STREAM, 0, fd_pair) != 0)
	{
		LIS_ERROR("socketpair failed:%s\n", strerror(errno));
		return -1;
	}

	LIS_DEBUG("fd[0] = %d fd[1] = %d \n", fd_pair[0], fd_pair[1]);


	//���������ӽ���
    pid_t pid = fork();

    if(-1 == pid)
    {
        LIS_ERROR("fork: %s\n", strerror(errno));
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return -1;
    }
    else if(0 == pid)   /* �ӽ��� */
    {
    	g_r5_log.logOnlyClose();
		close(fd_pair[FD_WRITE]);

        char recv_exe[256]   = {'\0'};
        char proc_name[256]  = {'\0'};
		char str_socket[32] = {0};

        snprintf(recv_exe, sizeof(recv_exe) - 1, "%s",  g_conf.recv_file);
        snprintf(proc_name, sizeof(proc_name) - 1, "%s", g_conf.recv_file);
        snprintf(str_socket, sizeof(str_socket) - 1, "%d", fd_pair[FD_READ]);


        int retval = execl(recv_exe,
                           proc_name,
                           "-s", str_socket,
                           "-c", status.conf_file,
                           (char*)NULL);

        if(-1 == retval)
        {
            perror("execl");
            //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
            exit(0);
        }
    }
    else
    {
    	close(fd_pair[FD_READ]);
    	status.recv_fd = fd_pair[FD_WRITE];
    	status.recv_pid = pid;

        //LIS_INFO("New recv process pid = %d.\n", plc->recv_child_pid[0]);
    }

	return 0;
}


int start_send_process(struct proc_status& status)
{
	//����socketpair�����ڴ���������
	int fd_pair[2];

	if(socketpair(AF_UNIX, SOCK_STREAM, 0, fd_pair) != 0)
	{
		LIS_ERROR("socketpair failed:%s\n", strerror(errno));
		return -1;
	}

	LIS_DEBUG("fd[0] = %d fd[1] = %d \n", fd_pair[0], fd_pair[1]);


	//���������ӽ���
    pid_t pid = fork();

    if(-1 == pid)
    {
        LIS_ERROR("fork: %s\n", strerror(errno));
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return -1;
    }
    else if(0 == pid)   /* �ӽ��� */
    {
		g_r5_log.logOnlyClose();

		close(fd_pair[FD_WRITE]);

        char send_exe[256]   = {'\0'};
        char proc_name[256]  = {'\0'};
		char str_socket[32] = {0};

        snprintf(send_exe, sizeof(send_exe), "%s", g_conf.send_file);
        snprintf(proc_name, sizeof(proc_name), "%s", g_conf.send_file);
        snprintf(str_socket, sizeof(str_socket), "%d", fd_pair[FD_READ]);

        int retval = execl(send_exe,
                           proc_name,
                           "-s", str_socket,
                           "-c", status.conf_file,
                           (char*)NULL);

        if(-1 == retval)
        {
            perror("execl");
            //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
            exit(0);
        }
    }
    else
    {
    	close(fd_pair[FD_READ]);
    	status.send_fd = fd_pair[FD_WRITE];
    	status.send_pid = pid;
        //LIS_INFO("New send process pid = %d.\n", plc->send_child_pid[0]);
    }

	return 0;
}

int prepare_to_run(struct proc_status& status){
	int ret = 0;

	ret = start_recv_process(status);
	if(ret < 0){
		LIS_ERROR("start recv process failed.\n");
		return -1;
	}

	ret = start_send_process(status);
	if(ret < 0){
		LIS_ERROR("start send process failed.\n");
		return -1;
	}

	return 0;
}


int accept_connection(int lsn_fd, struct proc_status& status){

    struct sockaddr_in client_addr;
	socklen_t addrlen = sizeof(client_addr);
	int accept_fd = accept(lsn_fd, (struct sockaddr*)&client_addr, &addrlen);
    if(accept_fd < 0){
        //���ź��ж�
        if(errno == EINTR){
            if(Signal::HandleSignal() < 0)
                return RE_FAILED;
        } else {
            //��������
            return RE_FAILED;
        }
    } else {
        char ipbuf[32] = {0};
        inet_ntop(AF_INET, &(client_addr.sin_addr), ipbuf, sizeof(ipbuf));

        LIS_INFO("receiver a connection from[%s:%d]\n", ipbuf, ntohs(client_addr.sin_port));

        static int unique_id = 1;
		char buf[8] = {'\0'};
		snprintf(buf, sizeof(buf), "%d", unique_id);
		int send_len = sizeof(buf);

		unique_id++;
		unique_id %= FD_SIZE;
		if(unique_id == 0)
		    unique_id = 1;

		if(send_fd(status.recv_fd, buf, send_len, accept_fd) > 0){
		    LIS_INFO("send fd to recv success.\n");
		} else {
			LIS_ERROR("send fd to recv failed.\n");
		}

		if(send_fd(status.send_fd, buf, send_len, accept_fd) > 0){
			LIS_INFO("send fd to send success.\n");
		} else {
			LIS_ERROR("send fd to send failed.\n");
		}

		close(accept_fd);
    }

    return RE_SUCCESS;
}

int proc_run(struct proc_status& status)
{
    int lsn_fd = 0;
    //��ʼ��epoll
	CEpoll* pepoll = new CEpoll(10, 10, 10000);
    if(NULL == pepoll){
        LIS_ERROR("new epoll failed.\n")
        return RE_FAILED;
    }

	if(0 != pepoll->init()){
		LIS_ERROR("epoll init failed!\n");
		return RE_FAILED;
	}

	if((lsn_fd = start_listen_client(pepoll)) < 0)
		return RE_FAILED;

       g_r5_log.flush();
        
	if(prepare_to_run(status) < 0){
		LIS_ERROR("prepare_to_run failed.\n");
		return RE_FAILED;
	}

	LIS_INFO("Program running!\n");

    vector<CEpoll::EpollEve> EV;

    while(1){
        if(g_exit)
            break;

        if(RE_SUCCESS != pepoll->wait(EV)){
            int err = errno;
			LIS_WARN("epoll failed,err:%s\n", strerror(err));

			if(Signal::HandleSignal() < 0)
            	return RE_FAILED;

        	if(err != EINTR)
        	    break;
        }

		vector<CEpoll::EpollEve>::iterator iter;
		for(iter = EV.begin(); iter != EV.end(); ++iter){
			if(iter->fd == lsn_fd){
				accept_connection(lsn_fd, status);
			}
		}
	}


	if(pepoll){
	    delete pepoll;
	    pepoll = NULL;
	}
	close(lsn_fd);

	return 0;
}


void daemon(){
    int pid = 0;
    if((pid = fork()) > 0)
        exit(0);

    setsid();
    if((pid = fork()) > 0)
        exit(0);
}

/*
*/
void exit(struct proc_status& status){
    stop_process(status, SIGTERM);
}

/*
*/
void stop_process(struct proc_status& status, int signo){

    if(status.recv_pid > 0){
        kill(status.recv_pid, signo);
        LIS_INFO("kill recv process %d\n", status.recv_pid);
        status.recv_fd = -1;
    }
    usleep(1000);

    if(status.send_pid > 0){
        kill(status.send_pid, signo);
        LIS_INFO("kill send process %d\n", status.send_pid);
        status.send_fd = -1;
    }
}


int main(int argc, char* argv[]){
	int ret = 0;
	struct proc_status status;
	share_mem shm;
	Csem sem;

	ret = read_arg(argc, argv, status);
	if(ret < 0){
		fprintf(stderr, "read args failed.\n");
		return RE_FAILED;
	}

	ret = load_conf();
	if(ret < 0){
		fprintf(stderr, "load conf failed.\n");
		return RE_FAILED;
	}

	//�Ժ�̨��ʽ����
	if(status.is_deamon)
	    daemon();

	ret = init(status, shm, sem);
	if(ret < 0){
		fprintf(stderr, "init failed.\n");
		return RE_FAILED;
	}

	ret = register_signal();
	if(ret < 0){
		LIS_ERROR("register signal failed.\n");
		return -1;
	}

	proc_run(status);

	shm.destroy();
	//sem.destroy(); is need??
	exit(status);

    LIS_INFO("Program Exit.\n");
	g_r5_log.flush();

	return 0;
}


int DoSigTerm(){
    LIS_WARN("interruptted by SIGTERM.\n");
    g_exit = 1;
    return 0;
}

int DoSigChild(){
    LIS_WARN("interruptted by SIGCHLD.\n");

    return 0;
}

int DoSigHup(){
    LIS_WARN("interruptted by SIGHUP.\n");
    return load_conf(true);
}

int DoSigUsr2(){
    LIS_WARN("interruptted by SIGUSR2.\n");
    g_r5_log.flush();
    return 0;
}


int DoSigAlarm(){
    LIS_WARN("interruptted by SIGALRM.\n");
    return 0;
}

int DoSigPipe(){
    LIS_WARN("interruptted by SIGPIPE.\n");
    return 0;
}
