#!/usr/bin/python
#-*-coding:utf-8-*-
'''
Created on 2011-5-19

@author: bonly
'''
##@ingroup testcase
##@package testdata
##@file
##@brief 生成测试数据到文件的脚本

def create_data():
   fil = open("./route.txt","w")
   count = 10000
   basenum = 13719360000
   for num in range(count):
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "testdb1","user/passwd@127.0.0.1:8080", "0", "1000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "testdb2","user/passwd@137.0.0.1:8080", "0", "1000"))
      fil.write("%s\t%s\t%s\t%s\t%s\n" % 
                (basenum+num, "testdb3","user/passwd@157.0.0.1:8080", "0", "1000"))
   fil.close()
         
if __name__ == '__main__':
   create_data()
   
'''
mysqlimport test /home/hadoop/Router/route
'''


