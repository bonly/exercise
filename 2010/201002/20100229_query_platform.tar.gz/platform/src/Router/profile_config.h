/**
 * @file
 * @brief 启动参数管理
 *
 * @date 2009-4-10 created
 * @author bonly
 */
#ifndef __PROFILE_CONFIG_H__
#define __PROFILE_CONFIG_H__
#include "head.hpp"
//#include <boost/shared_ptr.hpp>
using namespace boost;
//using namespace std;

/// 配置解释器
class Config
{
  public:
    int parse(int argc=0, char* argv[]=0);
    static Config& instance();
    int count(const char* key){return (*_cfg).count(key);}
    void help();

    template<typename RET>
    RET get(const char* key){return (*_cfg)[key].as<RET>();}

  private:
    shared_ptr<program_options::variables_map>         _cfg;
    program_options::options_description               _desc_cfg;
    program_options::options_description               _visible_cfg;
    program_options::options_description               _hidden_cfg;
    int argc;char** argv;
    int clear();

  public:
    static shared_ptr<Config> _config;
};

#endif //__PROFILE_CONFIG_H__


