/**
 * @file
 * @brief
 *
 * @date 2011-4-20 created
 * @author bonly
 */

#ifndef BAS_CLIENT_HPP
#define BAS_CLIENT_HPP

#include <boost/asio/detail/mutex.hpp>
#include <boost/asio.hpp>
#include <boost/noncopyable.hpp>

#include "io_service_pool.hpp"
#include "service_handler.hpp"
#include "service_handler_pool.hpp"

namespace bas {

template<typename Work_Handler, typename Work_Allocator, typename Socket_Service = boost::asio::ip::tcp::socket>
class client
  : private boost::noncopyable
{
public:
  typedef service_handler<Work_Handler, Socket_Service> service_handler_type;
  typedef boost::shared_ptr<service_handler_type> service_handler_ptr;

  typedef service_handler_pool<Work_Handler, Work_Allocator, Socket_Service> service_handler_pool_type;
  typedef boost::shared_ptr<service_handler_pool_type> service_handler_pool_ptr;

  client(const std::string& address,
      unsigned short port,
      service_handler_pool_type* service_handler_pool)
    : mutex_(),
      service_handler_pool_(service_handler_pool),
      endpoint_(boost::asio::ip::address::from_string(address), port)
  {
    BOOST_ASSERT(service_handler_pool != 0);
  }

  client(service_handler_pool_type* service_handler_pool)
    : mutex_(),
      service_handler_pool_(service_handler_pool)
  {
    BOOST_ASSERT(service_handler_pool != 0);
  }

   ~client()
  {
    service_handler_pool_.reset();
  }

  void connect(boost::asio::io_service& io_service,
      boost::asio::io_service& work_service,
      boost::asio::ip::tcp::endpoint& endpoint)
  {
    service_handler_ptr new_handler = service_handler_pool_->get_service_handler(io_service,
        work_service,
        mutex_);

    new_handler->connect(endpoint);
  }

  template<typename Parent_Handler>
  void connect(Parent_Handler& parent_handler,
      boost::asio::ip::tcp::endpoint& endpoint)
  {
    service_handler_ptr new_handler = service_handler_pool_->get_service_handler(parent_handler.io_service(),
        parent_handler.work_service(),
        mutex_);

    parent_handler.set_child(new_handler.get());
    new_handler->set_parent(&parent_handler);
    
    new_handler->connect(endpoint);
  }

  void connect(boost::asio::io_service& io_service,
      boost::asio::io_service& work_service)
  {
    connect(io_service, work_service, endpoint_);
  }

  void connect(boost::asio::io_service& io_service,
      boost::asio::io_service& work_service,
      const std::string& address,
      unsigned short port)
  {
    boost::asio::ip::tcp::endpoint endpoint(boost::asio::ip::address::from_string(address), port);

    connect(io_service, work_service, endpoint);
  }

  template<typename Parent_Handler>
  void connect(Parent_Handler& parent_handler)
  {
    connect(parent_handler, endpoint_);
  }

  template<typename Parent_Handler>
  void connect(Parent_Handler& parent_handler,
      const std::string& address,
      unsigned short port)
  {
    boost::asio::ip::tcp::endpoint endpoint(boost::asio::ip::address::from_string(address), port);

    connect(parent_handler, endpoint);
  }

private:
  boost::asio::detail::mutex mutex_;

  service_handler_pool_ptr service_handler_pool_;

  boost::asio::ip::tcp::endpoint endpoint_;
};

} // namespace bas

#endif // BAS_CLIENT_HPP
