/**
 * @file
 * @brief 测试客户端
 *
 * @date 2011-4-20 created
 * @author bonly
 */

#define BOOST_LIB_DIAGNOSTIC

/**
 * @file
 * @brief 启动参数管理
 *
 * @date 2009-4-10 created
 * @author bonly
 */

#include <fstream>
#include <iostream>
#include "profile_config.h"

boost::shared_ptr<Config> Config::_config;
void Config::help()
{
  std::cout << _visible_cfg;
}
int Config::clear()
{
  _cfg.reset();
  _cfg = shared_ptr<program_options::variables_map>(new program_options::variables_map);
  return 0;
}

int Config::parse(int argc, char* argv[])
{
  try
  {
    clear();
    if(argc!=0 || argv!=0)
    {
      this->argc=argc;
      this->argv=argv;
    }

    std::string brief(
"程序为客户端提供号码段路由服务"
    );

    _visible_cfg.add_options ()
      ("help,h", brief.data())
      ("config-file,c", program_options::value<std::string>(),"use config file")
      ("route.port,p",program_options::value<int>()->default_value(4560),"service port")
      ("route.ip,a", program_options::value<std::string>()->default_value("127.0.0.1"),"service ip")
      ("route.ios,i", program_options::value<int>()->default_value(1),"io pool size")
      ("route.threads,r",program_options::value<int>()->default_value(1),"thread pool size")
      ("route.handlers,j",program_options::value<int>()->default_value(1),"preallocated handler number")
      ("route.buffer,b",program_options::value<int>()->default_value(256),"data buffer size")
      ("route.timeout,t",program_options::value<int>()->default_value(28800),"timeout seconds")
      ("route.wait,w",program_options::value<int>()->default_value(1),"closed wait")
      ("route.number,n",program_options::value<int>()->default_value(1),"connect number")
      ("test.mode,m",program_options::value<int>()->default_value(0),"Working MODE 0:query 1:query_group 2:change_route")
      ("test.subno,s",program_options::value<long long>()->default_value(13719360000L),"Working MODE 0:subno")
      ("test.loop,l",program_options::value<long long>()->default_value(1L),"Working MODE 1/2:loop times")
      ("test.groupid,g",program_options::value<std::string>()->default_value("1"),"Working MODE 1:query groupid")
      ("test.node_num,u",program_options::value<std::string>()->default_value("1"),"Working MODE 2:node number")
      ("test.connect_str1",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status1",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status1")
      ;
    _hidden_cfg.add_options()
      ("test.connect_str2",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status2",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status2")
      ("test.connect_str3",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status3",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status3")
      ("test.connect_str4",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status4",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status4")
      ("test.connect_str5",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status5",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status5")
      ("test.connect_str6",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status6",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status6")
      ("test.connect_str7",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status7",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status7")
      ("test.connect_str8",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status8",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status8")
      ("test.connect_str9",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status9",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status9")
      ("test.connect_str10",program_options::value<std::string>()->default_value("172.16.200.103|3306|paas|root|111"),"Working MODE 2:connect str1")
      ("test.status10",program_options::value<std::string>()->default_value("0"),"Working MODE 2:status10")
    ;

    _desc_cfg.add(_visible_cfg).add(_hidden_cfg);

    program_options::positional_options_description p;
    p.add("config-file", -1);
    store (
        program_options::command_line_parser(this->argc,this->argv).options(_desc_cfg).positional(p).run(),
        *_cfg);

    notify(*_cfg);

    if ((*_cfg).count("help")||(*_cfg).count("version"))
      return 0;

    if (!(*_cfg).count("config-file"))
    {
      std::cerr << "usage: " << argv[0] << " <config-file> \n";
      exit(EXIT_FAILURE);
    }

    std::ifstream ifs((*_cfg)["config-file"].as<std::string>().c_str());
    store(parse_config_file(ifs,_desc_cfg),*_cfg );
    ifs.close();
    notify(*_cfg);
  }
  catch(std::exception& e)
  {
    std::cout << e.what() << "\n";
    exit(EXIT_FAILURE);
  }
  return 0;
}

Config& Config::instance()
{
  if (Config::_config.get() == 0)
  {
    Config::_config.reset(new Config);
  }
  return *Config::_config;
}

#include <iostream>
#include <string>
#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/asio.hpp>

#ifndef BAS_CLIENT_WORK_HPP
#define BAS_CLIENT_WORK_HPP

#include "service_handler.hpp"
#include "Protocal.h"
#include <iostream>
#include "head.hpp"
enum MODE{QUERY=0,QUERY_GROUP,CHG_ROUTE} mode;
namespace bas
{

   std::string echo_message = "echo server test message.\r\n";

   class client_work
   {
      public:
         typedef bas::service_handler<client_work> client_handler_type;

         client_work():i(0),count(0)
         {
         }

         void on_clear(client_handler_type& handler)
         {
         }

         void on_open(client_handler_type& handler)
         {
            boost::posix_time::ptime time_epoch(
                     boost::gregorian::date(1970, 1, 1));
            boost::posix_time::ptime time_start =
                     boost::posix_time::microsec_clock::universal_time();
            boost::posix_time::time_duration td_epoch = time_start - time_epoch;

            srand(td_epoch.total_milliseconds());

            char *buf = 0;
            int ret = -1;
            switch(mode)
            {
                case QUERY:
                {
                    i = Config::instance().get<long long>("test.subno");
                    count = i + Config::instance().get<long long>("test.loop");
                    char subno[15]="";
                    snprintf(subno,15,"%lld",i);
                    Protocal p;
                    p << subno << 1 ;  // 以整型命令码值表示赋值结束,如果结束后再加字串字段会不让编译通过
                    //cout << "encoded first: " << p << endl;  // 打印包体内容(不包括命令码)

                    ret = p.Encode(buf);  // ret 返回整个数据的包长度,-1表示失败
                    break;
                }
                case QUERY_GROUP:
                {
                    i = Config::instance().get<long long>("test.loop");
                    Protocal p;
                    // 组ID
                    p << Config::instance().get<std::string>("test.groupid").c_str() << 5;

                    ret = p.Encode(buf);
                    break;
                }
                case CHG_ROUTE:
                {
                    i = Config::instance().get<long long>("test.loop");
                    Protocal p;
                    // 节点数,(连接串,状态)...
                    p << (char*)Config::instance().get<std::string>("test.node_num").c_str();
                    int num = atoi(Config::instance().get<std::string>("test.node_num").c_str());
                    for (int i = 1; i<=num; ++i)
                    {
                        char con[30]="";
                        char stat[30]="";
                        sprintf(con,"test.connect_str%d",i);
                        sprintf(stat,"test.status%d",i);
                        p << Config::instance().get<std::string>(con).c_str()
                           << Config::instance().get<std::string>(stat).c_str();
                    }
                    p << 7;
                    ret = p.Encode(buf);
                    break;
                }
            }


            if (ret !=-1 )
            {
               handler.async_write(
                        boost::asio::buffer(buf, ret));
            }
         }

         void on_read(client_handler_type& handler,
                  std::size_t bytes_transferred)
         {
            //HexDump((char*)(handler.read_buffer().data()+handler.read_buffer().size()),256);

            Protocal p;
            //*
            if (0 != p.DecodeAns((const char*)(handler.read_buffer().data()+handler.read_buffer().size())))
            {
               printf ("decode err\n");
            }
            clog << "decoded: " << p << endl;
            //*/

            switch(mode)
            {
                case QUERY:
                {
                    if(++i > count-1)
                    {
                      handler.close();
                      break;
                    }

                    char tel[15]="";
                    sprintf(tel, "%lld", i);

                    p.Reset();
                    int cmd = ((i%2==0)?1:3);
                    p << tel << cmd ;  // 以整型命令码值表示赋值结束,如果结束后再加字串字段会不让编译通过
                    //cout << "encoded: " << cmd << "\t" << p << endl;  // 打印包体内容(不包括命令码)

                    char *buf = 0;
                    int ret = p.Encode(buf);  // ret 返回整个数据的包长度,-1表示失败
                    if (ret !=-1 )
                    {
                       handler.async_write(
                                boost::asio::buffer(buf, ret));
                    }


                    break;
                }
                case QUERY_GROUP:
                {
                    int ret = -1;
                    char *buf = 0;
                    if(++count < i-1)
                    {
                        Protocal p;
                        // 组ID
                        p << Config::instance().get<std::string>("test.groupid").c_str() << 5;

                        ret = p.Encode(buf);
                    }
                    else
                    {
                        handler.close();
                    }
                    if (ret !=-1 )
                    {
                       handler.async_write(
                                boost::asio::buffer(buf, ret));
                    }
                    break;
                }
                case CHG_ROUTE:
                {
                    int ret = -1;
                    char *buf = 0;
                    if (++count < i-1)
                    {
                        Protocal p;
                        // 节点数,(连接串,状态)...
                        p << (char*)Config::instance().get<std::string>("test.node_num").c_str();
                        int num = atoi(Config::instance().get<std::string>("test.node_num").c_str());
                        for (int i = 1; i<=num; ++i)
                        {
                            char con[30]="";
                            char stat[30]="";
                            sprintf(con,"test.connect_str%d",i);
                            sprintf(stat,"test.status%d",i);
                            p << Config::instance().get<std::string>(con).c_str()
                               << Config::instance().get<std::string>(stat).c_str();
                        }
                        p << 7;
                        ret = p.Encode(buf);
                    }
                    else
                    {
                        handler.close();
                    }
                    if (ret !=-1 )
                    {
                       handler.async_write(
                                boost::asio::buffer(buf, ret));
                    }
                    break;
                }
            }
         }

         void on_write(client_handler_type& handler,
                  std::size_t bytes_transferred)
         {
            //handler.async_read_some();
            handler.async_read_pack();
         }

         void on_close(client_handler_type& handler,
                  const boost::system::error_code& e)
         {
            switch (e.value())
            {
               //功能
               case 0:
               case boost::asio::error::eof:
                  break;

                  // 超时
               case boost::asio::error::timed_out:
                  std::cout << "client error " << e << " message "
                           << e.message() << "\n";
                  std::cout.flush();
                  break;

                  // 断开
               case boost::asio::error::connection_aborted:
               case boost::asio::error::connection_reset:
               case boost::asio::error::connection_refused:
                  break;

                  // 其它错
               case boost::asio::error::no_buffer_space:
                  std::cout << "client error " << e << " message "
                           << e.message() << "\n";
                  std::cout.flush();
                  break;
            }
         }

         void on_parent(client_handler_type& handler, const bas::event event)
         {
         }

         void on_child(client_handler_type& handler, const bas::event event)
         {
         }

         long long i;
         long long count;
   };

} // namespace

#endif // BAS_CLIENT_WORK_HPP

#ifndef BAS_CLIENT_WORK_ALLOCATOR_HPP
#define BAS_CLIENT_WORK_ALLOCATOR_HPP

namespace bas
{
   class client_work;
   class client_work_allocator
   {
      public:
         typedef boost::asio::ip::tcp::socket socket_type;

         client_work_allocator()
         {
         }

         socket_type* make_socket(boost::asio::io_service& io_service)
         {
            return new socket_type(io_service);
         }

         client_work* make_handler()
         {
            return new client_work();
         }
   };

} // namespace

#endif // BAS_CLIENT_WORK_ALLOCATOR_HPP

#ifndef BAS_CLIENT_CONNECTIONS_HPP
#define BAS_CLIENT_CONNECTIONS_HPP

#include <boost/date_time/posix_time/posix_time_types.hpp>
#include "io_service_pool.hpp"
#include "service_handler_pool.hpp"
#include "client.hpp"

#include <iostream>

#include <ctime>

namespace bas
{

   class connections
   {
      public:
         typedef bas::service_handler_pool<client_work, client_work_allocator>
                  client_handler_pool_type;
         typedef bas::client<client_work, client_work_allocator> client_type;

         explicit connections(const std::string& address, unsigned short port,
                  std::size_t io_service_pool_size,
                  std::size_t work_service_pool_size,
                  std::size_t connection_number,
                  client_handler_pool_type* service_handler_pool) :
            io_service_pool_(io_service_pool_size),
                     work_service_pool_(work_service_pool_size),
                     client_(address, port, service_handler_pool),
                     connection_number_(connection_number)
         {
            BOOST_ASSERT(connection_number != 0);
         }

         void run()
         {
            boost::posix_time::ptime time_start =
                   boost::posix_time::microsec_clock::universal_time();
            std::cout << "Creating " << connection_number_ << " connections.\n";

            work_service_pool_.start();
            io_service_pool_.start();

            for (std::size_t i = 0; i < connection_number_; ++i)
               client_.connect(io_service_pool_.get_io_service(),
                        work_service_pool_.get_io_service());

            io_service_pool_.stop();
            work_service_pool_.stop();

            work_service_pool_.start();
            io_service_pool_.start();
            io_service_pool_.stop();
            work_service_pool_.stop();

            boost::posix_time::time_duration time_long =
                     boost::posix_time::microsec_clock::universal_time()
                              - time_start;
            std::cout << "All connections complete in "
                     << time_long.total_milliseconds() << " ms.\n";
            std::cout.flush();

            /*    boost::asio::io_service io_service;
             boost::asio::deadline_timer timer(io_service);
             timer.expires_from_now(boost::posix_time::seconds(3));
             timer.wait();
             */
         }

      private:
         bas::io_service_pool io_service_pool_;

         bas::io_service_pool work_service_pool_;

         client_type client_;

         std::size_t connection_number_;
   };

} // namespace

#endif // BAS_CLIENT_CONNECTIONS_HPP

int main(int argc, char* argv[])
{
   try
   {
      /* Check command line arguments.
      if (argc != 10)
      {
         std::cerr
                  << "Usage: echo_client <address> <port> <io_pool_size> <thread_pool_size> <preallocated_handler_number> <data_buffer_size> <timeout_seconds> <closed_wait> <connection_number>\n";
         std::cerr << "  For IPv4, try:\n";
         std::cerr << "    TestClient 0.0.0.0 1000 4 4 500 64 0 1 100\n";
         std::cerr << "  For IPv6, try:\n";
         std::cerr << "    TestClient 0::0 1000 4 4 500 64 0 1 100\n";
         return 1;
      }

      unsigned short port = boost::lexical_cast<unsigned short>(argv[2]);
      std::size_t io_pool_size = boost::lexical_cast<std::size_t>(argv[3]);
      std::size_t thread_pool_size = boost::lexical_cast<std::size_t>(argv[4]);
      std::size_t preallocated_handler_number =
               boost::lexical_cast<std::size_t>(argv[5]);
      std::size_t read_buffer_size = boost::lexical_cast<std::size_t>(argv[6]);
      std::size_t timeout_seconds = boost::lexical_cast<std::size_t>(argv[7]);
      std::size_t closed_wait = boost::lexical_cast<std::size_t>(argv[8]);
      std::size_t connection_number = boost::lexical_cast<std::size_t>(argv[9]);
*/

      Config::instance().parse(argc, argv);
      if (Config::instance().count("help"))
      {
          Config::instance().help();
          exit(EXIT_SUCCESS);
      }
      unsigned short port = Config::instance().get<int> ("route.port");
      std::size_t io_pool_size = Config::instance().get<int> ("route.ios");
      std::size_t thread_pool_size = Config::instance().get<int> ("route.threads");
      std::size_t preallocated_handler_number = Config::instance().get<int> ("route.handlers");
      std::size_t read_buffer_size = Config::instance().get<int> ("route.buffer");
      std::size_t timeout_seconds = Config::instance().get<int> ("route.timeout");
      std::size_t closed_wait = Config::instance().get<int> ("route.wait");
      std::size_t connection_number = Config::instance().get<int> ("route.number");
      mode = (MODE)Config::instance().get<int>("test.mode");
      typedef bas::service_handler_pool<bas::client_work,
               bas::client_work_allocator> client_handler_pool;

      bas::connections client(
               Config::instance().get<std::string>("route.ip").c_str(),
               port,
               io_pool_size,
               thread_pool_size,
               connection_number,
               new client_handler_pool(new bas::client_work_allocator(),
                        preallocated_handler_number, read_buffer_size, 0,
                        timeout_seconds, closed_wait));

      client.run();
   }
   catch (std::exception& e)
   {
      std::cerr << "exception: " << e.what() << "\n";
   }

   return 0;
}
