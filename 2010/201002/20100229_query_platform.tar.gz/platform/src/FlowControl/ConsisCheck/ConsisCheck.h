

/*
	class CConsisCheck: 
	  to Check the consistency of the database instances of one group. there are 2 situations
	  that :
	  1.  for dailyCheck ,need detail info of each instances
	  2. for pre-compressing of Myisam table to Innodb,  to find  a integral instance.	

*/


#ifndef _CONSISTENCY_CHECK_H
#define _CONSISTENCY_CHECK_H


#include "../NCF/Ncf_Common.h"

#include "base_constants.h"
#include "sqltypes.h"


#include <mysql++.h>
//#include "../SortBill/Service_Common.h"
#include <iostream>
#include <unistd.h>


//#include "../SortBill/fdb_conn.h"
//#include "Load_Tools.h"
#include <sys/time.h>
#include <time.h>
#include <string>
#include <fstream>
#include <mysql.h>
#include <vector>

#define		ERR_DESC_STR_LEN		500			//���������ַ�������
#define		MAX_ERR_TYPE_NUM		32			//�����������32��
#define 	MAX_COL_NAME_LEN		50	//�������ֶ��������洢����

//��������
#define 	TABLE_NAME_DB_NEW				"indb_newtable_record"
#define 	TABLE_NAME_REF_DATA				"NODE_GROUP_DATA_STANDARD"
#define		TABLE_NAME_CHK_LOG				"node_check_log"

#define		DEBUG_CONSIS_CHECK_EN			1


enum enmCHKERR{
	CHK_RES_CORRECT = 0,
	CHK_RES_NO_DATA,
	CHK_RES_DATA_DISCON,
	CHK_RES_OTHER_ERR,

	CHK_RES_MAX
};

// the error type of special instance description, most 32 types
enum enmInstance_Err_TYPE{
	ERR_TYPE_NONE				= 0, 		//δ��ʼ��

	ERR_TYPE_CONN 				= 1,		//����Ӳ������:�����Ӵ���
	ERR_TYPE_DATA_DAMAGE		= (1<<1),		// �����ļ���
	ERR_TYPE_DATA_DISCORDANT 	= (1<<2),		//�ڲ�����ͳ�ƴ��ڲο�����
	ERR_TYPE_BATCH_STAT_INCON	= (1<<3),		//ʵ�����ͬ���α���״̬��һ�¡�

//	ERR_TYPE_DATA_LACK 			= (1<<4),		//ȱ������ noUSE later


	ERR_TYPE_NO_DATA			= (1 << 28)	,	//ʵ��������
	ERR_TYPE_OTHER				=  (1<<29),		//�����쳣

	ERR_TYPE_DATA_INTE			=  (1<<30),		//������ȷ

	ERR_TYPE_REF_DB_ACC			=  (1<<31),		//�ο����ݿ�����쳣:������
	
	ERR_TYPE_MAX				
};

typedef struct __ERR_TYPE_DESC
{
	BASE2_UINT32	enmErrType;
	BASE2_CHAR		sErrDesc[ERR_DESC_STR_LEN];

}st_ERR_TYPE_DESC;


static st_ERR_TYPE_DESC stErrTypeInfo[MAX_ERR_TYPE_NUM + 1]		=
{
//	{	ERR_TYPE_NONE							, 	"NULL"			      },
	{	ERR_TYPE_CONN 							,	"����Ӳ��/��������"   },
	{	ERR_TYPE_DATA_DAMAGE					,	"�����ļ���"	      },
	{	ERR_TYPE_DATA_DISCORDANT 				,	"ʵ��������ο����ݲ�ͬ"            },
	{	ERR_TYPE_BATCH_STAT_INCON				,	"��������״̬�������ı���һ��"	  },
//	{	ERR_TYPE_DATA_LACK 			  			,	"����ȱ��"	          },
	{ERR_TYPE_NO_DATA							,   "ʵ��������"		  },
	{	ERR_TYPE_OTHER							,	"�����쳣����"	      },
	{	ERR_TYPE_DATA_INTE						,	"��������"	          },
	{	ERR_TYPE_REF_DB_ACC						,	"�ο����ݿ��쳣"      }

};




typedef struct __TABLE_COL_NAME_MAPPING
{
	BASE2_INT32		enmColmID;
	BASE2_CHAR		sColName[MAX_COL_NAME_LEN];

}st_TABLE_COL_MAPPING;


//indb_newtable_record 's column 
enum  enmNewTableCol{
	TABLENAME_NTB	=  0  ,
	TIME_NTB			  ,
	STATUS_NTB			  ,
	INS_COUNT_NTB		  ,
	TABLE_NUM_NTB	  , 
	BUSINESS_TYPE_NTB	  ,
	DAY_NTB				  ,

	NEW_TB_MAX_COL	  
};


static st_TABLE_COL_MAPPING  stNTbColName[NEW_TB_MAX_COL + 1] =
{

	{	TABLENAME_NTB				,   "tablename"		  },
	{	TIME_NTB					,	"time"				},
	{	STATUS_NTB					,	"status"			},
	{	INS_COUNT_NTB				,	"ins_count" 		},
	{	TABLE_NUM_NTB				,	"table_num" 		},
	{	BUSINESS_TYPE_NTB	  		,   "business_type"	  },
	{	DAY_NTB 					,	"day"				}


};


enum enmRefDBDataCol{
	
	REF_GROUPID = 0		,
	REF_TIME			,
	REF_TABLE_NUM		,
	REF_BILL_TYPE		,
	REF_INS_COUNT		,	
	
	REF_DB_MAX_COL	
};


static st_TABLE_COL_MAPPING stRefTbCol[REF_DB_MAX_COL + 1] = 
{
	
	{ REF_GROUPID		  ,   "groupID"	 },
	{ REF_TIME			  ,   "time"	   },
	{ REF_TABLE_NUM 	  ,   "table_num"  },
	{ REF_BILL_TYPE 	  ,   "bill_type"  },
	{ REF_INS_COUNT 	  , 	"ins_count"  }		 


};


enum enmTBNodeChkLogCol{
	CHKLOG_ID				=	0,
	CHKLOG_GROUPID 		    ,
	CHKLOG_STARTITIME     ,
	CHKLOG_TIMECOST       ,
	CHKLOG_ERRLEVEL       ,
	CHKLOG_ISINT        ,
	CHKLOG_ERRINFO        ,

	CHKLOG_MAX_COL
};

static st_TABLE_COL_MAPPING  stChkLogTbCol[CHKLOG_MAX_COL + 1] = 
{
	
	{	CHKLOG_ID				  ,   "id"				  },
	{	CHKLOG_GROUPID			  ,   "groupid" 		  },
	{	CHKLOG_STARTITIME	  ,   "starttime"		  },
	{	CHKLOG_TIMECOST 	  ,   "timecost"		  },
	{	CHKLOG_ERRLEVEL 	  ,   "errlevel"		  },
	{	CHKLOG_ISINT		  ,   "isint" 		  },
	{	CHKLOG_ERRINFO		  ,   "errinfo" 		  },
	


};



 


enum  enmINST_INFO
{	
	INST_ERROR_TYPE 		= 0,
	INST_RECORD_NUM			= 1,

	INST_INFO_MAX

};


typedef struct __ERRINFO_OF_CHK_RESULT
{
	string 		sInstanceName;
	string 		sErrOfInstance;

	struct 	__ERRINFO_OF_CHK_RESULT * pNext;

	
}st_ERRINFO_OF_INST;




//the check detail result info

// the db instance info
typedef struct __INS_INFO
{
//detail logical error of one instance 
	ConnectInfo		stConnInfo;

	BASE2_INT32		nIns_count;
	string 			sErrInfo;
	BASE2_INT32		nErrLevel;

}ST_INS_INFO;


//new table record info
typedef 	struct _NTB_RECORD
{
	string 			 sNtbCol[NEW_TB_MAX_COL + 1];
	//vector<string >   vNtbCol(  1, ""); //
	bool 			  bFlag;	
	BASE2_INT32		  nBillType; // 0 cur month , 1 history month

}ST_NTB_RCRD_INFO;

typedef struct __LOG_CHK_RES
{
// batch  error info
	BASE2_UINT32			unErrType;
	string		 			sTable_num;
	string		 			sTable_name;
	string 					sTime;

	BASE2_INT32				nIns_count;	// ins_count of reference  data.
	string 					strErrInfo;
	vector<ST_INS_INFO>		vInsInfo; 	// logical  check result
}ST_LOG_CHK_RES;




typedef struct __NTB_RECORD_SET
{
	vector<ST_NTB_RCRD_INFO>  	vRrdMege; 	// the merge of  3 record set

	vector< vector<ST_NTB_RCRD_INFO> >  vInsRcrds;

	BASE2_INT32					nInsSetNum;

}ST_NTB_RECORD_SET;



typedef struct __NCC_DETAIL_RES
{
	string 					sErrDesc; 
	/*       Ӳ������:
	 1	 db ���ܷ���/���ݿ�����
	 2	 ���β�һ��/ʵ�����ݲ�һ��	*/
	 
	vector<ST_INS_INFO> 	vHwDbDamage;		// hardware and db check result

	vector<ST_LOG_CHK_RES>	vLogChkRes;			// logical check result

	//the record set from 3 instances
	ST_NTB_RECORD_SET		stRrdInfoSet;
	
	
}st_NCC_DT_RES;


/*
	CConsisCheck:  for the consistency checking of  the special database instances set
	
*/
class CConsisCheck{

//	private:
		
	protected:

		st_NCC_DT_RES				m_stNccDtRes;
		
		string						strGroupInfo;

//		bool						m_bDetailChk;    // get more detail info
		
//		string						m_sGropName;
		BASE2_INT32 				m_nDBTotalNum;
		BASE2_INT32 				m_nDBInteNum;
		BASE2_INT32 				m_nDBUnInteNum;
		BASE2_UINT32 				m_nErrLevel;		
		ConnectList 				m_DbConSet;
		
//		BASE2_UINT32 				m_nArrDbInstInfo[MAX_NODE_NUM][INST_INFO_MAX];		// real info of the special instance

		mysqlpp::Connection * 		m_pRefConn;

		st_ERRINFO_OF_INST *	 	m_pErrInfoSet;

		time_t						m_tChkTimeCost;
		time_t 						m_tChkDTime;

		string						m_path; // log file 's path
		
		BASE2_INT32					m_nGroupID;
		BASE2_INT32					m_nTime;

	public:
	
		bool		CConsisCheck_Ex(BASE2_INT32 nGroupID	,mysqlpp::Connection *refPconn, ConnectList & dbConnSet,  bool bDailyCheck );
		CConsisCheck(BASE2_INT32 nGroupID	,mysqlpp::Connection *refPconn, ConnectList & dbConnSet);

		~CConsisCheck();


		bool  Debug_Db_data(int gLine, string gFile);

		int 	RemoteConnectDb(const char* strConnString, mysqlpp::Connection &conn);

		bool 	AnalyConnString(const char* strConnString,std::string &strdb,std::string &strserver,
					std::string &struser,std::string &strpwd,int &iport);
		

		BASE2_INT32 CalcTimeCost(struct  timeval	& stStarTime, struct  timeval	& stEndTime);

		bool	HasBatchInfoRecord(vector<ST_LOG_CHK_RES> & vLogRes, ST_NTB_RCRD_INFO & stRecord, BASE2_INT32 & nIndex);

		bool 	IsBatchSetConsis();
		bool	MergeRcrdSets_Distinct(vector<ST_NTB_RCRD_INFO> & destV, vector<ST_NTB_RCRD_INFO>	& srcV);

		bool	ChkInsDataSetWithRef();


		bool MarkLogErrInfo(BASE2_UINT32	unErrLvl, ST_NTB_RCRD_INFO	& stRecord,  ConnectInfo & stItem, string sRefIns_count,string sNdCount , string strInfo);

		bool     MarkLogErrInfo(BASE2_UINT32 unErrLvl, string strErrInfo);

		bool	MarkLogErrInfo(BASE2_UINT32 unErrLvl, ST_NTB_RCRD_INFO & stRecord,  string strErrInfo);


		bool		FindRecord(vector<ST_NTB_RCRD_INFO> & destV , ST_NTB_RCRD_INFO & stRecord);

//		bool		MarkHwErrInfo(BASE2_UINT32	nErrInfo , ConnectInfo	& stConnInfo);
		bool  		MarkHwErrInfo(BASE2_UINT32	unErrlevel, string strErrInfo);
		bool		MarkHwErrInfo(BASE2_UINT32	unErrlevel , ConnectInfo  & stConnInfo, string stErrInfo );


		bool  GetBatchRcrd(vector<ST_NTB_RCRD_INFO> & vBatchRcrdSet, ConnectInfo & stConnInfo, BASE2_UINT32 & nErrInfo, BASE2_INT32  nStatus);


		bool	Clear();

		bool	ChkBatchRcrdOfAllIns();
		
//		bool	ChkInsDataSetWithRef();

		vector<ST_LOG_CHK_RES>  GetConsisRcrdInfo();

//		 check the consistency of the instances
		BASE2_INT32 	ExecuteCheck(BASE2_INT32		nTime);

		//compare the db instance with reference db info with detail info output , for DailyCheck
//		BASE2_UINT32		CompDbWithRef(BASE2_INT32 nDBIndex);	

		bool		ReportLog(time_t timeCost);

//		bool	VerifyDbCon(BASE2_CHAR connectStr);

//		BASE2_INT32	VerifyDbCon(BASE2_CHAR * connectStr, BASE2_INT32  nDataBatch, BASE2_INT32	nRecordNumOfRefDb);

//		BASE2_UINT32	CheckDbSet();
		bool	CheckDbSet_EX();

//		BASE2_INT32	CheckDbSet_Thumb();

//		BASE2_UINT32  CompRowInfoWithRef(string sInstanceName, mysqlpp::Row RowRecord, mysqlpp::Connection *  pConn);

		bool 		IsHistoryMonth(mysqlpp::String sTableName);

//		bool		RecordErrorInfo(string sInstanceName , string sErrInfo);

		string 		GetErrDescOfType(BASE2_UINT32	enmErrType);


		bool	WriteReporToFile(const char *file_name, string sFileName);
		bool 	RecordChkResToDb(string strTime , BASE2_INT32	 nTimeCost);

};


#endif 
