#include "Scf_Init.h"
#include "Signal.h"
#include "DataAccess_Mysql.h"
#include "iniconfig.h"
#include "r5log.h"
#include "r5api.h"
#include "log.h"
#include <stdio.h>
#include <iostream>



using namespace std;
using namespace Signal;

char g_szConfFile[MAX_FILE_LEN+1];



int Scf_Init(const char *pConfFile, const int nFileLen)
{
    if(NULL == pConfFile || NULL == g_pConf)
    {
        printf("Scf_Init input param wrong !\n");
        return -1;    
    }
    int nRet = -1;
        
    ///��ȡ����
    nRet = Load_Conf(pConfFile, nFileLen);
    if(nRet < 0)
    {
        printf("Load_Conf failed!\n");
        //write_kpi(KPI_CONFIG_ERROR, KPI_SCALE_EMERGENCY);
        return -1;
    }
        
    ///�ź�ע��
    nRet = Register_Signal();
    if(nRet < 0)
    {
        LOG_ERROR("Register_Signal failed!\n");
        return -1;
    }
    
    ///�������ݿ�����
    nRet = connectDb(g_pConf->szDbName, g_pConf->szDbAddr, g_pConf->szDbUser, g_pConf->szDbPwd, g_pConf->nDbPort);
    if(nRet != 0)
    {
    	LOG_ERROR("connectDb error!\n");
    	return -1;
    }
    
    ///����������أ�Ϊˢ�ź��ض�������
    strncpy(g_szConfFile, pConfFile, sizeof(g_szConfFile)-1);

    return 0;
}


int Load_Conf(const char *pConfFile, const int nFileLen)
{
    if(NULL == pConfFile || NULL == g_pConf)
        return -1;
    IniConfig Iconf;
    
    IniSection *pSec = NULL;
    
    string sData;
    
     
    if(Iconf.open(pConfFile) < 0)
    {
        printf("open ConfFile failed!\n");
        return -1;
    }
    
    
    pSec = Iconf.getSection("COMMON");
    if(NULL == pSec)
    {
        printf("get COMM section failed!\n");
        return -1;
    }
    
    //-------------------------------------------
    // set logger path & logger head information
    //-------------------------------------------
    //set log level
    int log_file_lev, log_term_lev;
    sData = pSec->getValue("LOG_LEVEL_FILE");
    if(0 == sData.length())
    {
    	log_file_lev = 40;
    }
    log_file_lev = atoi(sData.c_str());
    sData = pSec->getValue("LOG_LEVEL_TERM");
    if(0 == sData.length())
    {
    	log_term_lev = 40;
    }
    log_term_lev = atoi(sData.c_str());
    SET_LOG_LEVEL(&g_scf_log, log_file_lev, log_term_lev);

    //initLogLevel(&g_service_log, Iconf);    // calling r5api.h
    sData = pSec->getValue("LOG_PATH");
    if (0 == sData.length())
    {
        printf("ERROR: read LOG_PATH cfg param failed!\n" );
        return -1;        
    }
    if (SET_LOG_DIR(&g_scf_log, sData.c_str())<0) // calling r5log.h
    {
    	printf("ERROR: set log path failed:%s!\n", sData.c_str());
    	return -1;
    }
   
    sData = pSec->getValue("LOG_HEADER");
    if (0 == sData.length())
    {
    	printf("ERROR: read LOG_HEADER cfg param failed!\n");
    	return -1;
    }
    SET_LOG_NAME_HEAD(&g_scf_log, sData.c_str());  // calling r5log.h
    
    //----------------------------------------------------------
    //�������
    //----------------------------------------------------------
    ///��Ŀ¼·��
    sData = pSec->getValue("ROOT_PATH");
    if(0 == sData.length())
    {
        printf("FMP: get ROOT_PATH failed!\n");
        return -1;
    }
    strncpy(g_pConf->szRootPath, sData.c_str(), MAX_PATH_LEN);
    
    ///SortBill������
    sData = pSec->getValue("EXE_NAME");
    if(0 == sData.length())
    {
        printf("FMP: get EXE_NAME failed!\n");
        return -1;
    }
    strncpy(g_pConf->szProName, sData.c_str(), 64);
    
    ///SortBill�����ļ���
    sData = pSec->getValue("CONF_FILE");
    if(0 == sData.length())
    {
        printf("FMP: get CONF_FILE failed!\n");
        return -1;
    }
    strncpy(g_pConf->szSortConfFile, sData.c_str(), MAX_FILE_LEN);
    
    //----------------------------------------------------------
    //��ȡɨ�������Ϣ
    //----------------------------------------------------------
    //������������ֵ
    sData = pSec->getValue("SORT_THRESHOLD");
    if (0 == sData.length())
    {
    	printf("ERROR: read SORT_THRESHOLD cfg param failed!\n");
    	return -1;
    }
    g_pConf->nSortThreshold = atoi(sData.c_str());
    
    //�澯��ֵ
    sData = pSec->getValue("ALARM_THRESHOLD");
    if (0 == sData.length())
    {
    	printf("ERROR: read ALARM_THRESHOLD cfg param failed!\n");
    	return -1;
    }
    g_pConf->nAlarmThreshold = atoi(sData.c_str());
    
    //ʧ�ܴ�����ֵ
    sData = pSec->getValue("FAILURE_COUNT");
    if (0 == sData.length())
    {
    	printf("ERROR: read FAILURE_COUNT cfg param failed!\n");
    	return -1;
    }
    g_pConf->nFailureCount = atoi(sData.c_str());
    
    //����ʱ��
    sData = pSec->getValue("SLEEP_TIME");
    if (0 == sData.length())
    {
    	printf("ERROR: read SLEEP_TIME cfg param failed!\n");
    	return -1;
    }
    g_pConf->nSleepTime = atoi(sData.c_str());
    
    //=============================��ȡ���ݿ�������Ϣ===========================
	sData = pSec->getValue("DB_NAME");
	if(0 == sData.length())
    {
        printf("SORT: get DB_NAME failed!\n");
        return -1;
    }
    strncpy( g_pConf->szDbName, sData.c_str(), sizeof(g_pConf->szDbName) );
    sData = pSec->getValue("DB_ADDR");
	if(0 == sData.length())
    {
        printf("SORT: get DB_ADDR failed!\n");
        return -1;
    }
    strncpy( g_pConf->szDbAddr, sData.c_str(), sizeof(g_pConf->szDbAddr) );
    sData = pSec->getValue("DB_USER");
	if(0 == sData.length())
    {
        printf("SORT: get DB_USER failed!\n");
        return -1;
    }
    strncpy( g_pConf->szDbUser, sData.c_str(), sizeof(g_pConf->szDbUser) );
    sData = pSec->getValue("DB_PWD");
	if(0 == sData.length())
    {
        printf("SORT: get DB_PWD failed!\n");
        return -1;
    }
    strncpy( g_pConf->szDbPwd, sData.c_str(), sizeof(g_pConf->szDbPwd) );
    sData = pSec->getValue("DB_PORT");
	if(0 == sData.length())
    {
        printf("SORT: get DB_PORT failed!\n");
        return -1;
    }
    g_pConf->nDbPort = atoi(sData.c_str());
       
    return(0);
}



int Register_Signal()
{
    //ˢ�������ź�,�����ж�,ִ�����źŴ��������,�����ж�ǰ�ĺ���
    if (my_signal(SIGHUP, SigHup, false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGHUP error\n");
        return -1;
    }
    
    //��־��д�ź�,�����ж�,ִ�����źŴ��������,�����ж�ǰ�ĺ���
    if (my_signal(SIGUSR2, SigUsr2, false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGUSR2 error\n");
        return -1;
    }
    
    //��ֹ�ź�,�����ж�,ִ�����źŴ��������,ԭ���������жϷ���EINTR
    if (my_signal(SIGTERM, SigTerm , true) == SIG_ERR)
    {
        LOG_ERROR("signal SIGTERM error\n");
        return -1;
    }
    
    if(my_signal(SIGUSR1, SIG_IGN ,false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGUSR1 error:%s\n", strerror(errno));      
        return -1;
    }
    
    ///�ն��жϷ� ����
    if(my_signal(SIGINT, SigTerm ,true) == SIG_ERR)
    {
        LOG_ERROR("signal SIGINT error:%s\n", strerror(errno));      
        return -1;
    }
    
    /*
    ///SIGALRM �ź�
    if(my_signal(SIGALRM, SigAlarm ,false) == SIG_ERR)
    {
        LOG_ERROR("signal SIGALRM error:%s\n", strerror(errno));      
        return -1;
    }*/
    
    return 0;
        
}


int Scf_Destroy()
{
    int nRet = -1;

    LOG_INFO("Process exit!\n");
    
    ///ˢ����־
	g_scf_log.flush();
    
    return 0;
}








