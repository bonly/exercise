#include "DataAccess_Mysql.h"
#include <iostream>
#include <vector>





mysqlpp::Connection g_conn(false);
	

	
	
	
int connectDb(char *db_name, char *ip_addr, char *user, char *pwd, int nPort)
{
	if(g_conn.connect(db_name, ip_addr, user, pwd, nPort))
	{
		LOG_INFO("connect db sucess!\n");
		return 0;
	}
	else
	{
		LOG_ERROR("db connect failed!(%s|%s|%s|%s|%d|%s)\n", db_name, ip_addr, user, pwd, nPort, g_conn.error());
		return -1;
	}
		
}



unsigned long GetNowTimeString()
{
    time_t  t;
    t=time(NULL);
    struct tm *s_time=localtime(&t);
    
    unsigned long lTime = mktime(s_time) + CONV_1900_1970;
    return     lTime;
}



int selectNodeGroupInfo(NODE_LIST* pNL)
{
	if( !g_conn.ping() )
	{
		if( connectDb(g_pConf->szDbName, g_pConf->szDbAddr, g_pConf->szDbUser, g_pConf->szDbPwd, g_pConf->nDbPort) )
		{
			return -1;
		}
	}
	
	char sql[256]={0};
	snprintf(sql, sizeof(sql), "select groupID,connectStr,unloadPath,status,processStep,updateTime from Node_Group order by groupID");
	
	Query query = g_conn.query(sql);
	if (StoreQueryResult res = query.store()) 
	{		
		pNL->nCount = 0;
		for (size_t i =0; i < res.num_rows(); ++i)
		{
			pNL->stNode[i].groupID     = atoi(res[i]["groupID"].c_str());
			strncpy(pNL->stNode[i].connectStr, res[i]["connectStr"].c_str(), sizeof(pNL->stNode[i].connectStr));
			strncpy(pNL->stNode[i].unloadPath, res[i]["unloadPath"].c_str(), sizeof(pNL->stNode[i].unloadPath));
			pNL->stNode[i].status      = atoi(res[i]["status"].c_str());
			pNL->stNode[i].processStep = atoi(res[i]["processStep"].c_str());
			pNL->stNode[i].updateTime  = atol(res[i]["updateTime"].c_str());
			pNL->nCount++;
		}
		return(0);

	}
	else
	{
		LOG_ERROR("Failed to get item list: %s\n", query.error() );	
		return -1;
	}
}












