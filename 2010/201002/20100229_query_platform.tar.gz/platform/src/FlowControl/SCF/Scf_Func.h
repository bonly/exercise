#ifndef _SCF_FUNC_H_
#define _SCF_FUNC_H_


#include "Scf_Common.h"




//
int Scf_Process(const char *pConfFile);


int GetNodeGroupInfo(NODE_LIST* pNL);
int GetFileNum(char *path);

#endif


