#include "Ncf_Crl.h"
#include "DataAccess_Mysql.h"
#include "Error.h"
#include "Ncf_Init.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>





//---------------------------------------------------
//׼������
//---------------------------------------------------
int PM_Init(int nGroupID)
{
	//��Router��ѯ�ڵ���������Ϣ
	int nRet = getNodeConnStr(nGroupID);
	if(nRet != 0)
	{
		LOG_ERROR("getNodeConnStr error!\n");
		return -1;
	}
	
	//������ID��ѯ״̬�Լ����̲���
	nRet = getNodeGroupForID(nGroupID);
	if(nRet != 0)
	{
		LOG_ERROR("getNodeGroupInfo error!\n");
		return -1;
	}
	
	return 0;
}


int getNodeGroupForID(int nGroupID)
{
	int nRet = 0;
	
	nRet = selectNodeGroupForID(nGroupID);
	if(nRet != 0)
	{
		LOG_ERROR("selectNodeGroupForID error!\n");
		return -1;
	}
	
	return 0;
	
}


int getNodeConnStr(int nGroupID)
{
	int nRet = 0;
	
	Protocal p;
	char *buf = NULL;
	char szGroup[4];
	snprintf(szGroup, sizeof(szGroup), "%d", nGroupID);
	p<<szGroup<<SEL_GP_ROUTER_REQ;
	int nLen = p.Encode(buf);  
	if(nLen <= 0)
	{
		LOG_ERROR("Protocal Encode fail! code=%d\n", nLen);
		return -1;
	}
	
	LOG_DEBUG("parket send:%s", p.Buffer()->GetMsgBody());
	
	//���ͽ�����Ϣ
	nRet = RounterExchangeTCP(buf, nLen, p);
	if(nRet != 0)
	{
		LOG_ERROR("RounterExchangeTCP error! code=%d\n", nRet);
		return -1;
	}
	
	//������
	LOG_DEBUG("RECV:%s\n", p.Buffer()->GetMsgBody())
	
	//����������Ϣ
	nRet = SaveConnStr(p);
	if(nRet != 0)
	{
		LOG_ERROR("SaveConnStr error! code=%d\n", nRet);
		return -1;
	}
	
	return 0;
}


int SaveConnStr(Protocal &p)
{
	//router�޼�¼����Ҫ����
	if(p.data()->nodeMsgNum == 0)return 0;
	g_stCL.nCount = 0;
	for(int i=0; i<p.data()->nodeMsgNum; i++)
	{
		strncpy(g_stCL.stItem[i].connectStr, p.data()->nodes[i].connectStr, sizeof(g_stCL.stItem[i].connectStr));
		g_stCL.stItem[i].status = p.data()->nodes[i].status;
		g_stCL.nCount++;
	}
	return 0;		
}


//----------------------------------------------------
//���ڵ�״̬�Ƿ�����
//----------------------------------------------------
int CheckNodeStatus(int nGroupID)
{
	for(int i=0; i<g_stCL.nCount; i++)
	{
		if(g_stCL.stItem[i].status != 0)
		{
			LOG_ERROR("node status(%d) abnormal! connStr=%s\n", g_stCL.stItem[i].status, g_stCL.stItem[i].connectStr);
			return -1;
		}
	}
	return 0;
	
}



//----------------------------------------------------
//�޸Ľڵ�״̬
//----------------------------------------------------
int AlterNodeStatus(int nGroupID, int status)
{
	int nRet = 0;
	
	Protocal p;
	char *buf = NULL;
	char num[4];
	snprintf(num, sizeof(num), "%d", g_stCL.nCount);
    p<<num;
    
    char szType[4];
    snprintf(szType, sizeof(szType), "%d", status);
    
    for(int i=0; i<g_stCL.nCount; i++)
    {
    	p<<g_stCL.stItem[i].connectStr<<szType;
    }
    p<<UPDATE_ROUTER_REQ;
    int nLen = p.Encode(buf);  
	if(nLen <= 0)
	{
		LOG_ERROR("Protocal Encode fail! code=%d\n", nLen);
		return -1;
	}
	
	LOG_DEBUG("parket send:%s", p.Buffer()->GetMsgBody());
	
	//���ͽ�����Ϣ
	nRet = RounterExchangeTCP(buf, nLen, p);
	if(nRet != 0)
	{
		LOG_ERROR("RounterExchangeTCP error! code=%d\n", nRet);
		return -1;
	}
	
	//������
	LOG_DEBUG("RECV:%s\n", p.Buffer()->GetMsgBody())
    
    //����Ƿ�ɹ�
    if(p.data()->resultcode != 0)
    {
    	LOG_ERROR("Command processing failed or illegal, code=%d\n", p.data()->resultcode);
    	return -1;
    }
    
    //�������ڵ��Ƿ���³ɹ�
    if(p.data()->nodeMsgNum > 0)
    {
        for(int j=0; j<p.data()->nodeMsgNum; j++)
        {
    	    LOG_ERROR("%s update status(%d) error\n", p.data()->nodes[j].connectStr, p.data()->nodes[j].status);
        }
        return -1;
    }
    
	return 0;
}



//------------------------------------------------------------
//����ӿ�
//------------------------------------------------------------
int RounterExchangeTCP(char *InBuf, int nLen, Protocal &p)
{
	int nRealCount = 0;
	int nTmpCount  = 0;
	int nRet = 0;
	
	///send
	while (nRealCount < nLen)
	{
		nTmpCount = ::send(g_nFd, InBuf+nRealCount, nLen-nRealCount, 0);
		//cout<<"send:"<<nTmpCount<<endl;
		if (nTmpCount >= 0)
		{
			nRealCount += nTmpCount;
		}
		else  // -1
		{
			// c1: interrupt
			if (errno == EINTR)  // ����I/O, ���ж�
			{
				continue;
			}
			
			// c2: error
			LOG_ERROR("send is error! error code is %d\n", nTmpCount);
			return ER_NET_SEND_ERROR;
		}
	}
	
	// receiv msg
	fd_set rset;
    struct timeval tv;
    tv.tv_sec  = 3; // 3��
    tv.tv_usec = 0;  
    int nRecvLen = 0;
    char OutBuf[NET_PACKET_LENGTH] = {0};
    
    while (true)
	{
		FD_ZERO(&rset);
		FD_SET(g_nFd, &rset);
		nRet = select(g_nFd+1, &rset, NULL, NULL, &tv);
		if (nRet > 0)
		{
			if (FD_ISSET(g_nFd, &rset))
			{
				memset(OutBuf, 0 , sizeof(OutBuf));
				// read head
				if (nRet = readTCPMsg(g_nFd, OutBuf, PACKET_HEAD_LEN) == 0)
				{
					//len=4
					nRecvLen = ntohl(*((int*)(OutBuf)));
					// �����Ϣ�����Ƿ�Ϸ�
    				if (nRecvLen < PACKET_HEAD_LEN|| nRecvLen > NET_PACKET_LENGTH)
   					{
   						LOG_ERROR("Message len=%d\n", nRecvLen);
   						return ER_RE_MSG_HEAD_LENGTH_ERROR;
   					}
   					
   					// read body
   					if (nRet = readTCPMsg(g_nFd, OutBuf+PACKET_HEAD_LEN, nRecvLen-PACKET_HEAD_LEN) == 0)
   					{
                        p.Reset();
                        nRet = p.DecodeAns(OutBuf);
                        if(nRet != 0)
                        {
                        	LOG_ERROR("Protocal DecodeAns error! ret=%d\n");
                        	return ER_PRO_DECODEANS_ERROR;
                        }
                        if(p.data()->acommand != SEL_GP_ROUTER_RES && p.data()->acommand != UPDATE_ROUTER_RES)
                        {
                        	LOG_ERROR("not right answer code(%d)\n", p.data()->acommand);
                        	return ER_PRO_ANS_CODE_ERROR;
                        }
                        return SUCCESS;
   						
   					} // ~end of if()
 				}
		        if(nRet == -1)
		        {
		            return ER_NET_RECV_ERROR_READMSG;
		        }
		        if(nRet == -2)
		        {
		            return ER_NET_SOCKET_CLOSED;
		        }
		        else
		        {
		            return -4;
		        }
			}
			else
			{
				FD_SET(g_nFd, &rset);
			}
		}
		else if (nRet == 0)
		{
			// time out
			return ER_NET_RECV_TIME_OUT;
		}
		else if (nRet < 0 && errno == EINTR)
		{
			// error
			continue;
		}
		else
		{
			return ER_NET_RECV_ERROR_SELECT;
		}
	} // ~end of while()

	return nRet;
}




int readTCPMsg(int nSocketfd, char* pBuffer, int nSize)
{
	int nRealCount = 0;
	int nTmpCount  = 0;
	
	while (nRealCount < nSize)
	{	
		// �ֽ������ⲿת��
		nTmpCount = ::recv(nSocketfd, pBuffer + nRealCount, nSize - nRealCount, 0);
		if (nTmpCount > 0)
		{
			nRealCount += nTmpCount;
		}
		else if (nTmpCount == 0)
		{
		    LOG_ERROR("peer socket is closed!\n");
			return -2;  // peer socket is closed
		}
		else  // -1
		{
			// c1: interrupt
			if (errno == EINTR)  // ����IO, ���ж�
			{
				continue;
			}
	
			// c2: error
			LOG_ERROR("recv is error! error code is %d\n", nTmpCount);
			return -1;
		}
	}
	
	return 0;
	
}



//----------------------------------------------------
//����newtable��״̬
//----------------------------------------------------
int AlterNewtableStatus(char *tn, int num)
{
	if(tn == NULL)
	{
		LOG_ERROR("[AlterNewtableStatus]tn is NULL\n");
		return -1;
	}
	int nRet = 0;
	mysqlpp::Connection conn(false);
	DB_CONN_STR stConnStr;
	memset(&stConnStr, 0, sizeof(DB_CONN_STR));
	for(int i=0; i<g_stCL.nCount; i++)
	{
		AnalyConnString(g_stCL.stItem[i].connectStr, stConnStr);
		
		nRet = connectDb(stConnStr.szDbName, stConnStr.szDbAddr, stConnStr.szDbUser, stConnStr.szDbPwd, 
		                    stConnStr.nDbPort, conn);
		if(nRet != 0)
		{
			LOG_ERROR("connectDb error!\n");
    	    return -1;
		}
		
		nRet = updateNewtableStatus(conn, tn, num, 0, 1);
		if(nRet != 0)
		{
			LOG_ERROR("updateNewtableStatus error!\n");
    	    return -1;
		}           
		
		///�ͷ����ݿ�����
	    //conn.Destory();   
		             
	}
	
	return 0;	
}



void AnalyConnString(char * connectStr, DB_CONN_STR &stConnStr)
{
	char szConnstr[1024];
	memset(szConnstr, 0, sizeof(szConnstr));
	strncpy(szConnstr, connectStr, sizeof(szConnstr));
	
	strncpy(stConnStr.szDbAddr, strtok(szConnstr, "|"), sizeof(stConnStr.szDbAddr));
	char* sPort = strtok(NULL, "|");
	stConnStr.nDbPort = atoi(sPort);
	strncpy(stConnStr.szDbName, strtok(NULL, "|"), sizeof(stConnStr.szDbName));
	strncpy(stConnStr.szDbUser, strtok(NULL, "|"), sizeof(stConnStr.szDbUser));
	strncpy(stConnStr.szDbPwd,  strtok(NULL, "|"), sizeof(stConnStr.szDbPwd));
	LOG_DEBUG("server=%s,p=%d,db=%s,usr=%s,pwd=%s\n",stConnStr.szDbAddr, stConnStr.nDbPort, stConnStr.szDbName, stConnStr.szDbUser, stConnStr.szDbPwd);	
}




//------------------------------------------------------------------
//һ���Լ����ѹ�����
//------------------------------------------------------------------
void getModelNode(vector<ST_INS_INFO> &v_si, int ref, char *connectStr, int nLen)
{
	int max_ins = 0;
	memset(connectStr, 0, sizeof(connectStr));
	
	for(int i=0; i<v_si.size(); i++)
	{
	    if(ref == v_si[i].nIns_count)
	    {
	    	strncpy(connectStr, v_si[i].stConnInfo.connectStr, nLen);
	    	break;
	    }
	    else if(v_si[i].nIns_count > max_ins)
	    {
	    	max_ins = v_si[i].nIns_count;
	    	strncpy(connectStr, v_si[i].stConnInfo.connectStr, nLen);
	    }
    }

}



int TransferCompress(char *connectStr, int nLen, int table_num)
{
	if(connectStr == NULL)
	{
		LOG_ERROR("[TransferCompress]connectStr is NULL\n");
		return -1;
	}
	int nRet = 0;
	int nFd = 0;
	DB_CONN_STR stDBCS[4];
	memset(stDBCS, 0, sizeof(DB_CONN_STR)*4);
	char szCopystr[1024];
	char szTmpstr[512];
	memset(szCopystr, 0, sizeof(szCopystr));
	
	for(int i=0; i<g_stCL.nCount&&i<5; i++)
	{
		memset(szTmpstr, 0, sizeof(szTmpstr));
		AnalyConnString(g_stCL.stItem[i].connectStr, stDBCS[i]);
		if( strncmp(connectStr, g_stCL.stItem[i].connectStr, nLen) == 0)
		{			
			///����socket����
			InitNet(nFd, stDBCS[i].szDbAddr, g_pConf->nAgentPort);
			
		}
		else
		{
			snprintf(szTmpstr, sizeof(szTmpstr), "%s:%d:%s:%s:%s:%s", stDBCS[i].szDbAddr, stDBCS[i].nDbPort, stDBCS[i].szDbName,
			                   stDBCS[i].szDbUser, stDBCS[i].szDbPwd, g_stNode.compressPath);
			if( strlen(szCopystr) != 0)
			{
				strcat(szCopystr, "|");	
			}
			strcat(szCopystr, szTmpstr);
		}
	}
	
	char szInBuf[4096], szOutBuf[4096];
	memset(szInBuf, 0, sizeof(szInBuf));
	memset(szOutBuf, 0, sizeof(szOutBuf));
	//�齨Agent�����
	nRet = CreateAgentReqPacket(g_pConf->szAgentProName, g_pConf->szAgentConfName, table_num, szCopystr, szInBuf, sizeof(szInBuf));
	if(nRet != 0)
	{
		LOG_ERROR("CreateAgentReqPacket error\n");
		return -1;
	}
	
	//��Agent����������ܷ���
	nRet = AgentExchangeTCP(szInBuf, strlen(szInBuf), nFd, szOutBuf);
	if(nRet != 0)
	{
		LOG_ERROR("AgentExchangeTCP error, code=%d\n", nRet);
		return -1;
	}
	
	//����Agent��������,ȷ�Ͻ��
	nRet = CheckAgentResPacket(szOutBuf);
	if(nRet != 0)
	{
		LOG_ERROR("CheckAgentResPacket error, code=%d\n", nRet);
		return -1;
	}
	
	//�ر�socket
	CleanupNet(nFd);
	return 0;
}


int CreateAgentReqPacket(char *szProName, char *szConfName, int table_num, char *szCopystr, char *buf, int nLen)
{
	
	if(szProName == NULL || szCopystr == NULL || buf == NULL)
	{
		LOG_ERROR("[CreateAgentReqPacket]szProName or szCopystr or buf is NULL\n");
		return -1;
	}
    char tmp1[1024], tmp2[2048];
    memset(tmp1, 0, sizeof(tmp1));
    memset(tmp2, 0, sizeof(tmp2));    
    
    if( strlen(szCopystr) == 0 )
    {
        snprintf(tmp1, sizeof(tmp1), "-n %d -f -c %s", table_num, szConfName);
    }
    else
    {
    	snprintf(tmp1, sizeof(tmp1), "-n %d -s %s -c %s", table_num, szCopystr, szConfName);
    }
    snprintf(tmp2, sizeof(tmp2), "<type>%d</type><name>%s</name><param>%s</param><max>1</max>", AGENT_START, szProName, tmp1);
    //snprintf(tmp2, sizeof(tmp2), "<type>%d</type><name>%s</name><param>%s</param><max>1</max>", 1, "/home/hadoop/compress/test", "");
    snprintf(buf,  nLen, "%04d%s", strlen(tmp2)+4, tmp2);
    
    LOG_DEBUG("Agent Msg: %s\n", buf);
    
    return 0;	
	
}



int AgentExchangeTCP(char *szInBuf, int nLen, int nFd, char *szOutBuf)
{
	if(szInBuf == NULL || szOutBuf == NULL)
	{
		LOG_ERROR("[AgentExchangeTCP]szInBuf or szOutBuf is NULL\n");
		return -1;
	}
	
	int nRealCount = 0;
	int nTmpCount  = 0;
	int nRet = 0;
	
	///send
	while (nRealCount < nLen)
	{
		nTmpCount = ::send(nFd, szInBuf+nRealCount, nLen-nRealCount, 0);
		if (nTmpCount >= 0)
		{
			nRealCount += nTmpCount;
		}
		else  // -1
		{
			// c1: interrupt
			if (errno == EINTR)  // ����I/O, ���ж�
			{
				continue;
			}
			
			// c2: error
			LOG_ERROR("send is error! error code is %d\n", nTmpCount);
			return ER_NET_SEND_ERROR;
		}
	}
	
	// receiv msg
	fd_set rset;
    struct timeval tv;
    tv.tv_sec  = 30; // 3��
    tv.tv_usec = 0;  
    int nRecvLen = 0;
    
    while (true)
	{
		FD_ZERO(&rset);
		FD_SET(nFd, &rset);
		nRet = select(nFd+1, &rset, NULL, NULL, &tv);
		if (nRet > 0)
		{
			if (FD_ISSET(nFd, &rset))
			{
				memset(szOutBuf, 0 , sizeof(szOutBuf));
				// read head
				if (nRet = readTCPMsg(nFd, szOutBuf, PACKET_HEAD_LEN) == 0)
				{
					//len=4
					nRecvLen = atoi(szOutBuf);
					// �����Ϣ�����Ƿ�Ϸ�
    				if (nRecvLen < PACKET_HEAD_LEN|| nRecvLen > NET_PACKET_LENGTH)
   					{
   						LOG_ERROR("Message len=%d\n", nRecvLen);
   						return ER_RE_MSG_HEAD_LENGTH_ERROR;
   					}
   					
   					// read body
   					if (nRet = readTCPMsg(nFd, szOutBuf+PACKET_HEAD_LEN, nRecvLen-PACKET_HEAD_LEN) == 0)
   					{
   						LOG_DEBUG("rev msg:%s\n", szOutBuf);
                        return SUCCESS;
   						
   					} // ~end of if()
 				}
		        if(nRet == -1)
		        {
		            return ER_NET_RECV_ERROR_READMSG;
		        }
		        if(nRet == -2)
		        {
		            return ER_NET_SOCKET_CLOSED;
		        }
		        else
		        {
		            return -4;
		        }
			}
			else
			{
				FD_SET(nFd, &rset);
			}
		}
		else if (nRet == 0)
		{
			// time out
			return ER_NET_RECV_TIME_OUT;
		}
		else if (nRet < 0 && errno == EINTR)
		{
			// error
			continue;
		}
		else
		{
			return ER_NET_RECV_ERROR_SELECT;
		}
	} // ~end of while()
	
	return nRet;
}




int CheckAgentResPacket(char *buf)
{
	if(buf == NULL)
	{
		LOG_ERROR("[CheckAgentResPacket]buf is null\n");
		return -1;
	}
	
	char szMsg[4096];
	memset(szMsg, 0, sizeof(szMsg));
	
	memcpy(szMsg, buf, sizeof(szMsg));
	
	int nMsgLen = atoi(strtok(szMsg, "<retcode>"));
	int retcode = atoi(strtok(NULL, "</retcode>"));
	if(retcode != EXEC_SUSS)
	{
		LOG_ERROR("start compress abnormal\n");
        return -1;
	}
	return 0;
}



//--------------------------------------------------------------------
//
//--------------------------------------------------------------------
int AdjustNewtableStatus()
{
	int nRet = 0;
	mysqlpp::Connection conn(false);
	int id = 0;
	DB_CONN_STR stConnStr;
	memset(&stConnStr, 0, sizeof(DB_CONN_STR));
	for(int i=0; i<g_stCL.nCount; i++)
	{
		AnalyConnString(g_stCL.stItem[i].connectStr, stConnStr);
		
		nRet = connectDb(stConnStr.szDbName, stConnStr.szDbAddr, stConnStr.szDbUser, stConnStr.szDbPwd, 
		                    stConnStr.nDbPort, conn);
		if(nRet != 0)
		{
			LOG_ERROR("connectDb error!\n");
    	    return -1;
		}
		
		nRet = selectNewtableRecord(conn, -1, id);
		if(nRet != 0)
		{
			LOG_ERROR("selectNewtableRecord error!\n");
    	    return -1;
		} 
		LOG_DEBUG("id=%d\n", id);
		
		nRet = updateNewtableForID(conn, id);
		if(nRet != 0)
		{
			LOG_ERROR("updateNewtableForID error!\n");
    	    return -1;
		} 
		
		///�ͷ����ݿ�����
	    //conn.Destory();   
		             
	}
	
	return 0;	
}














