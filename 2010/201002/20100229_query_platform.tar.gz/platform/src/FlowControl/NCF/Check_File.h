#ifndef _CHECK_FILE_H_
#define _CHECK_FILE_H_





int GetFileNum(char *path);

int CheckUnloadFile(int nGroupID);






#endif



