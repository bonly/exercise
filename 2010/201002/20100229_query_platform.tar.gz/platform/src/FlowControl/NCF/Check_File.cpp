#include "Check_File.h"
#include "Ncf_Common.h"
#include "DataAccess_Mysql.h"







int GetFileNum(char *path)
{
	char cmd[512];
	
	memset(cmd, 0, sizeof(cmd));
	
    struct dirent **namelist;
    int n = scandir(path, &namelist, 0, 0);
	if(n < 0)
	{
		perror("not found\n");
		return -1;
	}
	else
	{
		LOG_DEBUG("path:%s, file:%d\n", path, n);
		//ע��namelist��ͨ��malloc��̬�����ڴ��,������ʹ��ʱҪע���ͷ��ڴ�
		for(int i=0; i<n; i++)
		{
			free(namelist[i]);
		}
		free(namelist);
		
		//"."��".."��Ҫ�ų�����
		return (n-2);
	}
	
}

/*
int GetNodeGroupInfo(NODE_LIST* pNL)
{
	int nRet = 0;
	
	nRet = selectNodeGroupInfo(pNL);
	if(nRet != 0)
	{
		LOG_ERROR("selectNodeGroup error!\n");
		return -1;
	}
	
	return 0;
	
}
*/

int CheckUnloadFile(int nGroupID)
{
	int nRet = 0;
	
	int nFileNum = GetFileNum(g_stNode.unloadPath);
	nRet = selectNodeGroupForID(nGroupID);
	if(nRet != 0)
	{
		LOG_ERROR("selectNodeGroupForIDs error!\n");
		return -1;
	}
	
	//������
	int st = 0;
	int pid = 0;
	char szSortBin[1024];
    char szConfFile[1024];
	do
	{
		//�ȼ���Ƿ�ȴ�̫��ʱ����
		if(st > g_pConf->nWaitSortBillNum)
		{
			LOG_ERROR("SortBill deal too long time!\n");
			return -1;
		}
			
		if(nFileNum > 0 && g_stNode.status == SORT_END)
		{
						
			//����·��
            snprintf(szSortBin, sizeof(szSortBin), "%s/bin/%s", g_pConf->szRootPath, g_pConf->szProName);
            snprintf(szConfFile, sizeof(szConfFile), "%s/etc/%s", g_pConf->szRootPath, g_pConf->szSortConfFile);
        
            pid = fork();
            if(pid < 0)
            {
                perror("fork");
            }
            else if(pid == 0)
            {
                nRet = execl(szSortBin, 
            		     g_pConf->szProName,
            		     "-c", szConfFile,
            		     "-p", g_stNode.unloadPath,
            		     (char*)NULL);
                if(nRet == -1)
                {
                    //perror("execl");
                    LOG_ERROR("%s -c %s -p %s\n", g_pConf->szProName, szConfFile, g_stNode.unloadPath);
                    exit(0);	
                }
                exit(0);
            }
			
			nRet = updateNodeGroupStatus(SORT_STARTED, nGroupID);
            if(nRet != 0)
            {
                LOG_ERROR("updateNodeGroupInfo error, ret=%d\n", nRet);
                return -1;	
            }    	
		}
		
		sleep(g_pConf->nWaitSortBillTime);
        st++;
		
		//����һ��������Ϣ
        nFileNum = GetFileNum(g_stNode.unloadPath);
	    nRet = selectNodeGroupForID(nGroupID);
	    if(nRet != 0)
	    {
		    LOG_ERROR("selectNodeGroupForID error!\n");
		    return -1;
	    }	
						
	}
	while(nFileNum > 0);

	//
	return 0;
	
}




















