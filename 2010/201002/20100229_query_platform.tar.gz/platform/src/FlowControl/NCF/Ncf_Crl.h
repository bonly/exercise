#ifndef _NCF_CRL_H_
#define _NCF_CRL_H_


#include "Ncf_Common.h"
#include "Protocal.h"
#include "ConsisCheck.h"



using namespace bas;



//׼��
int PM_Init(int nGroupID);
int getNodeGroupForID(int nGroupID);
int getNodeConnStr(int nGroupID);
int SaveConnStr(Protocal &p);

//
int CheckNodeStatus(int nGroupID);

//
int AlterNodeStatus(int nGroupID, int status);

//
int RounterExchangeTCP(char *InBuf, int nLen, Protocal &p);
int readTCPMsg(int nSocketfd, char* pBuffer, int nSize);

//
int AlterNewtableStatus(char *tn, int num);
void AnalyConnString(char * connectStr, DB_CONN_STR &stConnStr);

//
void getModelNode(vector<ST_INS_INFO> &v_si, int ref, char *connectStr, int nLen);
int TransferCompress(char *connectStr, int nLen, int table_num);
int CreateAgentReqPacket(char *szProName, char *szConfName, int table_num, char *szCopystr, char *buf, int nLen);
int AgentExchangeTCP(char *szInBuf, int nLen, int nFd, char *szOutBuf);
int CheckAgentResPacket(char *buf);
int AdjustNewtableStatus();












#endif


