#ifndef _DATAACCESS_MYSQL_H_
#define _DATAACCESS_MYSQL_H_

#include <cstdio>
#include <mysql++.h>
#include <cstdlib>
#include <ssqls.h>
#include "Ncf_Common.h"


using namespace std;
using namespace mysqlpp;

extern Connection g_conn;
	
	
	

int connectDb(char *db_name, char *ip_addr, char *user, char *pwd, int nPort, mysqlpp::Connection &conn);

//select
int selectNodeGroupInfo(NODE_LIST* pNL);
int selectNodeGroupForID(int nGroupID);

//update
int updateNodeGroupStatus(int nStatus, int groupID);
int updateNodeGroupStep(int nStep, int groupID);


//Զ�̵�¼
int updateNewtableStatus(mysqlpp::Connection &conn, char *tn, int num, int status_src, int status_tar);
int selectNewtableRecord(mysqlpp::Connection &conn, int status, int &id);
int updateNewtableForID(mysqlpp::Connection &conn, int id);








#endif







