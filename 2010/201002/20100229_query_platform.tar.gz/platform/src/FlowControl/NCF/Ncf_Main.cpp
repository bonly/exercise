#include "Ncf_Main.h"
#include "Ncf_Init.h"
#include "Ncf_Func.h"
#include <unistd.h>
#include <stdio.h>
#include <iostream> 



R5_Log g_ncf_log;
NCF_CONF *g_pConf;
int    g_nGroupID;




void Help_Message()
{
    printf("NCF [-h] [-c profile] [-g groupID] [-e] [-v]\n");
    printf("            -h: Show Help_Message\n");
    printf("            -c: conf file\n");
    printf("            -e: deamon\n");
    printf("            -v: version\n");
}


void Get_Option(int argc, char *argv[], char *pConfFile, int nGroupID, int &nProType, bool &bDaemon)
{

    extern char *optarg;
    int optch;

    static char optstring[] = "hec:g:vV";
    
    char szType[10]={0};
    
    while((optch = getopt(argc , argv , optstring)) != -1 ) 
    {
        switch( optch ) 
        {
        case 'h':
            Help_Message();
            exit(-1);
        case 'e':
            bDaemon = true;
            break;
        case 'c':            
            strcpy(pConfFile, optarg);
            break;
        case 'g': 
        	nGroupID = atoi(optarg);
        	//printf("deal with group id %d\n", nGroupID);          
            break;
        case 'v':
        case 'V':
            printf("NCF version %s\n", PROGRAM_VERSION);
            exit(-1);
        case '?':
            Help_Message();
            printf("unknown parameter: %c\n", optopt);
            exit(-1);
        case ':':
            Help_Message();
            printf("need parameter: %c\n", optopt);
            exit(-1);

        default:
            break;
        }
    }
        
    if(access(pConfFile, F_OK) != 0)
    {
        printf("conf file %s not exist,please check!\n", pConfFile);
        exit(-1);
    }
    
}

void daemon() 
{
    // ��̨����
    int pid = 0;
    pid = fork();
    if(pid < 0)
    {
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return;
    }  
    if (pid  >  0) 
    {
        exit(0);
    }
   
    setsid();
    pid=fork();
    if(pid < 0)
    {
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return;           
    }    
    if(pid > 0) 
    {
        exit(0);
    }
}


int main(int argc, char *argv[])
{
	
    char szConfFile[MAX_FILE_LEN+1];
    NCF_CONF stNC;
    
    memset(&stNC,      0, sizeof(NCF_CONF));
    memset(szConfFile, 0, sizeof(szConfFile));
    
    g_pConf = &stNC;
    
    int nProType   = -1;
    int nRet       = -1;
    bool bDaemon   = false;
    
    ///��ȡ�������
    Get_Option(argc, argv, szConfFile, g_nGroupID, nProType, bDaemon);
    
    if(bDaemon)
    {
        daemon();
    }
     
    nRet = Ncf_Init(szConfFile, strlen(szConfFile));
    if(nRet != 0)
    {
        printf("Init failed!\n");
        exit(-1);
    }
        
    nRet = Ncf_Process(g_nGroupID);
    if(nRet != 0)
    {
    	LOG_ERROR("Ncf_Process error! ret=%d\n", nRet);
    }
    
    nRet = Ncf_Destroy();
    if(nRet < 0)
    {
        LOG_ERROR("Ncf_Destroy failed!\n");
    }
    
    g_ncf_log.flush();
	
	return(0);
}
