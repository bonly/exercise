#include "Ncf_Func.h"
#include "Signal.h"
#include "DataAccess_Mysql.h"
#include "Check_File.h"
#include "Ncf_Crl.h"
#include "ConsisCheck.h"
#include "Ncf_Common.h"
#include "com_date.h"
#include <sys/prctl.h>
#include <stdlib.h>
#include <errno.h>
#include <dirent.h>



#define  FLOW_TIME        1




using namespace Signal;




ConnectList g_stCL;
NODE        g_stNode;
int         g_step;



void printCHKRES(vector<ST_LOG_CHK_RES> &v_sr)
{
	LOG_DEBUG("CHKRES size:%d\n", v_sr.size());
	for(int i=0; i<v_sr.size(); i++)
	{
		LOG_DEBUG("====Errtype:%d, table_num:%s, table_name:%s, time:%s, ins_count:%d\n", 
		    v_sr[i].unErrType, v_sr[i].sTable_num.c_str(), v_sr[i].sTable_name.c_str(), v_sr[i].sTime.c_str(), v_sr[i].nIns_count);
		LOG_DEBUG("====InsInfo size:%d\n", v_sr[i].vInsInfo.size());
		for(int j=0; j<v_sr[i].vInsInfo.size(); j++)
		{
			LOG_DEBUG("========ins_count:%d, errInfo:%s, errLevel:%d\n", 
			    v_sr[i].vInsInfo[j].nIns_count, v_sr[i].vInsInfo[j].sErrInfo.c_str(), v_sr[i].vInsInfo[j].nErrLevel);
			LOG_DEBUG("========connect info(connectStr:%s)\n", v_sr[i].vInsInfo[j].stConnInfo.connectStr);
			
		}
	}
	
}



int Ncf_Process(int nGroupID)
{
	if(NULL == g_pConf)
    {
        LOG_ERROR("Ncf_Process input param wrong!\n");
        return -1;
    }
    
    int nRet = -1;
        
    while(!g_bSigTerm)
    {
    	///�źŴ���
        nRet = HandleSignal();
        if(nRet < 0)
        {
            LOG_ERROR("HandleSignal failed!\n");
            return -1;
        }
        
        g_ncf_log.flush();
        
        nRet = Process_Master(nGroupID);
        if(nRet < 0)
        {
            LOG_ERROR("Process_Master failed!\n");
            return -1;
        }
        
        return (0);
    }
          
    return (0);
}
    




int Process_Master(int nGroupID)
{
	int nRet = PM_Init(nGroupID);
	if(nRet != 0)
	{
		LOG_ERROR("PM_Init error!\n");
		SEND_EVEN_KPI("PM_Init error", CRITICAL);
		return -1;
	}
	
	/*����Agent
    g_stCL.nCount=3;
    strcpy(g_stCL.stItem[0].connectStr, "172.16.200.101|3312|paas|root|123");
    strcpy(g_stCL.stItem[1].connectStr, "172.16.200.102|3312|paas|root|123");
    strcpy(g_stCL.stItem[2].connectStr, "172.16.200.103|3312|paas|root|123");
    nRet = TransferCompress("172.16.200.103|3312|paas|root|123", 33, 2);
    if(nRet != 0)
    {
        printf("TransferCompress error\n");
    }*/
	
	//����1:���ڵ�״̬
    nRet = CheckNodeStatus(nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("check node status error!\n");
        SEND_EVEN_KPI("check node status error", CRITICAL);
        return -1;
    }
    
    //��Ϊ����1
    nRet = updateNodeGroupStep(g_step=CHECK_NODE, nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("[%d]update node step error!\n", g_step);
        SEND_EVEN_KPI("[1]update node step error", CRITICAL);
        return -1;
    }
    LOG_DEBUG("[%d]check node status finished...\n", g_step);
    sleep(FLOW_TIME);
    
    //����2:���δ�����ļ��������������Sort����
    nRet = CheckUnloadFile(nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("check unload file error!\n");
        SEND_EVEN_KPI("check unload file error", CRITICAL);
        return -1;
    }
    
    //��Ϊ����2
    nRet = updateNodeGroupStep(g_step=CHECK_UNLOAD_FILE, nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("[%d]update node step error!\n", g_step);
        SEND_EVEN_KPI("[2]update node step error", CRITICAL);
        return -1;
    }
    LOG_DEBUG("[%d]check unload file finished...\n", g_step);
    sleep(FLOW_TIME);
    
    //����3:���Ľڵ�״̬Ϊ--����������⣬���Բ������
    nRet = AlterNodeStatus(nGroupID, NOT_ALLOW_LOAD);
    if(nRet != 0)
    {
        LOG_ERROR("alter node  status error!\n");
        SEND_EVEN_KPI("alter node  status error", CRITICAL);
        return -1;
    }
    
    //��Ϊ����3
    nRet = updateNodeGroupStep(g_step=CNS_ADD_PRO, nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("[%d]update node step error!\n", g_step);
        SEND_EVEN_KPI("[3]update node step error", CRITICAL);
        return -1;
    }
    LOG_DEBUG("[%d]update node status finished...\n", g_step);
    sleep(FLOW_TIME);
    
    //����4:���δ�����ļ��������������Sort����
    nRet = CheckUnloadFile(nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("check unload file error!\n");
        SEND_EVEN_KPI("check unload file error", CRITICAL);
        return -1;
    }
    
    //��Ϊ����4
    nRet = updateNodeGroupStep(g_step=CHECK_UNLOAD_FILE_D, nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("[%d]update node step error!\n", g_step);
        SEND_EVEN_KPI("[4]update node step error", CRITICAL);
        return -1;
    }
    
    LOG_DEBUG("[%d]check unload file finished...\n", g_step);
    sleep(FLOW_TIME);
    
    //����5:���Ľڵ�״̬Ϊ--���������Ͳ������
    nRet = AlterNodeStatus(nGroupID, ALL_NOT_ALLOW);
    if(nRet != 0)
    {
        LOG_ERROR("alter node  status error!\n");
        SEND_EVEN_KPI("alter node  status error", CRITICAL);
        return -1;
    }
    
    //��Ϊ����5
    nRet = updateNodeGroupStep(g_step=CNS_NOT_ALLOW, nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("[%d]update node step error!\n", g_step);
        SEND_EVEN_KPI("[5]update node step error", CRITICAL);
        return -1;
    }
    
    LOG_DEBUG("[%d]update node status finished...\n", g_step);
    sleep(FLOW_TIME);
        
    //����6:����һ���Լ����ѹ��
    int max_num = 0;
    char connectStr[64+1];
    memset(connectStr, 0, sizeof(connectStr));
    char table_name[64];
    memset(table_name, 0, sizeof(table_name));
    char szYearMon[7];
    //��ȡ��ǰ����(��Ҫ�۳�һ����ƫ��ʱ��)
    CCommonDate comm_date(time(NULL));
    comm_date.addSecond( -(g_pConf->nDelayTime) );
    snprintf(szYearMon, sizeof(szYearMon), "%4d%02d", comm_date.getYear(), comm_date.getMonth());
    LOG_DEBUG("YearMon=%s\n", szYearMon);
    
    /*           0: ok,�������
     * 	         1: ʵ�����������޼�¼
     *	         2: ����״̬��ȷ�����ݲ�ƥ��
     * 	         3: �������ش���
     */
    CConsisCheck CConsisCheck(nGroupID, &g_conn, g_stCL);
    nRet = CConsisCheck.ExecuteCheck(atoi(szYearMon));
    if(nRet == 1)
    {
    	LOG_WARN("no data to check!\n"); 
    	SEND_EVEN_KPI("no data to check", WARNING);
    }
    else if(nRet == 3)
    {
    	LOG_ERROR("check data serious error!\n");
        SEND_EVEN_KPI("check data serious error", CRITICAL);
        return -1;
    }
    else 
    {
    	if(nRet == 2)
    	{
    		LOG_WARN("node in the data part of the inconsistency, but does not affect the subsequent processing\n");
    		SEND_EVEN_KPI("node in the data part of the inconsistency, but does not affect the subsequent processing", WARNING);
    	}
    	
    	///��ȡ���������Ϣ
    	vector<ST_LOG_CHK_RES> v_sr = CConsisCheck.GetConsisRcrdInfo();
    	printCHKRES(v_sr);
    	if( v_sr.size() == 0 )
    	{
    	    LOG_ERROR("CConsisCheck no data to get!\n");
            SEND_EVEN_KPI("CConsisCheck no data to get", CRITICAL);
            return -1;
        }
        else
        {
        	///����newtable��״̬
        	for(int i=0; i<v_sr.size(); i++)
        	{
        		//��ȡ���num
        		if(atoi(v_sr[i].sTable_num.c_str()) > max_num)
        		{
        			max_num = atoi(v_sr[i].sTable_num.c_str());
        		}
        		strncpy(table_name, v_sr[i].sTable_name.c_str(), sizeof(table_name));
        		nRet = AlterNewtableStatus(table_name, atoi(v_sr[i].sTable_num.c_str()) );
                if(nRet != 0)
                {
                    LOG_ERROR("alter newtable  status error!\n");
                    SEND_EVEN_KPI("alter newtable  status error", CRITICAL);
                    return -1;
                }
                else
                {
                    ///��ȡѹ�������ڵ�
                    getModelNode(v_sr[i].vInsInfo, v_sr[i].nIns_count, connectStr, sizeof(connectStr));
                
                    //�齨��Ϣ,����Զ��ѹ������
                    nRet = TransferCompress(connectStr, sizeof(connectStr), atoi(v_sr[i].sTable_num.c_str()));
                    if(nRet != 0)
                    {
                        LOG_ERROR("TransferCompress error!\n");
                        SEND_EVEN_KPI("TransferCompress error", CRITICAL);
                        return -1;
                    }
                }
        	}
        }
    	
    }
        
    //��Ϊ����6
    nRet = updateNodeGroupStep(g_step=CHECK_DATA_COMPRESS, nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("[%d]update node step error!\n", g_step);
        SEND_EVEN_KPI("[6]update node step error", CRITICAL);
        return -1;
    }
    LOG_DEBUG("[%d]update newtable status finished...\n", g_step);
    sleep(FLOW_TIME);
    
    //����7:�����µ�newtable��¼Ϊ0,�Ա���������±�
    //�Ȳ�ѯ״̬Ϊ-1���������ڵ��µļ�¼,Ȼ���ٸ�������״̬
    nRet = AdjustNewtableStatus();
    if(nRet != 0)
    {
        LOG_ERROR("adjust newtable status error!\n");
        SEND_EVEN_KPI("adjust newtable status error", CRITICAL);
        return -1;
    }
    
    
    //��Ϊ����7
    nRet = updateNodeGroupStep(g_step=NEW_TABLE_USE, nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("[%d]update node step error!\n", g_step);
        SEND_EVEN_KPI("[7]update node step error", CRITICAL);
        return -1;
    }
    LOG_DEBUG("[%d]update newtable status(-1 to 0) finished...\n", g_step);
    sleep(FLOW_TIME);
    
        
    //����8:���Ľڵ�״̬Ϊ--�������Ͳ������
    nRet = AlterNodeStatus(nGroupID, ALLOW_LOAD);
    if(nRet != 0)
    {
        LOG_ERROR("alter node  status error!\n");
        SEND_EVEN_KPI("alter node  status error", CRITICAL);
        return -1;
    }
    
    //��Ϊ����0
    nRet = updateNodeGroupStep(g_step=END_PRO, nGroupID);
    if(nRet != 0)
    {
        LOG_ERROR("[%d]update node step error!\n", g_step);
        SEND_EVEN_KPI("[0]update node step error", CRITICAL);
        return -1;
    }
    LOG_DEBUG("[%d]update node status finished...\n", g_step);
    sleep(FLOW_TIME);
    
    return 0;
		
}














