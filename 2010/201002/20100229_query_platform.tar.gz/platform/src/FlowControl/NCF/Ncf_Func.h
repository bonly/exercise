#ifndef _NCF_FUNC_H_
#define _NCF_FUNC_H_








int Ncf_Process(int nGroupID);


int Process_Master(int nGroupID);




#endif


