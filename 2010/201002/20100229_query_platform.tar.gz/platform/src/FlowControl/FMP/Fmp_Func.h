#ifndef _FMP_FUNC_H_
#define _FMP_FUNC_H_


#include "Fmp_Common.h"




//
int Fmp_Process(const char *pConfFile);


int GetNodeGroupInfo(NODE_LIST* pNL);
int GetFileNum(char *path);

#endif


