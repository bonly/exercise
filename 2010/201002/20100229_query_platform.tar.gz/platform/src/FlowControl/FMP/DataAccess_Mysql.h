#ifndef _DATAACCESS_MYSQL_H_
#define _DATAACCESS_MYSQL_H_

#include <cstdio>
#include <mysql++.h>
#include <cstdlib>
#include <ssqls.h>
#include "Fmp_Common.h"


using namespace std;
using namespace mysqlpp;

extern Connection g_conn;
	
	
	

int connectDb(char *db_name, char *ip_addr, char *user, char *pwd, int nPort);


int selectNodeGroupInfo(NODE_LIST* pNL);
int updateNodeGroupStatus(int nStatus, int groupID);


unsigned long GetNowTimeString();




#endif







