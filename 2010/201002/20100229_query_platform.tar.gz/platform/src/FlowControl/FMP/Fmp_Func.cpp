#include "Fmp_Func.h"
#include "Fmp_Signal.h"
#include "DataAccess_Mysql.h"
#include <sys/prctl.h>
#include <stdlib.h>
#include <errno.h>
#include <dirent.h>



using namespace Signal;





int Fmp_Process(const char *pConfFile)
{
	if(NULL == g_pConf || pConfFile == NULL)
    {
        LOG_ERROR("Fmp_Process input param wrong!\n");
        SEND_EVEN_KPI("Fmp_Process input param wrong!", CRITICAL);
        return -1;
    }
    
    int nRet = -1;
    
    NODE_LIST stNodeList;
        
    char szSortBin[1024];
    char szConfFile[1024];
    while(!g_bSigTerm)
    {
    	///�źŴ���
        nRet = HandleSignal();
        if(nRet < 0)
        {
            LOG_ERROR("HandleSignal failed!\n");
            SEND_EVEN_KPI("HandleSignal failed!", CRITICAL);
            return -1;
        }
        
        g_fmp_log.flush();
        
        memset(&stNodeList, 0, sizeof(NODE_LIST));
        //��ȡ���нڵ���������Ϣ
        nRet = GetNodeGroupInfo(&stNodeList);
        if(nRet != 0)
        {
            LOG_ERROR("get node info error!\n");
            SEND_EVEN_KPI("get node info error!", CRITICAL);
            return -1;
        }
        
        int pid=0;
        int nFileNum;
        for(int i=0; i<stNodeList.nCount; i++)
        {
        	//ɨ��Ŀ¼����ȡ�ļ���
        	nFileNum = GetFileNum(stNodeList.stNode[i].unloadPath);
        	if(nFileNum >= g_pConf->nSortThreshold && (stNodeList.stNode[i].status == 0 || 
        		(GetNowTimeString()-stNodeList.stNode[i].updateTime>g_pConf->nSortFailureTime) ))
        	{
        		if(nFileNum > g_pConf->nAlarmThreshold)
        		{
        			snprintf(szKpiMsg, sizeof(szKpiMsg), "unload files are too many:%d", nFileNum);
        			SEND_EVEN_KPI(szKpiMsg, CRITICAL);
        		}
        		pid = fork();
            	if(pid < 0)
            	{
            		perror("fork");
            	}
            	else if(pid == 0)
            	{
            		g_fmp_log.logOnlyClose();
            		
            		//����·��
            		snprintf(szSortBin, sizeof(szSortBin), "%s/bin/%s", g_pConf->szRootPath, g_pConf->szProName);
            		snprintf(szConfFile, sizeof(szConfFile), "%s/etc/%s", g_pConf->szRootPath, g_pConf->szSortConfFile);
            		
            		//printf("%s\n", szSortBin);
            		//printf("%s\n", szConfFile);
            		
            		nRet = execl(szSortBin, 
            		             g_pConf->szProName,
            		             "-c", szConfFile,
            		             "-p", stNodeList.stNode[i].unloadPath,
            		             (char*)NULL);
            		if(nRet == -1)
            		{
            			//perror("execl");
            			LOG_ERROR("%s -c %s\n", g_pConf->szProName, szConfFile);
            			SEND_EVEN_KPI("execl sortbill error!", CRITICAL);
                        exit(0);	
            		}

            		exit(0); 
            	}
            	
            	nRet = updateNodeGroupStatus(SORT_STARTED, stNodeList.stNode[i].groupID);
            	if(nRet != 0)
            	{
            		LOG_ERROR("updateNodeGroupStatus error, ret=%d\n", nRet);
            		SEND_EVEN_KPI("updateNodeGroupStatus error!", CRITICAL);
                    return -1;	
                }
        	}
        }
        waitpid(-1, NULL, 0);
        
        sleep(g_pConf->nSleepTime);
    }
    
    return (0);
}
    



int GetNodeGroupInfo(NODE_LIST* pNL)
{
	int nRet = 0;
	
	nRet = selectNodeGroupInfo(pNL);
	if(nRet != 0)
	{
		LOG_ERROR("selectNodeGroup error!\n");
		return -1;
	}
	
	return 0;
	
}


int GetFileNum(char *path)
{
	char cmd[512];
	
	memset(cmd, 0, sizeof(cmd));
	
    struct dirent **namelist;
    int n = scandir(path, &namelist, 0, 0);
	if(n < 0)
	{
		perror("not found\n");
		return -1;
	}
	else
	{
		LOG_DEBUG("path:%s, file:%d\n", path, n);
		//ע��namelist��ͨ��malloc��̬�����ڴ��,������ʹ��ʱҪע���ͷ��ڴ�
		for(int i=0; i<n; i++)
		{
			free(namelist[i]);
		}
		free(namelist);
		
		//"."��".."��Ҫ�ų�����
		return (n-2);
	}
	
}












