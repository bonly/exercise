/******************************************************************************
    Copyright (C), 1996-2011, Sunrise Tech. Co., Ltd.
        File name:                  main.cpp
        Author:                     yusang
        Version:                    1.0
        Date:                       2011.6.21
        Description:								��ɱ���ѹ������
        Others:
        Function List:
        History:
******************************************************************************/

#include "readini.h"
#include "k_mysql.h"

#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

typedef vector<string>  SAME_TABLES;

static int TABLE_NUM;
static int SEGNUM;
static string BIIL_STATUS_TABLE;
static string MY_IP;
static int MY_PORT;
static string MY_USERNAME;
static string MY_PASSWD;
static string MY_DBNAME;
static string ROUTER_IP;
static int ROUTER_PORT;
static string ROUTER_INSTANCE;
static string ROUTER_USERNAME;
static string ROUTER_PASSWD;
static string ROUTER_DBNAME;
static string MY_DB_PATH;
static string MY_PACK_CMD;
static string MY_CHECK_CMD;

//��þ�ȷʱ��
string  signedtime( )
{
	time_t result;
	struct tm tm_tmp;
	
	result= time(NULL);
	localtime_r(&result, &tm_tmp);
	char buffer[128];memset(buffer, 0, sizeof(buffer));
	
	snprintf(buffer, sizeof(buffer),"%2d:%02d:%02d",tm_tmp.tm_hour,tm_tmp.tm_min,tm_tmp.tm_sec);
	string str = buffer;
	
	return str;
}

//����·�ɱ�
int update_route(K_Database &db, const char* flag, const char * status)
{
	string sql = "update route set status = ";
	sql += status;
	sql += " where connect_string = '";
	sql += flag;
	sql += "'";
	db.ExecQuery(sql.c_str());
	cout<<sql<<endl;
}

//�õ�������ɲ���ı���
void get_all_tablename(K_Database &db, const char* matchline, vector<SAME_TABLES> vecTablename)
{
	K_recordSet sa;
	db.ExecQueryGetRecord("select distinct(table_name) from information_schema.columns  where table_schema='yusang' and table_name like 'BILL_%'",sa);
	for(int i=0;i<sa.GetRecordCount();i++)
	{
		for(int j=0;j<sa.GetFieldNum();j++)
		{
			printf("%s\t",sa[i][j].c_str ());
		}
		printf("\n");
	}
}

//�õ�������ɲ���ı���
void get_all_tablename(K_Database &db, const char* matchline, map<string, SAME_TABLES> vecTablename)
{
	K_recordSet sa;
	db.ExecQueryGetRecord("select distinct(table_name) from information_schema.columns  where table_schema='yusang' and table_name like 'BILL_%'",sa);
	for(int i=0;i<sa.GetRecordCount();i++)
	{
		for(int j=0;j<sa.GetFieldNum();j++)
		{
			printf("%s\t",sa[i][j].c_str ());
		}
		printf("\n");
	}
}

//�õ�������ɲ���ı��� 
void get_all_tablename(K_Database &db, const char* name_table, const char* matchline )
{
	string sql = "create table ";
	sql += name_table ;
	sql += "(name char(128));";
	db.ExecQuery (sql.c_str());
	
	K_recordSet sa;
	db.ExecQueryGetRecord("select distinct(table_name) from information_schema.columns  where table_schema='yusang' and table_name like 'BILL_%' order by table_name",sa);
	for(int i=0;i<sa.GetRecordCount();i++)
	{
		string s = "insert into ";
		s += name_table;
		s += " values('";
		s += sa[i][0];
		s += "')";          
		db.ExecQuery(s.c_str());
	}
}

//�õ�������ɲ���ı���
void get_finished_tables(K_Database &db, vector<string>& tables, vector<string>& ids)
{
	tables.clear();
	ids.clear();
	
	K_recordSet sa;
	string sql;
	sql = "select id, tablename, table_num from ";
	sql += BIIL_STATUS_TABLE;
	sql += " where status =1";
	db.ExecQueryGetRecord(sql.c_str(), sa);
	char tmp[64]; memset(tmp, 0, sizeof(tmp));
	
	for(int i=0;i<sa.GetRecordCount();i++)
	{
		ids.push_back(sa[i][0]);
		memset(tmp, 0, sizeof(tmp));
		for(int j=0;j<TABLE_NUM;j++)
		{
			int a = atoi( sa[i][2].c_str());
			sprintf(tmp, "%s_%02d_%03d", sa[i][1].c_str(), j, a);
			
			K_recordSet sa1;
			string sql = "select 1 from ";
			sql += tmp;
			sql += " limit 1";
			cout<<sql<<endl;
			if ( db.ExecQueryGetRecord(sql.c_str(), sa1) != -1)
				tables.push_back(tmp);
		}
	}
	
	return;
}

/*
��Ҫ����:ִ��ѹ������
����ֵ:0�ɹ� -1 ִ��ʧ�� 
˵��:1��������Ѿ�������ɵı�����2��ʼѹ����3ѹ����ɺ�ɾ�����ɣ�4�޸�router��״̬
*/
void work(K_Database &db, K_Database &router_db, const char* name_table)
{
	string sql;

	string route_flag = MY_IP;
	route_flag += "|";
	char tmpbuf[8];memset(tmpbuf, 0, sizeof(tmpbuf));
	sprintf(tmpbuf, "%d", MY_PORT); 
	route_flag += tmpbuf;
	route_flag += "|";
	route_flag += ROUTER_INSTANCE;
	route_flag += "|";
	route_flag += ROUTER_USERNAME;
	route_flag += "|";
	route_flag += ROUTER_PASSWD;
	
	sql = "update route set status = 1 where connect_string = '";
	sql += route_flag;
	sql += "'";
	router_db.ExecQuery(sql.c_str());

	vector<string> dealingID;
	vector<string>::iterator itr;
	dealingID.clear();
	
	vector<string> aa;
	aa.clear();
	get_finished_tables(db, aa, dealingID);
	vector<string>::iterator it;
	
	for(it = aa.begin(); it != aa.end(); ++it)
	{
		string tname = *it;
		cout<<tname<<endl;
		sql = "drop table ";
		sql += tname.substr(0,19);
		sql += "_tmp";
		cout<<sql<<endl;
		db.ExecQuery(sql.c_str());
		
		sql = "create table ";
		sql += tname.substr(0,19);
		sql += "_tmp";
		sql += " engine = myisam select * from ";
		sql += tname;
		sql += " where 1 = 2";
		cout<<sql<<endl;
		if( db.ExecQuery(sql.c_str()) == -1)
		{
			printf("cant create tabel: %s", sql.c_str());
			return ;
		}
		
		sql = "create index idx_subno on ";
		sql += tname.substr(0,19);
		sql += "_tmp";
		sql += "(subno) ";
		db.ExecQuery(sql.c_str());

		int num = atoi(it->substr(20, 3).c_str());
		char tmp[64];memset(tmp, 0, sizeof(tmp));
		sprintf(tmp, "%s_%02d", tname.substr(0,19).c_str(), (num-1)/SEGNUM + 1);
		
		sql = "create table ";         //�˴�����һ�������ݵ�һ�ι鲢ѹ��ʱ���ᴴ��һ���ձ��ɹ����˺���ᴴ��ʧ��
		sql += tmp;
		sql += " engine = myisam select * from ";
		sql += tname;
		sql += " where 1 = 2";
		db.ExecQuery(sql.c_str());
		
		sql = "insert into ";
		sql += tname.substr(0,19);
		sql += "_tmp";
		sql += " select * from ";
		sql += tname;
		sql += " union all select * from ";
		sql += tmp;	
		sql += " order by subno ";     // order by subno, id 
		db.ExecQuery(sql.c_str());
		
		sql = "drop table ";
		sql += tmp;
		db.ExecQuery(sql.c_str());
		
		sql = "drop table ";
		sql += tname;
		db.ExecQuery(sql.c_str());  //needuse
		
		sql = "alter table ";
		sql += tname.substr(0,19);
		sql += "_tmp";
		sql += " rename ";
		sql += tmp;
		if( db.ExecQuery(sql.c_str()) == -1)
		{
	    printf("cant alter tabel: %s", sql.c_str());
	    return ;
		}
		string cmdline = MY_PACK_CMD;
		cmdline += " -v ";
		cmdline += MY_DB_PATH;
		cmdline += MY_DBNAME;
		cmdline += "/";
		cmdline += tmp;
		cmdline += ".MYI";
		int error = system(cmdline.c_str());
		printf("Outer program return value: %d\n", WEXITSTATUS(error));
		
		cmdline = MY_CHECK_CMD; 
		cmdline += " -rq ";
		cmdline += MY_DB_PATH;
		cmdline += MY_DBNAME;
		cmdline += "/";
		cmdline += tmp;
		cmdline += ".MYI";
		cout<<"command: "<<cmdline<<endl;
		error = system(cmdline.c_str());
		printf("Outer program return value: %d\n", WEXITSTATUS(error));
	}
	
	//�����е���ѹ���ı�״̬��Ϊѹ�����״̬
	for(itr = dealingID.begin(); itr != dealingID.end(); ++itr)
	{
		sql = "update ";
		sql += BIIL_STATUS_TABLE;
		sql += " set status = 2 where id = ";
		sql += *itr;
		cout<<sql<<endl;
		db.ExecQuery(sql.c_str());
	}
	dealingID.clear();
	//needuse
	
	//�޸�router��״̬����ʾѹ���Ѿ���ɣ���������ʹ��
	sql = "update route set status = 2 where connect_string = '";
	sql += route_flag;
	sql += "'";
	router_db.ExecQuery(sql.c_str());
}

//�������ļ�
int read_config()
{
	map<string, string> m_url;
	m_url = read_conf( CONFIG );
	printf( "---------%s \n\n", "Show Map Infos");
	map<string, string>::iterator it_url;
	for(it_url = m_url.begin(); it_url != m_url.end(); it_url++)
	{
		printf( "%s  <==> %s \n", it_url->first.c_str(), it_url->second.c_str() );
	}
	
	TABLE_NUM = atoi(m_url["TABLE_NUM"].c_str());  
	SEGNUM = atoi(m_url["SEGNUM"].c_str());
	BIIL_STATUS_TABLE = m_url["BIIL_STATUS_TABLE"];
	MY_IP = m_url["MY_IP"];
	MY_PORT = atoi(m_url["MY_PORT"].c_str());         
	MY_USERNAME = m_url["MY_USERNAME"];
	MY_PASSWD = m_url["MY_PASSWD"];
	MY_DBNAME = m_url["MY_DBNAME"];
	ROUTER_IP = m_url["ROUTER_IP"];
	ROUTER_PORT = atoi(m_url["ROUTER_PORT"].c_str());
	ROUTER_INSTANCE = m_url["ROUTER_INSTANCE"];
	ROUTER_USERNAME = m_url["ROUTER_USERNAME"];
	ROUTER_PASSWD = m_url["ROUTER_PASSWD"];
	ROUTER_DBNAME = m_url["ROUTER_DBNAME"];
	MY_DB_PATH=m_url["MY_DB_PATH"];
	MY_PACK_CMD=m_url["MY_PACK_CMD"];
	MY_CHECK_CMD = m_url["MY_CHECK_CMD"];	
}
 
int main()
{
	read_config();

	K_Database a;
	int i;

	i=a.Connect(MY_IP,MY_USERNAME,MY_PASSWD,MY_DBNAME,MY_PORT,0); 
	if(i!=0) 
	{
		printf("Can`t connect the DB\n");
		return 0;
	}
	else
	{
		printf("Connect successed\n");
	}
	
	K_Database b;
	i=b.Connect(ROUTER_IP, ROUTER_USERNAME,ROUTER_PASSWD,ROUTER_DBNAME,ROUTER_PORT,0);
	if(i!=0)
	{
		printf("Can`t connect the router DB\n");
		return 0;
	}
	else
	{
		printf("Connect router db successed\n");
	}

	ofstream logfile("timelog", ios::out);
	for(int i=0;i<1/*150*/;i++){ 
		logfile<<"day: "<< i/5 +1<<"\t";
		logfile<<"no: "<<i%5+1<<"\t";	
		logfile<<signedtime()<<"\t";
		work(a,b, "");
		logfile<<signedtime()<<endl;
	}
	logfile.close(); 
	
	a.DisConnect ();
	b.DisConnect ();
	
	return 0;
}


