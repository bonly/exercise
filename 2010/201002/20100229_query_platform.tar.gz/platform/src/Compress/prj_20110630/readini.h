#include <map>
#include <string>
#include <iostream>
#include <signal.h> /* SIGSEGV */
#include <stdlib.h>

using namespace std;

#define CONFIG "conf.ini"
#define EQU "="
#define SPACE " " //0x20
#define CR "\r" //0x0d
#define CRLF "\r\n" //0x0a

//�������ļ�
map<string,string> read_conf(char *FileName)
{
	FILE *fp;
	char line[512];
	char *note = "#";                        /*ע�ͷ���*/
	char *s1;
	char *s2;
	map<string,string> m_date;
	printf("---------filename:%s \n\n",FileName);
	if( ( fp = fopen(FileName,"rb") ) ==NULL )   
	{   
		printf("read_conf Can not open conf file:%d\n\n",FileName);
		return m_date;
	}
	else  
	{
		printf("---------opened %s  \n\n",  FileName );
	}
	while (fgets(line, 512, fp))
	{
		/*�жϴ����Ƿ�Ϊע����,ȥ��ע����*/
		if (!strlen(line) || !strncmp(line,note,1) || !strcmp(line,CR) || !strcmp(line,CRLF))
		{
			continue;
		}
		s1 = strtok(line,EQU);
		s2 = strtok(NULL,CRLF);
		if (!s2) 
		{
			s2 = strtok(NULL,CR);                        /*�ж�ÿ����û�лس���*/
		}
		
		if (!s1 || !s2)
		{
			continue;
		}
		m_date[s1] = s2;
	}
	
	return m_date; 
}

