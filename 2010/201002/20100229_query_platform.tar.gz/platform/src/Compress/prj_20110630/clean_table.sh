#!/bin/sh

mysql -uroot -p111 test -s -e "show tables like 'tb_110323%';" >tablelist.txt
for tablename in `cat tablelist.txt`
do
mysql -uroot -p111 test -s -e  \
"
drop table $tablename;
"
done 


