#include <mysql.h>
#include <stdlib.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>

#include <string>
#include <map>
#include <vector>

#include "query_db.h"

#include "iniconfig.h"
#include "r5api.h"
#include "r5log.h"
//#include "sysinfo.h"
#include "hexdump.h"

using namespace std;

/// 全局数据库连接容器
map<string, MYSQL*> g_mysql_map;
/// 全局日志
R5_Log g_r5_log;
int in_queue, out_queue;
param g_param;

/// 初始化日志宏
#define INIT_LOG(plog, log_path, log_header, file_level, term_level)\
    if(SET_LOG_DIR(plog, log_path) < 0)\
    {\
        printf("log path can not access:%s\n", log_path);\
        exit(-1);\
    }\
    SET_LOG_LEVEL(plog, file_level, term_level);\
    SET_LOG_NAME_HEAD(plog, log_header);

int MyMsgSend(int msqid, struct msgform *msgp, size_t msgsz, int msgflg)
{
    while (true)
    {
        //printf("send msg: \n");
        //HexDump((char*)msgp, msgsz);
        int nRet = msgsnd(msqid, msgp, msgsz, msgflg);
        if (nRet < 0)
        {
            if (errno == EINTR) //被信号中断
            {
                continue;
            }
            else if (errno == EAGAIN)
            {
                return 0;
            }
            else //其他错误
            {
                return -2;
            }
        }
        else
        {
            return 0;
        }
    }
}

int MyMsgRecv(int msqid, struct msgform *msgp, size_t msgsz, int msgtyp,
            int msgflg)
{
    while (true)
    {
        int nLen = msgrcv(msqid, msgp, msgsz, msgtyp, msgflg);
        //printf("recv msg: \n");
        //HexDump((char*)msgp, nLen);
        if (nLen < 0)
        {
            if (errno == EINTR) //被信号中断
            {
                continue;
            }
            else //其他错误
            {
                return -3;
            }
        }
        else
        {
            return nLen;
        }
    }
}

int connect_mysql(const char* connect_str)
{
    string str_con(connect_str);
    char *str = (char*) connect_str;
    bill_conf conf;
    memset(&conf, 0, sizeof(conf));

    //default username:'root'
    //default password:null
    strncpy(conf.db_username, "root", PRO_DB_LEN);

    do
    {
        char* p = strchr(str, '|');
        if (NULL == p)
        {
            return -1;
        }
        memcpy(conf.db_host, str, p - str);
        str = p + 1;

        p = strchr(str, '|');
        if (NULL == p)
        {
            return -1;
        }
        char tmp[8] = { 0 };
        memcpy(tmp, str, p - str);
        conf.db_port = atoi(tmp);
        str = p + 1;

        p = strchr(str, '|');
        if (NULL == p)
        {
            strncpy(conf.db_name, str, PRO_DB_LEN);
            break;
        }
        memcpy(conf.db_name, str, p - str);
        str = p + 1;

        memset(conf.db_username, 0, sizeof(conf.db_username));
        p = strchr(str, '|');
        if (NULL == p)
        {
            strncpy(conf.db_username, str, PRO_DB_LEN);
            break;
        }
        memcpy(conf.db_username, str, p - str);
        str = p + 1;

        strncpy(conf.db_password, str, PRO_DB_LEN);
    } while (0);

    MYSQL* db = mysql_init(0);
    if (NULL == db)
    {
        QUERY_ERROR("mysql_init failed.\n");
        return -1;
    }

    if (!mysql_real_connect(db, conf.db_host, conf.db_username,
                conf.db_password, conf.db_name, conf.db_port, 0, 0))
    {
        QUERY_ERROR("mysql: error=[%s]\n", mysql_error(db));
        return -1;
    }

    g_mysql_map.insert(make_pair<string, MYSQL*>(str_con, db));
    map<string, MYSQL*>::iterator it = g_mysql_map.find(str_con);
    if (it == g_mysql_map.end())
        return -1;

    QUERY_INFO("connect to mysql success! constr = %s\n", connect_str);

    return 0;
}

void exit()
{

    map<string, MYSQL*>::iterator it;
    for (it = g_mysql_map.begin(); it != g_mysql_map.end(); ++it)
    {
        if (NULL != it->second)
            mysql_close(it->second);
    }

}

int query_bill(char* buf, request_message* request, int outqueue,
            struct msgform ms)
{
    char query[256];
    int n = 0;
    memset(query, 0, sizeof(query));

    /// 构造查表的SQL语句
    n =
                snprintf(
                            query,
                            sizeof(query),
                            "select * from %s where subno = '%s' and start_time >= '%s' and start_time <= '%s'",
                            //"select * from %s where subno = '%24s' and start_time >= '%s' and start_time <= '%s'",
                            request->table_name, request->sub_no,
                            request->start_time, request->end_time);

    QUERY_DEBUG("SQL:%s\n", query);

#if 0
    pack_back_msg("abc", 4, 1, 1, outqueue, ms);
    return 0;
#endif

    /// 查找对应的数据库连接,没找到则新建一个连接并放入容器中,连接失败则返回-1
    string str(request->connect_str);
    map<string, MYSQL*>::iterator it = g_mysql_map.find(str);
    if (it == g_mysql_map.end())
    {
        if (connect_mysql(request->connect_str) < 0)
        {
            QUERY_WARN("connect to mysql faield. con_str = %s\n",
                        request->connect_str);
            /// 返回空消息
            pack_back_msg(buf, 0, 0, 0, outqueue, ms);
            return -1;
        }
    }

    /// 找到成功的连接
    it = g_mysql_map.find(str);
    MYSQL* db = it->second;

    /// 查询数据库,失败时处理:
    const int r = mysql_real_query(db, query, n > 0 ? n : 0);
    if (r != 0)
    {
        unsigned int err = mysql_errno(db);
        QUERY_ERROR("mysql: error=[%s] errno =%d\n", mysql_error(db), err);
        ///- 如果查询的表不存在,则返回0
        if (1146 == err)
        {
            /// 返回空消息
            pack_back_msg(buf, 0, 0, 0, outqueue, ms);
            return 0;
        }

        ///- 如果数据库已断开,则从容器中删除
        if (2006 == err)
            g_mysql_map.erase(it);

        /// 返回空消息
        pack_back_msg(buf, 0, 0, 0, outqueue, ms);
        return -1; ///- 失败返回-1
    }

    /// 查询成功,获取数据
    MYSQL_ROW row = 0;
    unsigned long *lengths = 0;
    unsigned int num_rows = 0;
    unsigned int num_flds = 0;
    MYSQL_RES *res = mysql_store_result(db);

    if (res != 0)
    {
        num_rows = mysql_num_rows(res); /// 获取总记录条数
        num_flds = mysql_num_fields(res); /// 获取字段数
        QUERY_DEBUG("num_rows:%d, num_flds:%d\n", num_rows, num_flds);

        if (num_rows == 0) /// 没有记录则返回空消息
        {
            pack_back_msg(buf, 0, 0, 0, outqueue, ms);
            return 0;
        }

        int current_num = 0;
        while ((row = mysql_fetch_row(res))) /// 处理所有记录
        {
            ++current_num;
            char* p = buf;
            lengths = mysql_fetch_lengths(res); /// 获取每个字段的长度
            int len = 0;
            /*
             for(int i = 0; i < num_flds; ++i)
             {
             strcpy(p, row[i]);
             p += lengths[i];
             *len += lengths[i];
             *p = '|';
             p++;
             (*len)++;

             if(*len >= 32*1024*1024)
             return -2;
             }
             */
            for (unsigned int i = 0; i < num_flds; ++i)
            {
                //printf("field[%d]:%s\n",i,row[i]);
                memcpy(p, row[i], lengths[i]);
                p += lengths[i];
                len += lengths[i];
            }
            *p = '\n';
            ++p;
            ++len;

            /// 返回结果消息
            pack_back_msg(buf, len, num_rows, current_num, outqueue, ms);
        }
        //QUERY_DEBUG("query len:%d query result:%s\n", *len, buf + PRO_HEAD_LEN);
    }
    else
    {
        /// 查询失败则返回空消息
        pack_back_msg(buf, 0, 0, 0, outqueue, ms);
    }

    /// 释放Mysql资源
    mysql_free_result(res);

    return 0; /// 成功返回0
}

int process(char* pbuf, int inqueue, int outqueue)
{
    //int nRet;
    int nLen;
    struct msgform ms;

    //int buflen = sizeof(ms.mtext) - 8;

    while (true)
    {
        /// 从消息队列中取出最前的消息
        nLen = MyMsgRecv(outqueue, &ms, sizeof(ms.mtext), 0, 0);
        if (nLen < 0)
        {
            QUERY_ERROR("msgrcv failed(%d):%s\n", nLen, strerror(errno));
            return nLen;
        }

        //QUERY_INFO("recv one msg.\n");

        /// 把消息中的用户消息体取出
        request_message* request = (request_message*) ms.mtext;

        /// 到数据库中查清单
        query_bill(pbuf, request, inqueue, ms);

    }
    return 0;
}

int pack_back_msg(char* pbuf, int msglen, int count, int current_num,
            int outqueue, struct msgform ms)
{
    int flag = 0; //分包标识
    int nRet = 0;

    /// 当消息长度为>=0时,返回应答消息
    if (msglen >= 0)
    {
        struct msgform bill;
        bill.mtype = ms.mtype; ///mtype即进程号
        char*p = bill.mtext;

        flag = 0; /// 因消息大小固定,所以不分包返回
        memcpy(p, &flag, sizeof(flag));
        p += sizeof(flag);

        /// 消息长度为
        memcpy(p, &msglen, sizeof(msglen));
        p += sizeof(msglen);

        /// 写入总记录数
        memcpy(p, &count, sizeof(count));
        p += sizeof(count);

        /// 写入当前记录号
        memcpy(p, &current_num, sizeof(current_num));
        p += sizeof(current_num);

        /// 写入消息内容
        if (msglen > 0)
            memcpy(p, pbuf, msglen);

        ///将每一条清单写到消息队列
        nRet = MyMsgSend(outqueue, &bill, msglen + 16, IPC_NOWAIT);

        //QUERY_DEBUG("send ont msg, falg = %d len = %d\n", flag, len);
    }
    return nRet;
}

/// 初始化
int load_conf()
{

    /// 读取配置文件,失败返回-1
    IniConfig config;
    if (config.open(g_param.conf_file) < 0)
    {
        QUERY_ERROR("open file(%s) error!\n", g_param.conf_file);
        return -1;
    }

    /// QUERY_DB节点
    const char* query_db = "QUERY_DB";

    /// 读结果消息队列，错误返回 -1
    const char* query_db_in = config.getValue(query_db, "QUERYDB_QUENE_IN");
    if (query_db_in && strlen(query_db_in) != 0)
    {
        in_queue = connectQueue(query_db_in);
        if (in_queue < 0)
        {
            QUERY_ERROR("connect in queue [%s] failed.\n", query_db_in);
            return -1;
        }
    }

    /// 读请求消息队列，失败返回 -1
    const char* query_db_out = config.getValue(query_db, "QUERYDB_QUENE_OUT");
    if (query_db_out && strlen(query_db_out) != 0)
    {
        out_queue = connectQueue(query_db_out);
        if (out_queue < 0)
        {
            QUERY_ERROR("connect out queue [%s] failed.\n", query_db_out);
            return -1;
        }
    }

    /// 设置日志路径
    const char* log_path = config.getValue(query_db, "LOG_PATH");
    if (log_path && strlen(log_path) != 0)
    {
        printf("Log path %s \n", log_path);
    }
    else
    {
        printf("read LOG_PATH item failed, configure file:%s.\n", log_path);
        return -1;
    }

    /* 文件日志级别 */
    int ifile_level = 0;
    const char* file_level = config.getValue(query_db, "LOG_LEVEL_FILE");
    if (file_level && strlen(file_level) != 0)
    {
        ifile_level = atoi(file_level);
        if (ifile_level < 0 || ifile_level > 120)
        {
            printf("LOG_LEVEL_FILE = %d error! use default-----info level\n",
                        ifile_level);
            ifile_level = 40;
        }
    }
    else
    {
        printf("read LOG_LEVEL_FILE failed, use default-----info level\n");
        ifile_level = 40;
    }

    /* 终端日志级别 */
    int iterm_level = 0;
    const char* term_level = config.getValue(query_db, "LOG_LEVEL_TERM");
    if (term_level && strlen(term_level) != 0)
    {
        iterm_level = atoi(term_level);
        if (iterm_level < 0 || iterm_level > 120)
        {
            printf("LOG_LEVEL_TERM = %d error! use default-----info level\n",
                        iterm_level);
            iterm_level = 40;
        }
    }
    else
    {
        printf("read LOG_LEVEL_TERM failed, use default-----info level\n");
        iterm_level = 40;
    }

    /// 初始化日志输出
    INIT_LOG((&g_r5_log), log_path, "db_query", ifile_level, iterm_level);
    return 0;
}

/**
 * @brief 程序入口
 */
int main(int argc, char* argv[])
{
    /// 解释启动参数
    if (0 != read_arg(argc, argv))
    {
        fprintf(stderr, "read args failed.\n");
        return RE_FAILED;
    }

    char *pbuf = (char*) malloc(60 * 1024);
    if (NULL == pbuf)
    {
        printf("malloc failed.\n");
        return -1;
    }

    /// 加载配置
    int ret = load_conf();
    if (ret < 0)
    {
        fprintf(stderr, "load conf failed.\n");
        return -1;
    }

    //以后台方式运行
    if (g_param.deamon)
        ::daemon(0, 0);

    /// 处理输出消息队列中的消息 
    process(pbuf, in_queue, out_queue);

    /// 程序退出清理
    exit();
    if (pbuf)
        free(pbuf);

}

int read_arg(int argc, char* argv[])
{
    int optch;
    extern char *optarg;
    const char optstring[] = "hvec:C:";

    g_param.deamon = true;
    while ((optch = getopt(argc, argv, optstring)) != -1)
    {
        switch (optch)
        {
            case 'h': // 打印帮助信息
                usage(argv[0]);
                exit(0);

            case 'v': // 显示版本号
                show_version();
                exit(0);

            case 'C':
            case 'c': // 配置文件
                strcpy(g_param.conf_file, optarg);
                break;

            case 'e': // 后台方式启动
                g_param.deamon = false;
                break;

            default:
                break;
        }
    }

    if ('\0' == g_param.conf_file[0])
    {
        usage(argv[0]);
        return -1;
    }

    return 0;
}

void usage(const char* exec_file)
{
    printf("usage : %s [-c configure filename] [-e] [-h] [-v]\n", exec_file);
    printf("        -h show help, optional\n");
    printf("        -v show version, optional\n");
    printf("        -c configure filename, must\n");
    printf("-----------------------------------------------\n");
    printf("example:\n");
    printf("%s -c ../etc/proxy.conf \n", exec_file);
}

void show_version()
{
#ifdef PROGRAM_VERSION
    printf("Program version:%s\n\n", PROGRAM_VERSION);
#else
    printf("No version\n");
#endif
}
