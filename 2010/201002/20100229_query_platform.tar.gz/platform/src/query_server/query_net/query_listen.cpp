/**
 * @file
 * @brief 侦听实现
 * @author lqb
 * @date 2011-05-03 lqb create
 * @date 2011-08-30 bonly 命名管道通信
 * @date 2011-08-31 bonly 改命名管道为共享内存
 */

#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <unistd.h>

#include "query_listen.h"
#include "tools.h"
#include "query_type.h"
#include "share_mem.h"
#include "sem.h"
#include "public_signal.h"
#include "cepoll.h"

//from base lib
#include"iniconfig.h"
#include"r5api.h"
#include <list>
#include <algorithm>

using std::list;

list<pid_t> lst_proc; //< 业务处理进程列表
list<pid_t> lst_procdb; //< 数据处理进程列表

//int g_lsn_sock = 0;
char g_configure_file[MAX_FILE_LEN + 1];

struct listen_conf g_conf;

R5_Log g_r5_log;

int g_exit = 0;

CEpoll* g_pepoll = NULL;

int read_arg(int argc, char **argv, struct proc_status& status)
{
    memset(&status, 0, sizeof(status));
    strcpy(status.program_name, argv[0]);
    status.is_deamon = 1;

    int optch;
    extern char *optarg;
    const char optstring[] = "hvec:C:d:D:Ff";

    while ((optch = getopt(argc, argv, optstring)) != -1)
    {
        switch (optch)
        {
            case 'h': /* 打印帮助信息 */
                usage(status);
                exit(RE_SUCCESS);

            case 'v': /* 显示版本号 */
                show_version();
                exit(RE_SUCCESS);

            case 'e': /* 后台方式启动 */
                status.is_deamon = 0;
                break;

            case 'C':
            case 'c': /* 配置文件 */
                strncpy(status.conf_file, optarg, MAX_FILE_LEN);
                break;

            case 'f':
            case 'F': /**/
                status.is_froce = 1;
                break;

            case 'D':
            case 'd': /*是否删除共享内存*/
                status.is_destroy_shm = 1;
                break;

            default:
                break;
        }
    }

    if (status.conf_file[0] == '\0')
    {
        fprintf(stderr, "configure file is MUST!\n");
        return RE_FAILED;
    }

    memset(g_configure_file, 0, sizeof(g_configure_file));
    strncpy(g_configure_file, status.conf_file, MAX_FILE_LEN);

    return RE_SUCCESS;
}

// load config 
int load_conf(bool is_reload)
{
    if (!is_reload)
    {
        memset(&g_conf, 0, sizeof(g_conf));
    }

    IniConfig config;
    if (config.open(g_configure_file) < 0)
    {
        printf("open %s failed:%s\n", g_configure_file, strerror(errno));
        return RE_FAILED;
    }

    const char* comm = "COMM";

    /// 日志路径
    const char* log_path = config.getValue(comm, "LOG_PATH");
    if (log_path && strlen(log_path) != 0)
    {
        if (0
                    != path_string(log_path, g_conf.log_path,
                                sizeof(g_conf.log_path)))
        {
            printf(
                        "read LOG_PATH item failed, configure file: '%s', LOG_PATH: '%s'.\n",
                        g_configure_file, log_path);
            return RE_FAILED;
        }
    }
    else
    {
        printf("read LOG_PATH item failed, configure file:%s.\n",
                    g_configure_file);
        return RE_FAILED;
    }

    /// 文件日志级别
    const char* file_level = config.getValue(comm, "LOG_LEVEL_FILE");
    if (file_level && strlen(file_level) != 0)
    {
        g_conf.file_level = atoi(file_level);
        if (g_conf.file_level < 0 || g_conf.file_level > 120)
        {
            printf("LOG_LEVEL_FILE = %d error! use default-----info level\n",
                        g_conf.file_level);
            g_conf.file_level = 40;
        }
    }
    else
    {
        printf("read LOG_LEVEL_FILE failed, use default-----info level\n");
        g_conf.file_level = 40;
    }

    /// 终端日志级别
    const char* term_level = config.getValue(comm, "LOG_LEVEL_TERM");
    if (term_level && strlen(term_level) != 0)
    {
        g_conf.term_level = atoi(term_level);
        if (g_conf.term_level < 0 || g_conf.term_level > 120)
        {
            printf("LOG_LEVEL_TERM = %d error! use default-----info level\n",
                        g_conf.term_level);
            g_conf.term_level = 40;
        }
    }
    else
    {
        printf("read LOG_LEVEL_TERM failed, use default-----info level\n");
        g_conf.term_level = 40;
    }

    //初始化日志
    INIT_LOG((&g_r5_log), g_conf.log_path, "query_listen", g_conf.file_level,
                g_conf.term_level);

    //the local_ip is optional
    const char *local_ip = config.getValue(comm, "LISTEN_IP");
    if (local_ip && strlen(local_ip) != 0)
    {
        strncpy(g_conf.local_ip, local_ip, sizeof(g_conf.local_ip) - 1);
    }

    /// 监听端口
    const char *port = config.getValue(comm, "LISTEN_PORT");
    if (port && strlen(port) != 0)
    {
        g_conf.listen_port = atoi(port);
    }
    else
    {
        printf("read LISTEN_PORT failed, configure file:%s\n",
                    g_configure_file);
        return RE_FAILED;
    }

    /// 对端IP  --optional--
    const char *remote_ip = config.getValue(comm, "REMOTE_IP");
    if (remote_ip && strlen(remote_ip) != 0)
    {
        strncpy(g_conf.remote_ip, remote_ip, sizeof(g_conf.remote_ip) - 1);
    }

    /* 最大连接数 */
    /*
     const char * max_conn = config.getValue(comm, "MAX_CONNECT");
     if(strlen(max_conn) != 0)
     {
     g_conf.max_connect = atoi(max_conn);
     if(g_conf.max_connect < 1 || g_conf.max_connect > FD_SIZE)
     {
     printf("max_conn error! read MAX_CONNECT = %s\n", max_conn);
     return RE_FAILED;
     }
     }
     else
     {
     printf("read MAX_CONNECT failed, configue file:%s\n", g_configure_file);
     return RE_FAILED;
     }
     */

    /// 接收进程名
    const char *recv_file = config.getValue(comm, "RECV_FILE");
    if (recv_file && strlen(recv_file) != 0)
    {
        strncpy(g_conf.recv_file, recv_file, sizeof(g_conf.recv_file) - 1);

    }
    else
    {
        printf("read RECV_FILE failed, configure file:%s\n", g_configure_file);
        return RE_FAILED;
    }

    /// 发送进程名
    const char *send_file = config.getValue(comm, "SEND_FILE");
    if (send_file && strlen(send_file) != 0)
    {
        strncpy(g_conf.send_file, send_file, sizeof(g_conf.send_file) - 1);
    }
    else
    {
        printf("read SEND_FILE failed, configure file:%s\n", g_configure_file);
        return RE_FAILED;
    }

    /// 业务处理进程名
    const char *proc_file = config.getValue(comm, "PROCESS_FILE");
    if (proc_file && strlen(proc_file) != 0)
    {
        strncpy(g_conf.proc_file, proc_file, sizeof(g_conf.proc_file) - 1);
    }
    else
    {
        printf("read PROCESS_FILE failed, configure file:%s\n",
                    g_configure_file);
        return RE_FAILED;
    }

    /// 业务进程数
    const char * proc_num = config.getValue(comm, "PROC_NUM");
    if (strlen(proc_num) != 0)
    {
        g_conf.proc_num = atoi(proc_num);
        if (g_conf.proc_num < 1 || g_conf.proc_num > FD_SIZE)
        {
            printf("process num error! read PROC_NUM = %s\n", proc_num);
            return RE_FAILED;
        }
    }
    else
    {
        printf("read PROC_NUM failed, configue file:%s\n", g_configure_file);
        return RE_FAILED;
    }

    /// 数据处理进程名
    const char *procdb_file = config.getValue(comm, "PROCESSDB_FILE");
    if (procdb_file && strlen(procdb_file) != 0)
    {
        strncpy(g_conf.procdb_file, procdb_file,
                    sizeof(g_conf.procdb_file) - 1);
    }
    else
    {
        printf("read PROCESSDB_FILE failed, configure file:%s\n",
                    g_configure_file);
        return RE_FAILED;
    }

    /// 数据处理进程数
    const char * procdb_num = config.getValue(comm, "PROCDB_NUM");
    if (strlen(procdb_num) != 0)
    {
        g_conf.procdb_num = atoi(procdb_num);
        if (g_conf.procdb_num < 1 || g_conf.procdb_num > FD_SIZE)
        {
            printf("process num error! read PROCDB_NUM = %s\n", procdb_num);
            return RE_FAILED;
        }
    }
    else
    {
        printf("read PROCDB_NUM failed, configue file:%s\n", g_configure_file);
        return RE_FAILED;
    }

    /// 共享内存文件
    const char* shm = config.getValue(comm, "SHM_FILE");
    if (shm && strlen(shm) != 0)
    {
        strncpy(g_conf.shm_file, shm, sizeof(g_conf.shm_file) - 1);
    }
    else
    {
        printf("read SHM_FILE failed, configure file:%s.\n", g_configure_file);
        return -1;
    }

    ///信号量文件
    const char* sem = config.getValue(comm, "SEM_FILE");
    if (sem && strlen(sem) != 0)
    {
        strncpy(g_conf.sem_file, sem, sizeof(g_conf.sem_file) - 1);
    }
    else
    {
        printf("read SEM_FILE failed, configure file:%s\n", g_configure_file);
        return -1;
    }

    ///共享内存块大小，单位：M
    const char *block_size = config.getValue(comm, "BLOCK_SIZE");
    if (block_size && strlen(block_size) != 0)
    {
        g_conf.block_size = atoi(block_size);
        if (g_conf.block_size < 1 || g_conf.block_size > 64)
        {
            printf("BLOCK_SIZE error, size = %d\n", g_conf.block_size);
            printf("the correct range is 1 <= block_size <= 64\n");
            return -1;
        }

        //转换成字节
        g_conf.block_size = g_conf.block_size << 16;
    }
    else
    {
        printf("read BLOCK_SIZE failed, configure file:%s\n", g_configure_file);
        return -1;
    }

    ///block count
    const char *block_cnt = config.getValue(comm, "BLOCK_CNT");
    if (block_cnt && strlen(block_cnt) != 0)
    {
        g_conf.block_cnt = atoi(block_cnt);
        if (g_conf.block_cnt < 2 || g_conf.block_cnt > 16)
        {
            printf("BLOCK_CNT error, size = %d\n", g_conf.block_cnt);
            printf("the correct range is 2 <= block_size <= 16\n");
            return -1;
        }
    }
    else
    {
        printf("read BLOCK_CNT failed, configure file:%s\n", g_configure_file);
        return -1;
    }

    return RE_SUCCESS;
}

void usage(struct proc_status& status)
{
    printf("usage : %s (-c configure filename) [-h] [-v]\n",
                status.program_name);
    printf("        -h show help, optional\n");
    printf("        -v show version, optional\n");
    printf("        -c configure filename, MUST\n");
    printf("-----------------------------------------------\n");
    printf("example:\n");
    printf("%s -c ../etc/query_conf.conf\n", status.program_name);
}

//打印版本号信息
void show_version()
{
#ifdef PROGRAM_VERSION
    printf("Program version:%s\n\n", PROGRAM_VERSION);
#else
    printf("No version\n");
#endif
}

int register_signal()
{
    //退出  SIGTERM是系统默认终止信号
    if (my_signal(SIGTERM, Signal::SigTerm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM,
                    strerror(errno));
        return -1;
    }

    //退出 SIGINT当用户按终端键（delete/ctrl+C），终端驱动程序产生此信号并送至前台进程中的每一个进程
    if (my_signal(SIGINT, Signal::SigTerm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGINT,
                    strerror(errno));
        return -1;
    }

    //通知守护进程重读配置
    if (my_signal(SIGHUP, Signal::SigHup, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGHUP,
                    strerror(errno));
        return -1;
    }

    //刷新日志
    if (my_signal(SIGUSR2, Signal::SigUsr2, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR2,
                    strerror(errno));
        return -1;
    }

    /* ALARM中断应立即返回 超时 */
    if (my_signal(SIGALRM, Signal::SigAlarm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGALRM,
                    strerror(errno));
        return -1;
    }

    /* PIPE中断应该立即返回 */
    if (my_signal(SIGPIPE, Signal::SigPipe, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGPIPE,
                    strerror(errno));
        return -1;
    }

    //忽略 子进程状态改变
    if (my_signal(SIGCHLD, Signal::SigChild, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                    strerror(errno));
        return -1;
    }

    //忽略
    if (my_signal(SIGUSR1, SIG_IGN, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR1,
                    strerror(errno));
        return -1;
    }

    return 0;
}

int init(struct proc_status& status, share_mem& shm, Csem& sem)
{
    //允许core文件
    struct rlimit fdlim;
    fdlim.rlim_cur = RLIM_INFINITY;
    fdlim.rlim_max = RLIM_INFINITY;
    setrlimit(RLIMIT_CORE, &fdlim);

    //初始化共享内存
    /*如果共享内存不存在则创建*/
    if (!shm.is_exist(g_conf.shm_file) || 1 == status.is_froce)
    {
        if (shm.create(g_conf.shm_file, g_conf.block_cnt, g_conf.block_size,
                    status.is_froce) < 0)
        {
            LIS_ERROR(
                        "create share memory failed, err = %d, str = %s\n", shm.error(), strerror(errno));
            return RE_FAILED;
        }
    }

    //初始化信号量
    if (!sem.is_exist(g_conf.sem_file))
    {
        if (sem.create(g_conf.sem_file) < 0)
        {
            LIS_ERROR(
                        "create sem failed, err = %d, str = %s\n", sem.error(), strerror(errno));
            return RE_FAILED;
        }
    }
    else
    {

        /*连接信号量*/
        if (sem.attach(g_conf.sem_file) < 0)
        {
            LIS_ERROR(
                        "attach sem failed, err = %d, file = %s\n", sem.error(), g_conf.sem_file);

            return -1;
        }

        //重新初始化
        if (sem.init() < 0)
        {
            LIS_ERROR("sem init failed! err = %d\n", sem.error());
            return RE_FAILED;
        }

    }

    return RE_SUCCESS;
}

int start_listen_client(CEpoll* pep)
{

    struct sockaddr_in server_addr;
    int lsn_fd = 0;

    if (lsn_fd != 0)
    {
        LIS_INFO("reset client listen port!\n");
        pep->delete_fd(lsn_fd);
        close(lsn_fd);
        lsn_fd = 0;
    }

    lsn_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (lsn_fd < 0)
    {
        int err = errno;
        LIS_ERROR(
                    "create client Listen port failed![%d, %s]\n", err, strerror(err));
        return RE_FAILED;
    }

    if (RE_SUCCESS != pep->add_fd(lsn_fd, EPOLLIN | EPOLLET | EPOLLERR))
    {
        LIS_ERROR("add lsn_fd to epoll failed! fd = %d \n", lsn_fd);
        return RE_FAILED;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(g_conf.listen_port); //30098
    if ('\0' == g_conf.local_ip[0])
    {
        server_addr.sin_addr.s_addr = htonl(INADDR_ANY); //以网络字节序表示的IP地址
    }
    else
    {
        //int inet_pton(int af, const char *src, void *dst);
        inet_pton(AF_INET, g_conf.local_ip, &server_addr.sin_addr); //以主机字节序表示的IP地址
    }

    int opt = 1;
    //重用Bind中的地址
    if (setsockopt(lsn_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
    {
        close(lsn_fd);
        int err = errno;
        LIS_ERROR(
                    "[setsockopt SO_REUSEADDR error] client listen sock![%d, %s]\n", err, strerror(err));
        return RE_FAILED;
    }
    //设置断开连接方式  
    struct linger slinger;
    slinger.l_onoff = 1;
    slinger.l_linger = 2;
    //若有未发送消息并且套接字关闭时，延迟时间
    if (setsockopt(lsn_fd, SOL_SOCKET, SO_LINGER, &slinger,
                sizeof(struct linger)) < 0)
    {
        close(lsn_fd);
        int err = errno;
        LIS_ERROR(
                    "[setsockopt SO_LINGER error] client listen sock![%d, %s]\n", err, strerror(err));
        return RE_FAILED;
    }

    if (bind(lsn_fd, (sockaddr *) &server_addr, sizeof(server_addr)) < 0)
    {
        close(lsn_fd);
        int err = errno;
        LIS_ERROR("bind client Listen ip![%d, %s]\n", err, strerror(err));
        return RE_FAILED;
    }

    if (listen(lsn_fd, LISTENMAX) < 0)
    {
        close(lsn_fd);
        int err = errno;
        LIS_ERROR("client Listen error![%d, %s]\n", err, strerror(err));
        return RE_FAILED;
    }

    LIS_INFO(
                "Port [%s:%d] Start Listen![cli_lsn fd = %d]\n", g_conf.local_ip, g_conf.listen_port, lsn_fd);

//	cout << "Port [" << g_conf.local_ip << ":" <<  g_conf.listen_port
//		<< "] Start Listen![Client]" << endl;

    return lsn_fd;
}

int start_recv_process(struct proc_status& status)
{
    //创建socketpair，用于传递描述符
    int fd_pair[2];

    if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd_pair) != 0)
    {
        LIS_ERROR("socketpair failed:%s\n", strerror(errno));
        return -1;
    }

    LIS_DEBUG("fd[0] = %d fd[1] = %d \n", fd_pair[0], fd_pair[1]);

    //启动接收子进程
    pid_t pid = fork();

    if (-1 == pid)
    {
        LIS_ERROR("fork: %s\n", strerror(errno));
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return -1;
    }
    else if (0 == pid) /* 子进程 */
    {
        g_r5_log.logOnlyClose();
        close(fd_pair[FD_WRITE]);

        char recv_exe[256] = { '\0' };
        char proc_name[256] = { '\0' };
        char str_socket[32] = { 0 };

        snprintf(recv_exe, sizeof(recv_exe) - 1, "%s", g_conf.recv_file);
        snprintf(proc_name, sizeof(proc_name) - 1, "%s", g_conf.recv_file);
        snprintf(str_socket, sizeof(str_socket) - 1, "%d", fd_pair[FD_READ]);

        int retval = execl(recv_exe, proc_name, "-s", str_socket, "-c",
                    status.conf_file, (char*) NULL);

        if (-1 == retval)
        {
            perror("execl");
            //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
            exit(0);
        }
    }
    else
    {
        close(fd_pair[FD_READ]);
        status.recv_fd = fd_pair[FD_WRITE];
        status.recv_pid = pid;

        /*
         /// 把socketpair入到epoll中,以便响应
         if(RE_SUCCESS != g_pepoll->add_fd(status.recv_fd, EPOLLIN|EPOLLET|EPOLLERR)) {
         LIS_ERROR("add status.recv_fd to epoll failed! fd = %d \n", status.recv_fd);
         return RE_FAILED;
         }
         */

        //LIS_INFO("New recv process pid = %d.\n", plc->recv_child_pid[0]);
    }

    return 0;
}

int start_send_process(struct proc_status& status)
{
    //创建socketpair，用于传递描述符
    int fd_pair[2];

    if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd_pair) != 0)
    {
        LIS_ERROR("socketpair failed:%s\n", strerror(errno));
        return -1;
    }

    LIS_DEBUG("fd[0] = %d fd[1] = %d \n", fd_pair[0], fd_pair[1]);

    //启动发送子进程
    pid_t pid = fork();

    if (-1 == pid)
    {
        LIS_ERROR("fork: %s\n", strerror(errno));
        //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
        return -1;
    }
    else if (0 == pid) /* 子进程 */
    {
        g_r5_log.logOnlyClose();

        close(fd_pair[FD_WRITE]);

        char send_exe[256] = { '\0' };
        char proc_name[256] = { '\0' };
        char str_socket[32] = { 0 };

        snprintf(send_exe, sizeof(send_exe), "%s", g_conf.send_file);
        snprintf(proc_name, sizeof(proc_name), "%s", g_conf.send_file);
        snprintf(str_socket, sizeof(str_socket), "%d", fd_pair[FD_READ]);

        int retval = execl(send_exe, proc_name, "-s", str_socket, "-c",
                    status.conf_file, (char*) NULL);

        if (-1 == retval)
        {
            perror("execl");
            //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
            exit(0);
        }
    }
    else
    {
        close(fd_pair[FD_READ]);
        status.send_fd = fd_pair[FD_WRITE];
        status.send_pid = pid;
        //LIS_INFO("New send process pid = %d.\n", plc->send_child_pid[0]);
    }

    return 0;
}

int start_deal_process(struct proc_status& status)
{
    for (int i = 0; i < g_conf.proc_num; ++i)
    {
        //启动接收子进程
        pid_t pid = fork();

        if (-1 == pid)
        {
            LIS_ERROR(
                        "fork process %d for query_process: %s\n", i, strerror(errno));
            //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
            return -1;
        }
        else if (0 == pid) // 子进程
        {
            g_r5_log.logOnlyClose();

            char proc_exe[256] = { '\0' };
            char proc_name[256] = { '\0' };

            snprintf(proc_exe, sizeof(proc_exe), "%s", g_conf.proc_file);
            snprintf(proc_name, sizeof(proc_name), "%s", g_conf.proc_file);

            int retval = execl(proc_exe, proc_name, "-c", status.conf_file,
                        "-e", (char*) NULL);

            if (-1 == retval)
            {
                perror("execl");
                //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
                exit(0);
            }
        }
        else //父进程
        {
            LIS_INFO("New business process pid = %d.\n", pid);
            lst_proc.push_back(pid);
        }
    }

    return 0;
}

int start_deal_process_db(struct proc_status& status)
{
    for (int i = 0; i < g_conf.proc_num; ++i)
    {
        //启动接收子进程
        pid_t pid = fork();

        if (-1 == pid)
        {
            LIS_ERROR(
                        "fork process %d for query_process_db: %s\n", i, strerror(errno));
            //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
            return -1;
        }
        else if (0 == pid) // 子进程
        {
            g_r5_log.logOnlyClose();

            char proc_exe[256] = { '\0' };
            char proc_name[256] = { '\0' };

            snprintf(proc_exe, sizeof(proc_exe), "%s", g_conf.procdb_file);
            snprintf(proc_name, sizeof(proc_name), "%s", g_conf.procdb_file);

            int retval = execl(proc_exe, proc_name, "-c", status.conf_file,
                        "-e", (char*) NULL);

            if (-1 == retval)
            {
                perror("execl");
                //write_kpi(KPI_FORK_FAILED, KPI_SCALE_EMERGENCY);
                exit(0);
            }
        }
        else //父进程
        {
            LIS_INFO("New database process pid = %d.\n", pid);
            lst_procdb.push_back(pid);
        }
    }

    return 0;
}

int prepare_to_run(struct proc_status& status)
{
    int ret = 0;

    ret = start_recv_process(status);
    if (ret < 0)
    {
        LIS_ERROR("start recv process failed.\n");
        return -1;
    }

    ret = start_send_process(status);
    if (ret < 0)
    {
        LIS_ERROR("start send process failed.\n");
        return -1;
    }

    //启动业务处理进程
    ret = start_deal_process(status);
    if (ret < 0)
    {
        LIS_ERROR("start business process failed.\n");
        return -1;
    }

    //启动数据处理进程
    ret = start_deal_process_db(status);
    if (ret < 0)
    {
        LIS_ERROR("start database process failed.\n");
        return -1;
    }
    return 0;
}

int accept_connection(int lsn_fd, struct proc_status& status)
{

    struct sockaddr_in client_addr;
    socklen_t addrlen = sizeof(client_addr);
    int accept_fd = accept(lsn_fd, (struct sockaddr*) &client_addr, &addrlen);
    if (accept_fd < 0)
    {
        //被信号中断
        if (errno == EINTR)
        {
            if (Signal::HandleSignal() < 0)
                return RE_FAILED;
        }
        else
        {
            //其他错误
            return RE_FAILED;
        }
    }
    else
    {
        char ipbuf[32] = { 0 };
        inet_ntop(AF_INET, &(client_addr.sin_addr), ipbuf, sizeof(ipbuf));

        LIS_INFO(
                    "receiver a connection from[%s:%d]\n", ipbuf, ntohs(client_addr.sin_port));

        static int unique_id = 1;
        char buf[8] = { '\0' };
        snprintf(buf, sizeof(buf), "%d", unique_id);
        int send_len = sizeof(buf);

        IP_MSG msg;
        strncpy(msg.ip, ipbuf, sizeof(msg.ip));
        msg.port = ntohs(client_addr.sin_port);
        msg.index = unique_id;

        unique_id++;
        unique_id %= FD_SIZE;
        if (unique_id == 0)
            unique_id = 1;

        if (send_fd(status.recv_fd, buf, send_len, accept_fd) > 0)
        {
            LIS_INFO("send fd to recv success.\n");
        }
        else
        {
            LIS_ERROR("send fd to recv failed.\n");
        }

        // 把IP信息发给recv
        if (write(status.recv_fd, &msg, sizeof(IP_MSG)) <= 0)
        {
            LIS_ERROR("send ip info to recv failed.\n");
        }

        if (send_fd(status.send_fd, buf, send_len, accept_fd) > 0)
        {
            LIS_INFO("send fd to send success.\n");
        }
        else
        {
            LIS_ERROR("send fd to send failed.\n");
        }

        close(accept_fd);
    }

    return RE_SUCCESS;
}

int scan_child_proc(proc_status &status)
{
    char process_file[MAX_FILE_LEN + 1]="";

    //recv进程检查
snprintf    (process_file,MAX_FILE_LEN+1,"/proc/%d/comm",status.recv_pid);
    if (access(process_file,F_OK)==-1)
    {
        LIS_ERROR("recv process %d had been shutdown!\n",status.recv_pid);
    }

    //send进程检查
    snprintf(process_file,MAX_FILE_LEN+1,"/proc/%d/comm",status.send_pid);
    if (access(process_file,F_OK)==-1)
    {
        LIS_ERROR("send process %d had been shutdown!\n",status.send_pid);
    }

    //业务进程检查
    for(list<pid_t>::iterator pid=lst_proc.begin(); pid!=lst_proc.end(); ++pid)
    {
        snprintf(process_file,MAX_FILE_LEN+1,"/proc/%d/comm",*pid);
        if(access(process_file, F_OK)==-1)
        {
            LIS_ERROR("business process %d had been shutdown!\n",*pid);
            list<pid_t>::iterator fp = find(lst_proc.begin(), lst_proc.end(), status.recv_pid);
            if (fp != lst_proc.end())
            {
               lst_proc.erase(fp);
               break;
            }
        }

    }
    //数据处理进程检查
    for(list<pid_t>::iterator pid=lst_procdb.begin(); pid!=lst_procdb.end(); ++pid)
    {
        snprintf(process_file,MAX_FILE_LEN+1,"/proc/%d/comm",*pid);
        if(access(process_file, F_OK)==-1)
        {
            LIS_ERROR("database process %d had been shutdown!\n",*pid);
            list<pid_t>::iterator fp = find(lst_procdb.begin(), lst_procdb.end(), status.recv_pid);
            if (fp != lst_procdb.end())
            {
               lst_procdb.erase(fp);
               break;
            }
        }
    }

    return 0;
}

int proc_run(struct proc_status& status)
{
    int lsn_fd = 0;
    //初始化epoll
    CEpoll* pepoll = new CEpoll(10, 10, 10000);
    g_pepoll = pepoll;
    if (NULL == pepoll)
    {
        LIS_ERROR("new epoll failed.\n")
        return RE_FAILED;
    }

    if (0 != pepoll->init())
    {
        LIS_ERROR("epoll init failed!\n");
        delete pepoll;
        pepoll = NULL;
        return RE_FAILED;
    }

    if ((lsn_fd = start_listen_client(pepoll)) < 0)
    {
        delete pepoll;
        pepoll = NULL;
        return RE_FAILED;
    }

    if (prepare_to_run(status) < 0)
    {
        LIS_ERROR("prepare_to_run failed.\n");
        delete pepoll;
        pepoll = NULL;
        return RE_FAILED;
    }

    LIS_INFO("Program running!\n");

    vector<CEpoll::EpollEve> EV;

    while (1)
    {
        if (g_exit)
            break;

        scan_child_proc(status);
        if (RE_SUCCESS != pepoll->wait(EV))
        {
            int err = errno;
            LIS_WARN("epoll failed,err:%s\n", strerror(err));

            if (Signal::HandleSignal() < 0)
            {
                delete pepoll;
                pepoll = NULL;
                return RE_FAILED;
            }

            if (err != EINTR
            )
                break;
        }

        vector<CEpoll::EpollEve>::iterator iter;
        for (iter = EV.begin(); iter != EV.end(); ++iter)
        {
            if (iter->fd == lsn_fd)
            {
                accept_connection(lsn_fd, status);
            }
        }

        // 回收recv 进程
        int resl = 0;
        if (0 < waitpid(status.recv_pid, &resl, WNOHANG))
        {
            LIS_INFO("Recv process finish [%d]\n", status.recv_pid);
        }

        // 回收send 进程
        if (0 < waitpid(status.send_pid, &resl, WNOHANG))
        {
            LIS_INFO("Send process finish [%d]\n", status.send_pid);
        }

        // 回收业务处理进程,一次回收一个
        for (list<pid_t>::iterator pid = lst_proc.begin();
                    pid != lst_proc.end(); ++pid)
                    {
            int ending = waitpid(*pid, &resl, WNOHANG);
            if (ending > 0)
            {
                LIS_INFO("Business process finish [%d]\n", *pid);
                lst_proc.erase(pid);
                break;
            }
        }

        // 回收数据处理进程,一次回收一个
        for (list<pid_t>::iterator pid = lst_procdb.begin();
                    pid != lst_procdb.end(); ++pid)
                    {
            int ending = waitpid(*pid, &resl, WNOHANG);
            if (ending > 0)
            {
                LIS_INFO("Database process finish [%d]\n", *pid);
                lst_procdb.erase(pid);
                break;
            }
        }

    }

    if (pepoll)
    {
        delete pepoll;
        pepoll = NULL;
    }
    close(lsn_fd);

    return 0;
}

void daemon()
{
    int pid = 0;
    if ((pid = fork()) > 0)
        exit(0);

    setsid();
    if ((pid = fork()) > 0)
        exit(0);
}

/*
 */
void exit(struct proc_status& status)
{
    stop_process(status, SIGTERM);
}

/*
 */
void stop_process(struct proc_status& status, int signo)
{

    if (status.recv_fd > 0)
    {
        kill(status.recv_fd, signo);
        LIS_INFO("kill recv process %d\n", status.recv_pid);
        status.recv_fd = -1;
    }
    usleep(1000);

    if (status.send_fd > 0)
    {
        kill(status.send_fd, signo);
        LIS_INFO("kill send process %d\n", status.send_pid);
        status.send_fd = -1;
    }

    for (list<pid_t>::iterator pid = lst_proc.begin(); pid != lst_proc.end();
                ++pid)
                {
        kill(*pid, signo);
        LIS_INFO("kill business process %d\n", *pid);
    }
    lst_proc.clear();

    for (list<pid_t>::iterator pid = lst_procdb.begin();
                pid != lst_procdb.end(); ++pid)
                {
        kill(*pid, signo);
        LIS_INFO("kill database process %d\n", *pid);
    }
    lst_procdb.clear();
}

int main(int argc, char* argv[])
{
    int ret = 0;
    struct proc_status status;
    share_mem shm;
    Csem sem;

    ret = read_arg(argc, argv, status);
    if (ret < 0)
    {
        fprintf(stderr, "read args failed.\n");
        return RE_FAILED;
    }

    ret = load_conf();
    if (ret < 0)
    {
        fprintf(stderr, "load conf failed.\n");
        return RE_FAILED;
    }

    //以后台方式运行
    if (status.is_deamon)
        daemon();

    ret = init(status, shm, sem);
    if (ret < 0)
    {
        fprintf(stderr, "init failed.\n");
        return RE_FAILED;
    }

    ret = register_signal();
    if (ret < 0)
    {
        LIS_ERROR("register signal failed.\n");
        return -1;
    }

    proc_run(status);

    shm.destroy();
    //sem.destroy(); is need??
    exit(status);

    LIS_INFO("Program Exit.\n");
    g_r5_log.flush();

    return 0;
}

int DoSigTerm()
{
    LIS_WARN("interruptted by SIGTERM.\n");
    g_exit = 1;
    return 0;
}

int DoSigChild()
{
    LIS_WARN("interruptted by SIGCHLD.\n");

    return 0;
}

int DoSigHup()
{
    LIS_WARN("interruptted by SIGHUP.\n");
    return load_conf(true);
}

int DoSigUsr2()
{
    LIS_WARN("interruptted by SIGUSR2.\n");
    g_r5_log.flush();
    return 0;
}

int DoSigAlarm()
{
    LIS_WARN("interruptted by SIGALRM.\n");
    return 0;
}

int DoSigPipe()
{
    LIS_WARN("interruptted by SIGPIPE.\n");
    return 0;
}
