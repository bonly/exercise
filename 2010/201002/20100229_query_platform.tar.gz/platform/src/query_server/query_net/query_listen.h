#ifndef __QUERY_LISTEN_H__
#define __QUERY_LISTEN_H__
/*
* date:2011-05-03
* author: lqb
*/


#define LIS_DEBUG(...)\
    R5_DEBUG((&g_r5_log), ("[lis] " __VA_ARGS__))
#define LIS_INFO(...)\
    R5_INFO((&g_r5_log), ("[lis] " __VA_ARGS__))
#define LIS_ERROR(...)\
    R5_ERROR((&g_r5_log), ("[lis] " __VA_ARGS__))
#define LIS_WARN(...)\
    R5_WARN((&g_r5_log), ("[lis] " __VA_ARGS__))
#define LIS_TRACE(...)\
    R5_TRACE((&g_r5_log), ("[lis] " __VA_ARGS__))


#define FD_READ  	0
#define FD_WRITE 	1

#define MAX_FILE_LEN 256
#define IP_LENGTH 32

struct listen_conf
{
	int file_level;			              //< 文件日志级别
	int term_level;			              //< 终端日志级别
	char log_path[MAX_FILE_LEN + 1];
	char shm_file[MAX_FILE_LEN + 1];
	char sem_file[MAX_FILE_LEN + 1]; 
	char recv_file[MAX_FILE_LEN + 1];
	char send_file[MAX_FILE_LEN + 1];
	char proc_file[MAX_FILE_LEN + 1];     //< 业务处理进程名
	char procdb_file[MAX_FILE_LEN + 1];     //< 数据处理进程名
	char local_ip[IP_LENGTH + 1];         //< 绑定本地IP(可以不配置)
	char remote_ip[IP_LENGTH + 1];        //< 对端IP
	int listen_port;                      //< 监听端口
	int block_size;
	int block_cnt;
	int max_connect;                      //< 最大连接数
	int proc_num;                         //< 业务处理进程数
	int procdb_num;                       //< 数据处理进程数
};

struct proc_status{
    char program_name[MAX_FILE_LEN + 1];
    char conf_file[MAX_FILE_LEN + 1];
    int is_deamon;
    int is_froce;
    int is_destroy_shm;
    
    int send_fd;
    int send_pid;
    
    int recv_fd;
    int recv_pid;

};

class share_mem;
class Csem;
class CEpoll;

void show_version();

void usage(struct proc_status& status);

//读取配置文件
int load_conf(bool is_reload = false);

int read_arg(int argc, char **argv, struct proc_status& status);

int init(share_mem& shm, Csem& sem);

int start_listen_client(CEpoll* pep);

/** @brief 启动接收子进程
 *
 */
int start_recv_process(struct proc_status& status);

/** @brief 启动发送子进程
 *
 */
int start_send_process(struct proc_status& status);

/** @breif 启动业务处理进程
 *
 */
int start_deal_process(struct proc_status& status);

/** @brief 启动数据处理进程
 *
 */
int start_deal_process_db(struct proc_status& status);

/**
 * @brief 启动相关的子进程
 */
int prepare_to_run(struct proc_status& status);

/**
 * @brief 检查子进程是否已退出
 */
int scan_child_proc(proc_status &status);

int accept_connection(int lsn_fd, struct proc_status& status);

int proc_run(struct proc_status& status);

void daemon();

void exit(struct proc_status& status);

int register_signal();

void stop_process(struct proc_status& status, int signo);

#endif
