/*
*date:2011-05-09
*author:lqb
*
*/
#include <dlfcn.h>

#include "r5api.h"
#include "plugin_translate.h"
#include "comm_structs.h"

extern R5_Log g_r5_log;

int (*p_tran_initialize)(const char* conf_file, R5_Log* plog);

int (*p_tran_destroy)();

int (*p_bill_translate)(const char* inmsg, int inlen, const void* protocol, void* outmsg, int* outlen);


int init_translate(const char* conf_file, const char* lib_file, R5_Log* plog){
    /// 加载动态库
    char *error = NULL;
    void *p_translate = dlopen(lib_file , RTLD_LAZY);
    error=dlerror();
    if(p_translate == NULL)
    {
        LOG_ERROR("open library %s failed\n error:%s\n" , lib_file, error);
        return -1;
    }
    dlerror();

    ///加载函数
    p_tran_initialize = (int(*)(const char*, R5_Log*))::dlsym(p_translate , "initialize");
    if ((error = dlerror()) != NULL)
    {
        ///报错
        LOG_ERROR("load tran_initialize fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();

    p_tran_destroy = (int(*)())::dlsym(p_translate, "destroy");
    if ((error = dlerror()) != NULL)
    {
        ///报错
        LOG_ERROR("load tran_destroy fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();

    p_bill_translate = (int(*)(const char*, int, const void*, void*, int*))::dlsym(p_translate, "bill_translate");
    if ((error = dlerror()) != NULL)
    {
        ///报错
        LOG_ERROR("load bill_translate fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();


    ///动态库初始化
    int nRet = tran_initialize(conf_file, plog);
    if(nRet < 0)
    {
        LOG_ERROR("tran_initialize failed!\n");
        return -1;
    }

    return 0;

}


int tran_initialize(const char* conf_file, R5_Log* plog){
    return p_tran_initialize(conf_file, plog);
}

int tran_destroy(){
    return p_tran_destroy();
}

int bill_translate(const char* inmsg, int inlen, const void* protocol, void* outmsg, int* outlen){
    return p_bill_translate(inmsg, inlen, protocol, outmsg, outlen);
}





