#ifndef __QUERY_PROCESS_H__
#define __QUERY_PROCESS_H__
/*
*
*
*/


#include "query_type.h"

struct query_conf{
	int file_level;			//文件日志级别
	int term_level;			//终端日志级别
	int lock_time;
	char log_path[MAX_FILE_LEN + 1];
	char shm_file[MAX_FILE_LEN + 1];
	char sem_file[MAX_FILE_LEN + 1];
	char protocol_plugin[MAX_FILE_LEN + 1];
	char route_plugin[MAX_FILE_LEN + 1];
	char query_plugin[MAX_FILE_LEN + 1];
	char translate_plugin[MAX_FILE_LEN + 1];

//	char recv_pipe[MAX_FILE_LEN + 1];   //接收服务的管道名
//	char local_pipe[MAX_FILE_LEN + 1];  //本地接收用的管道名

	char lmgr_work[MAX_FILE_LEN + 1]; //稽核日志工作路径
	char lmgr_bak[MAX_FILE_LEN + 1]; //稽核日志备份路径
	char lmgr_target[MAX_FILE_LEN + 1]; //稽核日志工作路径
	char lmgr_head[MAX_FILE_LEN + 1]; //稽核日志工作路径
};

struct query_param{
    int is_deamon;
    char conf_file[MAX_FILE_LEN + 1];
    char exec_file[MAX_FILE_LEN + 1];

//    int  p_local;       // 本地管道
//    int  p_recv;        //  接收服务管道
};


class buffer;
class share_mem;
class Csem;
class Block_Head;
struct query_protocol;

int read_arg(int argc, char* argv[], struct query_param& param);

void usage(struct query_param& param);

void show_version();

int load_conf(bool is_reload = false);

int register_signal();

int init(struct query_param& param, share_mem& mem, Csem& sem);

int read_message(int index, buffer& buff, share_mem& mem, char* msgbuf, int& outlen);

int process_msg(char* msgbuf, int msglen, char* response, int* resplen, Block_Head &bh);

int handle_msg(int index, buffer* pbuff, share_mem& mem, char* response, int* resplen, int& cnt);

int query_process(share_mem& mem, Csem& sem);

int force_unlock(int index, int waittime, buffer& buff, share_mem& mem);

int send_data(int index, buffer* pbuff, share_mem& mem, const char* data, int datalen, Block_Head &bh);

void exit();

int insert_random_code(share_mem& mem, Csem& sem, query_protocol* pro, int index);

int find_random_code(share_mem& mem, Csem& sem, int unique_id, query_protocol* pro);
//int find_random_code(share_mem& mem, Csem& sem, const char* msgbuf, query_protocol* pro);

int clear_random_code(share_mem& mem, Csem& sem, query_protocol* pro,int unique_id);

void status_check(share_mem& mem, Csem& sem);

/**
 * @brief 从recv中获取IP相关的信息
 * @param index 查反查的唯一索引
 * @param &msg 存放结果的结构
 * @return 0:成功
 */
int get_ip_info(int index, IP_MSG &msg);

/** @brief 输出稽核日志
 *  @param *msg IP信息
 *  @param *pro 协议数据包
 */
int write_log(const IP_MSG* msg, const query_protocol* pro);

/** @brief 有超时控制的读取功能
 *  @param fd 从文件符中读取
 *  @param pBuff 读到的数据存放的缓冲内存
 *  @param nSize 要读取的大小
 *  @param nTimeout 超时时间
 *  @return >0: 成功读取的数据长度
 */
int ReadTimeout(int fd, char *pBuff, int nSize, int nTimeout);
#endif
