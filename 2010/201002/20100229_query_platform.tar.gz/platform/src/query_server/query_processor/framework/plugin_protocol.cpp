/*
*date:2011-05-09
*author:lqb
*/

#include <dlfcn.h>

#include "r5api.h"
#include "plugin_protocol.h"
#include "comm_structs.h"

extern R5_Log g_r5_log;

//声明函数指针
int (*p_pro_initialize)(const char* conf_file, R5_Log *plog);

int (*p_pro_destroy)();

int (*p_protocol_proc)(const void * inmsg, const int inlen, 
        void* protocol, void* outmsg, int* outlen);

int (*p_package_msg)(const void * inmsg, const int inlen, const void* protocol, 
        void* outmsg, int* outlen);
        
int (*p_create_response)(void* protocol, void* outmsg, int* outlen);        
        
        

int init_protocol(const char* conf_file, const char* lib_file, R5_Log* plog){
    /// 加载动态库
    char *error = NULL;
    void *p_protocol = dlopen(lib_file , RTLD_LAZY);
    error=dlerror();
    if(p_protocol == NULL) 
    {
        LOG_ERROR("open library %s failed\n error:%s\n" , lib_file, error);
        return -1;
    }
    dlerror();
    
    ///加载函数
    p_pro_initialize = (int(*)(const char*, R5_Log*))::dlsym(p_protocol , "initialize");
    if ((error = dlerror()) != NULL)
    {
        ///报错
        LOG_ERROR("load p_pro_initialize fucntion failed , error %s\n", error);
        return -1;
    }
    dlerror();
    
    p_pro_destroy = (int(*)())::dlsym(p_protocol, "destroy");
    if ((error = dlerror()) != NULL)
    {
        ///报错
        LOG_ERROR("load p_pro_destroy fucntion failed , error %s\n", error);
        return -1;
    }	
    dlerror();
    
    p_protocol_proc = (int(*)(const void*, const int, void*, void*, int*))::dlsym(p_protocol, "protocol_proc");
    if ((error = dlerror()) != NULL)
    {
        ///报错
        LOG_ERROR("load p_prococol_proc fucntion failed , error %s\n", error);
        return -1;
    }	
    dlerror();   
    
    
    p_package_msg = (int(*)(const void*, const int, const void*, void*, int*))::dlsym(p_protocol, "package_msg");
    if ((error = dlerror()) != NULL)
    {
        ///报错
        LOG_ERROR("load package_msg fucntion failed , error %s\n", error);
        return -1;
    }	
    dlerror();


    p_create_response = (int(*)(void*, void*, int*))::dlsym(p_protocol, "create_response");
    if ((error = dlerror()) != NULL)
    {
        ///报错
        LOG_ERROR("load create_response fucntion failed , error %s\n", error);
        return -1;
    }	
    dlerror();
    
    ///动态库初始化
    int ret = pro_initialize(conf_file, plog);
    if(ret < 0)
    {
        LOG_ERROR("pro_initialize failed!\n");
        return -1;
    }
    
    return 0;         
}


int pro_initialize(const char* conf_file, R5_Log* plog){
    return p_pro_initialize(conf_file, plog);   
}

int pro_destory(){
    return p_pro_destroy();   
}
//协议解析
int protocol_proc(const void * inmsg, const int inlen, 
        void* protocol, void* outmsg, int* outlen){
    return p_protocol_proc(inmsg, inlen, protocol, outmsg, outlen);            
}
//组包 
int package_msg(const void * inmsg, const int inlen, const void* protocol, 
        void* outmsg, int* outlen){
    return p_package_msg(inmsg, inlen, protocol, outmsg, outlen);            
}
 //得到响应报        
int create_response(void* protocol, void* outmsg, int* outlen){
    return p_create_response(protocol, outmsg, outlen);   
}

