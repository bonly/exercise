#ifndef __PLUGIN_TRANSLATE_H__
#define __PLUGIN_TRANSLATE_H__
/*
*date:2011-05-09
*author:lqb
*/
class R5_Log;
struct translate_map;

int init_translate(const char* conf_file, const char* lib_file, R5_Log* plog);

int tran_initialize(const char* conf_file, R5_Log* plog);

int tran_destroy();

int bill_translate(const char* inmsg, int inlen, const void* protocol, void* outmsg, int* outlen);


#endif
