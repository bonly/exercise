/*


create at 24/09/07
*/

#include <string>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <iostream>

#include "type.h"
#include "ctcp.h"

using namespace std;

extern struct FDList g_fd[FD_SIZE]; 
//extern struct SysConfig g_conf;

//#ifdef _TMP_INT_TEST_
//extern struct ProcessStatus g_pstatus;
//#endif


//extern CGsp* GetGsConnection(int gsflg);

int CTcp::recv_data(int fd, buffer& buff)
{
	Con& hcon = get_con(fd);
	
	if(hcon.cbuf.is_deny == true)
	{
		discard_data(fd);
		return RE_FAILED;
	}

	if(recv(fd) < 0)
	{
		return RE_FAILED;
	}

	//const char* message;
	//int msg_len = 0;

	while(1)
	{
		int ret = process_message(fd, buff);
		if(ret == RE_FAILED)
		{
			//��Ϣͷ���ȴ���,�Ͽ�����
			set_fd_status(fd, hcon.Broken);
			return RE_FAILED;
		}
		else if(ret == 1)
		{
			//û����Ϣ����
			break;
		}

		//process_message(fd, message, msg_len);
	}
	
	return RE_SUCCESS;
}



int CTcp::get_message(int fd, buffer& buff)
{
	//size = 0;
	Con& hcon = get_con(fd);
	
    int data_size = hcon.cbuf.buffer.get_data_size();

    /* ��Ϣͷ�ĳ����ֶ�δ���� */
    if(26 > data_size)
    {
        return 1;
    }

    const char* readptr = hcon.SBuf.Buffer.get_read_ptr();
    char tmp[8] = {0};
    memcpy(tmp, readptr + 18, 8);
    int len = atoi(tmp);

    /* ��Ϣ�ĳ��Ȳ��Ϸ� */
    if(PRO_HEAD_LEN > len || len > MAX_MSG_LENGHT)
    {
        //LOG_WARN("Invalid message size %d\n", len);
        return RE_FAILED;
    }
    
     /* ���������Ѿ���һ����������Ϣ */
    if(buff.lock() < 0)
    {
        ///ǿ�ƽ����ж�
        if(1 != force_unlock(nIndex, nLockTime))
        {
            //LOG_DEBUG("read buff %d locked!\n", nIndex);
            return 2;
        }
        
        if(g_buff[nIndex].lock() < 0)
        {
            //LOG_DEBUG("read buff %d locked!\n", nIndex);
            return 2;
        }
    }
    
    buff.write(readptr, len);

    if(data_size >= len)   
    {
        message = readptr;
        size = len;
        hcon.SBuf.Buffer.set_read_size(len);  /* ���¼�����ջ�������С */
    }

    return RE_SUCCESS;
}





/*

Maybe need some chage !!!!
*/

void CTcp::ParseHead(int fd){
	
	Con& hcon = GetTcpCon(fd);

	int iLen = 0;
	short tmpShort;
	int tmpInt;

		
	memcpy(&tmpInt,hcon.SBuf.RecvBuf + iLen + sizeof(GSDataBody),sizeof(short));
	m_headFlag = ntohl(tmpInt);
		
	if(m_headFlag != 123){
		//LOg
				
		}

	iLen += sizeof(int);
	memcpy(&tmpShort,hcon.SBuf.RecvBuf + iLen + sizeof(GSDataBody),sizeof(short));
	m_ver= ntohs(tmpShort);
	if(m_ver != 1){
		//LOg
				
		}

	iLen+= sizeof(short);
	memcpy(&tmpShort,hcon.SBuf.RecvBuf + iLen + sizeof(GSDataBody),sizeof(short));
	m_gsid = ntohs(tmpShort);
	

	if(m_gsid < 0){
		//LOg
				
		}
	else
		hcon.SBuf.Gsid = m_gsid;
		
	
	iLen+= sizeof(short);
	memcpy(&tmpInt,hcon.SBuf.RecvBuf + iLen + sizeof(GSDataBody),sizeof(int));
	m_dataLen= ntohl(tmpInt);
	
	if(m_dataLen < 0 || m_dataLen > BUFSIZE){
		//LOg
				
		}
	hcon.SBuf.RecvLen = m_dataLen;

	iLen+= sizeof(int);
	hcon.SBuf.HeadLen = iLen;
	
}

bool CTcp::RecvContent(int fd)
{
	int len = 0;
	Con& hcon = GetTcpCon(fd);	

	if(hcon.SBuf.RecvPos >= hcon.SBuf.HeadLen + hcon.SBuf.RecvLen)
		return true;
	
	while(1)
	{
		//len = Recv(fd, hcon.SBuf.RecvBuf + sizeof(GSHead) + sizeof(GSDataBody)  - hcon.SBuf.HeadLen + hcon.SBuf.RecvPos, 
		//	hcon.SBuf.HeadLen + hcon.SBuf.RecvLen  - hcon.SBuf.RecvPos);		

		len = Recv(fd, hcon.SBuf.RecvBuf+hcon.SBuf.RecvPos, 
			hcon.SBuf.HeadLen + hcon.SBuf.RecvLen  - hcon.SBuf.RecvPos);	
			
		if(len <= 0)
		{
			LOG(CLog::log_dbg, "recv [fd=%d]content data error!len=%d", fd, len);
			break;
		}
		hcon.SBuf.RecvPos += len;
		
		
		if(hcon.SBuf.RecvPos >= hcon.SBuf.HeadLen + hcon.SBuf.RecvLen)
		{
			LOG(CLog::log_dbg, "recv [fd=%d]content data len=%d", fd, len);
			
			return true;
		}
		else
		{
			LOG(CLog::log_dbg, "recv [fd=%d]content data len=%d", fd, len);
		}
	}

	return false;
}

bool CTcp::RecvHead(int fd)
{
	Con& hcon = GetTcpCon(fd);
	int rlen = 0; 

	int headlen = sizeof(TcpHead);//TcpHead
	
	if(hcon.SBuf.RecvPos < headlen){
		
	rlen = Recv(fd, hcon.SBuf.RecvBuf+hcon.SBuf.RecvPos + sizeof(GSDataBody), 
		sizeof(hcon.SBuf.RecvBuf)  - hcon.SBuf.RecvPos - sizeof(GSDataBody));

	if(rlen <= 0)
		return false;
	
	hcon.SBuf.RecvPos += rlen;
	
	if(hcon.SBuf.RecvPos  < headlen)
		return false;
	
	}

	return true;
	
}


int CTcp::send_data(int fd)
{
	Con& hcon = GetTcpCon(fd);
	if(hcon.SBuf.BufStatus != hcon.SBuf.SendToUser)
		return 0;
	//for dbg

	//TcpHead * head = (TcpHead*) hcon.SBuf.SendBuf;
	//int tmpi;
	//memcpy(&tmpi,hcon.SBuf.SendBuf + 8,sizeof(int));
	//int dlen = ntohl(tmpi);
	
	//LOG(CLog::log_dbg, "before send , len=%d", dlen);
	int len = Send(fd, hcon.SBuf.SendBuf+hcon.SBuf.SendPos, 
			hcon.SBuf.SendLen-hcon.SBuf.SendPos);
	
	hcon.SBuf.SendPos += len;
	LOG(CLog::log_dbg, "send data to client, len=%d, send size=%d", 
			hcon.SBuf.SendLen, len);

	if(hcon.SBuf.SendPos == hcon.SBuf.SendLen)
	{//send ok
		hcon.SBuf.BufStatus = hcon.SBuf.BufOk;
		hcon.SBuf.SendPos = 0;
		hcon.SBuf.SendLen = 0;
		hcon.SBuf.HeadLen = 0;
		hcon.SBuf.RecvFromGsDataLen = 0;
		hcon.SBuf.RecvLen = 0;
		hcon.SBuf.RecvPos = 0;
		hcon.SBuf.SendLen = 0;
		hcon.SBuf.SendPos = 0;
		
		//if(!hcon.IsKeepAlive)
		//	FdShutDown(fd);
	}

	return 1;
}

Con& CTcp::get_con(int fd)
{
	return g_fd[fd].user_con;
}

int CTcp::recv(int fd)
{
	char* writeptr = hcon.cbuf.buffer.get_write_ptr();
    int size = hcon.cbuf.buffer.get_free_size();

	int rlen = 0;

	rlen = recv(fd, writeptr , size, 0);
	if(rlen ==0)
	{
		//�Է��Ͽ�����
		set_fd_status(fd, hcon.Broken);
		//LOG_ERROR("recv data from client len=%d \n", rlen);
		return RE_FAILED;
	}
	else if(rlen < 0)
	{
		//LOG_WARN("recv data from client len=%d \n", rlen);
		return RE_FAILED;
	}

	//* ���¼�����ջ�������С
    hcon.cbuf.buffer.set_write_size(rlen);
	

	//LOG_DEBUG("in CTcp::Recv [fd=%d]data datalen=%d\n", fd, rlen);

	if(rlen > 0)
	{
		hcon.active_time = time(NULL);
	}
	
	return ret;
}


int CTcp::Send(int fd, char* buf, int len)
{
	int ret = 0;
	if(len <= 0)
		return 0;
	
	while(1)
	{
		int slen = send(fd, buf+ret, len-ret,  0);
		if(slen < 0)
		{
			if(errno == EINTR)
				continue;
			else if(errno == EAGAIN || errno == EWOULDBLOCK)						
				break;
			else
			{
				int iErrno = errno;
				LOG(CLog::log_err, "send data error:[%d, %s]",  iErrno, strerror(iErrno));
				SetFdStatus(fd, Con::Broken);
				return 0;
			}
		}

		ret += slen;
		if(ret == len)
			break;
	}

	if(ret > 0)
		GetTcpCon(fd).ActiveTime = (int)time(NULL);
	return ret;
}


void CTcp::ResetFd(int fd)
{
	close(fd);
	Con& hcon = GetTcpCon(fd);

	g_con[fd].Type = 0;

	hcon.SBuf.Gsid = 0;
	hcon.Status = hcon.Broken;
	hcon.SBuf.BufStatus = hcon.SBuf.BufOk;
	hcon.SBuf.RecvPos = 0;
	hcon.SBuf.SendPos = 0;
	hcon.SBuf.SendLen = 0;
	hcon.SBuf.RecvLen = 0;
	hcon.SBuf.RecvFromGsDataLen = 0;
	hcon.SBuf.HeadLen = 0;
	hcon.SBuf.IsDeny = false;
	LOG(CLog::log_dbg, "reset fd by cs![%d]", fd);	
}


int CTcp::GetSessionCnt(int fd)
{
	return g_con[fd].SessionCnt;
}

void CTcp::SendErrorData(int fd, int errcode, int closetype)
{
	//MakeHead(fd, errcode, 0);
	Con& hcon = GetTcpCon(fd);
	hcon.SBuf.BufStatus = hcon.SBuf.SendToUser;
	hcon.SBuf.RecvPos = 0;
	hcon.SBuf.SendPos = 0;
	//hcon.IsKeepAlive = false;
	
	if(errcode == CS_REQ_IP_LIMIT)
		hcon.SBuf.IsDeny = true;

	LOG(CLog::log_dbg, "send error data to client![%d]", errcode);	

	SendData(fd);

	if(closetype == FD_CLOSE)
	{
		SetFdStatus(fd, Con::Broken);
	}
}


void CTcp::SetFdStatus(int fd, int status)
{
	Con& hcon = GetTcpCon(fd);
	hcon.Status = status;
}

void CTcp::DiscardData(int fd)
{
	int len = 1, rsum= 0;
	char buf[256];
	
	while(len > 0)
	{
		len = Recv(fd, buf, sizeof(buf));
		rsum += len;
		if(rsum > BUFSIZE)
		{
			SetFdStatus(fd, Con::Broken);
			break;
		}
	}
}

void CTcp::InitFd(int fd)
{
	Con& hcon = GetTcpCon(fd);
	hcon.SBuf.BufStatus = hcon.SBuf.BufOk;
	hcon.SBuf.Gsid = 0;
	hcon.SBuf.SendPos = 0;
	hcon.SBuf.SendLen = 0;
	hcon.SBuf.HeadLen = 0;
	hcon.SBuf.RecvFromGsDataLen = 0;
	hcon.SBuf.RecvLen = 0;
	hcon.SBuf.RecvPos = 0;
	hcon.SBuf.SendLen = 0;
	hcon.SBuf.SendPos = 0;
	hcon.SBuf.IsDeny = false;
}

