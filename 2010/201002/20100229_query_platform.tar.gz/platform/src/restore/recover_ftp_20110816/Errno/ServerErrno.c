#include "ServerErrno.h"

const char* srv_strerror(int error)
{
	if (error == 0)
	{
		return "OK";
	}
	if (error > 0) 
	{/*
        char* p = NULL;
		if ((p = strerror(error)) != NULL)
			return (p);����*/
		return "Unknown OS errno";
	}
	else
	{
		if ((error + SRV_ERROR_BASE - 1 < SRV_ERR_COUNT) 
			&& (error + SRV_ERROR_BASE - 1 >= 0))
			return errinfos[error + SRV_ERROR_BASE - 1].desc;
		else
			return "Unknown ServerDaemon errno";
	}
}
