#include "LogCallback.h"

#include "GlobalDefines.h"
#include <iostream>
using namespace std;

#define LOG_PREFIX          "serverlog."
#define SERVER_LOG_SIZE     1024000       // ServerDaemon��־�ļ���С
    
extern "C" 
{
    static int log_selector (const ACE_DIRENT *d)
    {
        return ACE_OS::strncmp (d->d_name, LOG_PREFIX, 10) == 0;
    }

    static int log_comparator (const ACE_DIRENT **d1, const ACE_DIRENT **d2)
    {
    	long a = ACE_OS::strtol ((*d1)->d_name + 10, 0, 10);
			long b = ACE_OS::strtol ((*d2)->d_name + 10, 0, 10);
        return a-b;
    }
}

LogCallback::LogCallback ()
{
}

LogCallback::~LogCallback ()
{
    ACE_OS::fclose (m_pLogFile);
}

void LogCallback::log (ACE_Log_Record& record)
{
	while (GetFileSize () > m_lMaxSize)
	{
		ACE_OS::fclose (m_pLogFile);
        char temp[1024];
    	ACE_OS::sprintf (temp, "%s/serverlog.%d", m_strPath.c_str (), ++m_iFileNo);
		m_pLogFile = ACE_OS::fopen (temp, "a+");
	}
    record.print (ACE_TEXT("SERVER : "), 0, m_pLogFile);
}

int LogCallback::Init (long maxsize, const char* path)
{
	ACE_Dirent_Selector dir_selector;
    if (dir_selector.open (path, log_selector, log_comparator) == -1)
        return -1;
	
	int number = dir_selector.length ();
	if (number == 0) 
	{
		char temp[1024];
    	ACE_OS::sprintf (temp, "%s/serverlog.%d", path, number+1);
    	m_pLogFile = ACE_OS::fopen (temp, "a+");
	}
	else
	{
		ACE_CString strLogFile = path;
		strLogFile += "/";
		strLogFile += dir_selector[number-1]->d_name;
		m_pLogFile = ACE_OS::fopen (strLogFile.c_str (), "a+");
	}
	if (!m_pLogFile)
		return -1;
	m_strPath  = path;
	m_lMaxSize = maxsize;
    m_iFileNo  = number;
	dir_selector.close ();
	return 0;
}

long LogCallback::GetFileSize ()
{
	if (ACE_OS::fseek (m_pLogFile, 0, SEEK_END) == -1)
		return -1;
	
	return ACE_OS::ftell (m_pLogFile);
}


