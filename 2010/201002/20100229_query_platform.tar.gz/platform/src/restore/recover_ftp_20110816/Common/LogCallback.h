#ifndef LOG_CALLBACK_H__
#define LOG_CALLBACK_H__

#include "GlobalDefines.h"
#include <iostream>
using namespace std;

#define LOG_PREFIX          "serverlog."
#define SERVER_LOG_SIZE     1024000       // ServerDaemon��־�ļ���С

class LogCallback : public ACE_Log_Msg_Callback
{
public:
    LogCallback ();
    ~LogCallback ();
    void log (ACE_Log_Record&);
	int	 Init (long, const char*);
private:
	long GetFileSize ();
private:
   	FILE*		m_pLogFile;
	ACE_CString	m_strPath;
	long		m_lMaxSize;
    int         m_iFileNo;
};

#endif //LOG_CALLBACK_H__

