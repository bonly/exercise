#ifndef PIDFILE_H__
#define PIDFILE_H__

#include "GlobalDefines.h"

// PID�ļ�ǰ׺�����ȶ���
#define PREFIX                  "pid."
#define PREFIX_LEN              4

extern "C" 
{
    static int selector (const ACE_DIRENT *d)
    {
        return ACE_OS::strncmp (d->d_name, PREFIX, PREFIX_LEN) == 0;
    }

    static int comparator (const ACE_DIRENT **d1, const ACE_DIRENT **d2)
    {
        return alphasort (d1, d2);
        //return ACE_OS::alphasort (d1, d2);
    }
}

class PidFile
{
public:
    PidFile ();
    ~PidFile ();
    int TouchPidFile (const char*, long);
    int CreatePidFile (const char*, long);
    int RemovePidFile (const char*, long);
private:
    PidFile (PidFile&);
    PidFile operator= (PidFile&);
};

#endif //PIDFILE_H__
