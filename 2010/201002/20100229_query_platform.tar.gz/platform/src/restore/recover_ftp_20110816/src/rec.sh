./recover -e /cdr2/home/lx/file_space/ENVBDB/backup -r /cdr2/home/lx/file_space/ENVBDB/test -t 10 -d 0 -p /cdr2/home/lx/file_space/ENVBDB/backup -s 1024000 &
