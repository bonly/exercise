#ifndef __LIBFTP_H__
#define __LIBFTP_H__

#include <sys/cdefs.h>	/* get __P definition (prototypes) */
#include <stdio.h>
#include <netdb.h>

#include <string.h>

#define	BINARY	1
#define ASCII	2
#define TENEX	3
#define EBCDIC	4

#ifndef	__CONST
	#define __CONST const		/* �Զ���__CONST */
#endif

typedef struct {
	long	size_bytes;		/* total bytes transferred */
	float	seconds;		/* time taken to transfer */
	float	kbs;			/* kilobytes per second */
} SPEED;


typedef struct {
	FILE	*filedes;		/* data file descriptor */
	char	transf_type;		/* type of transfer (bin/ascii) */
	char	*ftp_msg; 		/* error status of function or reply 
					   			string from server */
	int	transf_calc;		/* flag to turn on xfer rate calc */ 
	SPEED	speed;			/* xfer rate information */
	int	sockfd;			/* CNTRL connection socket id */
	int	datasd;			/* DATA connection socket id */
	int	reply;			/* return value of function or reply
					   code from server */
	int	debug;			/* flag to turn on debugging */
	int	linger;			/* flag to turn on socket linger opt */
	int	connected;		/* flag to indicate the existance of 
					   a control connection for the 
					   session under question */
	struct	servent	*ftp_sp;	/* specific service entry */
} FTPINFO;

/*
Description of data base entry for a single service. 
struct servent
{
  char *s_name;			 Official service name.  
  char **s_aliases;		 Alias list.  
  int s_port;			 Port number.  
  char *s_proto;		 Protocol to use.  
};
*/

//int ftp_accnt __P((FTPINFO *, __CONST char *));//d end
//int ftp_ascii __P((FTPINFO *));//d end
//int ftp_binary __P((FTPINFO *));//d end
//int ftp_bye __P((FTPINFO *));//d end
//int ftp_chdir __P((FTPINFO *, __CONST char *));//d end
//int ftp_command __P((FTPINFO *, __CONST char *, __CONST char *)); //d end
//int ftp_dataconn __P((FTPINFO *, __CONST char *, __CONST char *, __CONST char *));
//int ftp_del __P((FTPINFO *, __CONST char *));//d end
//int ftp_dir __P((FTPINFO *, __CONST char *, __CONST char *));//d end
//int ftp_ebcdic __P((FTPINFO *));
//int ftp_getfile __P((FTPINFO *, __CONST char *, __CONST char *));
//int ftp_idle __P((FTPINFO *, __CONST char *));
//int ftp_initconn __P((FTPINFO *));
//int ftp_login __P((FTPINFO *, __CONST char *, __CONST char *, __CONST char *, __CONST char *));//d end
//int ftp_mkdir __P((FTPINFO *, __CONST char *));//d end
//int ftp_passwd __P((FTPINFO *, __CONST char *));//d end
//int ftp_setport __P(( in_port_t ));//d end
//int ftp_prconnect __P((FTPINFO *, __CONST char *));//d end
//int ftp_putfile __P((FTPINFO *, __CONST char *, __CONST char *));//d end
//int ftp_appfile __P((FTPINFO *, __CONST char *, __CONST char *));
//int ftp_pwd __P((FTPINFO *));//d end
//int ftp_rmdir __P((FTPINFO *, __CONST char *));//d end
//int ftp_settype __P((FTPINFO *, int));//d end
//int ftp_site __P((FTPINFO *, __CONST char *));//d end
//int ftp_tenex __P((FTPINFO *));
//int ftp_user __P((FTPINFO *, __CONST char *));//d end

int ftp_accnt(FTPINFO *, __CONST char *);//d end
int ftp_ascii(FTPINFO *);//d end
int ftp_binary(FTPINFO *);//d end
int ftp_bye(FTPINFO *);//d end
int ftp_chdir(FTPINFO *, __CONST char *);//d end
int ftp_command(FTPINFO *, __CONST char *, __CONST char *); //d end
int ftp_dataconn(FTPINFO *, __CONST char *, __CONST char *, __CONST char *);
int ftp_del(FTPINFO *, __CONST char *);//d end
int ftp_dir(FTPINFO *, __CONST char *, __CONST char *);//d end
int ftp_ebcdic(FTPINFO *);
int ftp_getfile(FTPINFO *, __CONST char *, __CONST char *);
int ftp_idle(FTPINFO *, __CONST char *);
int ftp_initconn(FTPINFO *);
int ftp_login(FTPINFO *, __CONST char *, __CONST char *, __CONST char *, __CONST char *);//d end
int ftp_mkdir(FTPINFO *, __CONST char *);//d end
int ftp_passwd(FTPINFO *, __CONST char *);//d end
int ftp_setport( in_port_t );//d end
int ftp_prconnect(FTPINFO *, __CONST char *);//d end
int ftp_putfile(FTPINFO *, __CONST char *, __CONST char *);//d end
int ftp_appfile(FTPINFO *, __CONST char *, __CONST char *);
int ftp_pwd(FTPINFO *);//d end
int ftp_rmdir(FTPINFO *, __CONST char *);//d end
int ftp_settype(FTPINFO *, int);//d end
int ftp_site(FTPINFO *, __CONST char *);//d end
int ftp_tenex(FTPINFO *);
int ftp_user(FTPINFO *, __CONST char *);//d end

int ftp_renfile(FTPINFO *, __CONST char *, __CONST char *);//d end

//int ftp_isfileexist(FTPINFO *, __CONST char *); //d end


int ftp_isfileexist(FTPINFO *ftp_info, __CONST char *rem_path,
				__CONST char *file_name);

#endif
