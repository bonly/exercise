#ifndef _FILEOP_H_
#define _FILEOP_H_

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int ReadFile(int, char *, size_t, size_t *);
int WriteFile(int, char *, size_t, size_t *);
int OpenFile(const char *,int, int, int *,u_int32_t);
int CloseFile(int, u_int32_t);
int CopyFile(const char *, const char *, u_int32_t);
#endif
