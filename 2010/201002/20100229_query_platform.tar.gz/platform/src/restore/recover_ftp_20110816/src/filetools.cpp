#include "filetools.h"
#include <dirent.h> 
#include <errno.h> 
#include <stdio.h> 
#include <string.h> 

int remove_files(const char *dir, const char* headprefix, const char* tmpprefix)
{ 
	DIR   *dirp; 
	struct   dirent   *dp; 
	
	if   ((dirp   =   opendir( ". "))   ==   NULL)   { 
		perror( "couldn 't   open   '. ' ");
		return; 
	} 

	do { 
		errno = 0; 
		if ((dp = readdir(dir)) != NULL)   
		{
			if(strrch(dp->d_name, tmpprefix) == dp->d_name + strlen(dp->d_name) - strlen(tmpprefix))
				unlink(filename);
//			if(strcmp(dp->d_name, dir)   !=   0)
//				unlink(filename);
			else
				continue; 
		} 
	}while(dp != NULL);

	if   (errno != 0) 
		return -1;
		
	closedir(dirp);	
	
	return 0; 
} 

