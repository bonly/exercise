#include "libftp.h"
#include "ftpbase.h"
#include "tcpbase.h"

#define	READLINE		256

#define ON              1
#define OFF             0


int ftp_getfile(FTPINFO *ftp_info, __CONST char *rem_path,
					__CONST char *local_path)
{
	FILE	*fp_out;
	int		len;
	char	buffer[MAXLINE];
	char	file[MAXLINE], path[MAXLINE];
	int		i, n, size;
	char	*buf;
	
	if (rem_path == NULL)
	{
		message_print("Must specify a file name to get");
		return -1;
	}
	if (!(ftp_info->transf_type == BINARY || ftp_info->transf_type == ASCII))
	{
		if (ftp_binary(ftp_info) < 0)
		return -1;
	}
	if (ftp_get_data_sock(ftp_info) < 0)
		return -1;
	i = 0;
	memset(file, 0, sizeof(file));
	for (n = 0; n < strlen(rem_path); n++)
	{
		file[i++] = rem_path[n];
		if (rem_path[n] == '/')
		{
			memset(file, 0, sizeof(file));
			i = 0;
		}
	}
	if (local_path == NULL)
		strcpy(path, file);
	else
		strcpy(path, local_path);
	fp_out = fopen(path, "w");
	if (fp_out == NULL)
		fp_out = stdout;
	if (ftp_command(ftp_info, rem_path, "retr") < 0)
	{
		message_print("ftp command stor error!");
		return -1;
	}
	if (ftp_check_response(ftp_info, '1') < 0)
	{
		message_print("ftp command stor response error!");
		close(ftp_info->datasd);
		return -1;
	}
	if ((buf = strchr(ftp_info->ftp_msg, '(')))
	{
		buf++;
		size = atoi(buf);
	}
	if (ftp_info->transf_type == ASCII)
	{
		while ((len = tcp_read_line(ftp_info->datasd, buffer, MAXLINE - 1)) > 0)
		{
			debug_print("Line: %s", buffer);
			if (strcmp(&buffer[len - 2], "\r\n") == 0)
			{
				len -= 2;
				buffer[len++] = '\n';
				buffer[len] = '\0';
			}	
			if (fwrite(buffer, 1, len, fp_out) == -1)
			{
				perror("write");
				break;
			}
		}
	} else
		while ((len = tcp_readn(ftp_info->datasd, buffer, MAXLINE)) != 0)
		{
			if (fwrite(buffer, 1, len, fp_out) == -1)
			{
				perror("write");
				break;
			}
		}
	fclose(fp_out);
	if (close(ftp_info->datasd) == -1)
		perror("close");

	return (ftp_check_response(ftp_info, '2'));
}

int ftp_renfile(FTPINFO *ftp_info, __CONST char *old_path,
					__CONST char *new_path)
{
	if (ftp_command(ftp_info, old_path, "rnfr") < 0)
	{
		message_print("ftp command cwd error!");
		return -1;
	}
	
	if (ftp_command(ftp_info, new_path, "rnto") < 0)
	{
		message_print("ftp command cwd error!");
		return -1;
	}
	
	return (ftp_check_response(ftp_info, '3'));	
}

int ftp_putfile(FTPINFO *ftp_info, __CONST char *rem_path,
					__CONST char *local_path)
{
	FILE	*fp_in;
	int		len;
	char	buffer[MAXLINE];
	char	file[MAXLINE], path[MAXLINE];
	int		i, n;
	
	if (local_path == NULL)
	{
		message_print("Must specify a file name to send");
		return -1;
	}

	if (!(ftp_info->transf_type == BINARY || ftp_info->transf_type == ASCII))
	{
		if (ftp_binary(ftp_info) < 0)
		return -1;
	}
	fp_in = fopen(local_path, "r");
	if (fp_in == NULL)
	{
		perror(local_path);
		return -1;
	}
	if (ftp_get_data_sock(ftp_info) < 0)
		return -1;
	i = 0;
	memset(file, 0, sizeof(file));
	for (n = 0; n < strlen(local_path); n++)
	{
		file[i++] = local_path[n];
		if (local_path[n] == '/')
		{
			memset(file, 0, sizeof(file));
			i = 0;
		}
	}
	if (rem_path == NULL)
		strcpy(path, file);
	else
		strcpy(path, rem_path);
		
	if (ftp_command(ftp_info, path, "stor") < 0)
	{
		message_print("ftp command stor error!");
		return -1;
	}
	if (ftp_check_response(ftp_info, '1') < 0)
	{
		message_print("ftp command stor response error!");
		close(ftp_info->datasd);
		return -1;
	}
	if (ftp_info->transf_type == ASCII)
	{
		while ((len = file_read_line(fp_in, buffer, MAXLINE - 1)) > 0)
		{
			//debug_print("Line: %s", buffer);
			if (buffer[len-1] == '\n')
			{
				buffer[len-1] = '\r';
				buffer[len++] = '\n';
				buffer[len] = '\0';
			}
			if (tcp_write(ftp_info->datasd, buffer, len) == -1)
			{
				perror("write");
				break;
			}
		}
	} else
		while ((len = fread(buffer, 1, MAXLINE, fp_in)) != 0)
		{
			if (tcp_write(ftp_info->datasd, buffer, len) == -1)
			{
				perror("write");
				break;
			}
		}
	fclose(fp_in);
	if (close(ftp_info->datasd) == -1)
		perror("close");

	return (ftp_check_response(ftp_info, '2'));
}

int ftp_dir(FTPINFO *ftp_info, __CONST char *rem_path,
				__CONST char *local_path)
{
	FILE	*fp_out;
	char	buffer[MAXLINE];
	int		len;
	
	assert(rem_path != NULL);
	
	if (ftp_info->transf_type == BINARY)
		if (ftp_ascii(ftp_info) < 0)
			return -1;
	if (ftp_get_data_sock(ftp_info) < 0)
		return -1;
	if (ftp_command(ftp_info, rem_path, "list") < 0)
	{
		message_print("ftp command list error!");
		return -1;
	}
	if (ftp_check_response(ftp_info, '1') < 0)
	{
		message_print("ftp command list error!");
		close(ftp_info->datasd);
		return -1;
	}
	if (local_path == NULL)
		fp_out = stdout;
	else
	{
		fp_out = fopen(local_path, "w");
		if (fp_out == NULL)
		{
			perror(local_path);
			fp_out = stdout;
		}
	}
	while ((len = tcp_readn(ftp_info->datasd, buffer, MAXLINE)) > 0)
		fwrite(buffer, 1, len, fp_out);
	if (local_path != NULL)
		fclose(fp_out);
	close(ftp_info->datasd);
	
	return (ftp_check_response(ftp_info, '2'));
}

int ftp_site(FTPINFO *ftp_info, __CONST char *cmd)
{
	if (ftp_command(ftp_info, cmd, "site") < 0)
	{
		message_print("ftp command site error!");
		return -1;
	}
	return (ftp_check_response(ftp_info, '2'));
}

int ftp_mkdir(FTPINFO *ftp_info, __CONST char *path)
{
	if (ftp_command(ftp_info, path, "mkd") < 0)
	{
		message_print("ftp command cwd error!");
		return -1;
	}
	return (ftp_check_response(ftp_info, '2'));
}

int ftp_settype(FTPINFO *ftp_info, int type)
{
	if (ASCII == type)
		return (ftp_ascii(ftp_info));
	if (BINARY == type)
		return (ftp_binary(ftp_info));

	message_print("Type should be one of ASCII or BINARY.");
	return -1;
}

int ftp_rmdir(FTPINFO *ftp_info, __CONST char *path)
{
	if (ftp_command(ftp_info, path, "rmd") < 0)
	{
		message_print("ftp command cwd error!");
		return -1;
	}
	return (ftp_check_response(ftp_info, '2'));
}

int ftp_pwd(FTPINFO *ftp_info)
{
	if (ftp_command(ftp_info, "", "pwd") < 0)
	{
		message_print("ftp command quit error!");
		return -1;
	}
	return (ftp_check_response(ftp_info, '2'));
}

int ftp_del(FTPINFO *ftp_info, __CONST char *file)
{
	if (ftp_command(ftp_info, file, "dele") < 0)
	{
		message_print("ftp command cwd error!");
		return -1;
	}
	return (ftp_check_response(ftp_info,  '2'));
}

int ftp_chdir(FTPINFO *ftp_info, __CONST char *rempath)
{
	if (ftp_command(ftp_info, rempath, "cwd") < 0)
	{
		message_print("ftp command cwd error!");
		return -1;
	}
	return (ftp_check_response(ftp_info,  '2'));
}

int ftp_ascii(FTPINFO *ftp_info)
{
	if (ftp_command(ftp_info, "a", "type") < 0)
	{
		message_print("ftp command type a error!");
		return -1;
	}
	if (ftp_check_response(ftp_info,  '2') < 0)
	{
		message_print("read ftp command type a response error!");
		return -1;
	}
	ftp_info->transf_type = ASCII;
	
	return 1;
}

int ftp_binary(FTPINFO *ftp_info)
{
	if (ftp_command(ftp_info, "i", "type") < 0)
	{
		message_print("ftp command type i error!");
		return -1;
	}
	if (ftp_check_response(ftp_info,  '2') < 0)
	{
		message_print("read ftp command type i response error!");
		return -1;
	}
	ftp_info->transf_type = BINARY;
	
	return 1;
}

int ftp_bye(FTPINFO *ftp_info)
{
	if (ftp_command(ftp_info, "", "quit") < 0)
	{
		message_print("ftp command quit error!");
		return -1;
	}
	return (ftp_check_response(ftp_info,  '2'));
}

int ftp_accnt(FTPINFO *ftp_info, __CONST char *account)
{
	return 1;
}

int ftp_login(FTPINFO *ftp_info, __CONST char *remhost,
				__CONST char *user, __CONST char *passwd, __CONST char *account)
{
	if (ftp_prconnect(ftp_info, remhost) < 0)
		return -1;
	if (ftp_user(ftp_info, user) < 0)
		return -1;
	if (ftp_passwd(ftp_info, passwd) < 0)
		return -1;
		
	return (ftp_accnt(ftp_info, account));
}

int ftp_passwd(FTPINFO *ftp_info, __CONST char *passwd)
{	
	if (ftp_command(ftp_info, passwd, "pass") < 0)
	{
		message_print("ftp command user error!");
		return -1;
	}
	return (ftp_check_response(ftp_info,  '2'));
}

int ftp_user(FTPINFO *ftp_info, __CONST char *user)
{	
	if (ftp_command(ftp_info, user, "user") < 0)
	{
		message_print("ftp command user error!");
		return -1;
	}
	return (ftp_check_response(ftp_info,  '3'));
}

int ftp_command(FTPINFO *ftp_info, __CONST char *opt_info,
				 __CONST char *action)
{
	char	command[256];
	
	assert(action != NULL);
	assert(opt_info != NULL);
	
	if(ftp_info->connected != 1)
	{	
		message_print("The server is not connected");
		return -1;
	}
	
	memset(command, 0, sizeof(command));
	if (strlen(opt_info) == 0)
		sprintf(command, "%s\r\n", action);
	else
		sprintf(command, "%s %s\r\n", action, opt_info);

	debug_print("Send command: %s", command);
	if (tcp_write(ftp_info->sockfd, command, strlen(command)) < 0)
	{
		message_print("tcp_write command error!");
		return -1;
	}
	
	return 1;
}

int ftp_prconnect(FTPINFO *ftp_info, __CONST char *host)
{

	ftp_info->connected = 1;
	
	debug_print("Start to connect server: %s", host);
	
	if (tcp_connect_server(&(ftp_info->sockfd), (char *)host, ftp_port) < 0)
	{
		message_print("Can't connect to server!");
		return -1;
	}
	ftp_info->connected = 1;
	ftp_info->ftp_msg = ftp_message;
	
	if (ftp_check_response(ftp_info,  '2') < 0)
	{
		close(ftp_info->connected);
		return -1;
	}
	
	debug_print("Connect Success!\n");
	
	return 1;
}


int ftp_setport(in_port_t port)
{
	struct servent *se;
	
	if (port == 0)
	{
		if ((se = getservbyname("ftp", "tcp")) == NULL)
		{
			perror("getservbyname");
			return -1;
		}
		ftp_port = htons(se->s_port);
	} else
		ftp_port = port;
	
	return 1;	
}

int ftp_isfileexist(FTPINFO *ftp_info, __CONST char *rem_path,
				__CONST char *file_name)
{
	FILE	*fp_out;
	char	buffer[MAXLINE];
	int		len;
	
	assert(rem_path != NULL);
	
	if (ftp_info->transf_type == BINARY)
		if (ftp_ascii(ftp_info) < 0)
			return -1;
	if (ftp_get_data_sock(ftp_info) < 0)
		return -1;
	if (ftp_command(ftp_info, rem_path, "list") < 0)
	{
		message_print("ftp command list error!");
		return -1;
	}
	if (ftp_check_response(ftp_info, '1') < 0)
	{
		message_print("ftp command list error!");
		close(ftp_info->datasd);
		return -1;
	}
	if (file_name == NULL)
		return -1;

	while ((len = tcp_readn(ftp_info->datasd, buffer, MAXLINE)) > 0)
	{
		printf("%s\n", buffer);
		break;
	}
	close(ftp_info->datasd);
	
	return (ftp_check_response(ftp_info, '2'));
}
