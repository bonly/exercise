#ifndef __TCPBASE_H__
#define __TCPBASE_H__

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/types.h>	/* basic system data types */
#include <sys/socket.h>	/* basic socket definitions */
#include <sys/time.h>	/* timeval{} for select() */
#include <time.h>		/* timespec{} for pselect() */
#include <netinet/in.h>	/* sockaddr_in{} and other Internet defns */
#include <arpa/inet.h>	/* inet(3) functions */
#include <errno.h>
#include <fcntl.h>		/* for nonblocking */
#include <netdb.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>	/* for S_xxx file mode constants */
#include <sys/uio.h>		/* for iovec{} and readv/writev */
#include <unistd.h>
#include <sys/wait.h>
#include <sys/un.h>		/* for Unix domain sockets */

#ifdef	HAVE_SYS_SELECT_H
	#include <sys/select.h>	/* for convenience */
#endif

#ifdef	HAVE_POLL_H
	#include <poll.h>		/* for convenience */
#endif

#ifdef	HAVE_STRINGS_H
	#include <strings.h>		/* for convenience */
#endif

/* Three headers are normally needed for socket/file ioctl's:
 * <sys/ioctl.h>, <sys/filio.h>, and <sys/sockio.h>.
 */
#ifdef	HAVE_SYS_IOCTL_H
	#include <sys/ioctl.h>
#endif
#ifdef	HAVE_SYS_FILIO_H
	#include <sys/filio.h>
#endif
#ifdef	HAVE_SYS_SOCKIO_H
	#include <sys/sockio.h>
#endif

#ifdef	HAVE_PTHREAD_H
	#include <pthread.h>
#endif

#define MAXLINE			256

extern in_port_t	ftp_port;
extern int tcp_timeout;

int tcp_connect_server(int *, char *, int);
void debug_print(const char *, ...);
void message_print(const char *, ...);
void signal_alarm(int);
ssize_t tcp_read_line(int, void *, size_t);
ssize_t tcp_read(int, char *);
ssize_t	tcp_write(int, const void *, size_t);
ssize_t	tcp_readn(int, void *, size_t);
ssize_t file_read_line(FILE *, char *, int);

#endif
