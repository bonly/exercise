#include "transfile.h"

TransFile::TransFile(const char* ip, const char* username, const char* password)
{
	m_strIP = ip;
	m_strUser = username;
	m_strpswd = password;
}

int TransFile::login()
{
	ftpinfo.debug = OFF;
	ftpinfo.transf_calc = ON;
	ftpinfo.linger = OFF;
	
  ftp_setport(0);

  if (ftp_login ( &ftpinfo, m_strIP.c_str(), m_strUser.c_str(), m_strpswd.c_str(), NULL ) < 0) 
  {
    printf("ftp_login failed.\n");
    return -1;
  }
  
  if (ftp_settype ( &ftpinfo, BINARY ) < 0) 
  {
    printf("ftp_settype failed in BINARY mode.\n");
    return -1;    
  }

  return 0;
}

int TransFile::logout()
{
  if (ftp_bye( &ftpinfo ) < 0) 
  {
    printf("ftp_bye failed.\n");
    return -1;
  }	
  
  return 0;
}

int TransFile::safeSendFile(const char* sourcefile, const char* targetfile, const char* tmpprefix)
{
  string tmpname = (char*)targetfile;
  tmpname += tmpprefix;
  
  if (ftp_putfile ( &ftpinfo, tmpname.c_str(), sourcefile) < 0)     //���͵�Զ��Ŀ¼ʱ���ļ����ӡ�_tmp����׺
  {
    printf("ftp_putfile %s failed.\n", sourcefile);
    return -1;   
  }
  else 
  {
  	printf("sended file: %s\n", sourcefile);                                             
  }

  if(ftp_renfile ( &ftpinfo, tmpname.c_str(), targetfile) < 0)  //�����ļ���Ϻ󣬽���׺��-tmp��ȥ��
  {
    printf("rename %s.\n", tmpname.c_str());
    return -1;
  }
  else
  {
  	printf("ftp_rename %s <TO> %s\n", tmpname.c_str(), targetfile);
  }

  return 0;
}

int TransFile::completeRecv(const char* sourcefile, const char* targetfile, const char* tmpprefix)
{
  FTPINFO ftpinfo;
  char *progname;
  const char *host;

  ftpinfo.debug = OFF;
  ftpinfo.transf_calc = ON;
  ftpinfo.linger = OFF;

  ftp_setport(0);

  if (ftp_login ( &ftpinfo, m_strIP.c_str(), m_strUser.c_str(), m_strpswd.c_str(), NULL ) < 0) 
  {
    //ACE_ERROR_RETURN((_ERROR ACE_TEXT("ftp_login failed.\n")), -1);
    return -1;
  }

  if (ftp_settype ( &ftpinfo, BINARY ) < 0)
  {
    //ACE_ERROR_RETURN((_ERROR ACE_TEXT("ftp_settype failed in ascii mode.\n")), -1);
    return -1;
  }
 
  string tmpname1 = (char*)targetfile;
  
	if(access(tmpname1.c_str(), F_OK) == 0) //�ļ�������ֱ���˳���˵������ȷ���ļ�������ִ�п���
		return 0;
	
	
  string tmpname2 = tmpname1;
  tmpname1 += tmpprefix;  //��ʱ�ļ�����
  
  if(access(tmpname1.c_str(), F_OK) == 0 &&  unlink(tmpname1.c_str()) !=0)//�����ʱ�ļ�������ʱ�ļ����ڣ���ɾ��	
  	return -1;
  
  if (ftp_getfile ( &ftpinfo, sourcefile, tmpname1.c_str()) < 0)     //���͵�Զ��Ŀ¼ʱ���ļ����ӡ�_tmp����׺
  {
    printf("ftp_putfile %s failed.\n", tmpname1.c_str());
    return -1;   
  }
  
	if   (rename(tmpname1.c_str(),   tmpname2.c_str()) != 0)   
		return -1; 

//  if(ftp_renfile ( &ftpinfo, tmpname1.c_str(), tmpname2.c_str()) < 0)  //�����ļ���Ϻ󣬽���׺��-tmp��ȥ��
//  {
//        printf("ftp_rename failed: %s <TO> %s\n", tmpname2.c_str(), tmpname1.c_str());
//    return -1;
//  }
//  else
//  {
//		printf("ftp_rename : %s <TO> %s\n", tmpname1.c_str(), tmpname2.c_str());
//  }
  if (ftp_bye( &ftpinfo ) < 0) 
  {
    return -1;
  }
 
  return 0;
}

int TransFile::completeSend(const char* sourcefile, const char* targetfile, const char* tmpprefix)
{
  FTPINFO ftpinfo;
  char *progname;
  const char *host;

  ftpinfo.debug = OFF;
  ftpinfo.transf_calc = ON;
  ftpinfo.linger = OFF;

  ftp_setport(0);

  if (ftp_login ( &ftpinfo, m_strIP.c_str(), m_strUser.c_str(), m_strpswd.c_str(), NULL ) < 0) 
  {
    //ACE_ERROR_RETURN((_ERROR ACE_TEXT("ftp_login failed.\n")), -1);
    return -1;
  }

  if (ftp_settype ( &ftpinfo, BINARY ) < 0)
  {
    //ACE_ERROR_RETURN((_ERROR ACE_TEXT("ftp_settype failed in ascii mode.\n")), -1);
    return -1;
  }
 
  string tmpname1 = (char*)targetfile;
  string tmpname2 = tmpname1;
  tmpname1 += tmpprefix;
  
  if (ftp_putfile ( &ftpinfo, tmpname1.c_str(), sourcefile) < 0)     //���͵�Զ��Ŀ¼ʱ���ļ����ӡ�_tmp����׺
  {
    printf("ftp_putfile %s failed.\n", tmpname1.c_str());
    return -1;   
  }
  
  if(ftp_renfile ( &ftpinfo, tmpname1.c_str(), tmpname2.c_str()) < 0)  //�����ļ���Ϻ󣬽���׺��-tmp��ȥ��
  {
        printf("ftp_rename failed: %s <TO> %s\n", tmpname2.c_str(), tmpname1.c_str());
    return -1;
  }
  else
  {
		printf("ftp_rename : %s <TO> %s\n", tmpname1.c_str(), tmpname2.c_str());
  }
  if (ftp_bye( &ftpinfo ) < 0) 
  {
    return -1;
  }
 
  return 0;
}
