#ifndef __TRANSFILE_H
#define __TRANSFILE_H

#include "libftp.h"
#include <iostream>
using namespace std;

#define NORMAL          	0
#define ABNORMAL        	1
#define ON              	1
#define OFF             	0
#define ALTPORT         	190

#define TMPPREFIX "_restore"

class TransFile
{
public:
	TransFile(const char* ip, const char* username, const char* password);
	int login();
	int logout();
	int sendFile(const char* sourcefile, const char *targetfile);
	int safeSendFile(const char* sourcefile, const char* targetfile, const char* tmpprefix = TMPPREFIX);
	int completeSend(const char* sourcefile, const char* targetfile, const char* tmpprefix = TMPPREFIX);
	int completeRecv(const char* sourcefile, const char* targetfile, const char* tmpprefix = TMPPREFIX);
private:
	FTPINFO ftpinfo;
	string m_strIP;
	string m_strUser;
	string m_strpswd;
};

#endif
