#include "ftpbase.h"
#include "tcpbase.h"

char	ftp_message[FTP_MESSAGE_LEN];

int ftp_get_data_sock(FTPINFO *ftp_info)
{
	char	data_host[256];
	int		data_port;
	
	if (ftp_pasv(ftp_info, data_host, &data_port) < 0)
	{
		message_print("ftp pasv error!");
		return -1;
	}
	debug_print("Host: %s; Port: %d", data_host, data_port);
	
	if (tcp_connect_server(&(ftp_info->datasd), (char *)data_host,
							data_port) < 0)
	{
		message_print("Can't connect to data server!");
		return -1;
	}
	
	return 1;
}

int ftp_pasv(FTPINFO *ftp_info, char *dhost, int *dport)
{
	char	buffer[MAXLINE];
	unsigned char	*p;
	unsigned char addr[6];
	int		i;
	
	assert(dhost != NULL);
	
	if (ftp_command(ftp_info, "", "pasv") < 0)
	{
		message_print("ftp command pasv error!");
		return -1;
	}
	if (ftp_check_response(ftp_info, '2') < 0)
	{
		message_print("check ftp command pasv response error!");
		return -1;
	}
	strcpy(buffer, ftp_info->ftp_msg);
	p = (unsigned char *)buffer;
	for (p += 4; *p && !isdigit(*p); p++);
    	if (!*p)
			return -1;
	for (i = 0; i < 6; i++)
    {
		addr[i] = 0;
		for (; isdigit(*p); p++)
		    addr[i] = (*p - '0') + 10 * addr[i];
		if (*p == ',')
		    p++;
		else if (i < 5)
			{
		    	return -1;
			}
    }
    
	sprintf(dhost, "%d.%d.%d.%d", addr[0], addr[1], addr[2], addr[3]);
	*dport = (addr[4] << 8) + addr[5];
	    
	return 1;
}

void ftp_set_timeout(FTPINFO *ftp_info, int sec)
{
	tcp_timeout = sec;
	return;
}

int ftp_read_response(FTPINFO *ftp_info)
{
	char match[5];

	if (tcp_read_line(ftp_info->sockfd, ftp_info->ftp_msg, MAXLINE) == -1)
	{
		message_print("Control socket read failed");
		return -1;
	}
	
	if (ftp_info->debug == 1)
		message_print("%s", ftp_info->ftp_msg);
	if (ftp_info->ftp_msg[3] == '-')
	{
		strncpy(match, ftp_info->ftp_msg, 3);
		match[3] = ' ';
		match[4] = '\0';
		do
		{
			if (tcp_read_line(ftp_info->sockfd, ftp_info->ftp_msg,
							MAXLINE) == -1)
			{
				message_print("Control socket read failed");
				return -1;
			}
			if (ftp_info->debug == 1)
				message_print("%s", ftp_info->ftp_msg);
		}
		while (strncmp(ftp_info->ftp_msg, match, 4));
	}
	
	return 1;
}

int ftp_check_response(FTPINFO *ftp_info, char c)
{	
	if (ftp_read_response(ftp_info) < 0)
		return -1;
	
	if (ftp_info->ftp_msg[0] == c)
		return 1;
	
	return -1;
}
