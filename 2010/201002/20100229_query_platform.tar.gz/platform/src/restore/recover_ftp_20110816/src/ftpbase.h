#ifndef __FTPBASE_H__
#define __FTPBASE_H__

#include <ctype.h>

#include "libftp.h"

#define		FTP_MESSAGE_LEN		1024

extern char	ftp_message[FTP_MESSAGE_LEN];

int ftp_response(FTPINFO *);
void ftp_set_timeout(FTPINFO *, int);
int ftp_check_response(FTPINFO *, char);
int ftp_pasv(FTPINFO *, char *, int *);
int ftp_get_data_sock(FTPINFO *);

#endif
