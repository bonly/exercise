/**
*
* Copyright  Sunrise Tech. Co., Ltd.
*
* File name:   recover.h
* Description: define functions for recover the database from redo the log.
*
* Version:     v00.00.001
* Author:      yusang      
* Date:        20110810
*
*/

#ifndef __RECOVER_H
#define __RECOVER_H

//#include "GlobalDefines.h"
//#include "LogCallback.h"
//#include "PidFile.h"
#include "fileop.h"
#include "transfile.h"

#define IS_ZEROLSN(lsn)     ((lsn.file==0&&lsn.offset==0)?1:0)   

#define GROUP_MEMBER_COUNT  2

typedef struct {
	string ip;
	string port;
	string dbname;
	string usr;
	string passwd;
	string data_path;
} group_info;

//recover the database from the input dir
class Recover
{
public:
  Recover (const char* envhome);
  ~Recover ();
private:
	//group_info[2];
public:
};

#endif /* __RECOVER_H */

