./restore -n 1 -s ip:port:dbname:usr:passwd:data_path|ip:port:dbname:usr:passwd:data_path

