#include <iostream>
using namespace std;


static int remove_files(const char *dir, const char* headprefix, const char* tmpprefix);
