/******************************************************************************
    Copyright (C), 1996-2011, Sunrise Tech. Co., Ltd.
        File name:                  main.cpp
        Author:                     yusang
        Version:                    1.0
        Date:                       2011.8.10
        Description:								���ϵͳ�ָ�����
        Others:
        Function List:
        History:
******************************************************************************/
#include "Recover.h"
#include "k_mysql.h"
#include "readini.h"
//#include "filetools.h"
#include <dirent.h> 
#include <errno.h> 


#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

//typedef vector<string>  SAME_TABLES;

static int TABLE_NUM;
static int SEGNUM;
static string BIIL_STATUS_TABLE;
static string MY_IP;
static int MY_PORT;
static string MY_USERNAME;
static string MY_PASSWD;
static string MY_DBNAME;
static string MY_PACK_CMD;
static string MY_CHECK_CMD;
static string FTP_USERNAME;
static string FTP_PASSWD;
static string MY_DB_PATH;
static string DB_PATH;
static string ROUTER_IP;
static int ROUTER_PORT;
static string ROUTER_INSTANCE;
static string ROUTER_USERNAME;
static string ROUTER_PASSWD;
static string ROUTER_DBNAME;

string batchnum;	//��Ҫ�ָ������κ�
group_info info[GROUP_MEMBER_COUNT]; //�ڵ���Ϣ
	

//ɾ����ʱ�ļ�
int remove_files(const char *dir, const char* headprefix, const char* tmpprefix)
{ 
	DIR *dirp; 
	struct dirent *dp; 
	
	if   ((dirp = opendir(dir))   ==   NULL)   { 
		perror( "couldn 't   open   '. ' ");
		return -1; 
	} 

	do { 
		errno = 0; 
		if ((dp = readdir(dirp)) != NULL)   
		{
			string filename = dp->d_name;
			if(filename.find(headprefix) == 0 && filename.find(tmpprefix) == filename.length() - strlen(tmpprefix))
			{
				string filepath =dir;
				filepath += "/";
				filepath += filename;
				unlink(filepath.c_str());
			}
			else
				continue; 
		} 
	}while(dp != NULL);

	if   (errno != 0) 
		return -1;
		
	closedir(dirp);	
	
	return 0; 
} 

//�õ�������ɲ���ı���
void get_finished_tables(K_Database &db, const char* numseg, vector<string>& tables)
{
	tables.clear();

	K_recordSet sa;
	string sql;
	sql = "select id, tablename, table_num from ";
	sql += BIIL_STATUS_TABLE;
	sql += " where status =2 and table_num = ";
	sql += numseg;
	db.ExecQueryGetRecord(sql.c_str(), sa);
	char tmp[64]; memset(tmp, 0, sizeof(tmp));
	
	for(int i=0;i<sa.GetRecordCount();i++)
	{
		memset(tmp, 0, sizeof(tmp));
		for(int j=0;j<TABLE_NUM;j++)
		{
			int a = atoi( sa[i][2].c_str());
			sprintf(tmp, "%s_%02d_%03d", sa[i][1].c_str(), j, a);
			
			K_recordSet sa1;
			string sql = "select 1 from ";
			sql += tmp;
			sql += " limit 1";
			//cout<<sql<<endl;
			if ( db.ExecQueryGetRecord(sql.c_str(), sa1) != -1)
				tables.push_back(tmp);
		}
	}
	
	return;
}

//�����ļ�
int copy_file(TransFile* trans, const char* remote_path, const char* remote_filename, const char* local_path)
{
	string remote_file_path = remote_path;
	remote_file_path += "/";
	remote_file_path += remote_filename;
	
	string local_file_path = local_path;
	local_file_path += "/";
	local_file_path += remote_filename;
		
	return trans->completeRecv(remote_file_path.c_str(), local_file_path.c_str());
}

//�ָ���
int copy_table(TransFile* trans, const char* remote_path, const char* remote_tablename, const char* local_path)
{
	string tablename = remote_tablename;

	//�˴��ļ���˳��һ����frm�ļ���󿽱�����Ϊmysqlһ����鵽frm�ļ����ڼ���Ϊ��һ�����ڵı���
	string myd_name = tablename + ".MYD";
	string myi_name = tablename + ".MYI";
	string frm_name = tablename + ".frm";

	if (copy_file(trans, remote_path, myd_name.c_str(), local_path) != 0 ||
			copy_file(trans, remote_path, myi_name.c_str(), local_path) != 0 ||
			copy_file(trans, remote_path, frm_name.c_str(), local_path) != 0 )
	return -1;

	return 0;
}

//�������ļ�
int read_config()
{
	map<string, string> m_url;
	m_url = read_conf( CONFIG );
	printf( "---------%s \n\n", "Show Map Infos");
	map<string, string>::iterator it_url;
	for(it_url = m_url.begin(); it_url != m_url.end(); it_url++)
	{
		printf( "%s  <==> %s \n", it_url->first.c_str(), it_url->second.c_str() );
	}
	
	TABLE_NUM = atoi(m_url["TABLE_NUM"].c_str());  
	SEGNUM = atoi(m_url["SEGNUM"].c_str());
	BIIL_STATUS_TABLE = m_url["BIIL_STATUS_TABLE"];
	MY_IP = m_url["MY_IP"];
	MY_PORT = atoi(m_url["MY_PORT"].c_str());         
	MY_USERNAME = m_url["MY_USERNAME"];
	MY_PASSWD = m_url["MY_PASSWD"];
	MY_DBNAME = m_url["MY_DBNAME"];
	
	FTP_USERNAME = m_url["FTP_USERNAME"];
	FTP_PASSWD = m_url["FTP_PASSWD"];
	MY_DB_PATH=m_url["MY_DB_PATH"];
	
	DB_PATH = m_url["DB_PATH"];
	
	MY_PACK_CMD=m_url["MY_PACK_CMD"];
	MY_CHECK_CMD = m_url["MY_CHECK_CMD"];		
	
	ROUTER_IP = m_url["ROUTER_IP"];
	ROUTER_PORT = atoi(m_url["ROUTER_PORT"].c_str());
	ROUTER_INSTANCE = m_url["ROUTER_INSTANCE"];
	ROUTER_USERNAME = m_url["ROUTER_USERNAME"];
	ROUTER_PASSWD = m_url["ROUTER_PASSWD"];
	ROUTER_DBNAME = m_url["ROUTER_DBNAME"];
	
}

void usage(const char *progname)
{
	fprintf(stderr, "usage: %s ", progname);
	fprintf(stderr, "[-n seg][-s address]\n");
	fprintf(stderr, "NOTICE:  ./restore -n 1 -s ip:port:dbname:usr:passwd:data_path|ip:port:dbname:usr:passwd:data_path\n");
}

//���ͬ�������ڵ�����ӷ�ʽ
int get_group_info(const char* infoline, group_info ginfo[])
{
	string seg[2];
	char *buf = new char[strlen(infoline)+1];
	strcpy(buf, infoline);
	buf[strlen(infoline)] = '\0';

	int count = 0;
	char *token = strtok( buf, "#" );
	while(token != NULL )
	{
		count++;
		if(count == 1)
			seg[0] = token;
		else if(count == 2)
			seg[1] = token;
		else
			break;
		token = strtok( NULL, "#" );
	}

	delete buf;
	
	for(int i=0;i<2;i++)
	{
		char *buf1 = new char[seg[i].length()+1];
		strcpy(buf1, seg[i].c_str());
		buf1[seg[i].length()] = '\0';
		char *token1 = strtok( buf1, ":" );
		
		int count = 0;
		while(token1 != NULL )
		{
			count++;
			
			if(count == 1)
				ginfo[i].ip = token1;
			else if(count == 2)
				ginfo[i].port = token1;
			else if(count == 3)
				ginfo[i].dbname = token1;
			else if(count == 4)
				ginfo[i].usr = token1;
			else if(count == 5)
				ginfo[i].passwd = token1;
			else if(count == 6)
				ginfo[i].data_path = token1;
			else 
				return -1;
				
			token1 = strtok( NULL, ":" );
		}
		delete buf1;
	}
	
	return 0;
}

//�ӱ�Ļ����п������ݣ����ָ�
int restore_data(int machine)
{
	K_Database a;
	int i;
	int portnum = atoi( info[machine].port.c_str() ); 
	i=a.Connect(info[machine].ip,info[machine].usr,info[machine].passwd,info[machine].dbname,portnum,0);
	if(i!=0) 
	{
		printf("Can`t connect the DB\n");
		return 0;
	}
	else
	{
		printf("Connect successed\n");
	}
	
	//�õ������������Ѿ�ѹ����ɵ����ݿ��
	vector<string> dealingID;
	vector<string>::iterator itr;
	dealingID.clear();

	vector<string> tables;
	tables.clear();
	get_finished_tables(a, batchnum.c_str(), tables);
	vector<string>::iterator it;
	
	for(it = tables.begin(); it != tables.end(); ++it)
	{	string datapath = info[machine].data_path + info[machine].dbname;
	
		//��ʼ�ָ�����
		TransFile *m_pTransFile;
		if((m_pTransFile = new TransFile(info[machine].ip.c_str(), FTP_USERNAME.c_str(), FTP_PASSWD.c_str())) == NULL)
			return -1;
		
		
		copy_table(m_pTransFile, datapath.c_str(), it->c_str(), DB_PATH.c_str());
		
		
		delete m_pTransFile;
	}

	a.DisConnect ();	
	
	return 0;
}

int main(int argc,char* argv[])
{
	//��������в���
	extern char *optarg;
	string groupinfo;
	const char* progname = argv[0];
	char ch;
	
	if(argc == 1)
	{
		usage(progname);
		return -1;
	}
	
	while ((ch = getopt(argc, argv, "n:s:")) != EOF)
	{
		switch (ch) {	
			case 'n':
				cout<<optarg<<endl;
				batchnum = optarg;
				continue;
			case 's':
				cout<<optarg<<endl;
				groupinfo = optarg;
				continue;
			default:
				usage(progname);
				return -1;
		}
	}

	//������л��ͬ�����2�������Ĳ�����Ϣ
	get_group_info(groupinfo.c_str(), info);

	//���ļ�������Ϣ
	read_config();

	//ɾ�����ܴ��ڵ���ʱ�ļ�
	remove_files(DB_PATH.c_str(), "BILL_", "_restore");
	
	//��ͬ���е�2���ڵ㿽�����ݣ����ܴ�����һ����ȫ����������Ҫ�ٴӱ�Ľڵ㿽��
	for(int i=0;i<GROUP_MEMBER_COUNT;i++)
	{
		if(restore_data(i) == 0)
			break;
	}
	
	return 0;
}
