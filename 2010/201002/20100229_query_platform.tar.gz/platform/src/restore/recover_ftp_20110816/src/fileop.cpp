#include "fileop.h"

#define DB_RETRY  100

#define	RETRY_CHK(op, ret) do {						\
	int __retries, __t_ret;						\
	for ((ret) = 0, __retries = DB_RETRY;;) {			\
		if ((op) == 0)						\
			break;						\
		(ret) = errno;				\
		if (((__t_ret = ret)== EAGAIN ||	\
		     __t_ret == EBUSY || __t_ret == EINTR ||		\
		    __t_ret == EIO) && --__retries > 0)			\
			continue;					\
		break;							\
	}								\
} while (0)

int OpenFile(const char * filename ,int oflags, int mode, int * fdp,u_int32_t flags)
{  
    int nrepeat, retries = 0;
    int ret, fd;

    for (nrepeat = 1; nrepeat < 4; ++nrepeat) {
        	ret = 0;
		fd = open(filename, oflags, mode);
		if (fd > 0) {
			ret = 0;
                        *fdp=fd;
			break;
		}

		switch (ret = errno) {
		case EMFILE:
		case ENFILE:
		case ENOSPC:
			sleep(nrepeat * 2);
			break;
		case EBUSY:
		case EINTR:
			if (++retries < DB_RETRY)
				--nrepeat;
			break;
		default:
			goto err;
		}/*end of switch (ret = errno)*/
    }/*end of for (nrepeat = 1;....)*/

            
err:
    if(fd > 0&& ret!= 0)
          (void)CloseFile(fd, 0);
    return (ret);
}

int CloseFile(int fd, u_int32_t flags)
{
    int ret;
   
    if(fd < 0) return 0;

    RETRY_CHK((close(fd)), ret);
    if (ret != 0)
        printf("CloseFile: failed to close fd %d\n due to %s\n",fd,strerror(ret));
    
    return ret;
}

int WriteFile(int fd, char *addr, size_t len, size_t *nwp)
{
    size_t offset;
    ssize_t nw;
    int ret;
    char *taddr;

    ret = 0;

    for (taddr = addr, offset = 0;
            offset < len; taddr += nw, offset += (u_int32_t)nw) {
                RETRY_CHK(((nw = write(
                    fd, taddr, len - offset)) < 0 ? 1 : 0), ret);
                if (ret != 0)
                        break;
    }
    *nwp = len;
 
    if (ret != 0){
        ret = errno;
        printf("WriteFile: write file failed, due to %s\n",strerror(ret));
    }
 
    return (ret);
}

int ReadFile(int fd, char *addr, size_t len, size_t *nrp)
{
    size_t offset;
    ssize_t nr;
    int ret;
    char *taddr;

    ret = 0;

    for (taddr =addr, offset = 0; offset < len; taddr += nr, offset += (u_int32_t)nr) {
                RETRY_CHK(((nr = read(fd, taddr, len - offset)) < 0 ? 1 : 0), ret);
                if (nr == 0 || ret != 0)
                        break;
    }
    *nrp = (size_t)(taddr - addr);
  
    if (ret != 0){
                ret = errno;
                printf("ReadFile: read file failed, due to %s\n",strerror(ret));
    }

    return (ret);
}

int CopyFile(const char * src_file, const char * des_file , u_int32_t flags)
{
    int  rfd, wfd;
    size_t nr, nw;
    int ret;
    char *buf;

    ret = 0;
    buf = NULL;
   
    #define MEGABYTE  10485760
    /*
    * We MUST copy multiples of the page size, atomically, to ensure a
    * database page is not updated by another thread of control during
    * the copy.
    *
    * !!!
    * The current maximum page size for Berkeley DB is 64KB; we will have
    * to increase this value if the maximum page size is ever more than a
    * megabyte
    */
    if ((buf = (char *)malloc(MEGABYTE)) == NULL) {
                printf("CopyFile:%lu buffer allocation failed!\n error:(%s)\n", (u_long)MEGABYTE,strerror(errno));
		ret=errno;
                goto err;
    }

    /* Open the input file. */
    if ((ret = OpenFile(src_file,O_RDONLY, 0, &rfd, 0)) != 0) {
		printf("CopyFile: open src file %s for read failed\n",src_file);
                goto err;
    }

    /* Open the output file. */
    if ((ret = OpenFile(des_file,O_RDWR|O_CREAT|O_TRUNC, 0600, &wfd, 0)) != 0) {
                printf("CopyFile: open des file %s for write failed\n",des_file);
                goto err;
    }
    
    /* Copy the data. */
    while ((ret =ReadFile(rfd, buf, MEGABYTE, &nr)) == 0 &&
	    nr > 0)
		if ((ret = WriteFile(wfd, buf, nr, &nw)) != 0)
			break;

err:	
    if (buf != NULL)
	free(buf);
    

    if (rfd > 0 && CloseFile(rfd, 0) != 0){
              ret=1;
              printf("CopyFile: close src file %s failed\n",src_file); 
    }
    if (wfd > 0 && CloseFile(wfd, 0) != 0){
              ret=1;
              printf("CopyFile: close des file %s failed\n",des_file);
    }   
    return (ret);

}
