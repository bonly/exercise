#include "nTime.h"
#include "nSystem.h"
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/wait.h>
#include <sys/time.h>

#define arysize(ary)	(sizeof(ary)/sizeof((ary)[0]))


long CClock::clk_per_sec(void)
{
    static long cps = 0;

    return (cps != 0) ? cps : (cps = sysconf(_SC_CLK_TCK));
}

/***********************************************************/

CTime::CTime()
{
    clear();
    set();
    return;
}

CTime::CTime(const time_t & timer)
{
    clear();
    set(timer);
    return;
}

CTime::CTime(const timeval & timer)
{
    clear();
    set(timer);
    return;
}

CTime::CTime(const CTime & timer)
{
    clear();
    set(timer);
    return;
}

CTime::~CTime()
{
    return;
}

CTime & CTime::operator =(const CTime & timer)
{
    if (&timer != this)
    {
        set(timer);
    }

    return *this;
}

void CTime::clear(void)
{
    memset(&m_tm, 0, sizeof(m_tm));
    memset(&m_timeval, 0, sizeof(m_timeval));
    return;
}

time_t CTime::set()
{
    if ((gettimeofday(&m_timeval, NULL) != 0) ||
        (localtime_r(&m_timeval.tv_sec, &m_tm) == NULL))
    {
        return 0;
    }

    return m_timeval.tv_sec;
}

bool CTime::set(const time_t & timer)
{
    if ((timer < 0) || (localtime_r(&timer, &m_tm) == NULL))
    {
        return false;
    }

    m_timeval.tv_sec = timer;
    m_timeval.tv_usec = 0;

    return true;
}

bool CTime::set(const timeval & timer)
{
    if ((timer.tv_sec < 0) || (localtime_r(&timer.tv_sec, &m_tm) == NULL))
    {
        return false;
    }

    m_timeval.tv_sec = timer.tv_sec;
    m_timeval.tv_usec = timer.tv_usec;

    return true;
}

bool CTime::set(const CTime & timer)
{
    m_tm = timer.m_tm;
    m_timeval = timer.m_timeval;
    return true;
}

bool CTime::format(const string & fmt, string & str) const
{
    char szTime[256];
    memset(szTime, 0, sizeof(szTime));

    if (strftime(szTime, sizeof(szTime), fmt.c_str(), &m_tm) == 0)
    {
        return false;
    }

    str = szTime;
    return true;
}

bool CTime::format(const string & fmt, char *str, int size) const
{
    if ((isPtr(str) == false) ||
        (strftime(str, size, fmt.c_str(), &m_tm) == 0))
    {
        return false;
    }

    return true;
}

string & CTime::toString(time_format fmt)
{
    string str;
    switch (fmt)
    {
    case STR19:
        {
            format("%Y-%m-%d %H:%M:%S", str);
            break;
        }
    case STR14:
    default:
        {
            format("%Y%m%d%H%M%S", str);
            break;
        }
    }

    return str;
}

void CTime::toString(time_format fmt, string & str) const
{
    switch (fmt)
    {
    case STR19:
        {
            format("%Y-%m-%d %H:%M:%S", str);
            break;
        }
    case STR14:
    default:
        {
            format("%Y%m%d%H%M%S", str);
            break;
        }
    }

    return;
}

time_t CTime::toTime()
{
    m_timeval.tv_sec = mktime(&m_tm);
    m_timeval.tv_usec = 0;
    return m_timeval.tv_sec;
}

void CTime::sleep(unsigned int timer)
{
    // ��ֹ���ź��ж�
    while (timer > 0)
    {
        timer =::sleep(timer);
    }

    return;
}

void CTime::sleep(timeval & timer)
{
    select(0, NULL, NULL, NULL, &timer);

    return;
}

/***********************************************************/

CFluxNO::CFluxNO()
{
    set(0, 1, 0, 0);

    return;
}

CFluxNO::CFluxNO(int start, int width, int begin, int end)
{
    set(start, width, begin, end);

    return;
}

CFluxNO::~CFluxNO()
{
    return;
}

void CFluxNO::set(int start, int width, int begin, int end)
{
    m_nBegin = begin;
    m_nEnd = end;

    if (((m_nBegin < m_nEnd) && ((start <= m_nBegin) || (start >= m_nEnd))) ||  // begin->end ++, start not in [begin,end]
        ((m_nBegin > m_nEnd) && ((start >= m_nBegin) || (start <= m_nEnd))))    // begin->end --, start not in [end,begin]
    {
        m_nFluxno = m_nBegin;
    }
    else
    {
        m_nFluxno = start;
    }

    memset(m_szWidth, 0, sizeof(m_szWidth));
    snprintf(m_szWidth, sizeof(m_szWidth), "%%0%dd", width);    // %0xd

    m_passtime.start();

    return;
}

int CFluxNO::getNextFluxNO(int *fluxno)
{
    // ��ˮ��ѭ��
    if (((m_nBegin < m_nEnd) && ((m_nFluxno < m_nBegin) || (m_nFluxno >= m_nEnd))) ||   // ˳��
        ((m_nBegin > m_nEnd) && ((m_nFluxno > m_nBegin) || (m_nFluxno <= m_nEnd))))     // ����
    {
        if (m_nBegin < m_nEnd)  // ˳��
        {
            m_nFluxno = m_nBegin - 1;
        }
        else if (m_nBegin > m_nEnd)     // ����
        {
            m_nFluxno = m_nBegin + 1;
        }
        else                    //if (m_nBegin == m_nEnd)
        {
            m_nFluxno = m_nBegin;
        }
    }

    if (m_nBegin < m_nEnd)
    {
        m_nFluxno++;
    }
    else if (m_nBegin > m_nEnd)
    {
        m_nFluxno--;
    }

    return getCurFluxNO(fluxno);
}

string & CFluxNO::getNextFluxNO(void)
{
    char tmp[20];
    memset(tmp, 0, sizeof(tmp));
    snprintf(tmp, sizeof(tmp), m_szWidth, getNextFluxNO(NULL));

    m_strRet = tmp;

    return m_strRet;
}

int CFluxNO::getNextRFluxNO(int *fluxno)
{
    // ������ˮ�ŵĵڶ��ַ�ʽ: ��ʱ�䳬��һ��ʱ��ˮ�Ÿ�λ
    if ((m_passtime.elapsed() != 0) || ((m_nBegin < m_nEnd) && ((m_nFluxno < m_nBegin) || (m_nFluxno >= m_nEnd))) ||    // ˳��
        ((m_nBegin > m_nEnd) && ((m_nFluxno > m_nBegin) || (m_nFluxno <= m_nEnd))))     // ����
    {
        if (m_nBegin < m_nEnd)  // ˳��
        {
            m_nFluxno = m_nBegin - 1;
        }
        else if (m_nBegin > m_nEnd)     // ����
        {
            m_nFluxno = m_nBegin + 1;
        }
        else                    //if (m_nBegin == m_nEnd)
        {
            m_nFluxno = m_nBegin;
        }

        // ����һ�븴λ
        m_passtime.start();
    }

    if (m_nBegin < m_nEnd)
    {
        m_nFluxno++;
    }
    else if (m_nBegin > m_nEnd)
    {
        m_nFluxno--;
    }

    return getCurFluxNO(fluxno);
}

string & CFluxNO::getNextRFluxNO(void)
{
    char tmp[20];
    memset(tmp, 0, sizeof(tmp));
    snprintf(tmp, sizeof(tmp), m_szWidth, getNextRFluxNO(NULL));

    m_strRet = tmp;

    return m_strRet;
}

int CFluxNO::getCurFluxNO(int *fluxno)
{
    return (isPtr(fluxno) == true) ? (*fluxno = m_nFluxno) : m_nFluxno;
}

string & CFluxNO::getCurFluxNO(void)
{
    char tmp[20];
    memset(tmp, 0, sizeof(tmp));
    snprintf(tmp, sizeof(tmp), m_szWidth, getCurFluxNO(NULL));

    m_strRet = tmp;

    return m_strRet;
}

CCron::CCron()
{
    clear();
}

CCron::CCron(const CCron & p)
{
    operator=(p);
}

CCron::~CCron()
{
}

CCron & CCron::operator=(const CCron & p)
{
    memcpy(m_mins, p.m_mins, sizeof(m_mins));
    memcpy(m_hrs, p.m_hrs, sizeof(m_hrs));
    memcpy(m_days, p.m_days, sizeof(m_days));
    memcpy(m_mons, p.m_mons, sizeof(m_mons));
    memcpy(m_dow, p.m_dow, sizeof(m_dow));

    return *this;
}

void CCron::clear()
{
    memset(m_mins, 0, sizeof(m_mins));
    memset(m_hrs, 0, sizeof(m_hrs));
    memset(m_days, 0, sizeof(m_days));
    memset(m_mons, 0, sizeof(m_mons));
    memset(m_dow, 0, sizeof(m_dow));
}

int CCron::parse(const char *ptr)
{
    clear();

    if ((ptr = parse_field(m_mins, 60, 0, ptr)) == NULL)
        return 1;
    if ((ptr = parse_field(m_hrs, 24, 0, ptr)) == NULL)
        return 2;
    if ((ptr = parse_field(m_days, 32, 0, ptr)) == NULL)
        return 3;
    if ((ptr = parse_field(m_mons, 12, -1, ptr)) == NULL)
        return 4;
    if ((ptr = parse_field(m_dow, 7, 0, ptr)) == NULL)
        return 5;

    fixdaydow();

    return 0;
}

const char *CCron::parse_field(char *const ary, int modvalue, int off,
                               const char *ptr)
{
    const char *base = ptr;
    int n1 = -1;
    int n2 = -1;

    if (base == NULL)
        return (NULL);

    // ��Ϊ�հ׷�ʱ��ѭ��
    while (*ptr != ' ' && *ptr != '\t' && *ptr != '\n')
    {
        int skip = 0;

        /*
         * Handle numeric digit or '*'
         */
        if (*ptr == '*')
        {
            n1 = 0;             /* everything will be filled */
            n2 = modvalue - 1;
            skip = 1;
            ++ptr;
        }
        else if (*ptr >= '0' && *ptr <= '9')
        {
            if (n1 < 0)
                n1 = strtol(ptr, (char **) &ptr, 10) + off;
            else
                n2 = strtol(ptr, (char **) &ptr, 10) + off;
            skip = 1;
        }

        /*
         * handle optional range '-'
         */
        if (skip == 0)
        {
            printf("1failed parsing %s %d\n", base, ptr - base);
            return (NULL);
        }
        if (*ptr == '-' && n2 < 0)
        {
            ++ptr;
            continue;
        }

        /*
         * collapse single-value ranges, handle skipmark, and fill
         * in the character array appropriately.
         */
        if (n2 < 0)
            n2 = n1;

        if (*ptr == '/')
            skip = strtol(ptr + 1, (char **) &ptr, 10);

        /*
         * fill array, using a failsafe is the easiest way to prevent
         * an endless loop
         */
        {
            // parse "1-3,4-8/2,*/4,23-8,23-8/2"
            int s0 = 1;
            int failsafe = 1024;

            --n1;
            do
            {
                n1 = (n1 + 1) % modvalue;

                if (--s0 == 0)
                {
                    ary[n1 % modvalue] = 1;
                    s0 = skip;
                }
            }
            while (n1 != n2 && --failsafe);

            if (failsafe == 0)
            {
                printf("2failed parsing %s %d\n", base, ptr - base);
                return (NULL);
            }
        }
        if (*ptr != ',')
            break;
        ++ptr;
        n1 = -1;
        n2 = -1;
    }

    // �������һ���ִ��ǿհ׷��ķ���ʧ��
    if (*ptr != ' ' && *ptr != '\t' && *ptr != '\n')
    {
        printf("3failed  parsing %s %d\n", base, ptr - base);
        return (NULL);
    }

    // ����ʱ������һ���ǿհ׷�
    while (*ptr == ' ' || *ptr == '\t' || *ptr == '\n')
        ++ptr;

    return (ptr);
}

void CCron::fixdaydow()
{
    unsigned short i;
    short weekUsed = 0;
    short daysUsed = 0;

    for (i = 0; i < arysize(m_dow); ++i)
    {
        if (m_dow[i] == 0)
        {
            weekUsed = 1;
            break;
        }
    }

    for (i = 0; i < arysize(m_days); ++i)
    {
        if (m_days[i] == 0)
        {
            daysUsed = 1;
            break;
        }
    }

    // ֻʹ������,ûʹ����
    if (weekUsed && !daysUsed)
    {
        memset(m_days, 0, sizeof(m_days));
    }

    // ֻʹ����,ûʹ������
    if (daysUsed && !weekUsed)
    {
        memset(m_dow, 0, sizeof(m_dow));
    }
}

int CCron::test(time_t t) const
{
    struct tm result;
    memset(&result, 0, sizeof(result));
    localtime_r(&t, &result);

    return test(&result);
}

int CCron::test(time_t t1, time_t t2) const
{
    time_t t = 0;
    int n = 0;
    for (t = t1 - t1 % 60; t <= t2; t += 60)
    {
        if ((t >= t1) && (test(t) != 0))
        {
            n++;
        }
    }

    return n;
}

int CCron::test(struct tm *tp) const
{
    if (m_mins[tp->tm_min] &&
        m_hrs[tp->tm_hour] &&
        (m_days[tp->tm_mday] || m_dow[tp->tm_wday]) && m_mons[tp->tm_mon])
    {
        return 1;
    }

    return 0;
}

void CCron::print() const
{
    printf
        ("|---00----|---10----|---20----|---30----|---40----|---50----|\n");
    printf
        ("012345678901234567890123456789012345678901234567890123456789\n");
    for (int i = 0; i < sizeof(m_mins); i++)
    {
        printf("%i", m_mins[i]);
    }
    printf("\n");

    for (int i = 0; i < sizeof(m_hrs); i++)
    {
        printf("%i", m_hrs[i]);
    }
    printf("\n");

    for (int i = 0; i < sizeof(m_days); i++)
    {
        printf("%i", m_days[i]);
    }
    printf("\n");

    for (int i = 0; i < sizeof(m_mons); i++)
    {
        printf("%i", m_mons[i]);
    }
    printf("\n");

    for (int i = 0; i < sizeof(m_dow); i++)
    {
        printf("%i", m_dow[i]);
    }
    printf("\n");
    printf("-----------------------------------\n");
}
