#ifndef _H_H_CEPOLL_H_H_
#define _H_H_CEPOLL_H_H_

#include <vector>

using namespace std;

class CEpoll
{
	public:
		struct EpollEve
			{
				int fd;
				int events;
			};
			
	public:
		CEpoll(int fdsize, int eventsize, int waittime=10);
		~CEpoll();
		int add_fd(int fd, int event);
		int delete_fd(int fd);
		int wait(vector<EpollEve>& eventVec);
		int init();

	private:
	    int set_no_block(int fd);

		struct epoll_event* m_pevent;
		int m_epoll_fd;

		int m_fd_size;
		int m_event_size;
		int m_epoll_wait_time;//millisecond
};

#endif

