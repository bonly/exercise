#include "nNetwork.h"
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>

#include <iostream>
    using namespace std;
CTcpServer::CTcpServer() 
{
    m_listenfd = -1;
    m_connfd = -1;
    m_bTimeOut = false;
    memset(&m_servaddr, 0, sizeof(m_servaddr));
    memset(&m_clientaddr, 0, sizeof(m_clientaddr));
}
bool CTcpServer::InitServer(const char *ip, int port) 
{
    m_listenfd = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    unsigned int len = sizeof(opt);
    setsockopt(m_listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, len);
    setsockopt(m_listenfd, SOL_SOCKET, SO_KEEPALIVE, &opt, len);
    memset(&m_servaddr, 0, sizeof(m_servaddr));
    m_servaddr.sin_family = AF_INET;
    (ip != NULL) ? (m_servaddr.sin_addr.s_addr =
                     inet_addr(ip)) : (m_servaddr.sin_addr.s_addr =
                                       htonl(INADDR_ANY));
    m_servaddr.sin_port = htons(port);
    if (bind
          (m_listenfd, (struct sockaddr *) &m_servaddr,
           (socklen_t) sizeof(m_servaddr)) != 0)
        
    {
        CloseListen();
        return false;
    }
    if (listen(m_listenfd, 4) != 0)
        
    {
        CloseListen();
        return false;
    }
    
    //m_socklen = (socklen_t)sizeof(struct sockaddr_in);
    return true;
}

bool CTcpServer::Accept() 
{
    if (m_listenfd == -1)
        return false;
    
#if defined(_ENV_HPUX)
    int socklen = sizeof(struct sockaddr_in);
    if ((m_connfd =
          accept(m_listenfd, (void *) (&m_clientaddr), &socklen)) < 0)
        return false;
    
#else   /*  */
//#elif defined(linux) || defined(__linux) || defined(__linux__) || defined(_AIX) 
        socklen_t socklen = sizeof(struct sockaddr_in);
    if ((m_connfd =
          accept(m_listenfd, (struct sockaddr *) &m_clientaddr,
                 (socklen_t *) (&socklen))) < 0)
        
    {
        return false;
    }
    
#endif  /*  */
        return true;
}
char *CTcpServer::GetClientIP() 
{
    return (inet_ntoa(m_clientaddr.sin_addr));
}

bool CTcpServer::Read(char *strRead, time_t iSecond) 
{
    m_bTimeOut = false;
    m_BufLen = 0;
    switch (TcpRead(m_connfd, strRead, &m_BufLen, iSecond))
        
    {
    case -1:
        return false;
    case 0:
        return true;
    case -2:
        m_bTimeOut = true;
        return false;
    default:
        return false;
    }
}

bool CTcpServer::Write(const char *strWrite, long buflen, time_t iSecond) 
{
    m_bTimeOut = false;
    switch (TcpWrite(m_connfd, strWrite, buflen, iSecond))
        
    {
    case -1:
        return false;
    case 0:
        return true;
    case -2:
        m_bTimeOut = true;
        return false;
    default:
        return false;
    }
}
void CTcpServer::CloseListen() 
{
    if (m_listenfd > 0)
        
    {
        
            /*shutdown(m_listenfd,SHUT_RDWR); */ close(m_listenfd);
        m_listenfd = -1;
    }
}
void CTcpServer::CloseClient() 
{
    if (m_connfd > 0)
        
    {
        
            /*shutdown(m_connfd,SHUT_RDWR); */ close(m_connfd);
        m_connfd = -1;
    }
}

CTcpServer::~CTcpServer() 
{
    CloseListen();
    CloseClient();
}


//////////////////////////////////////////////////////////////////////
int TcpRead(int fd, char *strRead, size_t * buflen, time_t iSecond) 
{
    
//    struct stat buf;
//    if (fstat(fd, &buf) < 0)
//        return 1;
//    if ((buf.st_mode & S_IFMT) != S_IFSOCK)
//        return 1;
        if (fd < 0)
        return -1;
    
        // С��0ʱ������ʱ���
        if (iSecond >= 0)
        
    {
        fd_set tmpfd;
        FD_ZERO(&tmpfd);
        FD_SET(fd, &tmpfd);
        struct timeval timeout;
        timeout.tv_sec = iSecond;
        timeout.tv_usec = 0;
        int i = 0;
        if ((i = select(fd + 1, &tmpfd, NULL, NULL, &timeout)) <= 0)
            
        {
            if (i == 0)
                return -2;     // ��ʱ����2
            else
                return -3;     // select��������-2
        }
    }
    (*buflen) = 0;
    char strBufLen[5];
    memset(strBufLen, 0, sizeof(strBufLen));
    
        // �ȶ�����ͷ��ǰ4 byte,��4 byte���������ĵĳ���
        if (Readn(fd, (char *) strBufLen, 4) != 4)
        return -4;
    (*buflen) = atoi(strBufLen);
    
        // ��������
        if (Readn(fd, strRead, (*buflen) - 4) != ((*buflen) - 4))
        return -5;
    (*buflen) = (*buflen) - 4;
    return 0;
}
int TcpWrite(int fd, const char *strWrite, size_t buflen,
               time_t iSecond) 
{
    
//    struct stat buf;
//    if (fstat(fd, &buf) < 0)
//    {
//        return 1;
//    }
//    if ((buf.st_mode & S_IFMT) != S_IFSOCK)
//    {
//        return 1;
//    }
        if (fd < 0)
        return -1;
    
        // С��0ʱ������ʱ���
        if (iSecond >= 0)
        
    {
        fd_set tmpfd;
        FD_ZERO(&tmpfd);
        FD_SET(fd, &tmpfd);
        struct timeval timeout;
        
            //timeout.tv_sec = 5;
            timeout.tv_sec = iSecond;
        timeout.tv_usec = 0;
        int i = 0;
        if ((i = select(fd + 1, NULL, &tmpfd, NULL, &timeout)) <= 0)
            
        {
            if (i == 0)
                return -2;     // ��ʱ����2
            else
                return -3;     // select��������-2
        }
    }
    
        // �������Ϊ0���Ͳ����ַ����ĳ���
        if (buflen == 0)
        buflen = strlen(strWrite);
    if (buflen > TCPBUFLEN)
        return false;
    buflen = buflen + 4;
    char strBufLen[5];
    memset(strBufLen, 0, sizeof(strBufLen));
    sprintf(strBufLen, "%04ld", buflen);
    
        // ��д4 byte����ͷ����4 byte���������ĵĳ���
        if (Writen(fd, (char *) strBufLen, 4) != 4)
        
    {
        return -4;
    }
    
        // д������
        if (Writen(fd, strWrite, buflen - 4) != (buflen - 4))
        
    {
        return -5;
    }
    return 0;
}

ssize_t Readn(int fd, char *vptr, size_t n) 
{
    ssize_t nLeft = n, idx = 0, nread = 0;
    while (nLeft > 0)
        
    {
        if ((nread = recv(fd, vptr + idx, nLeft, 0)) < 0)
            
        {
            if (errno == EINTR)        // ���ж�
            {
                nread = 0;
            }
            
            else
                
            {
                
                    // ���ر�,�ɵ����߹ر�
                    /*shutdown(fd,SHUT_RDWR); *//*close(fd); */ return -1;
            }
        }
        
        else if (nread == 0)
            
        {
            break;             /* EOF */
        }
        idx += nread;
        nLeft -= nread;
    }
    return (n - nLeft);       /* return >=0 */
}

ssize_t Writen(int fd, const char *vptr, size_t n) 
{
    ssize_t nLeft = n, idx = 0, nwritten = 0;
    while (nLeft > 0)
        
    {
        if ((nwritten = send(fd, vptr + idx, nLeft, 0)) <= 0)
            
        {
            if ((nwritten < 0) && (errno == EINTR))    // ���ж�
            {
                nwritten = 0;
            }
            
            else
                
            {
                
                    // ���ر�,�ɵ����߹ر�
                    /*shutdown(fd,SHUT_RDWR); *//*close(fd); */ return -1;
            }
        }
        nLeft -= nwritten;
        idx += nwritten;
    }
    return (n - nLeft);
}


