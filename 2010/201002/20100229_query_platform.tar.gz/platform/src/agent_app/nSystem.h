#ifndef __NSYSTEM_H
#define __NSYSTEM_H

#include "config_nbase.h"
    
inline bool isPtr(const void * const p)
{
    return ((0>=p) ? false : true);
}

class CSys
{
public:
    static void makeDaemon(void);
    
    static const char * getLastError(void);
    static const char * getError(int in_errno);
    
    static bool getLastError(char* buf, int size);
    
private:
    CSys();
    ~CSys();
};

#endif // ~__SYSTEM_H

