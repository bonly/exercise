#ifndef __NTIMEKIT_H
#define __NTIMEKIT_H

#include "config_nbase.h"

#include <time.h>
#include <string>

// 1900��1970�������
#define SEC_1900_1970 2208988800UL

/** 
* @brief �ж�����
* 
* @param year 
* 
* @return 
*/
inline int is_leap_year(unsigned int year)
{
    return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
}

/** 
* @brief Tomohiko Sakamoto�ṩ,�������ڼ�
* 
* @param y year
* @param m month
* @param d day
*/
inline int dayofweek(int y, int m, int d) /* 0 = Sunday */
{
    static int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
    y -= m < 3;
    return ((y + y/4 -y/100 + y/400 + t[m-1] + d) % 7);
}

using std::string;

/** 
 * @brief ���ʱ��
 */
class CClock
{
public:
    /** 
     * @brief 
     */
    CClock() : m_start(0), m_end(0) {}

    /** 
     * @brief 
     */
    ~CClock() {}

    /** 
     * @brief 
     * 
     * @return 
     */
    clock_t start()      { return (m_start=clock()); }

    /** 
     * @brief 
     * 
     * @return 
     */
    clock_t end()        { return (m_end=clock()); }

    /** 
     * @brief 
     * 
     * @return 
     */
    clock_t diff() const { return (m_end-m_start); }

    //clock_t diff() const { return ((m_end == 0) ? ((m_end=end()) - m_start) : m_end-m_start); }
        
    /** 
     * @brief ���ŵ�ʱ��
     * 
     * @return 
     */
    clock_t elapsed() const { return (clock() - m_start); }
    
    /** 
     * @brief 
     * 
     * @return 
     */
    const clock_t & getStart() const { return m_start; }

    /** 
     * @brief 
     * 
     * @return 
     */
    const clock_t & getEnd()   const { return m_end; }
    
    /** 
     * @brief clock ticks per second
     * 
     * @return 
     */
    static long clk_per_sec(void);
    
private:
    clock_t m_start;
    clock_t m_end;
};

/** 
 * @brief 
 */
class CPassTime
{
public:
    /** 
     * @brief 
     */
    CPassTime():m_start(0),m_end(0) {};

    /** 
     * @brief 
     */
    ~CPassTime() {};
    
    /** 
     * @brief ��ʱ��ʼ
     * 
     * @return 
     */
    time_t start()      { return time(&m_start); }

    /** 
     * @brief ��ʱ����
     * 
     * @return 
     */
    time_t end()        { return time(&m_end); }

    /** 
     * @brief ��ʱ���
     * 
     * @return 
     */
    time_t diff() const { return (m_end-m_start); }
    //time_t diff() const { return ((m_end == 0) ? ((m_end=end()) - m_start) : m_end-m_start); }
        
    /** 
     * @brief 
     * 
     * @return start()֮�����ŵ�ʱ��
     */
    time_t elapsed() const { return (time(NULL) - m_start); }
    
    /** 
     * @brief 
     * 
     * @return 
     */
    const time_t & getStart() const { return m_start; }

    /** 
     * @brief 
     * 
     * @return 
     */
    const time_t & getEnd()   const { return m_end; }
    
private:
    time_t m_start;
    time_t m_end;
};

// ��ʱδʵ��ʱ��ļӼ�������ʱ������
class CTime
{
public:
    CTime();
    CTime(const time_t  &timer);
    CTime(const timeval &timer);
    CTime(const CTime   &timer);
    ~CTime();
    
    CTime & operator = (const CTime & timer);
    
    void clear(void);
    
    // get current time_t, fail return -1
    time_t set();
    
    // get specify time_t
    bool set(const time_t &timer);
    
    // get specify timeval
    bool set(const timeval &timer);
    
    // get specify CTime
    bool set(const CTime &timer);
    
    /* ���ø�ʽ
    *  %Y [2007]      %y [07]
    *  %m [01-12]
    *  %d [01-31]
    *  %H [00-23]      %I [01-12]      %p [AM/PM]
    *  %M [00-59]
    *  %S [00-60]
    *  %% [%]
    */
    bool format(const string &fmt, string &str) const; // ��ʽ��
    bool format(const string &fmt, char *str, int size) const;

    /*
    *    STR19 :yyyy-mm-dd hh:mi:ss
    *    STR14 :YYYYmmddhhmiss
    */
    enum _time_format {STR19,STR14};
    typedef _time_format time_format;
    
    // ���̰߳�ȫ
    string &toString(time_format fmt);
    
    // �̰߳�ȫ
    void toString(time_format fmt, string &str) const;
    
    time_t toTime();
    
    inline int    getSec(void)   const { return (m_tm.tm_sec); }          // �� [0,60]
    inline int    getMin(void)   const { return (m_tm.tm_min); }          // �� [0,59]
    inline int    getHour(void)  const { return (m_tm.tm_hour); }        // ʱ [0,23]
    inline int    getMDay(void)  const { return (m_tm.tm_mday); }        // �� �ڼ���[1,31]
    inline int    getMon(void)   const { return (m_tm.tm_mon+1); }        // �� [0,11]
    inline int    getYear(void)  const { return (m_tm.tm_year+1900); }   // �� ��1900��ʼ�����
    inline int    getWDay(void)  const { return (m_tm.tm_wday); }        // ���ڵڼ���[0,6]
    inline int    getYDay(void)  const { return (m_tm.tm_yday); }        // ��ڼ���[0,365]

    inline time_t getTime(void)  const { return (m_timeval.tv_sec); }  // ����time_t������
    inline time_t getUsec(void)  const { return (m_timeval.tv_usec); } // ΢��(10��-6�η���)
    inline time_t getUTime(void) const { return (m_timeval.tv_sec*1000000 + m_timeval.tv_usec); } // ��*1000000+΢��

    inline int setSec(int p)  { return ((p>=0 && p<=60) ? (m_tm.tm_sec = p) : -1 ); }
    inline int setMin(int p)  { return ((p>=0 && p<=59) ? (m_tm.tm_min = p) : -1); }
    inline int setHour(int p) { return ((p>=0 && p<=23) ? (m_tm.tm_hour = p) : -1); }
    inline int setMDay(int p) { return ((p>=1 && p<=31) ? (m_tm.tm_mday = p) : -1); }
    inline int setMon(int p)  { return ((p>=1 && p<=12) ? (m_tm.tm_mon = p-1,p) : -1); }
    inline int setYear(int p) { return ((m_tm.tm_year = p-1900), p); }
    
    // תΪ������ת����tm�ṹ
//    void addUsec(int val);
//    void addSec(int val);
//    void addMin(int val);
//    void addHour(int val);
//    void addMDay(int val);
//    void addMon(int val);
//    void addYear(int val);
    
    // �����ź��жϵ�sleep
    static void sleep(unsigned int timer);
    static void sleep(timeval &timer);
    
protected:
    //struct time_t m_time;
    struct tm m_tm;
    struct timeval m_timeval;
};

// ��ˮ����
class CFluxNO
{
public:
    /** 
     * @brief 
     */
    CFluxNO();

    /** 
     * @brief 
     * 
     * @param start 
     * @param width 
     * @param begin 
     * @param end 
     */
    CFluxNO(int start, int width, int begin, int end);

    /** 
     * @brief 
     */
    ~CFluxNO();
    
    /** 
     * @brief �����ֵ start��ʼ��ˮ, width��ˮ�ſ���, ֧��[begin,end]��[end,begin]
     * 
     * @param start 
     * @param width 
     * @param begin 
     * @param end 
     */
    void set(int start, int width, int begin, int end);
    
    /** 
     * @brief ���̰߳�ȫ,���س�Ա����
     * 
     * @return 
     */
    string & getNextFluxNO(void);

    /** 
     * @brief 
     * 
     * @return 
     */
    string & getNextRFluxNO(void);

    /** 
     * @brief 
     * 
     * @return 
     */
    string & getCurFluxNO(void);
    
    /** 
     * @brief �̰߳�ȫ
     * 
     * @param fluxno 
     * 
     * @return 
     */
    int      getNextFluxNO(int *fluxno);

    /** 
     * @brief 
     * 
     * @param fluxno 
     * 
     * @return 
     */
    int      getNextRFluxNO(int *fluxno);

    /** 
     * @brief 
     * 
     * @param fluxno 
     * 
     * @return 
     */
    int      getCurFluxNO(int *fluxno);
    
private:
    // ��ˮ������
    int m_nBegin;
    int m_nEnd;
    
    // ��ǰ��ˮ��
    int m_nFluxno;
    
    // ��ˮ�ſ���
    char m_szWidth[20];
    
    // ��ʱ��
    CPassTime m_passtime;
    
    string m_strRet;
};

class CCron
{
public:
    CCron();
    CCron(const CCron & p);
    ~CCron();
    
    CCron & operator=(const CCron &p);
    
    /** 
    * @brief clear current state
    */
    void clear();
    
    /** 
    * @brief ���� "* * * * * ", �� ʱ �� �� ���� ����ֶ�,�Կո�ָ�, �����ַ���ǰ�����clear()
    * 
    * @param ptr 
    * 
    * @return On success, zero is returned. On error,return field.
    */
    int parse(const char *ptr);

    /** 
    * @brief 
    * 
    * @param t 
    * 
    * @return 
    */
    int test(time_t t) const;
    
    /** 
    * @brief t1��t2��ͬһ�����ڵķ���0
    * 
    * @param t1 
    * @param t2 
    * 
    * @return > t1 and <= t2 ���ش���
    */
    int test(time_t t1, time_t t2) const;
    
    /** 
    * @brief 
    * 
    * @param tp 
    * 
    * @return 
    */
    int test(struct tm *tp) const;
    
    /** 
    * @brief 
    */
    void print() const;
    
protected:
    // ���� "1-3,4-8/2,*/4,23-8,23-8/2"����������
    static const char * parse_field(char * const ary, int modvalue, int off, const char *ptr);
    
    void fixdaydow();
    
private:
    char    m_mins[60];	/* 0-59 				*/
    char    m_hrs[24];	/* 0-23					*/
    char    m_days[32];	/* 1-31					*/
    char    m_mons[12];	/* 0-11 				*/
    char    m_dow[7];	/* 0-6, beginning sunday		*/
};

#endif // ~__TIMEKIT_H

