#include "nIniFile.h"
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <stdlib.h>
 using namespace std;
analyzeini::analyzeini(strMap & strmap):m_pmap(&strmap) 
{
}
void analyzeini::operator() (const string & in_strini)  {
    string strini = in_strini;
    string::size_type first = 0;
    string::size_type last = 0;
    
        // ȥ��#��ע��
        while (1)
        
    {
        if ((first = strini.find_first_of("#", first)) == string::npos)
            break;
        
            // ��\#תΪ#
            if (strini[first - 1] == '\\')
            
        {
            
                // ɾ��'\'
                strini.erase(first - 1, 1);
            
                // ��#��֮��ʼ��ƥ��ע��
                first++;
            continue;
        }
        strini.erase(first);
        break;
    }
    
        // ����[]
        first = strini.find('[');
    last = strini.rfind(']');
    if ((first != string::npos) && 
          (last != string::npos) && (first != last + 1))
        
    {
        
            // ȥ��[]�е�ǰ��ո�
            first = strini.find_first_not_of(" \t", first + 1);
        last = strini.find_last_not_of(" \t", last - 1);
        if ((first != string::npos) && 
              (last != string::npos) && (first != last + 1))
            
        {
            m_strsect = strini.substr(first, last - first + 1);
        }
        return;
    }
    if (m_strsect.empty())
        return;
    string strkey;            // key
    string strvalue;            // value
    
        // ����key=value
        if ((first = strini.find('=')) == string::npos)
        
    {
        strkey = strini;
        
            // ��ȥkeyǰ��Ŀ��ַ�
            first = strkey.find_first_not_of(" \t");
        last = strkey.find_last_not_of(" \t");
        if ((first == string::npos) || (last == string::npos))
            return;
        strkey = strkey.substr(first, last - first + 1);
    }
    
    else
        
    {
        strkey = strini.substr(0, first);
        strvalue = strini.substr(first + 1, string::npos);
        
            // ��ȥkeyǰ��Ŀ��ַ�
            first = strkey.find_first_not_of(" \t");
        last = strkey.find_last_not_of(" \t");
        if ((first == string::npos) || (last == string::npos))
            return;
        strkey = strkey.substr(first, last - first + 1);
        
            // ��ȥvalueǰ��Ŀ��ַ�
            first = strvalue.find_first_not_of(" \t");
        last = strvalue.find_last_not_of(" \t");
        if ((first == string::npos) || (last == string::npos))
            return;
        strvalue = strvalue.substr(first, last - first + 1);
    }
    
        // section_____***_______key ���
        (*m_pmap)[m_strsect + MIDDLESTRING + strkey] = strvalue;
    
        //cout<<"key= "<<m_strsect + MIDDLESTRING + strkey<<" value= "<<strvalue<<endl;
        return;
}

CIniFile::CIniFile() 
{
}

CIniFile::CIniFile(const string & filename) 
{
    do_open(filename);
} CIniFile::~CIniFile() 
{
} bool CIniFile::open(const string & inipath) 
{
    return do_open(inipath);
}

string CIniFile::read(const string & psect, const string & pkey) 
{
    strMapIt it = m_inimap.find(psect + MIDDLESTRING + pkey);
    if (it == m_inimap.end())
        return "";
    
    else
        return it->second;
}
int CIniFile::get_value(const string & psect, const string & pkey,
                          char *value, size_t size) 
{
    memset(value, 0, size);
    read(psect, pkey).copy(value, size);
    return 0;
}
int CIniFile::get_value(const string & psect, const string & pkey,
                          int *value) 
{
    *value = atoi(read(psect, pkey).c_str());
    return 0;
}
int CIniFile::get_value(const string & psect, const string & pkey,
                          long *value) 
{
    *value = atol(read(psect, pkey).c_str());
    return 0;
}
int CIniFile::get_value(const string & psect, const string & pkey,
                          double *value) 
{
    *value = atof(read(psect, pkey).c_str());
    return 0;
}
int CIniFile::get_section(vector < string > &sec) 
{
    string tmp1, tmp2;
    for (strMapIt it = m_inimap.begin(); it != m_inimap.end(); ++it)
        
    {
        tmp2 = it->first.substr(0, it->first.find(MIDDLESTRING));
        if (tmp1 != tmp2)
            
        {
            sec.push_back(tmp2);
            tmp1 = tmp2;
        }
    }
    return 0;
}
int CIniFile::get_key(const string & in_sec, vector < string > &key) 
{
    string sec_mid = in_sec + MIDDLESTRING;
    for (strMapIt it = m_inimap.begin(); it != m_inimap.end(); ++it)
        
    {
        if (it->first.compare(0, sec_mid.length(), sec_mid) == 0)
            
        {
            key.push_back(it->first.substr(sec_mid.length()));
        }
    }
    return 0;
}

bool CIniFile::do_open(const string & inipath) 
{
    if (0 != access(inipath.c_str(), R_OK))
        
    {
        return false;
    }
    ifstream fin(inipath.c_str());
    if (!fin.is_open())
        
    {
        return false;
    }
    vector < string > strvect;
    while (!fin.eof())
        
    {
        string inbuf;
        getline(fin, inbuf, '\n');
        strvect.push_back(inbuf);
    }
    if (strvect.empty())
        
    {
        return false;
    }
    for_each(strvect.begin(), strvect.end(), analyzeini(m_inimap));
    return !m_inimap.empty();
}


