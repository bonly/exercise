/**
 * Copyright (C) 2002-2010  SunRise Co. Ltd
 *
 * File name: agentConfig.h
 * @Author: han chunguang
 * @Version: 
 * Description:
 * Log:
 */
 
#ifndef AGENT_CONFIG_H_
#define AGENT_CONFIG_H_

#ifndef AGENT_HOME
#define AGENT_HOME "AGENT_HOME"
#endif

// oid
static const char *__oid_fep_conn  = "1.3.6.1.4.1.31360.1.1.4.1.3.0";
static const char *__oid_casp      = "1.3.6.1.4.1.31360.1.1.2.1.4.0";
static const char *__oid_errorcode = "1.3.6.1.4.1.31360.1.1.4.4.2.1";

/* TimeStamp oid */
static const char g_ts_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.2";

/* pid oid */
static const char g_pid_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.3";

/* user oid */
static const char g_user_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.4";

/* ������ oid */
static const char g_proc_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.5";

/* ��Ϣ oid */
static const char g_msg_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.6";

/* ���̰汾 oid */
static const char g_ver_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.7";

/* �澯���� */
static const char g_warn_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.8";

/* agent_id */
static const char g_agentid_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.1";

/* ������ˮ */
static const char g_backupid_oid[] = "1.3.6.1.4.1.31360.1.1.4.1.9";

static const char g_open_file_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.2.1";  // 4
static const char g_close_file_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.2.2"; // 4
static const char g_open_dir_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.2.3";   // 4 
static const char g_close_dir_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.2.4";  // 4
static const char g_no_access_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.2.5";  // 4
static const char g_backup_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.2.6";     // 3
static const char g_pid_name_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.3.1";   // 3
static const char g_fork_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.3.2";       // 4
static const char g_exec_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.3.3";       // 4
static const char g_connect_nms_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.3.4"; // 4
static const char g_bind_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.3.5";        // 4
static const char g_connect_db_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.4.1";  // 4
static const char g_dirty_read_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.4.2";  // 4
static const char g_prepare_sql_oid[] = "1.3.6.1.4.1.31360.1.1.4.2.4.3"; // 4


#define PROG_STRAT 1001
#define PROG_START_FAILED 1002
#define PROG_CORE 1099
#define RESTART_INVALID 1096
#define RESTART_FAILE 1097
#define RESTART_OK 1098

#define SUCCESS 1
#define FAILE 2
#define NOEXE 3
#define NOEXIST 4
#define EXIST 5
#define NOPROC 6

#endif

