#include "nSystem.h"
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
 extern int errno;
void CSys::makeDaemon(void) 
{
    if (fork() > 0)
        
    {
        _exit(0);
    }
    setsid();
    if (fork() > 0)
        
    {
        _exit(0);
    }
}
const char *CSys::getLastError(void) 
{
    return strerror(errno);
}
const char *CSys::getError(int in_errno) 
{
    return strerror(in_errno);
}

bool CSys::getLastError(char *buf, int size) 
{
    if ((isPtr(buf) == false) || 
         (strncpy(buf, strerror(errno), size) != 0))
        
    {
        return false;
    }
    return true;
}


