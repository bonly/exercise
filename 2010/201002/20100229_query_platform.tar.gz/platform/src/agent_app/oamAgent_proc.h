#ifndef __OAMAGENT_PROC_H
#define __OAMAGENT_PROC_H

#include <string>

#include "oamAgent_base.h"
#include "nNetwork.h"
#include "type.h"




#define FDSIZE 32

using namespace std;

class CEpoll;


class oamAgent_proc : public oamAgent_base
{
public:
    oamAgent_proc();
    ~oamAgent_proc();
    
    virtual int parse(int argc, char *argv[]);
    
    virtual int initialize(void);
    
    virtual int mainProcess(void);
    
    virtual void destroy(void);
    
protected:
    void ProcCmdClient(int fd);
    bool ProcStart(char * buf);
    bool ProcStop(char * buf);
    bool ProcQuery(char * buf);
    bool ProcVersion(char *buf);
   
	bool StartListen();
 	
	bool Accept_Client();

	void SetFdStatus(int fd, int status);

	int RecvData(int fd);

	int get_message(char*buf, int fd);

	Con& GetTcpCon(int fd);

	int SendData(int fd, char* buf, int len);

	FDList& GetConnectionFd(int fd);

private:    
    string m_myip;
    int m_myport;
	    
	int m_listen_fd;
	FDList m_fd[FDSIZE];

	CEpoll* m_pepoll;
	
	time_t m_timeclock;

    // ��ط������Ķ�ָ����д���
    //CTcpServer m_agent;
};


#endif

