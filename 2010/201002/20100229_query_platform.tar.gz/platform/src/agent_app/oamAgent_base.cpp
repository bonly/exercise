#include <stdio.h>
#include <iostream>

#include "oamAgent_base.h"
#include "comm.h"
#include "agentConfig.h"
#include "nTime.h"
#include "nIniFile.h"
#include "nSystem.h"
#include "r5api.h"

using namespace std;

extern R5_Log g_r5_log;
extern int g_sigExit;


oamAgent_base::oamAgent_base():m_nRuntimes(0), m_uDelay(1), m_nSpeed(100),
m_nSpeedSleep(1)
{

}

int oamAgent_base::parse(int argc, char *argv[])
{
    return 0;
}

void oamAgent_base::run(void)
{
    if (m_nRuntimes < 0)
    {
        return;
    }

    int iRet = 0;

    if ((iRet = initialize()) != 0)
    {
        LOG_ERROR("initialize failed\n");
        return;
    }

    int ii = 0;                 // ��¼����
    int err_times = 0;          // ��¼��������

    CPassTime passtime;
    passtime.start();

    while (m_nRuntimes >= 0)
    {
        // ����˳�����
        if ((iRet = checkExit()) != 0)
        {
            checkExitStatus(iRet);
            LOG_ERROR("checkExit failed\n");
            break;
        }

        // �����ٶ�����
        if (ii++ > m_nSpeed)
        {
            if (passtime.elapsed() == 0)
            {
                ::sleep(m_nSpeedSleep);
            }

            passtime.start();
            ii = 0;
        }


        // ������
        if ((iRet = mainProcess()) != 0)
        {
            // ������ʧ��Ҫ�˳�����
            mainProcessStatus(iRet);
            LOG_ERROR("mainProcess failed\n");
            break;
        }


        // ���ѭ������
        if ((m_nRuntimes != 0) && (--m_nRuntimes <= 0))
        {
            LOG_INFO("cycle time over.\n");
            break;
        }

        if (m_uDelay > 0)
        {
            sleep();
        }
    }

    destroy();

    return;
}

void oamAgent_base::sleep(void)
{
    ::sleep(m_uDelay);
    return;
}

int oamAgent_base::checkExit(void)
{
    return 0;
}

int oamAgent_base::checkExitStatus(int retcode)
{
    return 0;
}

int oamAgent_base::initialize(void)
{
    return 0;
}

int oamAgent_base::mainProcess(void)
{
    return 0;
}

int oamAgent_base::mainProcessStatus(int retcode)
{
    return 0;
}

void oamAgent_base::destroy(void)
{
    return;
}

int oamAgent_base::set_conf_file(const char *conf_file)
{
    if (NULL != conf_file && strlen(conf_file) < 256)
    {
        strncpy(m_conf_file, conf_file, 255);
        return 0;
    }

    return -1;
}


int oamAgent_base::get_conf_file(char *conf_file, int buflen)
{
    if (NULL != conf_file && buflen > strlen(m_conf_file))
    {
        strncpy(conf_file, m_conf_file, buflen);
        return 0;
    }
    return -1;
}



int oamAgent_base::reloadConfig(void)
{
    if ('0' == m_conf_file[0])
        return -1;

    CIniFile ini;
    if (ini.open(m_conf_file) == false)
    {
        LOG_ERROR("open failed %s %s", m_conf_file, CSys::getLastError());
        return 1;
    }

    LOG_INFO("reload config.\n");

    int file_level = 40;
    int term_level = 100;
    file_level = atoi(ini.read("log", "log_level_file").c_str());
    term_level = atoi(ini.read("log", "log_level_term").c_str());

    SET_LOG_LEVEL(&g_r5_log, file_level, term_level);

    return 0;
}


void oamAgent_base::version()
{
    version();
}
