#ifndef __COMM_H
#define __COMM_H

#include <stdlib.h>

#ifndef AGENT_HOME
#define AGENT_HOME "AGENT_HOME"
#endif

#ifndef PROGRAM_NAME
#define PROGRAM_NAME "unknow"
#endif

#ifndef PROGRAM_VERSION
#define PROGRAM_VERSION "unknow"
#endif

#ifndef OPENING_TIME
#define OPENING_TIME "unknow"
#endif

#ifndef TEST_TIME
#define TEST_TIME "unknow"
#endif

#ifndef SOURCES
#define SOURCES "unknow"
#endif

static void version()
{
    printf("Module: %s\n"
           "Version: %s\n"
           "Opening time: %s\n"
           "Test Time: %s\n"
           "Sources: %s\n", PROGRAM_NAME, PROGRAM_VERSION, OPENING_TIME, TEST_TIME, SOURCES);
}

#endif
