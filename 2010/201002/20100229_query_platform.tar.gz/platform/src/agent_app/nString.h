#ifndef __NSTRING_H
#define __NSTRING_H

#include "config_nbase.h"

#include <string>
#include <vector>

using std::string;
using std::vector;


bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName, char *out_value, string::size_type in_StrLen);
bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName, int *out_value);
bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName, long *out_value);
bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName, float *out_value);
bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName, double *out_value);

#ifndef _ISDIGIT
    #define _ISDIGIT 0x10
#endif

inline unsigned char reverse8( unsigned char c )
{
    c = ( c & 0x55 ) << 1 | ( c & 0xAA ) >> 1;
    c = ( c & 0x33 ) << 2 | ( c & 0xCC ) >> 2;
    c = ( c & 0x0F ) << 4 | ( c & 0xF0 ) >> 4;
    return c;
}

class CStr
{
public:
    enum { npos = -1 };
    
    // �ж��Ƿ����ͻ��С�����ַ���
    inline static bool is_digit(const char *buf) {return((*buf & _ISDIGIT) ? 1 : (*buf =='.'));}
        
    // ת��Сд
    inline static char to_lower(unsigned char a) {return ((a >= 'A' && a <= 'Z') ? a+('a'-'A') : a );}
    
    // ת����д
    inline static char to_upper(unsigned char a) {return ((a >= 'a' && a <= 'z') ? a-('a'-'A') : a );}

    /** 
    * @brief Checks To See If A Char Or String Of Chars Is Numeric
    * 
    * @param chString In Char Or String Of Chars
    * 
    * @return This Function Checks To Is If A Char Or A String Of Chars Is Numeric Or Not
    */
    static bool is_numeric(const char *chString);

    /** 
    * @brief In Char Or String Of Chars,This Function Uppercases A Char Or Sting Of Chars
    * 
    * @param chString In Char Or String Of Chars
    * 
    * @return This Function Checks To Is If A Char Or A String Of Chars Is Numeric Or Not
    */
    static void uppercase(char *chString);			//Uppercases A Char Or String Of Chars

    /** 
    * @brief This Function Lowercases A Char Or Sting Of Chars
    * 
    * @param chString In Char Or String Of Chars
    * 
    * @return This Function Checks To Is If A Char Or A String Of Chars Is Numeric Or Not
    */
    static void lowercase(char *chString);			//Uppercases A Char Or String Of Chars

    /** 
    * @brief 
    * 
    * @param string 
    * @param accept 
    * 
    * @return 
    */
    static int find_first_of(const char * string, const char * accept);    
    
    /** 
    * @brief 
    * 
    * @param string 
    * @param abject 
    * 
    * @return 
    */
    static int find_first_not_of(const char * string, const char * abject);
    /** 
    * @brief 
    * 
    * @param string 
    * @param accept 
    * 
    * @return 
    */
    static int find_last_of(const char * string, const char * accept);
    
    /** 
    * @brief ��stringĩβ��ʼ���ҷ�abject���ַ�,�������±�,�±�ΪnposΪû�ҵ�.��֧������
    * 
    * @param string 
    * @param abject 
    * 
    * @return 
    */
    static int find_last_not_of(const char * string, const char * abject);

    /** 
    * @brief 
    * 
    * @param p 
    * @param m 
    * @param s 
    * 
    * @return 
    */
    static int replace(char *p, const char *m, char s);
    
    /** 
    * @brief 
    * 
    * @param s Դ�ַ�
    * @param s_len Դ�ַ�������
    * @param d Ŀ���ַ���
    * @param d_len Ŀ���ַ�������
    * @param start ��ʼ��ʶ
    * @param end ������ʶ
    * 
    * @return -1 sΪNULL;
              -2 ûƥ��start;
              -3 ûƥ��end;
              �ɹ�ƥ�䵫dΪNULL��d�ĳ��Ȳ�������򷵻�0;
              �ɹ�ƥ��start��end,���ؿ�����d���ֽ���  
    */
    static int trunc_m(const char *s, size_t s_len,
               char *d, size_t d_len,
               const char * const start, const char * const end);
               
    /** 
    * @brief 
    * 
    * @param s 
    * @param s_len 
    * @param d 
    * @param start 
    * @param end 
    * 
    * @return 
    */
    static int trunc_m(const char *s, size_t s_len,
               int *d,
               const char * const start, const char *const end);
    
    /** 
    * @brief 
    * 
    * @param s 
    * @param s_len 
    * @param d 
    * @param start 
    * @param end 
    * 
    * @return 
    */
    static int trunc_m(const char *s, size_t s_len,
               long *d,
               const char * const start, const char *const end);
    
    /** 
    * @brief 
    * 
    * @param s 
    * @param s_len 
    * @param d 
    * @param start 
    * @param end 
    * 
    * @return 
    */
    static int trunc_m(const char *s, size_t s_len,
               float *d,
               const char * const start, const char *const end);
    
    /** 
    * @brief 
    * 
    * @param s 
    * @param s_len 
    * @param d 
    * @param start 
    * @param end 
    * 
    * @return 
    */
    static int trunc_m(const char *s, size_t s_len,
               double *d,
               const char * const start, const char *const end);
    
    /** 
    * @brief �س��ַ���pĩβ��mode�е������ַ���,��֧������
    * 
    * @param p 
    * @param p_len 
    * @param mode 
    * @param mode_len 
    * 
    * @return 
    */
    static int trunc_r(char *p, size_t p_len, const char * mode);
    
    /** 
    * @brief 
    * 
    * @param p 
    * @param mode 
    * 
    * @return 
    */
    static int trunc_r(string &p, const char * mode);
    
    /** 
    * @brief 
    * 
    * @param p 
    * @param p_len 
    * @param mode 
    * 
    * @return 
    */
    static int trunc_l(char *p, size_t p_len, const char *mode);
    
    /** 
    * @brief 
    * 
    * @param p 
    * @param mode 
    * 
    * @return 
    */
    static int trunc_l(string &p, const char * mode);
    
private:
    CStr();
    CStr(const CStr &);
    ~CStr();
};

class CSplitStr
{
public:
    typedef vector<string*> vec_pstr;
    typedef vec_pstr::iterator iterator;
    typedef vec_pstr::const_iterator const_iterator;
        
    CSplitStr();
    CSplitStr(const CSplitStr & split);
    ~CSplitStr();
    
    CSplitStr & operator = (const CSplitStr &split);
    
//    // �������ַ�����ַ���
//    vec_pstr::size_type Split(const char * str_begin, string::size_type length, const char delimit);
    
    // ��һ���ַ�������ַ���
    vec_pstr::size_type split(const char * str_begin, string::size_type length, const char *delimit);

    // �����Ȳ���ַ���
    vec_pstr::size_type split(const char * str_begin, string::size_type length, int size);

    // ��ÿ�ֶγ��Ȳ���ַ���
    vec_pstr::size_type split(const char * str_begin, string::size_type length, vector<int> spec);
        
    // �±곬���ʱ���طָ���
    const string & operator [](const int &index) const
    //{ return (((index >=0 ) && (index < size())) ? *(m_strs[index]) : CSplitStr::nullstring); }
    { return *(m_strs.at(index)); }
    
    string & operator [](const int &index)
    //{ return (((index >=0 ) && (index < size())) ? *(m_strs[index]) : CSplitStr::nullstring); }
    { return *(m_strs.at(index)); }

    // �ͷ��ڲ���Դ    
    void release();
    
    // ��ֺ���ֶθ���
    vec_pstr::size_type size() const { return m_strs.size(); }
    
    iterator begin() { return m_strs.begin(); }
    const_iterator begin() const { return m_strs.begin(); }

    iterator end()   { return m_strs.end(); }
    const_iterator end() const { return m_strs.end(); }

    iterator erase(iterator &loc);
        
    // �ָ���
    const string & delimit() const { return m_delimit; }
    
private:
    string m_delimit;
    
    vec_pstr m_strs;
    static const string nullstring;
};


#endif // ~__STRINGKIT_H

