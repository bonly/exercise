#ifndef __OAMAGENT_KPI_H
#define __OAMAGENT_KPI_H

#include <string>

#include "oamAgent_base.h"

using namespace std;

class oamAgent_kpi : public oamAgent_base
{
public:
    oamAgent_kpi();
    ~oamAgent_kpi();
    
    virtual int parse(int argc, char *argv[]);
    
    virtual int initialize(void);
    
    virtual int mainProcess(void);
    
    virtual void destroy(void);
    
protected:
    int ProcMsg(void);
    
private:    
 	int m_msgid;   
	string m_gearman_path;
	string m_gearman_server;
	string m_gearman_key;
	string m_gearman_encry;

};


#endif

