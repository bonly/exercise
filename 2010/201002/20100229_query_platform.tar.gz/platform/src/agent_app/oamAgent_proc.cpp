#include <unistd.h>
#include "agentConfig.h"
#include <iostream>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/epoll.h>
#include <errno.h>

#include "nSystem.h"
#include "nIniFile.h"
#include "net_buffer.h"
#include "cepoll.h"

#include "oamAgent_proc.h"
#include "kpi_if.h"
#include "public_signal.h"
#include "nString.h"
#include "r5api.h"

using namespace std;

extern char *optarg;


static bool init_signals();
//static void catch_sig(int signo);

int g_client_limit = 1;
char g_conf_file[256] = { 0 };
string g_logfile;


int g_sigExit = 0;
R5_Log g_r5_log;


int main(int argc, char *argv[])
{
    oamAgent_proc proc;

    if (proc.parse(argc, argv) != 0)
    {
        return 0;
    }

    if (INIT_KPI("oamAgent_proc", g_conf_file) < 0)
    {
        printf("INIT KPI failed.\n");
        return -1;
    }

    proc.set_conf_file(g_conf_file);
    proc.run();

    LOG_DEBUG("checking catched signal %d\n", g_sigExit);


    SEND_EVEN_KPI("program exit", 2);

    return 0;
}

oamAgent_proc::oamAgent_proc():m_myip("0.0.0.0"), m_myport(19812),
m_listen_fd(0)
{
}

oamAgent_proc::~oamAgent_proc()
{
	for(int i = 0; i < FDSIZE; i++)
	{
		if(m_fd[i].user_con.status == Con::Connected)
		{
			m_pepoll->delete_fd(i);
			close(i);
			SetFdStatus(i, Con::Broken);
		}
		
	}

	if(m_listen_fd > 0)
    	close(m_listen_fd);

	if(m_pepoll)
	{
		delete m_pepoll;
		m_pepoll = NULL;
	}
}

bool oamAgent_proc::StartListen()
{
    struct sockaddr_in server_addr;

    if (m_listen_fd != 0)
    {
        LOG_INFO("reset client listen port!\n");
        m_pepoll->delete_fd(m_listen_fd);
        close(m_listen_fd);
        m_listen_fd = 0;
    }

    m_listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (m_listen_fd < 0)
    {
        int err = errno;
        LOG_ERROR("create client Listen port failed![%d, %s]\n", err,
                  strerror(err));
        return false;
    }

    if (RE_SUCCESS !=
        m_pepoll->add_fd(m_listen_fd, EPOLLIN | EPOLLET | EPOLLERR))
    {
        LOG_ERROR("add m_listen_fd to epoll failed! fd = %d \n",
                  m_listen_fd);
        return false;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(m_myport);
    if (m_myip.empty())
    {
        server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    else
    {
        //int inet_pton(int af, const char *src, void *dst);
        inet_pton(AF_INET, m_myip.c_str(), &server_addr.sin_addr);
    }

    int opt = 1;
    if (setsockopt
        (m_listen_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
    {
        close(m_listen_fd);
        int err = errno;
        LOG_ERROR
            ("[setsockopt SO_REUSEADDR error] client listen sock![%d, %s]\n",
             err, strerror(err));
        return false;
    }

    if (bind(m_listen_fd, (sockaddr *) & server_addr, sizeof(server_addr))
        < 0)
    {
        close(m_listen_fd);
        int err = errno;
        LOG_ERROR("bind client Listen ip![%d, %s]\n", err, strerror(err));
        return false;
    }

    if (listen(m_listen_fd, LISTENMAX) < 0)
    {
        close(m_listen_fd);
        int err = errno;
        LOG_ERROR("client Listen error![%d, %s]\n", err, strerror(err));
        return false;
    }

    LOG_INFO("Port [%s:%d] Start Listen![cli_lsn fd = %d]\n",
             m_myip.c_str(), m_myport, m_listen_fd);

    return true;
}

int oamAgent_proc::parse(int argc, char *argv[])
{
    memset(g_conf_file, 0, sizeof(0));
    int optch = 0;
    while ((optch = getopt(argc, argv, "vi:p:c:l:h")) != -1)
    {
        switch (optch)
        {
        case 'v':
            version();
            return 1;
        case 'i':
            // ��IP,��Զ�IP�ķ�����
            m_myip = optarg;
            break;
        case 'p':
            // �����˿ںţ�Ĭ��19812
            m_myport = atoi(optarg);
            break;
        case 'c':
            strncpy(g_conf_file, optarg, sizeof(g_conf_file) - 1);
            break;
        case 'l':
            g_logfile = optarg;
            break;
        case 'h':
            cout <<
                "oamAgent_proc [-i my IP] [-p my port] [-c configure file] [-l logfile]"
                << endl;
            return 2;
        }
    }

    if ('\0' == g_conf_file[0])
    {
        printf("Usage:\n./oamAgent_proc -c conf_file\n");
        return -1;
    }

    return 0;
}


bool oamAgent_proc::Accept_Client()
{
    struct sockaddr_in client_addr;
    socklen_t addrlen = sizeof(client_addr);
    int accept_fd =
        accept(m_listen_fd, (struct sockaddr *) &client_addr, &addrlen);
    if (accept_fd < 0)
    {
        //���ź��ж�
        if (errno == EINTR)
        {
            if (Signal::HandleSignal() < 0)
                return false;
        }
        else
        {
            //��������
            return false;
        }
    }
    else
    {


        char ipbuf[32] = { 0 };
        inet_ntop(AF_INET, &(client_addr.sin_addr), ipbuf, sizeof(ipbuf));

        LOG_INFO("receiver a connection from[%s:%d]\n", ipbuf,
                 ntohs(client_addr.sin_port));


        if (accept_fd > FDSIZE || g_client_limit <= 0)
        {
            LOG_ERROR("FD abnormity, too large![fd=%d]\n", accept_fd);
            close(accept_fd);
            return false;
        }

        FDList & hfd = GetConnectionFd(accept_fd);
        hfd.type = USER_SOCK;
		SetFdStatus(accept_fd, Con::Connected);

        if (0 != m_pepoll->add_fd(accept_fd, EPOLLIN | EPOLLET | EPOLLERR))
        {
            LOG_ERROR("add newsock to poll failed! fd = %d \n", accept_fd);
            return false;

        }

        g_client_limit--;
    }

    return true;
}


int oamAgent_proc::initialize(void)
{
    if (oamAgent_base::initialize() != 0)
    {
        return 1;
    }

    if (init_signals() == false)
    {
        return 1;
    }

    if (g_logfile.empty() == true)
    {
        char config[256] = { 0 };
        if (get_conf_file((char *) config, sizeof(config)) < 0
            || strlen(config) <= 0)
            return -1;

        CIniFile ini;
        if (ini.open(config) == false)
        {
            cout << "open failed " << config << CSys::
                getLastError() << endl;
            return 1;
        }

        g_logfile = ini.read("log", "log_path");
    }

    INIT_LOG(&g_r5_log, g_logfile.c_str(), "agent_proc", 40, 40)
        reloadConfig();

    m_pepoll = new CEpoll(10, 10, 100 /*���� */ );
    if (NULL == m_pepoll)
    {
        LOG_ERROR("new CEpoll Failed.\n");
        return -1;
    }

    if (RE_SUCCESS != m_pepoll->init())
    {
        LOG_ERROR("m_pepoll init failed.\n");
        return -1;
    }

    if (!StartListen())
    {
        SEND_EVEN_KPI("listen faield, program exit.", 2);
        LOG_ERROR("listen failed.\n");
        return -1;
    }
	
	m_timeclock = time(NULL);
	
    return 0;
}


static bool init_signals()
{
    //�˳�
    if (my_signal(SIGTERM, Signal::SigTerm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM,
                strerror(errno));
        return -1;
    }

    //�˳�
    if (my_signal(SIGINT, Signal::SigTerm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM,
                strerror(errno));
        return -1;
    }


    //�ض�����    
    if (my_signal(SIGHUP, Signal::SigHup, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }


    //ˢ����־
    if (my_signal(SIGUSR2, Signal::SigUsr2, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }

    /* ALARM�ж�Ӧ��������  */
    if (my_signal(SIGALRM, Signal::SigAlarm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }


    /* PIPE�ж�Ӧ���������� */
    if (my_signal(SIGPIPE, Signal::SigPipe, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }

    //����
    if (my_signal(SIGCHLD, Signal::SigChild, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }

    //����
    if (my_signal(SIGUSR1, SIG_IGN, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR1,
                strerror(errno));
        return -1;
    }
    return true;
}

FDList & oamAgent_proc::GetConnectionFd(int fd)
{
    return m_fd[fd];
}

int oamAgent_proc::mainProcess(void)
{
    if (g_sigExit)
        return -1;

	time_t tmp_time = time(NULL);
	if(tmp_time - m_timeclock >= 30)
	{
		SEND_EVEN_KPI("just heart beat", 0);
		m_timeclock = tmp_time;
		LOG_INFO("just heart beat.\n");
	}

    vector < CEpoll::EpollEve > EV;


    if (RE_SUCCESS != m_pepoll->wait(EV))
    {
        LOG_ERROR("EPOLL wait faield.\n");
        return -1;
    }

    vector < CEpoll::EpollEve >::iterator iter;

    for (iter = EV.begin(); iter != EV.end(); ++iter)
    {
        if (iter->fd == m_listen_fd)
        {
            if (iter->events & EPOLLIN)
            {
                Accept_Client();
            }
            continue;
        }

        FDList & hfd = GetConnectionFd(iter->fd);
        if (hfd.type == USER_SOCK)
        {
            if (iter->events & EPOLLIN)
            {
                RecvData(iter->fd);
            }
            if (iter->events & EPOLLERR
                || hfd.user_con.status == hfd.user_con.Broken)
            {
				if(iter->events & EPOLLERR)
				{
					LOG_DEBUG("iter->events & EPOLLERR\n");
				}
				else
				{
					LOG_DEBUG("Broken\n");
				}	
					
                int tmp_fd = iter->fd;
				close(tmp_fd);
                m_pepoll->delete_fd(tmp_fd);
				hfd.user_con.status = hfd.user_con.Broken;
                g_client_limit++;
                LOG_INFO("client error, close fd[%d]\n", tmp_fd);
                continue;
            }

        }

    }


    if (Signal::HandleSignal() < 0 || g_sigExit)
    {
        return -1;
    }

    return 0;
}

void oamAgent_proc::SetFdStatus(int fd, int status)
{
    Con & hcon = GetTcpCon(fd);
    hcon.status = status;
}


int oamAgent_proc::RecvData(int fd)
{
    Con & hcon = GetTcpCon(fd);

    char *writeptr = hcon.cbuf.buffer.get_write_ptr();
    int size = hcon.cbuf.buffer.get_free_size();

    int rlen = 0;

    rlen = recv(fd, writeptr, size, 0);
    if (rlen == 0)
    {
        //�Է��Ͽ�����
        SetFdStatus(fd, hcon.Broken);
        LOG_ERROR("recv data from client len=%d \n", rlen);
        return -1;
    }
    else if (rlen < 0)
    {
		SetFdStatus(fd, hcon.Broken);
        LOG_WARN("recv data from client len=%d \n", rlen);
        return -1;
    }

    LOG_DEBUG("recv len = %d\n", rlen);

    //* ���¼�����ջ�������С
    hcon.cbuf.buffer.set_write_size(rlen);

    ProcCmdClient(fd);
}

void oamAgent_proc::destroy(void)
{
}

int oamAgent_proc::get_message(char *buf, int fd)
{
    Con & hcon = GetTcpCon(fd);

    int data_size = hcon.cbuf.buffer.get_data_size();

    /* ��Ϣͷ�ĳ����ֶ�δ���� */
    if (4 > data_size)
    {
        return -1;
    }

    const char *readptr = hcon.cbuf.buffer.get_read_ptr();
    char tmp[8] = { 0 };
    memcpy(tmp, readptr, 4);
    int len = atoi(tmp);

    if (data_size >= len)       /* ���������Ѿ���һ����������Ϣ */
    {
        memcpy(buf, readptr + 4, len - 4);
        hcon.cbuf.buffer.set_read_size(len);    /* ���¼�����ջ�������С */
    LOG_INFO("have one intact message. len = %d msg = %s\n", len, buf)}

    return 0;

}

Con & oamAgent_proc::GetTcpCon(int fd)
{
    return m_fd[fd].user_con;
}

int oamAgent_proc::SendData(int fd, char *buf, int len)
{
    int ret = 0;
    if (len <= 0)
        return 0;

    while (1)
    {
        int slen = send(fd, buf + ret, len - ret, 0);
        if (slen < 0)
        {
            if (errno == EINTR)
                continue;
            else if (errno == EAGAIN || errno == EWOULDBLOCK)
                break;
            else
            {
                int iErrno = errno;
                LOG_ERROR("send data error:[%d, %s]\n", iErrno,
                          strerror(iErrno));
                SetFdStatus(fd, Con::Broken);
                return 0;
            }
        }

        ret += slen;
        if (ret == len)
            break;
    }

	LOG_INFO("send success, send len = %d\n", ret);

    return ret;
}

void oamAgent_proc::ProcCmdClient(int fd)
{
    char buf[TCPBUFLEN];

    for (;;)
    {

        if (Signal::HandleSignal() < 0)
        {
            return;
        }

        if (g_sigExit)
            break;

        memset(buf, 0, sizeof(buf));
        if (get_message(buf, fd) < 0)
        {
            break;
        }

        int type = 0;

        if (GetXMLBuffer(buf, "type", &type) == false)
        {
            LOG_DEBUG("no type");
        }

        LOG_DEBUG("type = %d\n", type);

        switch (type)
        {
        case 1:
            //��������
            if (ProcStart(buf) == false)
            {
                //return;
            }
            break;
        case 2:
            // �����˳�
            if (ProcStop(buf) == false)
            {
                //return;
            }
            break;
        case 3:
            // ��ѯ����״̬
            if (ProcQuery(buf) == false)
            {
                //return;
            }
            break;
        case 4:
            // ��ѯ���̰汾
            if (ProcVersion(buf) == false)
            {
            }
            break;
        default:
            LOG_WARN("no type %d\n", type);
            snprintf(buf, sizeof(buf), "<retcode>%d</retcode>", NOEXE);
            break;
        }

        size_t len = strlen(buf);
        if (len > 0)
        {
            char tmpbuf[256] = { 0 };
            snprintf(tmpbuf, sizeof(tmpbuf), "%04d%s", len + 4, buf);
            LOG_INFO("befre SendData, len = %d buf=%s\n", len + 4, tmpbuf);
            if (SendData(fd, tmpbuf, len + 4) != 0)
            {
                break;
            }
        }
        else
        {
            // ProcStop ProcStart ProcQuery ProcAlarmû����дbuf�����
        }
    }                           // ~for (;;)

    return;
}

bool oamAgent_proc::ProcStart(char *buf)
{
    char path_name[256];        // �����еĳ���·��
    char param[100];
    char cmd[512];
    int max = 0;
    int ret = -1;
    pid_t pid = -1;
    FILE *fd = 0;
    int uid = 0;

    memset(path_name, 0, sizeof(path_name));
    memset(param, 0, sizeof(param));

    if ((GetXMLBuffer(buf, "name", path_name, sizeof(path_name)) == false)
        || (GetXMLBuffer(buf, "param", param, sizeof(param)) == false)
        || (GetXMLBuffer(buf, "max", &max) == false))
    {
        LOG_DEBUG("less name,param,max");

        ret = NOEXE;
        goto end;
    }

    LOG_DEBUG("name:%s param:%s max:%d\n", path_name, param, max);


    // ע��forkʱ�ļ�������
    // ps���½����� ps -fu `id -un` |grep bash |wc -l
    memset(cmd, 0, sizeof(cmd));

    uid = getuid();

    if (strlen(param) == 0)
    {
        //snprintf(cmd, sizeof(cmd), "ps -fu %d |grep -v grep |grep ' %s' |wc -l", uid, path_name);
        snprintf(cmd, sizeof(cmd),
                 "ps -u %d -o args|grep -v grep |sed 's/ $//'|grep '%s$' |wc -l",
                 uid, path_name);
    }
    else
    {
        //snprintf(cmd, sizeof(cmd), "ps -fu %d |grep -v grep |grep ' %s %s' |wc -l", uid, path_name, param);
        snprintf(cmd, sizeof(cmd),
                 "ps -u %d -o args|grep -v grep |sed 's/ $//'|grep '%s %s$' |wc -l",
                 uid, path_name, param);
    }

    fd = popen(cmd, "r");
    if (fd == NULL)
    {
        LOG_ERROR("popen failed %s %s", cmd, strerror(errno));

        ret = NOPROC;
        goto end;
    }

    memset(cmd, 0, sizeof(cmd));
    fgets(cmd, (int) sizeof(cmd), fd);
    fclose(fd);
    if (atoi(cmd) >= max)
    {
        LOG_WARN("running instance %d\n", atoi(cmd));

        ret = NOEXE;
        goto end;
    }

    if (access(path_name, X_OK | F_OK) != 0)
    {
        LOG_WARN("access failed %s\n", path_name);

        ret = NOEXE;
        goto end;
    }

    pid = fork();

    if (0 == pid)
    {
        close(m_listen_fd);
        g_r5_log.logOnlyClose();

        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd), "%s %s", path_name, param);
        LOG_DEBUG("exec %s", cmd);


        CSplitStr cmdparam;
        cmdparam.split(cmd, strlen(cmd), " ");

        char **argv = new char *[cmdparam.size() + 1];

        int j = 0;
        for (int i = 0; i < cmdparam.size(); i++)
        {
            if (cmdparam[i].size() == 0)
                continue;

            argv[j] = new char[cmdparam[i].size() + 1];
            strncpy(argv[j], cmdparam[i].c_str(), cmdparam[i].size() + 1);
            j++;
        }

//argv[cmdparam.Size()]=0;
        argv[j] = 0;

        setpgrp();

        if (execv(cmdparam[0].c_str(), argv) == -1)
        {
            SEND_EVEN_KPI(strerror(errno), 2);
        }

    }
    else if (pid > 0)
    {
        ret = SUCCESS;
        goto end;
    }
    else                        //if (pid < 0)
    {
        LOG_WARN("fork false %s\n", strerror(errno));
        SEND_EVEN_KPI(strerror(errno), 2);
        ret = FAILE;
        goto end;
    }

  end:
    memset(buf, 0, sizeof(buf));
    snprintf(buf, TCPBUFLEN, "<retcode>%d</retcode>", ret);

    LOG_DEBUG("in ProcStart, buf = %s\n", buf);

    return (ret == FAILE) ? false : true;
}

bool oamAgent_proc::ProcStop(char *buf)
{
    pid_t pid = 0;
    int ret = -1;
    FILE *fd = 0;
    char path_name[256];
    char param[100];
    char cmd[512];
    int uid = 0;

    memset(path_name, 0, sizeof(path_name));
    memset(param, 0, sizeof(param));

    if ((GetXMLBuffer(buf, "pid", &pid) == false) ||
        (GetXMLBuffer(buf, "name", path_name, sizeof(path_name)) == false)
        || (GetXMLBuffer(buf, "param", param, sizeof(param)) == false))
    {
        LOG_WARN("less pid,name,param");

        ret = NOEXE;
        goto end;
    }

    if (0 >= pid)
    {
        LOG_WARN("pid(%d)", pid);

        ret = NOEXE;
        goto end;
    }

    memset(cmd, 0, sizeof(cmd));

    uid = getuid();

    if (strlen(param) == 0)
    {
        //snprintf(cmd, sizeof(cmd), "ps -fu %d |grep -v grep |grep '%d.*%s'|wc -l", uid, pid, path_name);
        snprintf(cmd, sizeof(cmd),
                 "ps -u %d -o pid,args |sed 's/ $//'|grep '%d.*%s$'|wc -l",
                 uid, pid, path_name);
    }
    else
    {
        //snprintf(cmd, sizeof(cmd), "ps -fu %d |grep -v grep |grep '%d.*%s %s'|wc -l", uid, pid, path_name, param);
        snprintf(cmd, sizeof(cmd),
                 "ps -u %d -o pid,args |sed 's/ $//'|grep '%d.*%s %s$'|wc -l",
                 uid, pid, path_name, param);
    }

    fd = popen(cmd, "r");
    if (fd == NULL)
    {
        LOG_ERROR("popen failed %s %s", cmd, strerror(errno));

        ret = NOPROC;
        goto end;
    }

    memset(cmd, 0, sizeof(cmd));
    if (fgets(cmd, (int) sizeof(cmd), fd) != cmd)
    {
        LOG_ERROR("fgets failed %s", strerror(errno));

        ret = NOPROC;
        fclose(fd);
        goto end;
    }

    fclose(fd);
    if (atoi(cmd) <= 0)
    {
        LOG_WARN("no process pid(%d) path_name(%s) param(%s)", pid,
                 path_name, param);

        ret = NOEXE;
        goto end;
    }

    if (kill(pid, SIGTERM) != 0)
    {
        ret = FAILE;
        goto end;
    }
    else
    {
        ret = SUCCESS;
        goto end;
    }

  end:
    memset(buf, 0, TCPBUFLEN);
    snprintf(buf, TCPBUFLEN, "<retcode>%d</retcode>", ret);

    return true;
}

bool oamAgent_proc::ProcQuery(char *buf)
{
    pid_t pid = 0;
    int ret = -1;
    char path_name[256];        // �����еĳ���·��
    char param[100];
    char cmd[512];
    int uid = 0;
    FILE *fd = NULL;

    memset(path_name, 0, sizeof(path_name));
    memset(param, 0, sizeof(param));
    if ((GetXMLBuffer(buf, "name", path_name, sizeof(path_name)) == false)
        || (GetXMLBuffer(buf, "param", param, sizeof(param)) == false))
    {
        LOG_ERROR("less pid,name,param");

        ret = NOEXE;
        goto end;
    }

    memset(cmd, 0, sizeof(cmd));
    uid = getuid();

    if (strlen(param) == 0)
    {
        //snprintf(cmd, sizeof(cmd), "ps -fu %d |grep -v grep |grep '%d.*%s'|wc -l", uid, pid, path_name);
        snprintf(cmd, sizeof(cmd),
                 "ps -u %d -o pid,args |grep -v grep|sed 's/ $//'|grep '.*%s$'",
                 uid, path_name);
    }
    else
    {
        //snprintf(cmd, sizeof(cmd), "ps -fu %d |grep -v grep |grep '%d.*%s %s'|wc -l", uid, pid, path_name, param);
        snprintf(cmd, sizeof(cmd),
                 "ps -u %d -o pid,args |grep -v grep|sed 's/ $//'|grep '.*%s %s$'",
                 uid, path_name, param);
    }

    fd = popen(cmd, "r");
    if (fd == NULL)
    {
        LOG_ERROR("popen failed %s %s", cmd, strerror(errno));

        ret = NOPROC;
        goto end;
    }

    memset(cmd, 0, sizeof(cmd));
    if (fgets(cmd, (int) sizeof(cmd), fd) != cmd)
    {
        LOG_ERROR("fgets false %s", strerror(errno));

        ret = NOPROC;
        fclose(fd);
        goto end;
    }

    fclose(fd);

    pid = atol(cmd);
    ret = SUCCESS;

  end:
    memset(buf, 0, TCPBUFLEN);
    snprintf(buf, TCPBUFLEN, "<retcode>%d</retcode><pid>%d</pid>", ret,
             pid);

    return true;
}

bool oamAgent_proc::ProcVersion(char *buf)
{
    char path_name[256];        // �����еĳ���·��
    char cmd[512];
    int ret = 0;
    FILE *fd = NULL;

    memset(path_name, 0, sizeof(path_name));
    memset(cmd, 0, sizeof(cmd));

    if (GetXMLBuffer(buf, "name", path_name, sizeof(path_name)) == false)
    {
        LOG_DEBUG("less name");

        ret = NOEXE;
        goto end;
    }

    snprintf(cmd, sizeof(cmd), "%s -v", path_name);

    fd = popen(cmd, "r");
    if (fd == NULL)
    {
        LOG_ERROR("popen failed %s %s", cmd, strerror(errno));

        ret = NOEXE;
        memset(cmd, 0, sizeof(cmd));
        goto end;
    }
    memset(cmd, 0, sizeof(cmd));
    fread(cmd, 1, (size_t) sizeof(cmd) - 1, fd);
    cmd[sizeof(cmd) - 1] = 0;
    fclose(fd);

    ret = SUCCESS;

  end:
    memset(buf, 0, TCPBUFLEN);
    snprintf(buf, TCPBUFLEN, "<retcode>%d</retcode><version>%s</version>",
             ret, cmd);

    return true;
}



int DoSigTerm()
{
    LOG_ERROR("interruptted by SIGTERM.\n");
    g_sigExit = 1;

    return 0;
}

int DoSigChild()
{
    LOG_ERROR("interruptted by SIGCHLD.\n");
    pid_t child_pid;
    int stat;

    while ((child_pid = waitpid(-1, &stat, WNOHANG)) > 0)
    {
        //g_client_limit++;
        //LOG_ERROR("g_client_limit = %d\n", g_client_limit);
    }

    //g_client_limit++;

    return 0;
}

int DoSigHup()
{
    LOG_ERROR("interruptted by SIGHUP.\n");
}

int DoSigUsr2()
{
    LOG_ERROR("interruptted by SIGUSR2.\n");
    return 0;
}


int DoSigAlarm()
{
    LOG_ERROR("interruptted by SIGALRM.\n");
    return 0;
}

int DoSigPipe()
{
    LOG_ERROR("interruptted by SIGPIPE.\n");
    return 0;
}
