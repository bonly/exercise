#include "nString.h"
#include "nSystem.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName,
                  char *out_value, string::size_type in_StrLen)
{
    char *start = NULL, *end = NULL;
    char m_SFieldName[50], m_EFieldName[50];

    string::size_type m_NameLen = strlen(in_FieldName);
    memset(m_SFieldName, 0, sizeof(m_SFieldName));
    memset(m_EFieldName, 0, sizeof(m_EFieldName));

    sprintf(m_SFieldName, "<%s>", in_FieldName);
    sprintf(m_EFieldName, "</%s>", in_FieldName);

    start = 0;
    end = 0;

    start = (char *) strstr(in_XMLBuffer, m_SFieldName);
    end = (char *) strstr(in_XMLBuffer, m_EFieldName);

    if ((start == 0) || (end == 0))
    {
        return false;
    }

    if ((out_value == NULL) || in_StrLen == 0)
    {
        return true;
    }

    string::size_type m_ValueLen = end - start - m_NameLen - 2 + 1;

    if ((m_ValueLen - 1) > in_StrLen)
        strncpy(out_value, start + m_NameLen + 2, in_StrLen);
    else
        strncpy(out_value, start + m_NameLen + 2, m_ValueLen - 1);

    return true;
}

bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName,
                  int *out_value)
{
    char value[15];
    memset(value, 0, sizeof(value));

    if (false ==
        GetXMLBuffer(in_XMLBuffer, in_FieldName, value, sizeof(value)))
    {
        return false;
    }

    *out_value = atoi(value);
    return true;
}

bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName,
                  long *out_value)
{
    char value[25];
    memset(value, 0, sizeof(value));

    if (false ==
        GetXMLBuffer(in_XMLBuffer, in_FieldName, value, sizeof(value)))
    {
        return false;
    }

    *out_value = atol(value);
    return true;
}

bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName,
                  float *out_value)
{
    char value[15];
    memset(value, 0, sizeof(value));

    if (false ==
        GetXMLBuffer(in_XMLBuffer, in_FieldName, value, sizeof(value)))
    {
        return false;
    }

    *out_value = (float) atof(value);
    return true;
}

bool GetXMLBuffer(const char *in_XMLBuffer, const char *in_FieldName,
                  double *out_value)
{
    char value[25];
    memset(value, 0, sizeof(value));

    if (false ==
        GetXMLBuffer(in_XMLBuffer, in_FieldName, value, sizeof(value)))
    {
        return false;
    }

    *out_value = atof(value);
    return true;
}

/**********************************************************************/

bool CStr::is_numeric(const char *chString)
{
    const char *buf = chString; //Temp Char VAR

    //Loop Through The Pointer Using The Inline Function IsDigit
    while (is_digit(buf))
    {
        buf++;                  //Increase The Pointer
    }

    return (bool) (*buf == 0x00);
}

void CStr::uppercase(char *chString)
{
    char *buf = chString;
    unsigned int i = 0;

    //Loop Through The Length Of The Pointer 
    while (*buf != 0x00)
    {
        chString[i] = to_upper(chString[i]);
        buf++;
        i++;
    }
}

void CStr::lowercase(char *chString)
{
    char *buf;
    unsigned int i = 0;

    //Loop Through The Length Of The Pointer 
    while (*buf != 0x00)
    {
        //Make The Temp VAR Set To The Lowercase Of The Input VAR
        chString[i] = to_lower(chString[i]);
        buf++;
        i++;
    }
}

int CStr::find_first_of(const char *string, const char *accept)
{
    unsigned char map[32];
    const char *str;
    int count;

    if ((isPtr(string) == false) || (isPtr(accept) == false))
        return -1;

    // ��string��ʼ
    str = string;

    /* Clear out bit map */
    for (count = 0; count < 32; count++)
        map[count] = 0;

    /* Set bits in control map */
    while (*accept)
    {
        map[*(unsigned char *) accept >> 3] |=
            (1 << (*(unsigned char *) accept & 7));
        accept++;
    }

    /* 1st char in control map stops search */
    map[0] |= 1;                /* null chars not considered */
    while (!
           (map[*(unsigned char *) str >> 3] &
            (1 << (*(unsigned char *) str & 7))))
    {
        // ָ��+1
        str++;
    }

    // ��ĩβ�򷵻�npos,���򷵻��±�
    return ((str >= string + strlen(string)) ? npos : (str - string));
}

int CStr::find_first_not_of(const char *string, const char *abject)
{
    unsigned char map[32];
    const char *str;
    int count;

    if ((isPtr(string) == false) || (isPtr(abject) == false))
        return -1;

    // ��string��ʼ
    str = string;

    /* Clear out bit map */
    for (count = 0; count < 32; count++)
        map[count] = 0;

    /* Set bits in control map */
    while (*abject)
    {
        map[*(unsigned char *) abject >> 3] |=
            (1 << (*(unsigned char *) abject & 7));
        abject++;
    }

    /* 1st char in control map stops search */
    map[0] |= 1;                /* null chars not considered */
    while ((map[*(unsigned char *) str >> 3] &
            (1 << (*(unsigned char *) str & 7))))
    {
        // ָ��+1
        str++;
    }

    // ��ĩβ�򷵻�npos,���򷵻��±�
    return ((str >= string + strlen(string)) ? npos : (str - string));
}

int CStr::find_last_of(const char *string, const char *accept)
{
    unsigned char map[32];
    const char *str;
    int count;

    if ((isPtr(string) == false) || (isPtr(accept) == false))
        return -1;

    // ��ĩβ��ʼ,'\0'ǰһλ
    str = string + strlen(string) - 1;

    /* Clear out bit map */
    for (count = 0; count < 32; count++)
        map[count] = 0;

    /* Set bits in control map */
    while (*accept)
    {
        map[*(unsigned char *) accept >> 3] |=
            (1 << (*(unsigned char *) accept & 7));
        accept++;
    }

    /* 1st char in control map stops search */
    //map[0] |= 1;    /* null chars not considered */ 
    while (!
           (map[*(unsigned char *) str >> 3] &
            (1 << (*(unsigned char *) str & 7))))
    {
        str--;

        if (str <= string)
            return npos;
    }

    // ����ʼ����npos,���򷵻��±�
    return (str - string);
}

int CStr::find_last_not_of(const char *string, const char *abject)
{
    unsigned char map[32];
    const char *str;
    int count;

    if ((isPtr(string) == false) || (isPtr(abject) == false))
        return -1;

    // ��ĩβ��ʼ,'\0'ǰһλ
    str = string + strlen(string) - 1;

    /* Clear out bit map */
    for (count = 0; count < 32; count++)
        map[count] = 0;

    /* Set bits in control map */
    while (*abject)
    {
        map[*(unsigned char *) abject >> 3] |=
            (1 << (*(unsigned char *) abject & 7));
        abject++;
    }

    /* 1st char in control map stops search */
    //map[0] |= 1;    /* null chars not considered */ 
    while (map[*(unsigned char *) str >> 3] &
           (1 << (*(unsigned char *) str & 7)))
    {
        str--;

        // ���ƥ�������ʼ,����npos
        if (str <= string)
            return npos;
    }

    // �����±�
    return (str - string);
}

int CStr::replace(char *str, const char *m, char s)
{
    char *p, *begin, *match;
    int ret;

    if ((isPtr(str) == false) || (isPtr(m) == false))
        return -1;

    match = str;

    // match������ģʽm
    if ((ret = find_first_of(match, m)) == npos)
        return 0;

    match[ret] = s;

    if (s == '\0')
        return 0;

    // ��ģʽ��һ�ַ���ʼ����ƥ��
    match += (ret + 1);

    p = match;
    begin = match;

    while (*match != '\0')
    {
        // ���ҷ�ģʽ��ʼ����
        if ((ret = find_first_not_of(match, m)) == npos)
        {
            // �����ڷ�ģʽ,�ض��ַ���
            *p = '\0';
            return 0;
        }

        if (ret == 0)
        {
            // �����ŷ�ģʽ�������������ģʽ����
            if ((ret = find_first_of(match, m)) == npos)
                return 0;

            p[ret] = s;
            p += (ret + 1);
            match += (ret + 1);

            continue;
        }

        // ��ҪǨ�Ƶ��ַ���ͷ��
        begin = match + ret;

        // ���ҷ�ģʽ��ĩβ����
        if ((ret = find_first_of(begin, m)) == npos)
        {
            // ���ַ�����β
            strcpy(p, begin);
            return 0;
        }

        // ����Ϊ0,��Ϊbegin���Ǵӷ�ģʽ��ʼ
//        if (ret == 0)
//        {
//            continue;
//        }

        if (p != begin)
            strncpy(p, begin, ret);

        p[ret] = s;
        p += (ret + 1);
        match = begin + ret;
    }

    //*--begin = '\0';
    return 0;
}

int CStr::trunc_m(const char *s, size_t s_len,
                  char *d, size_t d_len,
                  const char *const start, const char *const end)
{
    const char *const pe = s + s_len;   /* ָ��Դ��ĩβ */
    const char *pStart = start;
    const char *pEnd = end;

    /* �ַ���ԴΪ�� */
    if (s == NULL)
        return -1;

    /* ƥ�俪ʼģʽ */
    if (start == NULL)
    {
        pStart = s;             /* û�п�ʼģʽ */
    }
    else
    {
        if (((pStart = strstr(s, start)) == NULL) ||    /* û�ҵ���ʼģʽ */
            ((pStart += strlen(start)) > pe))   /* ģʽ����Դ�ķ�Χ */
            return -2;
    }

    /* ƥ��ĩβģʽ */
    if (end == NULL)
    {
        pEnd = pe;              /* û��ĩβģʽ */
    }
    else
    {
        if (((pEnd = strstr(pStart, end)) == NULL) ||   // û�ҵ�ĩβģʽ
            ((pEnd + strlen(end)) > pe))        /* ģʽ����Դ�ķ�Χ */
            return -3;
    }

    if ((d != NULL) && (d_len >= (pEnd - pStart)))
    {
        memset(d, 0, d_len);
        strncpy(d, pStart, pEnd - pStart);
        return (pEnd - pStart);
    }

    return 0;
}

int CStr::trunc_m(const char *s, size_t s_len,
                  int *d, const char *const start, const char *const end)
{
    char t[20];
    int ret = 0;

    ret = trunc_m(s, s_len, t, sizeof(t), start, end);

    if (ret < 0)
        return ret;

    if (isPtr(d))
    {
        *d = atoi(t);
    }

    return ret;
}

int CStr::trunc_m(const char *s, size_t s_len,
                  long *d, const char *const start, const char *const end)
{
    char t[20];
    int ret = 0;

    ret = trunc_m(s, s_len, t, sizeof(t), start, end);

    if (ret < 0)
        return ret;

    if (isPtr(d))
    {
        *d = atol(t);
    }

    return ret;
}

int CStr::trunc_m(const char *s, size_t s_len,
                  float *d, const char *const start, const char *const end)
{
    char t[20];
    int ret = 0;

    ret = trunc_m(s, s_len, t, sizeof(t), start, end);

    if (ret < 0)
        return ret;

    if (isPtr(d))
    {
        *d = static_cast < float >(atof(t));
    }

    return ret;
}

int CStr::trunc_m(const char *s, size_t s_len,
                  double *d,
                  const char *const start, const char *const end)
{
    char t[20];
    int ret = 0;

    ret = trunc_m(s, s_len, t, sizeof(t), start, end);

    if (ret < 0)
        return ret;

    if (isPtr(d))
    {
        *d = atof(t);
    }

    return ret;
}

int CStr::trunc_r(char *p, size_t p_len, const char *mode)
{
    int i = 0;

    if ((isPtr(p) == false) || (isPtr(mode) == false))
        return -1;

    i = CStr::find_last_not_of(p, mode);

    if (i != CStr::npos)
    {
        i++;
        p[i] = '\0';
        return (p_len - i);
    }
    else
    {
        p[0] = '\0';
        return p_len;
    }
}

int CStr::trunc_r(string & p, const char *mode)
{
    int i = 0;
    int p_len = p.length();

    if (isPtr(mode) == false)
        return -1;

    i = p.find_last_not_of(mode);

    if (i != string::npos)
    {
        i++;
        p.erase(i);
        return p_len - i;
    }
    else
    {
        p.clear();
        return p_len;
    }
}

int CStr::trunc_l(char *p, size_t p_len, const char *mode)
{
    int i = 0;

    if ((isPtr(p) == false) || (isPtr(mode) == false))
        return -1;

    i = CStr::find_first_not_of(p, mode);

    if (i != CStr::npos)
    {
        strncpy(p, p + i, p_len);
        return i;
    }
    else
    {
        p[0] = '\0';
        return p_len;
    }
}

int CStr::trunc_l(string & p, const char *mode)
{
    int i = 0;
    int p_len = p.length();

    if (isPtr(mode) == false)
        return -1;

    i = p.find_first_of(mode);

    if (i != string::npos)
    {
        i++;
        p.erase(0, i);
        return i;
    }
    else
    {
        p.clear();
        return p_len;
    }
}

/**********************************************************************/

const string CSplitStr::nullstring;

CSplitStr::CSplitStr():m_delimit("")
{
}

CSplitStr::CSplitStr(const CSplitStr & sp)
{
    operator=(sp);
}

CSplitStr::~CSplitStr()
{
    release();
}

CSplitStr & CSplitStr::operator =(const CSplitStr & sp)
{
    if (&sp != this)
    {
        m_delimit = sp.m_delimit;
        for (vec_pstr::const_iterator iter = sp.m_strs.begin();
             iter != sp.m_strs.end(); ++iter)
        {
            m_strs.push_back(new string(**iter));
        }
    }

    return *this;
}

void CSplitStr::release()
{
    vec_pstr::iterator iter = m_strs.begin();

    while (iter != m_strs.end())
    {
        iter = erase(iter);
    }

    m_delimit = "";
//    for (vec_pstr::iterator iter=m_strs.begin(); iter!= m_strs.end(); ++iter)
//    {
//        delete *iter;
//    }
//    
//    m_delimit = "";
//    m_strs.clear();
}

CSplitStr::iterator CSplitStr::erase(iterator & loc)
{
    // check range of the loc 
    if ((loc < m_strs.begin()) || (loc >= m_strs.end()))
    {
        return m_strs.begin();
    }

    if (*loc != NULL)
        delete *loc;

    return m_strs.erase(loc);
}

//CSplitStr::vec_pstr::size_type CSplitStr::Split(const char * str, int length, const char delimit)
//{
//    release();
//    
//    if (isPtr(str) == false)
//    {
//        return 0;
//    }
//    
//    const char *start = str;
//    char *end=NULL;
//    vec_pstr::size_type count=0;
//    
//    m_delimit=delimit;
//    
//    for(;;)
//    {
//        if (*start == NULL) break;
//        
//        end = (char*)strstr(start, &delimit);
//        
//        if (end == 0) break;
//        
//        m_strs.push_back(new string(start, end-start));
//
//        start = end + 1;
//        end=NULL;
//        count++;
//    }
//   
//    // ���һ�ֶκ���û�зָ���
//    if (*start != 0)
//    {
//        m_strs.push_back(new string(start, strlen(start) +1));
//        //m_strs.push_back(new string(start, strlen(start)));
//        count++;
//    }
//    
//    return count;
//}

CSplitStr::vec_pstr::size_type CSplitStr::split(const char *str_begin,
                                                string::size_type length,
                                                const char *delimit)
{
    release();

    if (isPtr(str_begin) == false)
        return 0;

    const char *const str_end = str_begin + length;
    const string::size_type delimit_len = strlen(delimit);

    const char *start = str_begin;
    const char *end = NULL;
    vec_pstr::size_type count = 0;

    m_delimit = delimit;

    for (;;)
    {
        if (start > str_end)
            break;

        end = (char *) strstr(start, delimit);

        // endûƥ�䣬��end�����ַ������ȣ���ƥ��ʱ����ָ������
        if ((end == 0) || (end > str_end) || (end + delimit_len > str_end))
            break;

        m_strs.push_back(new string(start, end - start));

        start = end + delimit_len;
        end = NULL;
        count++;
    }

    // ���һ�ֶκ���û�зָ���,����ָ������ַ�������β�ˣ���ָ�������Ҳ��һ������Ϊ0���ַ���
    if ((*start != 0) && (start <= str_end))
    {
        m_strs.push_back(new string(start, str_end - start));
        count++;
    }

    return count;
}

CSplitStr::vec_pstr::size_type CSplitStr::split(const char *str_begin,
                                                string::size_type length,
                                                int size)
{
    release();

    if (isPtr(str_begin) == false)
    {
        return 0;
    }

    const char *str = str_begin;
    vec_pstr::size_type count = 0;

    while (length > size)
    {
        m_strs.push_back(new string(str, size));

        str += size;
        length -= size;

        count++;
    }

    if (length > 0)
    {
        m_strs.push_back(new string(str, length));
        count++;
    }

    return count;
}

CSplitStr::vec_pstr::size_type CSplitStr::split(const char *str_begin,
                                                string::size_type length,
                                                vector < int >spec)
{
    release();

    if (isPtr(str_begin) == false)
    {
        return 0;
    }

    const char *str = str_begin;
    vec_pstr::size_type count = 0;

    for (int i = 0; i < spec.size(); i++)
    {
        // ����ָ������
        if (length < spec[i])
            break;

        m_strs.push_back(new string(str, spec[i]));

        str += spec[i];
        length -= spec[i];

        count++;
    }

    if (length > 0)
    {
        m_strs.push_back(new string(str, length));
        count++;
    }

    return count;
}
