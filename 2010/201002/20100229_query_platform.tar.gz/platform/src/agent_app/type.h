#ifndef __H_TYPE_H__
#define __H_TYPE_H__

#include "net_buffer.h"

//typedef unsigned long long uint64_t; 

#define MAX_FILE_LEN 256
#define IP_LENGTH 32

#define FD_SIZE 2048
#define BLOCK_CNT_MAX 16
#define PROTOCOL_HEAD_LEN 60

#define LISTENMAX 10
#define MAX_NODE_COUNT 10

#define FD_CLOSE 0
#define FD_SHUTDOWN 1

#define RE_SUCCESS 0
#define RE_FAILED -1

class RecvBuffer;

struct ConBuf
{
	enum 
	{//buf_status
		RecvHead = 0,
		RecvContent = 1,
		SendToSvr = 2,
		BufOk=3,		
		Forbid=4,
		WaitBind=5
	};
	
	int buf_status;
	RecvBuffer buffer;
	bool is_deny;//�Ƿ�ܾ�

};

struct Con
{
	enum
	{
		Broken=0,
		Connected=1
	};
	
	time_t active_time;//��һ���շ����ݵ�ʱ��
	short status;      //socket status
	struct ConBuf cbuf;
};

//#define LIS_SOCK 0
#define USER_SOCK 1
#define SOCK_PAIR 2

struct FDList
{
	short type;//���������ͣ�USER_SOCK:1��SOCK_PAIR:2
	struct Con user_con;
};



#endif

