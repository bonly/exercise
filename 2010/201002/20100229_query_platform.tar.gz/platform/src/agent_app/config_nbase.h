#ifndef __CONFIG_NBASE_H
#define __CONFIG_NBASE_H

#include <string>
#include <sys/types.h>
#include <inttypes.h>


#define INIT_LOG(plog, log_path, log_header, file_level, term_level)\
    if(SET_LOG_DIR(plog, log_path) < 0)\
    {\
        printf("log path can not access:%s\n", log_path);\
        exit(-1);\
    }\
    SET_LOG_LEVEL(plog, file_level, term_level);\
    SET_LOG_NAME_HEAD(plog, log_header);

#define LOG_DEBUG(...)\
    R5_DEBUG((&g_r5_log), ("[agent] " __VA_ARGS__))
#define LOG_INFO(...)\
    R5_INFO((&g_r5_log), ("[agent] " __VA_ARGS__))
#define LOG_ERROR(...)\
    R5_ERROR((&g_r5_log), ("[agent] " __VA_ARGS__))
#define LOG_WARN(...)\
    R5_WARN((&g_r5_log), ("[agent] " __VA_ARGS__))
#define LOG_TRACE(...)\
    R5_TRACE((&g_r5_log), ("[agent] " __VA_ARGS__))


typedef char Char;
typedef uint8_t Uint8;
typedef int8_t Int8;
typedef uint16_t Uint16;
typedef int16_t Int16;
typedef uint32_t Uint32;
typedef int32_t Int32;
typedef uint64_t Uint64;
typedef int64_t Int64;
typedef std::string String;


#endif // ~__CONFIG_NBASE_H

