#include <unistd.h>
#include "agentConfig.h"
#include <iostream>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

#include <sys/ipc.h>


#include "nSystem.h"
#include "nIniFile.h"


#include "oamAgent_kpi.h"
#include "kpi_if.h"
#include "public_signal.h"
#include "nString.h"
#include "r5api.h"

using namespace std;

extern char *optarg;

static bool init_signals();
//static void catch_sig(int signo);

char g_conf_file[256] = { 0 };
string g_logfile;


int g_sigExit = 0;
R5_Log g_r5_log;


int main(int argc, char *argv[])
{
    oamAgent_kpi proc;

    if (proc.parse(argc, argv) != 0)
    {
        return 0;
    }
    proc.set_conf_file(g_conf_file);

    proc.run();
    LOG_DEBUG("checking catched signal %d", g_sigExit);

    return 0;
}

oamAgent_kpi::oamAgent_kpi():m_msgid(-1)
{
}

oamAgent_kpi::~oamAgent_kpi()
{
}

int oamAgent_kpi::parse(int argc, char *argv[])
{
    memset(g_conf_file, 0, sizeof(g_conf_file));
    int optch = 0;
    while ((optch = getopt(argc, argv, "vi:p:c:l:h")) != -1)
    {
        switch (optch)
        {
        case 'v':
            version();
            return 1;
        case 'c':
            strncpy(g_conf_file, optarg, 255);
            break;
        case 'l':
            g_logfile = optarg;
            break;
        case 'h':
            cout << "oamAgent_kpi [-c configure file] [-l logfile]" <<
                endl;
            return 2;
        }
    }

    if ('\0' == g_conf_file[0])
    {
        printf("Usage:\n./oamAgent_kpi -c confi_file\n");
        return -1;
    }

    return 0;
}

int oamAgent_kpi::initialize(void)
{
    if (oamAgent_base::initialize() != 0)
    {
        return 1;
    }

    if (init_signals() == false)
    {
        return 1;
    }

    char config[256] = { 0 };
    if (get_conf_file((char *) config, sizeof(config)) < 0
        || strlen(config) <= 0)
        return -1;

    CIniFile ini;
    if (ini.open(config) == false)
    {
        cout << "open failed " << config << CSys::getLastError() << endl;
        return 1;
    }

    if (g_logfile.empty() == true)
    {
        g_logfile = ini.read("log", "log_path");
    }
    if (g_logfile.empty())
        g_logfile = "agent_kpi";

    INIT_LOG(&g_r5_log, g_logfile.c_str(), "agent_kpi", 40, 40)
        string kpi_queue = ini.read("KPI", "KPI_QUEUE");
    if (kpi_queue.empty())
    {
        LOG_ERROR("read kpi_queue failed.\n");
        return -1;
    }

    m_gearman_path = ini.read("gearman", "gearman_path");
    if (m_gearman_path.empty())
    {
        LOG_ERROR("read gearman_path failed.\n");
        return -1;
    }

    m_gearman_server = ini.read("gearman", "gearman_server");
    if (m_gearman_server.empty())
    {
        LOG_ERROR("read gearman_server failed.\n");
        return -1;
    }

    m_gearman_key = ini.read("gearman", "gearman_key");
    if (m_gearman_key.empty())
    {
        LOG_ERROR("read gearman_key failed.\n");
        return -1;
    }

    m_gearman_encry = ini.read("gearman", "gearman_encry");
    if (m_gearman_encry.empty())
    {
        LOG_ERROR("read gearman_encry failed.\n");
        return -1;
    }

    /* ������Ϣ���� */
    key_t kid = ftok(kpi_queue.c_str(), 1);
    if (-1 == kid)
    {
        return -1;
    }

    m_msgid = msgget(kid, 0666 | IPC_CREAT);
    if (-1 == m_msgid)
    {
        return -1;
    }

    reloadConfig();


    return 0;
}


static bool init_signals()
{
    //�˳�
    if (my_signal(SIGTERM, Signal::SigTerm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM,
                strerror(errno));
        return -1;
    }

    //�˳�
    if (my_signal(SIGINT, Signal::SigTerm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGTERM,
                strerror(errno));
        return -1;
    }


    //�ض�����    
    if (my_signal(SIGHUP, Signal::SigHup, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }


    //ˢ����־
    if (my_signal(SIGUSR2, Signal::SigUsr2, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }

    /* ALARM�ж�Ӧ��������  */
    if (my_signal(SIGALRM, Signal::SigAlarm, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }


    /* PIPE�ж�Ӧ���������� */
    if (my_signal(SIGPIPE, Signal::SigPipe, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }

    //����
    if (my_signal(SIGCHLD, Signal::SigChild, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGCHLD,
                strerror(errno));
        return -1;
    }

    //����
    if (my_signal(SIGUSR1, SIG_IGN, true) == SIG_ERR)
    {
        fprintf(stderr, "register signal %d failed:%s\n", SIGUSR1,
                strerror(errno));
        return -1;
    }
    return true;
}

int oamAgent_kpi::mainProcess(void)
{
    return ProcMsg();
}

void oamAgent_kpi::destroy(void)
{
}

int oamAgent_kpi::ProcMsg()
{
    msg_struct msg_st;

    for (;;)
    {
        if (Signal::HandleSignal() < 0 || g_sigExit)
        {
            return -1;
        }


        memset(&msg_st, 0, sizeof(msg_st));

        int ret =
            msgrcv(m_msgid, &msg_st, sizeof(msg_st.mtext), 0, IPC_NOWAIT);
        if (ret < 0)
        {
            //signal catch
            if (EINTR == errno)
            {
                if (Signal::HandleSignal() < 0 || g_sigExit)
                {
                    return -1;
                }

                continue;
            }

            if (ENOMSG == errno)
            {
                usleep(100);
                //send heart beat here? 
                continue;
            }

            return -1;
        }

        char hostname[64] = { 0 };
        char result[8] = { 0 };
        char msg[512] = { 0 };
        char service[128] = { 0 };
        long send_time = 0;

        LOG_DEBUG("msg = %s\n", msg_st.mtext);

        if (GetXMLBuffer(msg_st.mtext, "time", &send_time) == false)
        {
            LOG_ERROR("no send time, msg = %s\n", msg_st.mtext);
            continue;
        }

        if (time(NULL) - send_time > 100)
        {
            LOG_ERROR("msg too old. send_time = %l\n", send_time);
            continue;
        }

        if (GetXMLBuffer(msg_st.mtext, "host", hostname, sizeof(hostname))
            == false)
        {
            LOG_ERROR("missing host. msg=%s\n", msg_st.mtext);
            continue;
        }

        if (GetXMLBuffer(msg_st.mtext, "module", service, sizeof(service))
            == false)
        {
            LOG_ERROR("missing module. msg=%s\n", msg_st.mtext);
            continue;
        }

        if (GetXMLBuffer(msg_st.mtext, "msg", msg, sizeof(msg)) == false)
        {
            LOG_ERROR("missing msg, msg=%s\n", msg_st.mtext);
            continue;
        }

        if (GetXMLBuffer(msg_st.mtext, "rcode", result, sizeof(result)) ==
            false)
        {
            LOG_ERROR("missing rcode, msg=%s\n", msg_st.mtext);
            continue;
        }

        char cmd[256];
        memset(cmd, 0, sizeof(cmd));
        snprintf(cmd, sizeof(cmd),
                 "%s --encryption=%s --key=%s --server=%s --host=%s --service=\"%s\" -m=\"%s\" -r=%s",
                 m_gearman_path.c_str(), m_gearman_encry.c_str(),
                 m_gearman_key.c_str(), m_gearman_server.c_str(), hostname,
                 service, msg, result);

        LOG_DEBUG("cmd = %s\n", cmd);

        FILE *fp = popen(cmd, "r");
        if (NULL == fp)
        {
            LOG_ERROR("popen failed.\n");
            continue;
        }

        //not care result code but just close the fp
        fclose(fp);

        LOG_INFO("execute cmd %s success.\n", cmd);
    }                           // ~for (;;)

    return 0;
}


int DoSigTerm()
{
    LOG_ERROR("interruptted by SIGTERM.\n");
    g_sigExit = 1;

    return 0;
}

int DoSigChild()
{
    LOG_ERROR("interruptted by SIGCHLD.\n");

    pid_t child_pid;
    int stat;

    while ((child_pid = waitpid(-1, &stat, WNOHANG)) > 0)
    {
        /* ֹͣ��˽�����ص��ӽ��� */
        //stop_process(g_param.index, SIGTERM);
    }

    return 0;
}

int DoSigHup()
{
    LOG_ERROR("interruptted by SIGHUP.\n");
}

int DoSigUsr2()
{
    LOG_ERROR("interruptted by SIGUSR2.\n");
    return 0;
}


int DoSigAlarm()
{
    LOG_ERROR("interruptted by SIGALRM.\n");
    return 0;
}

int DoSigPipe()
{
    LOG_ERROR("interruptted by SIGPIPE.\n");
    return 0;
}
