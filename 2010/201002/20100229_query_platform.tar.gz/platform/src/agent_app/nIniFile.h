#ifndef __NINIFILE_H
#define __NINIFILE_H

#include <string>
#include <vector>
#include <map>
#include <algorithm>

#include "config_nbase.h"

using std::string;
using std::vector;
using std::map;
using std::less;


typedef map< string, string, less<string> > strMap;
typedef strMap::iterator strMapIt;

const char *const MIDDLESTRING = "_____***_______";

struct analyzeini
{
    string m_strsect;
    strMap *m_pmap;
    
    analyzeini(strMap & strmap);
        
    void operator()( const string & in_strini);
};

class CIniFile
{
public:
    CIniFile( );
    CIniFile(const string &filename);
    
    ~CIniFile( );
    
    bool open(const string &pinipath);
    
    string read(const string &psect, const string &pkey);
    int get_value(const string &psect, const string &pkey, char *values, size_t size);
    int get_value(const string &psect, const string &pkey, int *values);
    int get_value(const string &psect, const string &pkey, long *values);
    int get_value(const string &psect, const string &pkey, double *values);
    
    // ��������section
    int get_section(vector<string> &sec);
    
    // ����section�µ�����key
    int get_key(const string &in_sec, vector<string> &key);
    
protected:
    bool do_open(const string &inipath);
        
    strMap m_inimap;
};

#endif // ~__INIFILE_H

