#include "inno2isam_server.h"
#include "mysql_include.h"


#include "inno2isam_compress.h"

extern THD * thd;

volatile  int INNO2ISAM_SIG_QUIT = 0;

pthread_handler_t mysql_heartbeat(void *p)
{
  DBUG_ENTER("mysql_heartbeat");


  //read innodb test
  my_thread_init();
  thd = new THD;
  thd->thread_stack = (char *)thd;
  thd->store_globals();
  const NET v = {0};
  thd->net = v;
  thd->variables.option_bits|=OPTION_BIN_LOG;
  thd->db = 0;
  my_pthread_setspecific_ptr(THR_THD, thd);
  pthread_mutex_lock(&LOCK_thread_count);
  thd->thread_id = thread_id++;
  threads.append(thd);
  ++thread_count;
  pthread_mutex_unlock(&LOCK_thread_count);
  //sleep(50);
  char *argv[] = {"inno2isam", "--join=/home/zwf/mysql-data/test/t1_isam", "/home/zwf/mysql-data/test/tmp_isam", "t1_inno"};
  inno2isampack(4, argv);
  //close_thread_tables(thd);

/*  �滻������
 char *argv[] = {"inno2isam", "--join=/home/mysql/data/test/t5_isam", "/home/mysql/data/test/tmp_isam", "bill_innodb"};
  inno2isampack(4, argv);
  trans_commit_stmt(thd);
  close_thread_tables(thd);
*/


   struct mysql_heartbeat_context *con= (struct mysql_heartbeat_context *)p;
   char buffer[HEART_STRING_BUFFER];
   unsigned int x= 0;
   time_t result;
   struct tm tm_tmp;

   while(1)
   {
     sleep(5);

     result= time(NULL);
     localtime_r(&result, &tm_tmp);
     my_snprintf(buffer, sizeof(buffer),
                 "%s at %02d%02d%02d %2d:%02d:%02d\n",
                 INNO2ISAM_SIG_QUIT?"QUIT":"Heartbeat",
                 tm_tmp.tm_year % 100,
                 tm_tmp.tm_mon+1,
                 tm_tmp.tm_mday,
                 tm_tmp.tm_hour,
                 tm_tmp.tm_min,
                 tm_tmp.tm_sec);
     my_write(con->heartbeat_file, (uchar*) buffer, strlen(buffer), MYF(0));
     x++;
     if(INNO2ISAM_SIG_QUIT) //���Ӹ��У������������ݿ���������
         break;
   }
  
   //close_thread_tables(thd);
   my_thread_end();//���Ӹ��У������������ݿ���������
   DBUG_RETURN(0);
}
