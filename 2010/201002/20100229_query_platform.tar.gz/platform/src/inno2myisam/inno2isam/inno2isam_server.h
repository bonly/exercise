#ifndef INNO2ISAM_SERVER_HPP
#define INNO2ISAM_SERVER_HPP

#include <stdlib.h>
#include <my_global.h>
#include <my_pthread.h>



#define I2S_STRING_BUFFER 100
#define HEART_STRING_BUFFER 100

pthread_handler_t mysql_heartbeat(void *p);

struct mysql_heartbeat_context
{
  pthread_t heartbeat_thread;
  File heartbeat_file;
};

extern volatile  int INNO2ISAM_SIG_QUIT;

#endif

