#ifndef INNO2ISAM_WORKER_H_
#define INNO2ISAM_WORKER_H_

#include "inno2isam_server.h"

namespace INNO2ISAM {

struct inno2isamsvr_worker_i;
typedef std::auto_ptr<inno2isamsvr_worker_i> inno2isamsvr_worker_ptr;

struct inno2isamsvr_worker_arg {
  const inno2isamsvr_shared_c *cshared;
  volatile inno2isamsvr_shared_v *vshared;
  long worker_id;
  inno2isamsvr_worker_arg() : cshared(0), vshared(0), worker_id(0) { }
};

struct inno2isamsvr_worker_i {
  virtual ~inno2isamsvr_worker_i() { }
  virtual void run() = 0;
  static  inno2isamsvr_worker_ptr create(const inno2isamsvr_worker_arg& arg);
};

};

#endif
