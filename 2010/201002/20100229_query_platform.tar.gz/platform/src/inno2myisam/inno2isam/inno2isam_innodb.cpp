#include <stdlib.h>
#include <vector>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/resource.h>

#include "inno2isam_server.h"
#include "mysql_include.h"

THD *thd = NULL;

extern "C" int inno2isam_open_innodb(const char *dbname, const char *tbname, void **handler, ha_rows *records)
{
    DBUG_ENTER("mysql_open_innodb");
    //struct mysql_inno2isampack_context *con= (struct mysql_inno2isampack_context *)p;
   // char buffer[I2S_STRING_BUFFER];

   // tbname = "bill_innodb";

    TABLE_LIST tables;
    TABLE *table = 0;
    const thr_lock_type lock_type = TL_WRITE;
    //bool refresh = true;

    #if MYSQL_VERSION_ID >= 50505
    tables.init_one_table(dbname, strlen(dbname),
        tbname, strlen(tbname), tbname, lock_type);
    tables.mdl_request.init(MDL_key::TABLE, dbname, tbname,
        MDL_SHARED_WRITE, MDL_TRANSACTION);
    Open_table_context ot_act(thd, 0);
    if (!open_table(thd, &tables, thd->mem_root, &ot_act)) {
      table = tables.table;
    }
    #else
    tables.init_one_table(dbname, tbname, lock_type);
    table = open_table(thd, &tables, thd->mem_root, &refresh,
      OPEN_VIEW_NO_PARSE);
    #endif
 
    /*
    if(table == 0)
       sprintf(buffer, "%s", "failed to open table\n");
    else
       sprintf(buffer, "%s", "succeed to open table\n");

    my_write(con->heartbeat_file, (const uchar *)buffer, strlen(buffer), MYF(0));
    */
    *handler=(void *)(table->file);
    *records=table->file->records();
    return 0;
}

extern "C" int inno2isam_init_handler(void *hnd)
{
    ((handler *)hnd)->init_table_handle_for_HANDLER();
    ((handler *)hnd)->ha_index_or_rnd_end();
    ((handler *)hnd)->ha_rnd_init(1); /*scan*/

     return 0;
}

extern "C" int inno2isam_inno_rnd_next(void *inno_hnd, uchar *buf) 
{
    return ((handler *)inno_hnd)->rnd_next(buf);  
}

extern "C" int inno2isam_close_handle(void *inno_hnd)
{
    return ((handler *)inno_hnd)->ha_index_or_rnd_end();
}
