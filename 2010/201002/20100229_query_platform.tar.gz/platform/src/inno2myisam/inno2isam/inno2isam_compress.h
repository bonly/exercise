#ifndef INNO2ISAM_COMPRESS_H_
#define INNO2ISAM_COMPRESS_H_

#ifdef __cplusplus
extern "C"{
#endif

int inno2isampack(int argc,char * *argv);

#ifdef __cplusplus
};
#endif

#endif
