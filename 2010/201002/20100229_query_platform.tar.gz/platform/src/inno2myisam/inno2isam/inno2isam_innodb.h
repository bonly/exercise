#ifndef INNO2ISAM_INNODB_H_
#define INNO2ISAM_INNODB_H_

#include <stdlib.h>
#include <my_global.h>
#include <my_pthread.h>

/*Hacking here, modify isam file info*/
int inno2isam_init_handler(void *hnd);
int inno2isam_inno_rnd_next(void *inno_hnd, uchar *buf);
int inno2isam_close_handle(void *inno_hnd);
int inno2isam_open_innodb(const char *dbname, const char *tbname, void **handler, ha_rows *records);

#endif
