#include "inno2isamsvr_worker.h"

namespace INNO2ISAM{

struct inno2isamsvr_worker:public inno2isamsvr_worker_i, private noncopyable{
    inno2isamsvr_worker(const inno2isamsvr_worker_arg&arg);
    virtual void run();
    void test();
private:
    const inno2isamsvr_shared_c& cshared;
    volatile inno2isamsvr_shared_v& vshared;
    long worker_id;
    dbcontext_ptr dbctx;
private:


};

inno2isamsvr_worker::inno2isamsvr_worker(const inno2isamsvr_worker_arg& arg)
:cshared(*arg.cshared), vshared(*arg.vshared), worker_id(arg.worker_id),
    dbctx(cshared.dbptr->create_context(cshared.for_write_flag))
{

}

namespace{

struct thr_init{
    thr_init(const dbcontext_ptr&dc):dbctx(dc)
    {
         dbctx->init_thread();     
    }
    ~thr_init()
    {
         dbctx->term_thread();
    }
    
    const dbcontext_ptr& dbctx;
};

}; /*end of anonymous namespace*/

void inno2isamsvr_worker::run()
{
    thr_init initobj(dbctx);
}

void inno2isamsvr_worker::test()
{
    cmd_open_args  args;
    args.pst_id = 1;
    args.dbn = "test";
    args.tbl = "test1_inno";
    args.idx = NULL;
    args.retflds = NULL;
    args.filflds = NULL;
    return dbctx->cmd_open(args);
}

inno2isamsvr_worker_ptr 
inno2isamsvr_worker_i::create(const inno2isamsvr_worker_arg& arg)
{
    return inno2isamsvr_worker_ptr(new inno2isamsvr_worker(arg));
}

}; /*end of namespace INNO2ISAM*/
