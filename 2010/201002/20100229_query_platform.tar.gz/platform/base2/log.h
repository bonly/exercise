#ifndef __LOG_H__
#define __LOG_H__

enum LOG_LEVEL
{
    log_trace = 0,
    log_debug = 20,
    log_info = 40,
    log_warn = 60,
    log_error = 80,
    log_fatal = 100,
    log_end = 120
};

#define R5_LOG(plog, le, X) \
    do{\
      if ( plog->checkLevelFile(le) )\
      {\
        plog->setConditional(le, __LINE__, __FILE__);\
        plog->log1 X;\
      }\
      if ( plog->checkLevelTerm(le) )\
      {\
        plog->setConditional(le, __LINE__, __FILE__);\
        plog->log2 X;\
      }\
    }while(0)

#define R5_LOG_AUTOWRAP(plog, le, X) \
    do{\
      if ( plog->checkLevelFile(le) )\
      {\
        plog->setConditional(le, __LINE__, __FILE__, true);\
        plog->log1 X;\
      }\
      if ( plog->checkLevelTerm(le) )\
      {\
        plog->setConditional(le, __LINE__, __FILE__, true);\
        plog->log2 X;\
      }\
    }while(0)

#define R5_INFO(plog, X) \
      R5_LOG((plog),r5_log_info, X);

#define R5_WARN(plog, X) \
      R5_LOG((plog), r5_log_warn, X);

#define R5_ERROR(plog, X) \
       R5_LOG((plog), r5_log_error, X);

#define R5_FATAL(plog, X) \
      R5_LOG((plog), r5_log_fatal, X);

#define R5_END(plog, X) \
       R5_LOG((plog), r5_log_end, X);

#ifdef NR5_LOG

#define R5_TRACE(plog, X) do{} while(0)

#define R5_DEBUG(plog, X) do{} while(0)

#else

#define R5_TRACE(plog, X) \
      R5_LOG((plog), r5_log_trace, X);

#define R5_DEBUG(plog, X) \
      R5_LOG((plog), r5_log_debug, X);

#endif


#define R5_INFO_AUTOWRAP(plog, X) \
      R5_LOG_AUTOWRAP((plog),r5_log_info, X);

#define R5_WARN_AUTOWRAP(plog, X) \
      R5_LOG_AUTOWRAP((plog), r5_log_warn, X);

#define R5_ERROR_AUTOWRAP(plog, X) \
       R5_LOG_AUTOWRAP((plog), r5_log_error, X);

#define R5_FATAL_AUTOWRAP(plog, X) \
      R5_LOG_AUTOWRAP((plog), r5_log_fatal, X);

#define R5_END_AUTOWRAP(plog, X) \
       R5_LOG_AUTOWRAP((plog), r5_log_end, X);

#ifdef NR5_LOG

#define R5_TRACE_AUTOWRAP(plog, X) do{} while(0)

#define R5_DEBUG_AUTOWRAP(plog, X) do{} while(0)

#else

#define R5_TRACE_AUTOWRAP(plog, X) \
      R5_LOG_AUTOWRAP((plog), r5_log_trace, X);

#define R5_DEBUG_AUTOWRAP(plog, X) \
      R5_LOG_AUTOWRAP((plog), r5_log_debug, X);

#endif


#define FLUSH_LOG_FILE(plog) (plog)->flush()

#define SET_LOG_LEVEL(plog, fl, tm) (plog)->setLevelClass(fl, tm)

#define SET_LOG_NAME_HEAD(plog, x) (plog)->setLogNameHead(x)

#define SET_LOG_SUB_DIR(plog, x) (plog)->setLogSubDir(x)

#define SET_LOG_DIR(plog, x) (plog)->setLogDir(x)

#define SET_ERR_LOG_INFO(plog, x) (plog)->setErrLoginfo(x)

#define SET_LOG_BUFFER(plog, x) (plog)->setLogBuffer(x)

#define SET_SWITCH_TIME(plog, x) (plog)->setSwitchTime(x)

#define LOG_CHECK_TRACE(plog) ((plog)->checkLevelFile(log_trace)||(plog)->checkLevelTerm(log_trace))

#define LOG_CHECK_DEBUG(plog) ((plog)->checkLevelFile(log_debug)||(plog)->checkLevelTerm(log_debug))

#define LOG_CHECK_INFO(plog) ((plog)->checkLevelFile(log_info)||(plog)->checkLevelTerm(log_info))

#define LOG_CHECK_WARN(plog) ((plog)->checkLevelFile(log_warn)||(plog)->checkLevelTerm(log_warn))

#define LOG_CHECK_ERROR(plog) ((plog)->checkLevelFile(log_error)||(plog)->checkLevelTerm(log_error))

#define LOG_CHECK_FATAL(plog) ((plog)->checkLevelFile(log_fatal)||(plog)->checkLevelTerm(log_fatal))


#endif //__LOG_H__
