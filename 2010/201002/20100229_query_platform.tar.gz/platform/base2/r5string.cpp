
// create by derek 20070516

#include "r5string.h"
#include <string.h>

//-----------------------------------------------------------------------------
void trimLeft(char *item, char ch)
{
    int count = 0;
    while (*(item+count) != 0 && *(item+count) == ch)
    {
        ++ count;
    }
    
    int len = strlen(item);
    
    for ( int i=0; i<=len; ++i) // i<=len Ϊ?˿???0??????
    {
        *(item+i) = *(item+count+i);
        if  (*(item+i) == 0 ) break;
    }
}

void trimRight(char *item, char ch)
{
    int len = strlen(item);
    
    char *p = item+len-1;
    char *p1 = item+len-1;
    
    while (p>=item)
    {
        if ( *p != ch )
        {
            if ( p != p1 ) *(p+1) = 0;
                
            return ;
        }
        --p;
    }
    *item = 0;        
}
//add by oyy 2010-6-24
void trim(char *item)
{
    //ȥ??ǰ???Ŀո???tab
    int count = 0;
    while ((*(item+count) != 0) &&isspace(*(item+count)))
    {
        ++ count;
    }
    
    int len = strlen(item);
    
    for ( int i=0; i<=len; ++i) // i<=len Ϊ?˿???0??????
    {
        *(item+i) = *(item+count+i);
        if  (*(item+i) == 0 ) break;
    }

    //ȥ???????Ŀո???tab
    len = strlen(item);
    
    char *p = item+len-1;
    char *p1 = item+len-1;
    
    while (p>=item)
    {
        if ( !isspace(*p) )
        {
            if ( p != p1 ) *(p+1) = 0;
                
            return ;
        }
        --p;
    }
    *item = 0; 
}
    
// cout = 0 ???????е?ch, cout>0 ????cout??ch
void parser(const char *item, char ch, vector<string> &v, int cout)
{
    const char *pos1 = item;
    const char *pos2 = item;
    const char *end = item+strlen(item);
    
    //printf("parser: %d :%s \n", strlen(item), item);
            
    int c = 0;
    int len = 0;
    while (pos2<end)
    {
        if (*pos2 == ch )
        {
            len = pos2-pos1;
            if ( len > 0 )
            {
                string str(pos1, len);
                v.push_back(str);
              
                ++c;
            }
            pos1 = pos2+1;
          
            if (c == cout ) break;
        }
        ++pos2;
    }
    
    len = end-pos1;
    if ( len > 0 )
    {
        string str(pos1, len);
        v.push_back(str);
    }
}
