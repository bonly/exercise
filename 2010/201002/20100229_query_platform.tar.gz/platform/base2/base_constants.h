#ifndef _BASE_CONSTANTS_H_
#define _BASE_CONSTANTS_H_

typedef char BASE2_INT8;
typedef unsigned char BASE2_UINT8;

typedef short BASE2_INT16;
typedef unsigned short BASE2_UINT16;

typedef int BASE2_INT32;
typedef unsigned int BASE2_UINT32;

typedef long long BASE2_INT64;
typedef unsigned long long BASE2_UINT64;

typedef float  BASE2_FLOAT32;
typedef double BASE2_FLOAT64;

typedef char BASE2_CHAR;
typedef unsigned char BASE2_UCHAR;

#endif
