/*
 * Copyright (C) 1995 By Microsoft Corp.
 * Copyright (C) 1999, 2008, Oracle. All rights reserved.
 * All rights reserved.
 *
 * This file defines the types used in ODBC
 *
 * Created for 2.50 specification
 */

#ifndef __SQLTYPES
#define __SQLTYPES

/* need this to pick up Solaris _LP64 definition */
#include <sys/types.h>

/* if ODBCVER is not defined, assume version 2.50 */
#ifndef ODBCVER
#define ODBCVER 0x0250
#endif

/* environment specific definitions */
#ifndef EXPORT
#define EXPORT   _export
#endif

#define SQL_API
#define FAR

/* SQL portable types for C */

typedef unsigned char           UCHAR;

typedef signed char             SCHAR;

typedef int                     SDWORD;
typedef unsigned int            UDWORD;

typedef short int               SWORD;
typedef unsigned short int      UWORD;

#if ( defined(TT_USE_ALL_TYPES) && (ODBCVER >= 0x0200) )
typedef signed int              SLONG;
typedef unsigned int            ULONG;
typedef unsigned short          USHORT;
typedef signed short            SSHORT;
#endif  /* TT_USE_ALL_TYPES && ODBCVER >= 0x0200 */
typedef double                  SDOUBLE;
typedef double                  LDOUBLE;
typedef float                   SFLOAT;

typedef void*   HWND;
typedef int*    LPDWORD;

typedef void*   PTR;

typedef void*   HENV;
typedef void*   HDBC;
typedef void*   HSTMT;

typedef signed short            RETCODE;

typedef UCHAR     SQLCHAR;
typedef SCHAR     SQLSCHAR;

typedef SDWORD    SQLINTEGER;
typedef UDWORD    SQLUINTEGER;

typedef SWORD     SQLSMALLINT;
typedef UWORD     SQLUSMALLINT;

#define SQLROWSETSIZE   SQLUINTEGER

/*
** Use the predefined platform-specific 64-bit macros here so
** that the correct definitions are picked up automatically when
** compiling end-user applications.
*/
/* HP-UX, Solaris(actually __sparcv9), AIX, Alpha */
#if defined(__LP64__) || defined(_LP64) || defined(__64BIT__) || defined(__alpha)
typedef signed long     SQLLEN;
typedef unsigned long   SQLULEN;
#define SQLSETPOSIROW   SQLUINTEGER
#else
typedef SQLINTEGER      SQLLEN;
typedef SQLUINTEGER     SQLULEN;
#define SQLSETPOSIROW   SQLUSMALLINT
#endif

#define SQLROWOFFSET    SQLLEN
#define SQLROWCOUNT     SQLULEN

typedef SDOUBLE   SQLDOUBLE;
typedef SDOUBLE   SQLFLOAT;
typedef SFLOAT    SQLREAL;

typedef void*     SQLPOINTER;

typedef HENV                    SQLHENV;
typedef HDBC                    SQLHDBC;
typedef HSTMT                   SQLHSTMT;

typedef SQLSMALLINT             SQLRETURN;


/* placehold for future O/S GUI window handle definition */
typedef SQLPOINTER              SQLHWND;

/* transfer types for DATE, TIME, TIMESTAMP */
typedef struct tagDATE_STRUCT
{
        SQLSMALLINT    year;
        SQLUSMALLINT   month;
        SQLUSMALLINT   day;
} DATE_STRUCT;

typedef struct tagTIME_STRUCT
{
        SQLUSMALLINT   hour;
        SQLUSMALLINT   minute;
        SQLUSMALLINT   second;
} TIME_STRUCT;

typedef struct tagTIMESTAMP_STRUCT
{
        SQLSMALLINT    year;
        SQLUSMALLINT   month;
        SQLUSMALLINT   day;
        SQLUSMALLINT   hour;
        SQLUSMALLINT   minute;
        SQLUSMALLINT   second;
        SQLUINTEGER    fraction;
} TIMESTAMP_STRUCT;

#define SQL_MAX_NUMERIC_LEN 16
typedef struct tagSQL_NUMERIC_STRUCT
{
        SQLCHAR        precision;
        SQLSCHAR       scale;
        SQLCHAR        sign;/* 1 if positive, 0 if negative */
        SQLCHAR        val[SQL_MAX_NUMERIC_LEN];
} SQL_NUMERIC_STRUCT;

#if (ODBCVER >= 0x0200)
typedef unsigned int       BOOKMARK;
#endif  /* ODBCVER >= 0x0200 */

typedef unsigned short SQLWCHAR;

/*
 * Definitions for 64-bit data types
 */
#if defined(__LP64__) || defined(_LP64) || defined(__64BIT__) || defined(__alpha)
typedef signed   long      SQLBIGINT;
typedef unsigned long      SQLUBIGINT;
#else
typedef signed   long long SQLBIGINT;
typedef unsigned long long SQLUBIGINT;
#endif

#endif /* #ifndef __SQLTYPES */
