
// create by derek 20070420

#ifndef __R5_INI_CONFIG__
#define __R5_INI_CONFIG__

#include <vector>
#include <map>
#include <assert.h>
#include <string>
#include <string.h>
#include "r5log.h"

using namespace std;

//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
class IniItem
{
public:
    IniItem(const char *im):b_parser(false), item(im) { }
    ~IniItem() { }
    
    
public:
    const char *getKey()
    { 
        if ( !b_parser ) // ????
        {
            b_parser = true;
            parser();
        }
        
        return key.data(); 
    }
    const char *getValue()
    { 
        if ( !b_parser )
        {
            b_parser = true;
            parser();
        }
        
        return value.data();
    }
    
    const char *getItem() { return item.data(); }
    
private:
    void parser();

public:
    string key;
    string value;
    string item;
    bool b_parser;
};

//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
class IniSection
{
public:
    IniSection(const char *sect):section(sect) { }
    ~IniSection()
    {
        iterator it = item_array.begin();
        for (; it!= item_array.end(); ++it)
        {
            delete *it;
        }
    }
    
public:
    typedef vector<IniItem*>::iterator iterator;
        
    iterator begin() { return item_array.begin(); }
    iterator end() { return item_array.end(); }
    
public:
    void push(const char *item)
    {
        item_array.push_back(new IniItem(item));
    }
    
public:
    const char *getValue(const char *key)
    {
        iterator it = begin();
        for ( ; it != end(); ++it )
        {
            if ( strcmp((*it)->getKey(), key) == 0 ) return (*it)->getValue();
        }
        return 0; 
  }
  
private:
    string section;
    vector<IniItem*> item_array;
};

//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
class IniConfig
{
public:
    IniConfig() { }
    ~IniConfig() { release(); }
    
public:
    typedef map<string, IniSection*>::iterator iterator;
        
    iterator begin() { return section.begin(); }
    iterator end() { return section.end(); }    
    
public:
    int open(const char *name);
    
public:    
    IniSection *getSection(const char *sct = 0 );
  
    const char *getValue(const char *sct, const char *key);
  
protected:
    void release();

private:
    map<string, IniSection*> section;
};

#endif // __R5_INI_CONFIG__
