/**
 * cdr�����
 */

#ifndef _CDR_LOG_H
#define _CDR_LOG_H

#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <string>
#include <dirent.h>

#include "r5log.h"
#include "iniconfig.h"

#define MAX_NAME_LEN   128
#define MAX_PATH_LEN   1024
#define MAX_PREFIX_LEN 128

#define DIR_IS_EXIT(nm) \
    DIR *dp=NULL;\
    dp = opendir(nm);\
    if(dp == NULL)\
    {\
        fprintf(stderr,"directory: %s is not exist\n", nm);\
        return -1;\
    }\
    if(access((nm), W_OK) < 0)\
    {\
        fprintf(stderr,"directory: %s can not access\n", nm);\
        return -1;\
    }\
    if(closedir(dp) < 0)\
        return -1;

class CDRLog
{
public:
    CDRLog();

    ~CDRLog()
    {
        Close();
    }

public:
    int SetWorkPath(const char *path);
    int SetBakPath(const char *path);
    int SetTargetPath(const char *path);
    int SetCdrHeader(const char *nm);
    int SetCdrSize(int size);
    int SetCdrTimeInterval(int interval);
    
    FILE *Open();
    void Close();

    int Write(const void *ptr, int len); //дCDR

    int Flush();

private:
    FILE *m_pCdrLog;

    unsigned int m_uLogSize; // log size
    unsigned int m_uLogCnt; // log count
    int m_nMaxSize;
    //char m_sTargetName[MAX_PATH_LEN+MAX_NAME_LEN];
    //char m_sBakName[MAX_PATH_LEN+MAX_NAME_LEN];
    char m_sPrefix[MAX_PREFIX_LEN];
    char m_sWorkPath[MAX_PATH_LEN];
    char m_sBakPath[MAX_PATH_LEN];
    char m_sTargetPath[MAX_PATH_LEN];

    char m_sFileName[MAX_NAME_LEN];

    time_t m_nSwitchTime;    // ��һ���л�ʱ��
    int    m_nTimeInterval;  // �л�ʱ����

    struct tm m_date;
};



#endif /* _CDR_LOG_H */
