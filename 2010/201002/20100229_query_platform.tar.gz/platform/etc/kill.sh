#!/bin/sh
 
 
 
 
ps -ef|grep Classify|grep -v "grep"|awk -F " " '{print $2}'|xargs kill
 
ps -ef|grep SortBill|grep -v "grep"|awk -F " " '{print $2}'|xargs kill