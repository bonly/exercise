 drop database if exists router;
 create database router;
 use router;
 
 drop table if exists route;
 create table route
 (
 subno_begin  char(32) not null,
 subno_end  char(32) not null,
 instance_name char(8),
 connect_string char(64),
 status int,
 threshold int
 );
 create index idx_subno on route(subno_begin,subno_end);
 
 drop trigger if exists router.area_inschk;
 create trigger area_inschk before insert on route
  for each row begin
  	top:begin
  	DECLARE i INT;
  	select count(*) into i 
	      from route as od 
	      where new.subno_begin=od.subno_begin and new.subno_end=od.subno_end;
	  if i>0 then
	    leave top;
	  end if;
	  select count(*) into i
	     from route as od
	     where (new.subno_begin between od.subno_begin and od.subno_end-1) or
	           (new.subno_end between od.subno_being and od.subno_end-1);
	  if i>0 then
	     insert into area_wrong values(1);
	  end if;
	end;
  end;
  
  drop trigger if exists router.area_updchk;
  create trigger area_updchk before update on route
  for each row begin
  	top:begin
  	DECLARE i INT;
  	select count(*) into i 
	      from route as od 
	      where new.subno_begin=od.subno_begin and new.subno_end=od.subno_end;
	  if i>0 then
	    leave top;
	  end if;
	  select count(*) into i
	     from route as od
	     where (new.subno_begin between od.subno_begin and od.subno_end-1) or
	           (new.subno_end between od.subno_being and od.subno_end-1);
	  if i>0 then
	     insert into area_wrong values(1);
	  end if;
	end;
  end; 
  
  insert into route values('0','99999999999','paas','172.16.200.103|3301|paas|root|123',0,10000);