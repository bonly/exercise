#include "kpi_if.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <time.h>
#include <pwd.h>
#include <sys/types.h>

#include "iniconfig.h"

stat_kpi  g_stat;

int kpi_connect(const char *name, const char *conf_file)
{
    //char queue[256];
    key_t kid = -1;
    //struct passwd *user = NULL;

    IniConfig config;
    if(config.open(conf_file) < 0)
    {
        printf("Error: Open %s failed:%s\n", conf_file, strerror(errno));
        return -1;
    }

    /* KPI queue path */
    const char* squeue = config.getValue("KPI", "KPI_QUEUE");
    if(NULL == squeue || strlen(squeue) <= 0)
    {
            printf("read KPI_QUEUE item failed, configure file: '%s'\n",conf_file);
            return -1;
    }        
    
    /* ������Ϣ���� */
    kid = ftok(squeue, 1);
    if (-1 == kid)
    {
        return -1;
    }
    
    g_stat.msgid = msgget(kid, 0666|IPC_CREAT);
    if (-1 == g_stat.msgid)
    {
        return -1;
    }

    g_stat.pid = getpid();    
    strncpy(g_stat.proc_name, name, sizeof(g_stat.proc_name));
    g_stat.crt_time = time(NULL);
    gethostname(g_stat.hostname, sizeof(g_stat.hostname));

    return KPI_SUCCESS;
}

/* flag = IPC_NOWAIT ������, 0 ���� */
static int queue_send(int mqid, long type, int flag, const void *msg, int len)
{   
    struct msqid_ds ds;
    
    memset(&ds,0,sizeof(ds));
    if (msgctl(mqid, IPC_STAT, &ds) != 0)
    {
        return KPI_GET_QUE_STAT;
    }
    
    /* ��Ϣ������ȴ���100�򲻷���Ϣ */
    if (ds.msg_qnum >= KPI_MQ_DEF_MAX)
    {
        return KPI_QUE_TOO_LONG;
    }
   
    if (len > SEND_BUF_LEN)
    {
        return KPI_MSG_TOO_LONG;
    }
    
	
	msg_struct buf;

    buf.mtype = type;
    memcpy(buf.mtext, msg, len);
    
    return msgsnd(mqid, &buf, len, flag);
}


int kpi_send_event(const char *msg, int level)
{
    char message[SEND_BUF_LEN] = {0};
    int val_len = 0;
    int ret = 0;
      
    /* ���message,����xml��ʽ�ı��� */
    val_len = snprintf(message, sizeof(message), "<time>%u</time><host>%s</host><msg>%s</msg><rcode>%d</rcode><module>%s</module>",
                time(NULL), g_stat.hostname, msg, level, g_stat.proc_name);
        
    ret = queue_send(g_stat.msgid, 1, IPC_NOWAIT, message, val_len);
    
    return ret;
}



int kpi_send_proc_internal(char type, pid_t pid, const char * name, const char * param, int ret, const char * msg)
{
#if 0
    char file[256];
    FILE *f = NULL;
    const char *pFileName = NULL;
    time_t t = 0;
    tm result;
    
    t = time(NULL);
    localtime_r(&t, &result);
    
    /* ��֧�־���·���������� */
    pFileName = strrchr(name, '/');
    if (NULL == pFileName)
    {
        pFileName = name;
    }
    
    /* memset(file,0,sizeof(file)); */
    file[snprintf(file, sizeof(file), "%s/kpi/pid/%s.%ld",
        getenv(AGENT_HOME), pFileName, pid)] = '\0';
    
    if (NULL == (f = fopen(file, "a+")))
    {
        return -1;
    }
    
    switch (type)
    {
        case KPI_START:
            fprintf(f, "<name>%s</name><param>%s</param><start_time>%04u%02u%02u%02u%02u%02u</start_time><start_msg>%s</start_msg>",
                name, param,
                result.tm_year+1900, result.tm_mon+1, result.tm_mday, result.tm_hour, result.tm_min, result.tm_sec,
                msg);
            break;
        case KPI_RUNNING:
            fprintf(f, "<running>%04u%02u%02u%02u%02u%02u</running><running_msg>%s</running_msg>",
                result.tm_year+1900, result.tm_mon+1, result.tm_mday, result.tm_hour, result.tm_min, result.tm_sec,
                msg);
            break;
        case KPI_FINISH:
            fprintf(f, "<exit>%d</exit><finish_time>%04u%02u%02u%02u%02u%02u</finish_time><finish_msg>%s</finish_msg>",
                ret,
                result.tm_year+1900, result.tm_mon+1, result.tm_mday, result.tm_hour, result.tm_min, result.tm_sec,
                msg);
            break;
        default:
            ;
    }
    
    fclose(f);
#endif    
    return 0;
}

int kpi_sent_proc(char type, pid_t pid, int argc, char *argv[], int ret, const char *msg)
{
    char param[256];
    char *name = argv[0];
    int i=0;
    
    if ((argc <= 0) && (NULL == argv))
    {
        return 1;
    }

    memset(param, 0, sizeof(param));

    /* ����argv����ϳ�������� */
    for (i=1; i < argc; i++)
    {
        if (strlen(argv[i]) <= 0)
        {
            continue;
        }

        strncat(param, argv[i], sizeof(param));

        if ((argc-1) != i)
        {
            strncat(param, " ", sizeof(param));
        }
    }

    return kpi_send_proc_internal(type, pid, name, param, ret, msg);
}
