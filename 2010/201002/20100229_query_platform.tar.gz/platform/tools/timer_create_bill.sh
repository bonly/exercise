#!/bin/sh


#�ļ�����
count=300
#seconds
sleeptime=5

if [ $# -eq 2 ] ; then
        count=$1
        sleeptime=$2
else
    echo "$0 count sleeptime"
fi

echo "$0 $count $sleeptime"

while [ 1 ] ;do

        /home/hadoop/tsh/python/Python-3.1.2/python make_bill.py 1 2 $count
        /home/hadoop/tsh/python/Python-3.1.2/python make_bill.py 2 1 $count
        /home/hadoop/tsh/python/Python-3.1.2/python make_bill.py 3 2 $count
        /home/hadoop/tsh/python/Python-3.1.2/python make_bill.py 4 1 $count
        /home/hadoop/tsh/python/Python-3.1.2/python make_bill.py 5 1 $count
        /home/hadoop/tsh/python/Python-3.1.2/python make_bill.py 6 1 $count
        /home/hadoop/tsh/python/Python-3.1.2/python make_bill.py 7 1 $count
   
        
        mv boss.01.* ../bill/cs
        mv boss.02.* ../bill/ps
        mv boss.03.* ../bill/gprs
        mv boss.04.* ../bill/sb
        mv boss.05.* ../bill/wlan
        mv boss.06.* ../bill/ff
        mv boss.07.* ../bill/of
        
        
        sleep $sleeptime
        
        
done;


