<?php
#��ʼ��������
date_default_timezone_set("Asia/Chongqing");
#�嵥�Ʒ���
$billing_month="201104";
#�嵥ҵ��01��07,Ŀǰֻ֧��02���͡�
$type="01";
#�嵥����
$count=10;
#�嵥�ļ���
$file_count=1;

if( $argc>1 )
	$type=$argv[1];
if( $argc>2 )
	$file_count=$argv[2];
if( $argc>3 )
	$count=$argv[3];


echo "ʹ�÷���:\n"; 
echo "$argv[0] [�嵥����01-05] [�ļ�����] [ÿ�ļ��嵥����] \n\n";
echo "��������������嵥����Ĭ��Ϊ01���ļ�����Ĭ��Ϊ1, ÿ�ļ��嵥��Ĭ��Ϊ10 \n";
echo "\n";
echo "���������type=$type, file_count=$file_count, count=$count\n";
echo "creating\n";

$YYYYMMDDHHMMSS=date("YmdHis"); 
$today=date("Ymd");
$fileno=10000001;
$chlA=0; 
$chlB=date("His"); 

#         438��ʼ
$pattern01="10000199902950  52014                203008990A5#1      0       0  10661518                10661518                010220902950              BZXX                                 06       0                                                  12345678901234567890123456789012345678901234067890120\r\n";
$pattern02="60000199902950  52014                203008990A5#1      0       0  10661518                10661518                010220902950              BZXX                                 06       0                                                  \r\n";
$pattern03="34000000004     30001                03109           0       0               1336385332                        cmnet                                                           d388eb82       ddb1429c            551         4000000004       2558      24008       02               \r\n";
$pattern04="7TCYZ           061Y0                40310030103000      0       0      013709690000             919411                                              TCYZ             0           0       0    1000\r\n";
$pattern05="3               61001                03101      0       0           00  15005    302019360     260123862145002020000460                                                                        01                                                            0\r\n";


for( $kk=0; $kk<$file_count; $kk++ ){
	$num=$fileno+$kk;
	$filename="boss.$type.$num.$chlA.$chlB.$billing_month.$today.GD46.XD.A";
	#����ͷ��¼
	$bill_count=sprintf("%010d", $count);
	$header="H04.001.001CG10.CDR                                                              000100000310000000450000000000CG10". $bill_count.$YYYYMMDDHHMMSS.$billing_month. "2010040903                                                                \r\n";      
	$current=$header;
	$handle = fopen($filename, "w");
	fwrite($handle, $header);

	#�����嵥����
	for( $i=0; $i<$count; $i++ ){

		$subno=13700000000+ rand(0,9000);
		$start_time=$billing_month.date("dHms");
		$pattern00=$type."000   1000002GD4646".$subno."                                           ".$start_time."00                                 00301A03                                CC                                                 0       0       0          0       0                                                                                                                                                        0       0       0       0       0 ";
		$current .= $pattern00. $pattern01;
		
		fwrite($handle, $pattern00. $pattern01);
	}
	fclose($handle);
}

?>
