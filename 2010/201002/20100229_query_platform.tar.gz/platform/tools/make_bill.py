﻿#!/usr/bin/python3
# -*- coding: utf-8 -*-

import random
import time
import sys




type     = 7
file_num = 0
line_num = 0


if len(sys.argv) != 4:
    type     = 7
    file_num = 1
    line_num = 1
    print('Standard format starting:python3 make_bill.py [BILL_TYPE] [FILE_NUM] [FILE_LINE]')
    print('Parameter error! default type={0} file_num={1} line_num={2}'.format(type,file_num,line_num))
else:
    type     = int(sys.argv[1])
    file_num = int(sys.argv[2])
    line_num = int(sys.argv[3])
    

#num range
start    = 13700000000
end      = 13700800000

busi_type = '0{}'.format(type)


def get_num(start_num, end_num):
    return random.randint(start_num, end_num)


def get_file_name(busi_type, xh):
    '''
    '''
    chlA=0
    #c_time=time.mktime(time.localtime())
    c_time=time.time()
    num='10000001{}'.format(xh)
    file_name = 'boss.{0}.{1}.{2}.{3:.0f}.GD46.XD.A'.format(busi_type,num,chlA,c_time)        
    return file_name
    
def get_time(ISOTIMEFORMAT):
    return time.strftime(ISOTIMEFORMAT, time.localtime())
    
def get_file_top_line(busi_type):
    '''
    '''
    s_time=get_time('%Y%m%d%H%M%S')
    m_time=get_time('%Y%m')
    d_time=get_time('%Y%m%d')    
    top_line = 'H04.001.001{0:<70}{1:<10}{2:<10}{3:<10}FRCC{4:<10}{5}{6}{7}{8}{9:<85}\r\n'.format('test','123','456','789','369',s_time,m_time,d_time,busi_type,'')
    return top_line
    
def get_fixed_line_head(num):
    s_time=get_time('%Y%m%d%H%M%S')
    p_time='20110515121314'
    line_head='{0}0001111111111FRCC01{1:<24}222222222222222333333333333333{2}77{3}111                 03014550758    {4:<24}08                                              3330    4320   7829010000000000000000000000000000000600000000000000000000000000000007                                    1 000000000000001{2:<24}3255607888888888888881        3240555555555555555555    1230666666666666666666    4440777777777777777777    5550888888888888888888    66601{2:<24}3255607888888888888881        3240555555555555555555    1230666666666666666666    4440777777777777777777    5550'.format(busi_type,num,s_time,p_time,'13512444444',type)
    return line_head
    
def get_bill_line(busi_type, num):
    fixed_line_head = ''
    bill_line       = ''
    busi_list = ['01','02','03','04','05']
    if busi_type in busi_list:
        fixed_line_head=get_fixed_line_head(num)
    if busi_type=='01':
        bill_line='{2}                                                                  000011122222220                              010000033218877{0:<24}{0:<24}{1:<24}444444444445555555555666677777777888899999999                  001                  002111012222222222222222333144444444556666666677777777                              \r\n'.format('13512444444',num,type)
    if busi_type=='02':
        bill_line='{2}                                                                 000022233333330                              00{0:<24}{1:<24}0202125555555555555555555566666666666666666666666666666600003330020000333        0277777777                                                              \r\n'.format('13512444444',num,type)
    if busi_type=='03':
        bill_line='{1}                                                         00000033333322222220                                          1207777777777{0:<24}999999999999999999999999999999999999999999999999999999999999999988888888888888888888888888888888777777777777777777777777777777770004444111111111122222222223333333333344444444444555555503666666666777770                              \r\n'.format(num,type)
    if busi_type=='04':
        bill_line='{2}                                                                  000011122222220                              0000222{0:<24}{1:<24}{1:<24}{0:<24}04013333333333334445567777111111102222222033333330                              \r\n'.format(num,'13512444444',type)
    if busi_type=='05':
        bill_line='{1}                                                         000022233333330                                       1002{0:<24}0003333000011111111100002222222223333333333333333333333334444444444444444444444444444444444444444444444444444444444444444555555555516666666666666666666666666666666677777777777777777777777777777722222220                              \r\n'.format(num,type)
    if busi_type=='06':
        s_time=get_time('%Y%m%d%H%M%S')
        bill_line='{0}0001111111111ZWHH{1:<24}{2}11CAB                  33333330    44444440                              {3}20111102122345201111022011110355555555555555555555555555555555                                                                                                         \r\n'.format(busi_type,num,s_time,type)
    if busi_type=='07':
        s_time=get_time('%Y%m%d%H%M%S')
        bill_line='{0}1001111111111ZWCC{1:<24}{2}11B                    33333330    44444440                              {3}               201111021223450104{4:<24}   3112222{4:<24}555555555555555555551                                                            \r\n'.format(busi_type,num,s_time,type,'13512444444')
    total_line=fixed_line_head + bill_line
    return total_line
    
    

def w_file(busi_type,xh):
    with open(get_file_name(busi_type,xh),mode='w',encoding='utf-8') as file:
        file.write(get_file_top_line(busi_type))
        i=0
        while True:      
            if i==line_num:
                break
            if i>20000:
                break      
            file.write(get_bill_line(busi_type,get_num(start,end)))
            i+=1
            
    
if __name__ == '__main__':    
    i=0
    while True:  
        if i==file_num:
            break
        if i>1000:
            break
        w_file(busi_type,i)
        i+=1
        
    
    