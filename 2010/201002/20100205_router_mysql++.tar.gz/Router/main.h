/**
 * main.h
 * @file
 * @brief 定义处理工作类
 *
 * @date 2011-5-12 created
 * @author bonly
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "head.hpp"
#include "service_handler.hpp"
#include "service_handler_pool.hpp"
#include "server.hpp"
#include "Protocal.h"
#include <mysql++.h>
class server_work_allocator;

struct GPARAM
{
   const char* server;
   const char* db;
   const char* user;
   const char* passwd;
   const char* table;
   const char* fields;
};

/// work handler工作类
class server_work
{
   public:

      typedef bas::service_handler<server_work> server_handler_type;

      server_work():connect_(false),query_(&connect_,false)
      {
         se_ = time(0);
         srand(se_);///初始化随机数种子
      }

      void on_clear(server_handler_type& handler)
      {
      }

      /// 新连接打开时调用
      void on_open(server_handler_type& handler);

      /// 读取完成时调用
      void on_read(server_handler_type& handler, std::size_t bytes_transferred);

      /// 写出完成时调用
      void on_write(server_handler_type& handler,
                        std::size_t bytes_transferred);

      /// 关闭时调用
      void on_close(server_handler_type& handler,
               const boost::system::error_code& e);

      void on_parent(server_handler_type& handler, const bas::event event)
      {
      }

      void on_child(server_handler_type& handler, const bas::event event)
      {
      }

      /** @brief 心跳,由client发起,本程序同时向hs发送open_index作为心跳
       *  @return 0:成功 其它:失败
       */
      int db_heartbeat();

      /** @brief 查询
       *  @param telno 查询的号码
       *  @param cr 保存结果的数据结构
       *  @return 0:成功 其它:失败
       */
      int db_query(const char* telno, bas::CR &cr);

      /** @brief 处理多结果请求获取结果
       *  @param phone 查询的号码
       *  @return 0:成功 其它:失败
       */
      int get_multi_result(const char* phone);

      /** @brief 处理单结果请求
       *  @param phone 查询的号码
       *  @return 0:成功　其它:失败
       */
      int get_single_result(const char* phone);

      /** @brief 产生随机数
       *  @param  rand 指定的范围
       *  @return 随机数
       */
      int get_rand(int rand);

   private:
      mysqlpp::Connection connect_; //< mysql连接
      mysqlpp::Query query_; //< mysql 查询
      mysqlpp::StoreQueryResult row_; //< mysql结果集
      bas::Protocal protocal_; //< 用于构造要发送的协议数据结构
      char sql_[255]; //< 存放sql语句
      unsigned int se_; //< 用于生成随机数
};

/// work handler工作类生成器
class server_work_allocator
{
   public:
      typedef PROTOCAL socket_type;

      server_work_allocator()
      {
      }
      /// 为适应service_handler 调用的模板模式
      socket_type* make_socket(boost::asio::io_service& io_service)
      {
         return new socket_type(io_service);
      }

      server_work* make_handler()
      {
         return new server_work();
      }
};


#endif /* MAIN_H_ */
