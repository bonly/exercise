/**
 * Protocal.cpp
 * @file
 * @brief 传协议的封装及解释实现
 * @author bonly
 *
 * @date 2011-5-4 bonly created
 * @date 2011-8-16 bonly 增加路由组状态查询及路由状态变更接口协议
 * @date 2011-9-23 bonly 修改组状态查询
 */

#include "Protocal.h"
#include <arpa/inet.h>
#include <errno.h>
#include <limits.h>

namespace bas
{
   int BufferEncoder::Encode(const char* s)
   {
      if (first_ == false)
      {
         strncat(MsgBody_, " ", 1);// 补一个空格
         MsgLen_++;
      }
      else
         first_ = false;

      int len = strlen(s); /// 取得字符串的长度,不包括'\0'
      if (MsgLen_ + len >= (MAXLEN - HEADLEN - 1)) /// 数据包长度不能大于 MAXLEN,否则返回1
         return 1;

      strncat(MsgBody_, s, len);
      MsgLen_ += len;
      return 0;
   }

   void BufferEncoder::EndOfBuffer(int i)
   {
      Command_ = i;
      MsgBody_[MsgLen_] = '\n';
      MsgLen_ = MsgLen_ + 2 + HEADLEN; /// 最后包长是要加上包头长度
      int len = htonl(MsgLen_); /// 包长值转换为网络字节
      memcpy(buffer_, &len, 4);
      int cmd = htonl(i); /// 命令码值转换为网络字节
      memcpy(buffer_ + 4, &cmd, 4);
   }

   int BufferEncoder::GetMsg(char*& s)
   {
      s = buffer_;
      return MsgLen_;
   }

   int BufferEncoder::Decode(const char* s)
   {
      /// 解释包头
      if (0 != Decode_Head(s))
         return -1;

      int num = 0;
      /// 检查数据包是否正确
      MsgBody_ = (char*) (s + HEADLEN);
      num = strlen(MsgBody_) + HEADLEN + 1;
      return (num == MsgLen_) ? 0 : 1;
   }

   int BufferEncoder::Decode_Head(const char* s)
   {
      /// 把网络字节序的长度值转为本地字节
      int num = 0;
      memcpy(&num, s, 4);
      MsgLen_ = ntohl(num);

      /// 把网络字节序的命令码值转为本地字节
      memcpy(&num, s + 4, 4);
      Command_ = ntohl(num);

      return 0;
   }

   int Protocal::DecodeQry(const char* s)
   {
      if (buffer_.Decode(s) != 0 || s == NULL)
         return -1;

      /// 获取命令码及整个包长
      data_.qcommand = buffer_.GetCommand();
      data_.msgLen = buffer_.GetMsgLen();

      istringstream ss;
      ss.str(buffer_.GetMsgBody());
      switch(data_.qcommand)
      {
          case 1:  /// 多结果查询与
          case 3:  /// 单结果查询处理相同
          {
              /// 获取电话号码phoneNum
              ss >> data_.phoneNum;
              break;
          }
          case 5: /// 路由组状态查询
          {
              /* @ingroup protocal_decode
               * @par 组状态查询协议 \n
               * 查询:  消息长度 5 组ID \n
               */
              /// 获取路由组ID
              string str;
              ss >> str;
              AtoI(str.c_str(),data_.groupID);
              break;
          }
          case 7: /// 修改路由状态
          {
              /// 获取要修改的路由节点个数
              string str;
              ss >> str;
              AtoI(str.c_str(), data_.nodeMsgNum);
              data_.resize(data_.nodeMsgNum);
              /// 取出所有要修改的节点信息
              for (int i=0; i < data_.nodeMsgNum; ++i)
              {
                  data_.nodes[i] = new nodeData();
                  /// 获取数据库连接字符串
                  ss >> str;
                  strncpy (data_.nodes[i]->connectStr, str.c_str(),
                              sizeof(data_.nodes[i]->connectStr));

                  /// 获取表状态
                  ss >> str;
                  AtoI(str.c_str(), data_.nodes[i]->status);
              }
              break;
          }
          case 9: /// IP信息查询
          {
              /// 获取要查询的IP地址
              string str;
              ss >> str;
              strncpy (data_.IP, str.c_str(), sizeof(data_.IP));
              break;
          }
          case 11: /// IP信息串修改
          {
              /// 获取源串
              string str;
              ss >> str;
              strncpy (data_.SrcConnectStr, str.c_str(), sizeof(data_.SrcConnectStr));

              /// 获取目标串
              ss >> str;
              strncpy (data_.DstConnectStr, str.c_str(), sizeof(data_.DstConnectStr));
              break;
          }
          case 13: /// 取服务器信息列表
          {
              break;
          }
      }

      return 0;
   }

   int Protocal::Encode(char*& s)
   {
      if (!this->good() && !this->eof())
      {
         return -1; /// 如果包状态是坏的并且没有结束,则返回-1
      }
      buffer_.GetMsg(s);
      return buffer_.GetMsgLen();
   }

   int Protocal::DecodeAns(const char* s)
   {
      if (buffer_.Decode(s) != 0 || s == NULL)
         return -1;

      try
      {
          /// 获取命令码及整个包长
          data_.acommand = buffer_.GetCommand();
          data_.msgLen = buffer_.GetMsgLen();

          istringstream ss;
          ss.str(buffer_.GetMsgBody());

          string str;

          /// 取ResultCode
          ss >> str;
          AtoI(str.c_str(), data_.resultcode);

          switch(data_.acommand)
          {
              case 0: /// 心跳直接返回0
                  return 0;
              case 2: /// 多结果查询的应答
              case 4: /// 单结果查询的应答
              {

                  if (data_.resultcode != 0) ///如果结果为失败,无需解释后面的内容
                      return 0;

                  /// 取SubNo
                  ss >> str;
                  strncpy(data_.phoneNum, str.c_str(), sizeof(data_.phoneNum));
                  /// 取SubNoEnd
                  ss >> str;
                  strncpy(data_.phoneNumEnd, str.c_str(), sizeof(data_.phoneNumEnd));
                  /// 取节点所属的路由组ID
                  ss >> str;
                  AtoI(str.c_str(), data_.groupID);
                  /// 取NodeMsgNum
                  ss >> str;
                  AtoI(str.c_str(), data_.nodeMsgNum);
                  data_.resize(data_.nodeMsgNum);
                  for (int i = 0; i < data_.nodeMsgNum; ++i)
                  {
                     data_.nodes[i] = new nodeData();
                     /// 取instanceName
                     ss >> str;
                     strncpy(data_.nodes[i]->instanceName, str.c_str(),
                              sizeof(data_.nodes[i]->instanceName));
                      /// 取connectStr
                     ss >> str;
                     strncpy(data_.nodes[i]->connectStr, str.c_str(),
                              sizeof(data_.nodes[i]->connectStr));

                     /// 取status
                     ss >> str;
                     AtoI(str.c_str(), data_.nodes[i]->status);

                     /// 取chreshold
                     ss >> str;
                     AtoI(str.c_str(), data_.nodes[i]->chreshold);
                  }
                  break;
              }
              case 6: /// 路由组状态查询的应答
              {
                 /** @ingroup protocal_decode
                  * 结果:  消息长度 6 1 组ID 节点数 \n
                  *       消息长度 6 0 组ID 节点数 {(连接串 状态)...}
                  *
                  */
                  /// 取GroupID
                  ss >> str;
                  AtoI(str.c_str(), data_.groupID);

                  /// 取NodeMsgNum
                  ss >> str;
                  AtoI(str.c_str(), data_.nodeMsgNum);

                  data_.resize(data_.nodeMsgNum);
                  /// 取各个节点的资料
                  for (int i = 0; i < data_.nodeMsgNum; ++i)
                  {
                      data_.nodes[i] = new nodeData();
                      /// 取数据库连接字符串
                      ss >> str;
                      strncpy(data_.nodes[i]->connectStr, str.c_str(),
                                  sizeof(data_.nodes[i]->connectStr));

                      /// 取表状态
                      ss >> str;
                      AtoI(str.c_str(), data_.nodes[i]->status);
                  }
                  break;

              }
              case 8: /// 路由状态修改的应答
              {
                  /// 取NodeMsgNum
                  ss >> str;
                  AtoI(str.c_str(), data_.nodeMsgNum);

                  /// 取各个节点的资料
                  data_.resize(data_.nodeMsgNum);
                  for (int i = 0; i < data_.nodeMsgNum; ++i)
                  {
                      data_.nodes[i] = new nodeData();
                      /// 取数据库连接字符串
                      ss >> str;
                      strncpy(data_.nodes[i]->connectStr, str.c_str(),
                                  sizeof(data_.nodes[i]->connectStr));

                      /// 取表状态
                      ss >> str;
                      AtoI(str.c_str(), data_.nodes[i]->status);
                  }
                  break;
              }
              case 10: /// 根据IP查服务器信息的应答
              {
                  /// 取NodeMsgNum
                  ss >> str;
                  AtoI(str.c_str(), data_.nodeMsgNum);

                  /// 取各个节点的资料
                  data_.resize(data_.nodeMsgNum);
                  for (int i = 0; i < data_.nodeMsgNum; ++i)
                  {
                      data_.nodes[i] = new nodeData();
                      /// 取组ID
                      ss >> str;
                      AtoI (str.c_str(), data_.nodes[i]->groupID);

                      /// 取connectstr
                      ss >> str;
                      strncpy(data_.nodes[i]->connectStr, str.c_str(),
                                  sizeof(data_.nodes[i]->connectStr));

                      /// 取状态status
                      ss >> str;
                      AtoI(str.c_str(), data_.nodes[i]->status);
                  }
                  break;
              }
              case 12: /// 修改IP连接信息串应答
              {
                  break;
              }
              case 14: /// 取服务器信息列表
              {
                  /// 取NodeMsgNum
                  ss >> str;
                  AtoI(str.c_str(), data_.nodeMsgNum);

                  /// 取各个节点的资料
                  data_.resize(data_.nodeMsgNum);
                  for (int i = 0; i < data_.nodeMsgNum; ++i)
                  {
                      data_.nodes[i] = new nodeData();
                      /// 取组ID
                      ss >> str;
                      AtoI (str.c_str(), data_.nodes[i]->groupID);

                      /// 取connectstr
                      ss >> str;
                      strncpy(data_.nodes[i]->connectStr, str.c_str(),
                                  sizeof(data_.nodes[i]->connectStr));

                      /// 取状态status
                      ss >> str;
                      AtoI(str.c_str(), data_.nodes[i]->status);
                  }
                  break;
              }
              default: /// 非已定义的应答返回-1
              {
                  return -1;
              }
          }

      }
      catch(...)
      {
          return -1;
      }

      return 0;
   }

}

  //**@addtogroup sample 测试样例
// * @ingroup protocal
// * @par 协议测试
// * @code
//   协议测试
#include "hexdump.h"
using namespace bas;
using namespace std;
int main()
{
 { /// 请求
     Protocal p;
     int ret = 0;
     p << "13719360007" << 1; // 以整型命令码值表示赋值结束,如果结束后再加字串字段会不让编译通过
     cout << "encoded: " << p << endl; // 打印包体内容(不包括命令码)

     char *buf = 0;
     ret = p.Encode(buf); // ret 返回整个数据的包长度,-1表示失败
     ret = p.DecodeQry(buf); // ret 0:成功 其它:失败

     p.Reset();  // 如果想要重用对象来压包或者出错后重用同一对象压包,必须先重置一次对象,以便清理状态;解包无此要求
     p << "13719360008" << 1; // 以整型命令码值表示赋值结束,在别的地方再加入字段内容,将舍弃新加的内容
     ret = p.Encode(buf);
     cout << "encoded: " << p << endl;
 }

 { ///查询结果
     Protocal p;
     int ret = 0;
     p << "0" << "1371936" << "1371937" << "1" << "2" // 结果,号码段起始,号码段结束,组ID,节点数
     << "inst1" << "abc/ok@testdb1" << "0" << "100000" //第1个节点
     << "inst2" << "abc/no@testdb2" << "0" << "100000" //第2个节点
     << 2; //命令码
     cout << "encoded: " << p << endl;

     char *buf = 0;
     ret = p.Encode(buf); // ret 返回整个数据的包长度,-1表示失败
     ret = p.DecodeAns(buf); // buf是收到的数据包指针, ret 0:成功 其它:失败
     cout << "共有节点数: " << p.data()->nodeMsgNum << endl;
     cout << "号码段: " << p.data()->phoneNum << endl;
     for (int i=0; i<p.data()->nodeMsgNum; ++i)
     {
         cout << "节点" << i <<": " << p.data()->nodes[i]->connectStr << endl;
     }
 }

 { /// 路由组状态查询
     Protocal p;
     int ret = 0;
     p << "3" << 5; // 路由组,命令码
     cout << "encoded: " << p << endl;

     p.Reset();
     // 应答码,组ID,节点数,连接串,状态,命令码
     p << "0" << "2" << "3"
              << "abc/ok@testdb3" << "2"
              << "abc/ok@testdb1" << "2"
              << "abc/ok@testdb2" << "2"
              << 6;
     char *buf = 0;
     ret = p.Encode(buf);
     ret = p.DecodeAns(buf);
     cout << "组ID: " << p.data()->groupID << endl;
     for (int i=0; i<p.data()->nodeMsgNum; ++i)
     {
         cout << "节点" << i << ": " << p.data()->nodes[i]->connectStr << endl;
     }
 }

 { /// 路由状态修改
     Protocal p;
     int ret = 0;
     p << "1" << "abc/ok@pair1" << "0" << 7;
     cout << "endcode: " << p << endl;

     p.Reset();
     // 应答码,失败节点数,连接串,状态,命令码
     p << "0" << "2" << "abc/ok@test1" << "3" << "abd/ok@test2" << "4" << 8;
     char *buf = 0;
     ret = p.Encode(buf);
     ret = p.DecodeAns(buf);
     cout << "失败节点数: " << p.data()->nodeMsgNum << endl;
     for (int i=0; i<p.data()->nodeMsgNum; ++i)
     {
         cout << "节点" << i << ": " << p.data()->nodes[i]->connectStr << endl;
     }
 }

 { ///根据IP查服务器信息
     Protocal p;
     int ret = 0;
     // IP地址,命令码
     p << "172.0.0.1" << 9;
     cout << "endcode: " << p << endl;

     p.Reset();
     // 应答码,节点数,组ID,连接串,状态
     p << "0" << "9"
              << "1" << "a/bc@test1" << "2"
              << "2" << "a2/bc@test1" << "2"
              << "1" << "b3/abc@test2" << "1"
              << "1" << "d4/aa1@test2" << "1"
              << "3" << "F5/Ade@test3" << "0"
              << "2" << "k6/aaa@test4" << "2"
              << "1" << "o7/aee@test4" << "1"
              << "3" << "q8/eqe@test2" << "3"
              << "3" << "o9/eqq@test1" << "2"
              << 10;
     char *buf = 0;
     ret = p.Encode(buf);
     ret = p.DecodeAns(buf);
     for (int i=0; i<p.data()->nodeMsgNum; ++i)
     {
         cout << "节点" << i << ": " << p.data()->nodes[i]->connectStr << endl;
     }
 }

 { /// 修改IP连接信息串
     Protocal p;
     int ret = 0;
     p << "abc/pass@test1" << "abc/pass@test2" << 11;
     cout << "endcode: " << p << endl;

     p.Reset();
     // 应答码
     p << "0" << 12;
     char *buf = 0;
     ret = p.Encode(buf);
     ret = p.DecodeAns(buf);
     cout << "应答: " << p.data()->resultcode << endl;
 }
 { /// 查服务器信息列表
     Protocal p;
     char *buf = 0;
     int ret = 0;
     p << 13;
     ret = p.Encode(buf);
     clog << "len: " << ret << endl;
     HexDump(buf, ret);

     p.Reset();
     // 应答
     p << "0" << "8" << "0" << "172.0.0.1|3306|paas|root|111" << "2"
                     << "0" << "172.0.0.2|3306|paas|root|111" << "2"
                     << "0" << "172.0.0.3|3306|paas|root|111" << "2"
                     << "0" << "172.0.0.4|3306|paas|root|111" << "2"
                     << "1" << "172.0.0.5|3306|paas|root|111" << "2"
                     << "1" << "172.0.0.6|3306|paas|root|111" << "2"
                     << "1" << "172.0.0.7|3306|paas|root|111" << "2"
                     << "1" << "172.0.0.8|3306|paas|root|111" << "2"
                     << 14;
     ret = p.Encode(buf);
     clog << "len: " << ret << endl;
     HexDump(buf, ret);
     ret = p.DecodeAns(buf);
     for (int i = 0; i < p.data()->nodeMsgNum; ++i)
     {
         cout << p.data()->nodes[i]->connectStr << endl;
     }
 }
 return 0;
}
//@endcode
// */

