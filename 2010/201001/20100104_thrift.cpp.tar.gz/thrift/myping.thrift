#!/home/bonly/thrift --gen cpp
namespace cpp Test
service Something
{
    i32 ping()
}
