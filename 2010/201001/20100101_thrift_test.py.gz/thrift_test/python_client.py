#!/usr/bin/python
#coding:utf-8

import sys
sys.path.append('./gen-py')
from hello import UserExchange
from hello.ttypes import *

from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol

if __name__=='__main__':
  try:
    transport = TSocket.TSocket('localhost',9090)
    transport = TTransport.TBufferedTransport(transport)
    protocol = TBinaryProtocol.TBinaryProtocol(transport)
    client = UserExchange.Client(protocol)
    transport.open()
    client.ping()
    print 'pring()...'

    user=User()
    user.firstname ='He'
    user.lastname='JB'
    client.add_user(user)
    print client.get_user(0)
  except Thrift.TException, tx:
    print '%s' % (tx.message)

