#!/usr/bin/python
#coding:utf-8

import sys
sys.path.append('./gen-py')
from hello import UserExchange
from hello.ttypes import *

from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol
from thrift.server import TServer

users = []

class usermanagerhandler:
    def __init__(self):
        pass

    def ping(self):
        print 'ping()'

    def add_user(self,user):
        if user.firstname == None:
           raise InvalidValueException(1,'no firstname exception')
        print 'process user ' + user.firstname + ' ' + user.lastname
        users.append(user)
        print users
        return True

    def get_user(self,user_id):
       if user_id < 0:
           raise InvalidValueException(5,'wrong id')
       return users[user_id]

    def clear_list(self):
       print 'clearing list'
       print users
       del users[:]
       print users

if __name__=='__main__':
   print 'program Begin...'
   handler = usermanagerhandler()
   processor = UserExchange.Processor(handler)
   transport = TSocket.TServerSocket(9090)
   tfactory = TTransport.TBufferedTransportFactory()
   pfactory = TBinaryProtocol.TBinaryProtocolFactory()
   server = TServer.TSimpleServer(processor,transport,tfactory,pfactory)
   print 'Starting the server...'
   server.serve()
   print 'done.'

