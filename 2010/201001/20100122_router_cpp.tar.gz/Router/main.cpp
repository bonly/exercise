/**
 * main.cpp
 * @file
 * @brief 主程序,管理信号
 *
 * @date 2011-5-12 created
 * @author bonly
 */

#include "main.h"
#include "profile_config.h"
#include "Protocal.h"

int server_work::hs_open_index()
{
   /// 请求打开索引
   /// P    1   test  route PRIMARY  subno,instance_name,connect_string,status,threshold
   _hs.request_buf_open_index(1,
            Config::instance().get<string> ("mysql.db").c_str(),
            Config::instance().get<string> ("mysql.table").c_str(),
            Config::instance().get<string> ("mysql.index_name").c_str(),
            Config::instance().get<string> ("mysql.fields").c_str(), 0);
   //std::clog << _hs.get_write_buffer() << std::endl;
   if (0 != _hs.request_send())
   {
      std::cerr << "index send:" << _hs.get_error_code() << _hs.get_error()
               << std::endl;

      return -1;
   }
   /// 接收应答结果
   size_t len = 0;
   _hs.response_recv(len);
   int ret = _hs.get_error_code();
   if (ret != 0)
      std::cerr << "index recv:" << _hs.get_error_code() << _hs.get_error()
               << std::endl;

   _hs.response_buf_remove();

   return ret;
}

int server_work::hs_heartbeat()
{
   /**
    * 打开索引,如果失败则关闭连接,重新打开连接,并再次调用自己去打开索引
    * @note 或者会死循环
    */
   if (0 != hs_open_index())
   {
      if (0 != _hs.reconnect())
      {
         std::cerr << "reconnet:" << _hs.get_error_code() << _hs.get_error()
                  << std::endl;
         return -1;
      }
      /// @TODO 此递归调用循环,sleep一会再连?
      return hs_heartbeat();
   }
   return 0;
}

int server_work::hs_query(const char* telno, bas::CR& cr)
{
   /// 设置数据
   int ret = 0;
   const dena::string_ref op("=", 1); // 操作
   const dena::string_ref kvs[1] = { dena::string_ref(telno, strlen(telno)) };

   _hs.request_buf_exec_generic(1, op, kvs, 1, 10, 0, dena::string_ref(), 0, 0,
            0, 0);
   //std::clog << _hs.get_write_buffer() << std::endl;
   /// 发送请求数据,失败则返回错误码
   if (0 != (ret = _hs.request_send()))
   {
      cr.resultcode = -1;
      std::cerr << _hs.get_error() << ":" << _hs.get_error_code() << std::endl;
      return ret;
   }

   /// 接收应答结果,失败则返回错误码
   size_t len = 0;
   if (0 != (ret = _hs.response_recv(len)))
   {
      cr.resultcode = -1;
      std::cerr << _hs.get_error() << ":" << _hs.get_error_code() << std::endl;
      return ret;
   }

   //std::clog << "hs record: " << _hs.get_read_buffer() << std::endl;
   // 0  5  1  testdb1  one/passwd1@test1 0  10000
   //len 是第二个值,字段数

   const dena::string_ref *row = _hs.get_next_row();
   int num_row = 0;
   cr.resultcode = 0;
   while (row != 0)
   {
      if (num_row == 0) ///字段0:号码段
      {
         strncpy(cr.phoneNum, string(row[0].begin(), row[0].size()).c_str(),
                  sizeof(cr.phoneNum));
      }
      for (unsigned int i = 1; i < len; ++i)
      {
         switch (i)
         {
            case 1: ///字段1:实例名
               strncpy(cr.nodes[num_row].instanceName,
                        string(row[i].begin(), row[i].size()).c_str(),
                        sizeof(cr.nodes[i].instanceName));
               break;
            case 2: ///字段2:连接串
               strncpy(cr.nodes[num_row].connectStr,
                        string(row[i].begin(), row[i].size()).c_str(),
                        sizeof(cr.nodes[i].connectStr));
               break;
            case 3: ///字段3:状态
               cr.nodes[num_row].status = atoi(
                        string(row[i].begin(), row[i].size()).c_str());
               break;
            case 4: ///字段4:阀值
               cr.nodes[num_row].chreshold = atoi(
                        string(row[i].begin(), row[i].size()).c_str());
               break;
            default:
               //clog << "unknown field: " << recvs[i] << endl;
               break;
         }
         // endof onerow
      }
      ++num_row;
      row = _hs.get_next_row();
   }
   cr.nodeMsgNum = num_row; ///修改记录数

   _hs.response_buf_remove();
   //_hs.close();
   return 0; /// 成功则返回0
}
void server_work::on_close(server_handler_type& handler,
         const boost::system::error_code& e)
{
   switch (e.value())
   {
      // 成功关闭
      case 0:
      case boost::asio::error::eof:
         std::cout << "close ok \n";
         std::cout.flush();
         break;

         // 连接破坏
      case boost::asio::error::connection_aborted:
      case boost::asio::error::connection_reset:
      case boost::asio::error::connection_refused:
         break;

         // 其它错误
      case boost::asio::error::timed_out:
      case boost::asio::error::no_buffer_space:
      default:
         std::cout << "server error " << e << " message " << e.message()
                  << "\n";
         std::cout.flush();
         break;
   }
   ///关闭 mysql
   _hs.response_buf_remove();
   _hs.close();
}

void server_work::on_write(server_handler_type& handler,
         std::size_t bytes_transferred)
{
   //std::cout << "send " << bytes_transferred
   //         << " bytes ok ...............\n";
   //std::cout.flush();

   handler.async_read_pack();
}

int server_work::get_multi_result(const char* phone)
{
   int ret = 0;
   bas::CR &cr = *protocal_.data();
   std::string phone_num(phone);
   /// 从全码条件开始搜索库表
   for (int i = strlen(phone); i > 0; --i)
   {
      std::string tel(phone_num, i);

      /// 检查结果记录数,排序,break
      if (0 == (ret = hs_query(phone_num.c_str(), cr)))
      {
         if (cr.nodeMsgNum <= 0) // 没有记录,减少一位重来
         {
            continue;
         }
         else // 多条记录
         {
            protocal_ << "0" << cr.phoneNum //结果,号码段
                     << boost::lexical_cast<string>(cr.nodeMsgNum).c_str(); // 节点数
            for (int i = 0; i < 8 && i < cr.nodeMsgNum; ++i)
            {
               //要所有结果的查询
               protocal_ << cr.nodes[i].instanceName << cr.nodes[i].connectStr
                        << boost::lexical_cast<string>(cr.nodes[i].status).c_str()
                        << boost::lexical_cast<string>(cr.nodes[i].chreshold).c_str();
            }
            protocal_ << 2; //应答命令码
            break; //已查到结果,跳出while
         }
      }
      else
      {
         protocal_ << "1" << phone_num.c_str() // 结果,号码段
                  << 2; //命令码
         break; //跳出for回结果
      }
   } //end for
   if (ret == 0 && cr.nodeMsgNum == 0) ///所有有可能的号码段都成功查询完毕但结果记录数为0
   {
      protocal_ << "0" << phone_num.c_str() << "0" << 2;
   }
   return ret;
}

int server_work::get_single_result(const char* phone)
{
   int ret = 0;
   bas::CR &cr = *protocal_.data();
   std::string phone_num(phone);
   /// 从全码条件开始搜索库表
   for (int i = strlen(phone); i > 0; --i)
   {
      std::string tel(phone_num, i);

      /// 检查结果记录数,排序,break
      if (0 == (ret = hs_query(phone_num.c_str(), cr)))
      {
         if (cr.nodeMsgNum <= 0) // 没有记录,减少一位重来
         {
            continue;
         }
         else // 多条记录
         {
            protocal_ << "0" << cr.phoneNum //结果,号码段
                     << "1"; // 节点数

            {//只要单个结果的查询
               ///@TODO 随机结果
               protocal_ << cr.nodes[0].instanceName //实例名
                        << cr.nodes[0].connectStr // 连接串
                        << boost::lexical_cast<string>(cr.nodes[0].status).c_str() //状态
                        << boost::lexical_cast<string>(cr.nodes[0].chreshold).c_str(); //阀值
            }

            protocal_ << 4; //应答命令码
            break; //已查到结果,跳出while
         }
      }
      else //数据库异常
      {
         protocal_ << "1" << phone_num.c_str() // 结果,号码段
                  << 4; //命令码
         break; //跳出for回结果
      }
   } //end for
   if (ret == 0 && cr.nodeMsgNum == 0) ///所有有可能的号码段都成功查询完毕但结果记录数为0
   {
      protocal_ << "0" << phone_num.c_str() << "0" << 4;
   }
   return ret;
}

void server_work::on_read(server_handler_type& handler,
         std::size_t bytes_transferred)
{
   protocal_.Reset(); /// 重置压码
   protocal_.data()->qcommand = handler.protocal().data()->qcommand; ///设置收到的查询码,以便后面据此设定应答码

   switch (protocal_.data()->qcommand)
   {
      case 1: // 多结果查询
         if (0 != get_single_result(handler.protocal().data()->phoneNum))
         {
            cerr << "查询失败" << endl;
         }
         break;

      case 3: //单结果查询
         if (0 != get_multi_result(handler.protocal().data()->phoneNum))
         {
            cerr << "查询失败" << endl;
         }
         break;

      default:
         protocal_ << "1" << handler.protocal().data()->phoneNum << (int)protocal_.data()->qcommand; //命令码错误
         cerr << "未知命令码 " << endl;
         break;

   }

   char *buf = 0;
   int ret = protocal_.Encode(buf); // ret 返回整个数据的包长度,-1表示失败
   std::cout << "encoded ans: " << protocal_ << std::endl;

   handler.async_write(boost::asio::buffer(buf, ret));
}

void server_work::on_open(server_handler_type& handler)
{
   std::cout << "client ["
            << handler.socket().remote_endpoint().address().to_string()
            << "] connect" << "\n";
   std::cout.flush();

   _conf["port"] = boost::lexical_cast<string>(
            Config::instance().get<int> ("mysql.port"));
   _conf["host"] = Config::instance().get<string> ("mysql.ip");
   _arg.set(_conf);
   if (0 != _hs.init(_arg))
   {
      std::cerr << "连接mysql失败\n";
      ///@TODO 初始化连接数据失败回出错应答包,处理是否退出程序等问题
      handler.close();
   }
   hs_open_index();

   handler.async_read_pack();
}

/// 主函数
int main(int argc, char* argv[])
{
   try
   {
      /// 检查命令行参数
      Config::instance().parse(argc, argv);

      if (Config::instance().count("help"))
      {
         Config::instance().help();
         exit(EXIT_SUCCESS);
      }

      /// 初始化 server.
      typedef bas::server<server_work, server_work_allocator> server;
      typedef bas::service_handler_pool<server_work, server_work_allocator>
               server_handler_pool;

      server s(
               Config::instance().get<string> ("route.ip").c_str(),
               Config::instance().get<int> ("route.port"),
               Config::instance().get<int> ("route.ios"),
               Config::instance().get<int> ("route.threads"),
               new server_handler_pool(new server_work_allocator(),
                        Config::instance().get<int> ("route.handlers"),
                        Config::instance().get<int> ("route.buffer"), 0,
                        Config::instance().get<int> ("route.timeout"),
                        Config::instance().get<int> ("route.wait")));

      // 阻塞所有信号,不传递给新创建的线程
      sigset_t new_mask;
      sigfillset(&new_mask);
      sigset_t old_mask;
      pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

      // 创建线程后台运行
      boost::thread t(boost::bind(&server::run, &s));

      // 恢复原来的信号
      pthread_sigmask(SIG_SETMASK, &old_mask, 0);

      // 等待特定的信号
      sigset_t wait_mask;
      sigemptyset(&wait_mask);
      sigaddset(&wait_mask, SIGINT);
      sigaddset(&wait_mask, SIGQUIT);
      sigaddset(&wait_mask, SIGTERM);
      sigaddset(&wait_mask, SIGUSR2);
      pthread_sigmask(SIG_BLOCK, &wait_mask, 0);
      int sig = 0;
      int ret = -1;
      while (-1 != (ret = sigwait(&wait_mask, &sig)))
      {
         printf("Receive signal. %d\n", sig);
         if (sig == SIGUSR2)
            continue;
         if (sig == SIGTERM || sig == SIGQUIT || sig == SIGINT)
            break;
      }
      if (ret == -1)
      {
         printf("sigwaitinfo() returned err: %d; %s\n", errno, strerror(errno));
      }

      // 停止服务器
      s.stop();
      t.join();
   }
   catch (std::exception& e)
   {
      std::cerr << "exception: " << e.what() << "\n";
   }

   return 0;
}

/**
 @addtogroup Database  数据库结构

 <table border>
 <tr><th>字段</th>             <th>类型</th>        <th>说明</th>
 <tr><td>subno</td>           <td>char(32)</td>    <td>Primary key,可以是一个号码，也可以是一个号码段</td>
 <tr><td>instance_name</td>   <td>char(8)</td>     <td>MySQL实例名称</td>
 <tr><td>connect_string</td>  <td>char(64)</td>    <td>数据库链接字符串</td>
 <tr><td>status</td>          <td>smallint</td>    <td><ul><li>表的状态，取值如下：
 <ol>
 <li>0：正常
 <li>1：表进行压缩
 <li>2：批量导入数据
 <li>3：处理scale out状态
 </ol>
 </ul></td>
 <tr><td>threshold</td>       <td>int</td>         <td>插入数量阀值</td>
 </table>

 @par SQL语句:
 @code
 drop table if exists route;
 create table route
 (
 subno  char(32) not null,
 instance_name char(8),
 connect_string char(64),
 status int,
 threshold int
 );
 create index idx_subno on route(subno);
 @endcode

 @addtogroup testcase 测试
 @ingroup Database
 @par 测试数据:
 @code
 insert into route values('1','testdb1','one/passwd1@test1',0,10000);
 @endcode

 @addtogroup Command 命令码
 @par 多结果查询
 请求包命令字:１
 应答包命令字:２
 @par 单结果查询
 请求包命令字:3
 应答包命令字:4
 */
