/**
 * Protocal.cpp
 * @file
 * @brief 传协议的封装及解释实现
 *
 * @date 2011-5-4 created
 * @author bonly
 */

#include "Protocal.h"
#include <arpa/inet.h>

namespace bas
{
   int BufferEncoder::Encode(const char* s)
   {
      if (first_ == false)
      {
         strncat(MsgBody_, " ", 1);// 补一个空格
         MsgLen_++;
      }
      else
         first_ = false;

      int len = strlen(s); /// 取得字符串的长度,不包括'\0'
      if (MsgLen_ + len >= (MAXLEN - HEADLEN - 1)) /// 数据包长度不能大于 MAXLEN,否则返回1
         return 1;

      strncat(MsgBody_, s, len);
      MsgLen_ += len;
      return 0;
   }

   void BufferEncoder::EndOfBuffer(int i)
   {
      Command_ = i;
      MsgBody_[MsgLen_] = '\n';
      MsgLen_ = MsgLen_ + 2 + HEADLEN; /// 最后包长是要加上包头长度
      int len = htonl(MsgLen_); /// 包长值转换为网络字节
      memcpy(buffer_, &len, 4);
      int cmd = htonl(i); /// 命令码值转换为网络字节
      memcpy(buffer_ + 4, &cmd, 4);
   }

   int BufferEncoder::GetMsg(char*& s)
   {
      s = buffer_;
      return MsgLen_;
   }

   int BufferEncoder::Decode(const char* s)
   {
      /// 解释包头
      if (0 != Decode_Head(s))
         return -1;

      int num = 0;
      /// 检查数据包是否正确
      MsgBody_ = (char*) (s + HEADLEN);
      num = strlen(MsgBody_) + HEADLEN + 1;
      return (num == MsgLen_) ? 0 : 1;
   }

   int BufferEncoder::Decode_Head(const char* s)
   {
      try
      {
         /// 把网络字节序的长度值转为本地字节
         int num = 0;
         memcpy(&num, s, 4);
         MsgLen_ = ntohl(num);

         /// 把网络字节序的命令码值转为本地字节
         memcpy(&num, s + 4, 4);
         Command_ = ntohl(num);
      }
      catch (...)
      {
         return -1;
      }

      return 0;
   }

   int Protocal::DecodeQry(const char* s)
   {
      if (buffer_.Decode(s) != 0 || s == NULL)
         return -1;

      /// 获取命令码及整个包长
      data_.qcommand = buffer_.GetCommand();
      data_.msgLen = buffer_.GetMsgLen();

      /// 获取电话号码phoneNum
      istringstream ss;
      ss.str(buffer_.GetMsgBody());
      ss >> data_.phoneNum;
      return 0;
   }

   int Protocal::Encode(char*& s)
   {
      if (!this->good() && !this->eof())
      {
         /** 如果包状态是坏的并且没有结束,则返回-1,
          */
         return -1; /// 如果包状态是坏的并且没有结束,则返回-1
      }
      buffer_.GetMsg(s);
      return buffer_.GetMsgLen();
   }

   int Protocal::DecodeAns(const char* s)
   {
      if (buffer_.Decode(s) != 0 || s == NULL)
         return -1;

      /// 获取命令码及整个包长
      data_.acommand = buffer_.GetCommand();
      data_.msgLen = buffer_.GetMsgLen();

      istringstream ss;
      ss.str(buffer_.GetMsgBody());

      string str;
      /// 取ResultCode
      ss >> str;
      data_.resultcode = atoi(str.c_str());
      if (data_.resultcode != 0) ///如果结果为失败,无需解释后面的内容
         return 0;

      /// 取SubNo
      ss >> str;
      strncpy(data_.phoneNum, str.c_str(), sizeof(data_.phoneNum));
      /// 取NodeMsgNum
      ss >> str;
      data_.nodeMsgNum = atoi(str.c_str());
      for (int i = 0; i < data_.nodeMsgNum || i < MAXNODE; ++i)
      {
         /// 取instanceName
         ss >> str;
         strncpy(data_.nodes[i].instanceName, str.c_str(),
                  sizeof(data_.nodes[i].instanceName));

         /// 取connectStr
         ss >> str;
         strncpy(data_.nodes[i].connectStr, str.c_str(),
                  sizeof(data_.nodes[i].connectStr));

         /// 取status
         ss >> str;
         data_.nodes[i].status = atoi(str.c_str());

         /// 取chreshold
         ss >> str;
         data_.nodes[i].chreshold = atoi(str.c_str());
      }

      return 0;
   }

}

/* test main
 using namespace bas;
 int main()
 {
 {
 Protocal p;
 p << "13719360007" << 1; // 以整型命令码值表示赋值结束,如果结束后再加字串字段会不让编译通过
 cout << "encoded: " << p << endl; // 打印包体内容(不包括命令码)

 char *buf = 0;
 int ret = p.Encode(buf); // ret 返回整个数据的包长度,-1表示失败
 ret = p.DecodeQry(buf); // ret 0:成功 其它:失败

 p.Reset();  // 如果想要重用对象来压包或者出错后重用同一对象压包,必须先重置一次对象,以便清理状态;解包无此要求
 p << "13719360008" << 1; // 以整型命令码值表示赋值结束,在别的地方再加入字段内容,将舍弃新加的内容
 ret = p.Encode(buf);
 cout << "encoded: " << p << endl;
 }
 {
 Protocal p;
 p << "0" << "1371936" << "2" // 结果,号码段,节点数
 << "inst1" << "abc/ok@testdb1" << "0" << "100000" //第1个节点
 << "inst2" << "abc/no@testdb2" << "0" << "100000" //第2个节点
 << 2; //命令码
 cout << "encoded: " << p << endl;

 char *buf = 0;
 int ret = p.Encode(buf); // ret 返回整个数据的包长度,-1表示失败
 ret = p.DecodeAns(buf); // buf是收到的数据包指针, ret 0:成功 其它:失败
 cout << "共有节点数: " << p.data()->nodeMsgNum << endl;
 cout << "号码段: " << p.data()->phoneNum << endl;
 }

 return 0;
 }
 // */

