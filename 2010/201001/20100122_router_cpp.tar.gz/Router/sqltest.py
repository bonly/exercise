#!/usr/bin/python
#-*-coding:utf-8-*-
##
#@package sqltest
#@file
#@brief 测试脚本
#

import MySQLdb
global conn, cursor

## 创建连接
def ConnectDB():
   global conn, cursor
   conn = MySQLdb.connect(host='127.0.0.1', user='root', passwd='')
   cursor = conn.cursor()
   
##创建ＤＢ   
def CreateDB():
   cursor.execute("""create database if not exists test""")
   
##创建表   
def CreateTab():   
   conn.select_db("test");
   cursor.execute("""create table if not exists route(
                     subno  char(32) not null,
                     instance_name char(8),
                     connect_string char(64),
                     status int,
                     threshold int)
                     """)
 
##创建索引
def CreateIndex():   
   cursor.execute("create index idx_subno on route(subno)")
   
##关闭连接   
def CloseAll():
   cursor.close()      

##插入测试数据         
def InsertData():
   count = 5000
   for i in range(count):
      cursor.execute("insert into route value(%s,%s,%s,%s,%s)",
                     [13719360000+i, "testdb1","user/passwd@127.0.0.1:8080", "0", "1000"])
      cursor.execute("insert into route value(%s,%s,%s,%s,%s)",
                     [13719360000+i, "testdb2","user/passwd@137.0.0.1:8080", "0", "1000"])
      cursor.execute("insert into route value(%s,%s,%s,%s,%s)",
                     [13719360000+i, "testdb3","user/passwd@157.0.0.1:8080", "0", "1000"])
               
if __name__ == "__main__":
   ConnectDB()
   CreateDB()
   
   CreateTab()
   #CreateIndex()
   InsertData()   
   
   CloseAll()
   
