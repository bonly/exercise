#ifndef __ini_h
#define __ini_h
#pragma warning (disable:4786 4101 4503 4508)

#include <string>
#include <map>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;
typedef map<string, string, less<string> > strMap;
typedef strMap::iterator strMapIt;

const char*const MIDDLESTRING = "_____***_______";

struct analyzeini
{
    string strsect;
    strMap *pmap;
    analyzeini(strMap & strmap):pmap(&strmap){}
    void operator()( const string & strini);
};

class IniFile
{
public:
    IniFile( ){};
    ~IniFile( ){};
    bool open(const char* pinipath)
    {
        return do_open(pinipath);
    }
    string read(const char*psect, const char*pkey);

protected:
    bool do_open(const char* pinipath);
    strMap c_inimap;
};

/*
    IniFile ini;
    if(!ini.open("test.ini"))
       return -1;
    string strvalue = ini.read("sect1","key1");
    if(strvalue.empty())
        return -1;
    else
        cout<<"value="<<strvalue<<endl;
    return 0;
*/

#endif

