#ifndef __Data_h
#define __Data_h

#include <string>
using namespace std;

class Data
{
  public:
    virtual int Process ()
    {
      read_data ();
      execute ();
      return 0;
    }

  protected:
    Data (){}
  private:
    virtual int read_data ()=0;
    virtual int execute ()=0;
};

#endif
