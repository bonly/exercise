#ifndef __Data_Online_Time_h
#define __Data_Online_Time_h

#include <iostream>
#include <list>
#include "Data.h"
#include "ini.h"
using namespace std;

#define OTL_ORA9I
#include "otlv4.h"

struct DB
{
  char pszDBConn[255];
   
  otl_connect db;
  otl_stream  cur;

  DB ();
  void connectDB(const char* pszDBConn, otl_connect *db, otl_stream *cur);
};

class Data_Online_Time : public Data
{
  public:
    struct Online
    {
      char account[255];
      char time[255];
      char month[255];
    };

    Data_Online_Time (string file):_file(file)
    {//todo init database connect str
    }
    virtual ~Data_Online_Time ()
    {//todo release list<Online*>
    }
  private:
    virtual int read_data ();
    virtual int execute ();
    int process_data (char* account, char* time, char* month);
  private:
    string _file;
    list<Online*> _online;
    DB _db;
};

#endif //__Data_Online_Time_h
