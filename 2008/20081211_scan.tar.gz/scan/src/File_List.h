#ifndef __File_List_h
#define __File_List_h
#include <list>
#include <string>
#include <iostream>
#ifdef WIN32
  #include <windows.h>
#else
  #include <dirent.h>
  #include <sys/stat.h>
  //#include <sys/types.h>
#endif //__WIN32

using namespace std;

class File_List
{
  public:
    File_List (string dir)
    {
      memset (_dirs, 0, 255);
      strncpy (_dirs, dir.data(),dir.length());
      
      _it=_files.begin();
    }
    virtual  ~File_List (){}
    virtual int scan_dir ()=0;
    list<string>::iterator  sore (){return _it=_files.begin();}
    list<string>::iterator  end_file (){return _files.end();}
    list<string>::iterator  begin_file (){return _files.begin();}
    list<string>::iterator  next_file (){return ++_it;}
    int move_file (const char* strSrcPath,const char*  strFile,const char*  strDesPath);
  protected:
    list<string> _files;
    list<string>::iterator _it;
    char _dirs[255];
};

#ifdef WIN32
class Win_File_List : public File_List
{
  public:
    Win_File_List (string dir):File_List(dir){}

    virtual ~Win_File_List (){}
    virtual int scan_dir ();
};
#endif

#ifndef WIN32
class Linux_File_List : public File_List
{
  public:
    virtual ~Linux_File_List (){}
    Linux_File_List (string dir):File_List::File_List(dir){}
    virtual int scan_dir ();
    char* get_month();
};
#endif

#endif  //__File_List_h
