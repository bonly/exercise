#ifndef __Application_h
#define __Application_h

#include <iostream>
#include "File_List.h"
#include "Data_Online_Time.h"
#include "ini.h"

class Application
{
  public:
    Application (){};
    virtual ~Application (){};
    
    int run ();

  private:
    File_List* _file_list;
    Data* _data;
    IniFile ini;
};

#endif //__Application_h
