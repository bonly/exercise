#include "File_List.h"

int File_List::move_file(const char*  strSrcPath, const char*  strFile,const char*  strDesPath)
{
        int result = 0;
#ifdef WIN32
        char szTemp[2] = "\\";
#else
        char szTemp[2] = "/";
#endif

        char strBakFile[255];
        char strSrcFile[255];
        memset (strSrcFile, 0, sizeof(strSrcFile));
        memset (strBakFile, 0, sizeof(strBakFile));

        strcpy (strBakFile, strDesPath);
        strcat (strBakFile, szTemp);
        strcat (strBakFile, strFile);

        strcpy (strSrcFile, strSrcPath);
        strcat (strSrcFile, szTemp);
        strcat (strSrcFile, strFile);

        rename(strSrcFile, strBakFile);
        return result;
}

char* Linux_File_List::get_month()
{
   time_t timep;
   struct tm *p;
   time(&timep);
   p=localtime(&timep);
   char* result=new char(11);
   memset (result,0,sizeof(result));
   sprintf(result,"%d%02d", (1900+p->tm_year),( 1+p->tm_mon));
   return result;
}

#ifndef WIN32
int Linux_File_List::scan_dir ()
{
  int result = 1;

  DIR* pDir;
  struct dirent *ent;

  const char* pszDir = strcat(_dirs,"/");

  /*
  char  filename[11];
  memset (filename,0,11);
  char* p=get_month();
  strcpy (filename,p);
  strcpy (filename,".txt");
  delete[] p;
  */

  if((pDir = opendir(pszDir)) == NULL)
  {
    std::cout << "Directory open err " << pszDir << std::endl;
    std::cout << __FILE__ << ": " << __LINE__ << std::endl;
  }
  else
  {
    while((ent = readdir(pDir)) != NULL)
    {
            if(strcmp(".",ent->d_name) == 0||strcmp("..",ent->d_name) == 0)
            {
                continue;
            }
            else
            {
              char str[255];
              memset (str, 0, sizeof(str));
              strcpy (str, pszDir);
              strcat (str, ent->d_name);

              struct stat buf;
              if(stat(str, &buf)!=0)
              {
                closedir(pDir);
                std::cout<< "stat file err:" << str << std::endl;
                std::cout << __FILE__ << ": " << __LINE__ << std::endl;
                break;
              }
              else
              {
                //if (0 == strcmp (ent->d_name,filename))
                //std::cout<< std::string("scan file: ") << _dirs 
		            //        << ent->d_name << std::endl;

		            _files.push_back (ent->d_name);

                //this->count++;
                result=0;
                //break; 
              }
             } //else
    }//while
  }//if else
  closedir(pDir);
  return result;
}
#endif

#ifdef WIN32
int Win_File_List::scan_dir ()
{
        int result=1;
        bool fFinished;
        HANDLE hList;
        char szDir[MAX_PATH+1];
        
        LPWIN32_FIND_DATAA FileData=new _WIN32_FIND_DATAA;

        // Get the proper directory path
        sprintf(szDir, "%s\\*", _dirs);

        // Get the first file
        hList = FindFirstFileA(szDir, FileData);
        if (hList == INVALID_HANDLE_VALUE)
        {
          printf("No files found\n\n");
        }
        else
        {
          // Traverse through the directory structure
          fFinished = false;
          while (!fFinished)
          {
              // Check the object is a directory or not
              if (FileData->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
              {
                  if ((strcmp(FileData->cFileName, ".") != 0) && (strcmp(FileData->cFileName, "..") != 0))
                  {
                      cout << "found subdir: "<< FileData->cFileName<<endl;
                  }
              }
              else  //found file
              {
                    std::cout<< std::string("scan file: ") << _dirs 
		                        << FileData->cFileName << std::endl;

		                _files.push_back (FileData->cFileName);

                    result=0;
               }

               if (!FindNextFileA(hList, FileData))
               {
                   if (GetLastError() == ERROR_NO_MORE_FILES)
                   {
                     fFinished = true;
                   }
               }
          }
        }
        FindClose(hList);
        delete FileData;

        return result;
}
#endif
