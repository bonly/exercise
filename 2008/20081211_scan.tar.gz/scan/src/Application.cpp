#include "Application.h"

int Application::run ()
{
  if (!ini.open ("Config.ini"))
  {
    cerr << "Can not find Config.ini!"<<endl;
    return 1;
  }

  string dir (ini.read ("Import","DIR"));
  //dir.erase (dir.length()-1,1);
  string dir_back (ini.read ("Import","DIR_BACKUP"));
  //dir_back.erase (dir_back.length()-1,1);
#ifdef WIN32
  _file_list = new Win_File_List (dir);
#else 
  _file_list = new Linux_File_List (dir);
#endif

  _file_list->scan_dir ();
  for (list<string>::iterator it=_file_list->sore (); 
      it!=_file_list->end_file ();
      it=_file_list->next_file ())
  {
#ifndef WIN32
     string file=dir+"/"+(*(it));
     string file_back=dir_back+"/";//+(*(it));
#else
     string file=dir+"\\"+(*(it));
     string file_back=dir_back+"\\";//+(*(it));
#endif
     Data *dt = new Data_Online_Time (file);
     dt->Process ();
     delete dt;
     _file_list->move_file (dir.c_str (), (*it).c_str(), file_back.c_str());
  }

  return 0;
}

