#include "Data_Online_Time.h"

int Data_Online_Time::read_data ()
{
  int result = 0;
  FILE *infile;
  if (NULL != (infile=fopen(_file.c_str (),"r")))
  {
    while (!feof(infile))
    {
      Online *online = new Online;
      memset (online,0,sizeof(Online));
      int ob = fscanf (infile,"%s %s %s\n",
	  &online->account,&online->time,&online->month);
      _online.push_back (online);
      if (0>=ob)
	break;
    }
#ifdef _DEBUG_LIST    
    for (list<Online*>::iterator it=_online.begin (); it!=_online.end(); it++)
    {
      cout << "Account: "<< (*it)->account <<" Time: "<<(*it)->time
	         <<" Month: "<<(*it)->month<<endl;
    }
#endif    
  }
  fclose (infile);
  return result;
}

int Data_Online_Time::execute ()
{ 
  int totle = _online.size ();
  int proc=0;
  for (list<Online*>::iterator it=_online.begin () ; it != _online.end (); it++, proc++)
  {

    std::cout << proc << " / " << totle <<  std::endl;
    if (0 != strcmp ((*it)->account, "account"))
      process_data ((*it)->account, (*it)->time, (*it)->month);
  }
  return 0;
}

int Data_Online_Time::process_data(char* account, char* time, char* month)
{
  int result = 0;

  try
  {
    _db.connectDB (_db.pszDBConn, &_db.db, &_db.cur);

    _db.cur.set_commit(0);

    char* sql="\
        insert into Report.RPT_BUSI_DEV_shangwangshichang \
               (shangwangzhanghao,duration,report_month) \
        values ( :account<char[255]>,:time<int>,:month<char[255]> )";
//        values ( :account<char[255]>,:time<int>,to_char(SYSDATE-INTERVAL'1' MONTH,'yyyymm') )";
    _db.cur.close ();
    _db.cur.open(1,sql,_db.db);

    _db.cur << account << atoi(time) << month;
//    _db.cur << account << atoi(time);
    _db.cur.flush();
    _db.db.commit();
  }
  catch(otl_exception& p)
  { // intercept OTL exceptions
    cerr<<p.msg<<endl; // print out error message
    cerr<<p.stm_text<<endl; // print out SQL that caused the error
    cerr<<p.var_info<<endl; // print out the variable that caused the error
    _db.db.rollback();
  }
  catch(const char* msg)
  {
    cerr<<msg<<endl; // print out the message
    _db.db.rollback(); // roll back transaction
  }

  return result;
}

void DB::connectDB(const char* pszDBConn, otl_connect *db, otl_stream *cur)
{
        if(db->connected)
        {
          return;
        }

        try
        {
          db->logoff();
        }
        catch(const otl_exception& ex)
        {
        }

        for(;;)
        {
                try
                {
                        db->rlogon (pszDBConn);
                        break;
                }
                catch(const otl_exception& ex)
                {
#ifndef WIN32
                        //sleep(5);
#endif
                }
                catch (...)
                {
                  std::cerr << "cann't connect to dababase" << std::endl;
                }
        }
}
DB::DB()
{
  IniFile ini;

  if(!ini.open("Config.ini"))
  {
   std::cout << "cann't find config.ini! \n" << std::endl;
   std::cout << __FILE__ << ": " << __LINE__ << std::endl;
   throw "No config.ini found";
  }

  memset (pszDBConn, 0, sizeof(pszDBConn));
  strcpy (pszDBConn, ini.read("Import","DB").c_str());

}

