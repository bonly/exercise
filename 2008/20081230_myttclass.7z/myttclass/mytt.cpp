// ttobject.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include <windows.h>
#include "db.hpp"
#include <iostream>

int main(int argc, char* argv[])
{
	using namespace bonly;
	CDB db;
	db.connect("DSN=bonly");

	PCmd cmd=db.prepare("select * from te");
	cmd->execute();
	while(cmd->fetch_next()==0)
	{
		int smskey=-1;
		char keyvalue[20+1];
		memset (keyvalue,0,21);
		cmd->ttcmd().getColumnNullable(1,&smskey);
		cmd->ttcmd().getColumnNullable(2,keyvalue);
		std::cout << "smskey: " << smskey << "\n";
		std::cout << "keyvalue: "<< keyvalue << "\n";
	}
	return 0;
}

