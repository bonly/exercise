#include "db.hpp"
namespace bonly{

int 
CCommand::close()
{
	_ttcmd.Close(_status);
	if(_status.rc)
	{
		printf("ttcmd close failed:  %s\n", _status.err_msg);
		return -1;
	}
	_ttcmd.Drop(_status);
	if (_status.rc)
	{
		printf("TTCmd::Close failed: %s\n", _status.err_msg);
		return -1;
	}
	return _db->commit();
}
int 
CCommand::execute()
{
	_ttcmd.Execute(_status);
	if(_status.rc)
	{
		printf("TTCmd::execute Failed", _status.err_msg);
		return -1;
	}
	return 0;
}
int 
CCommand::fetch_next()
{
  return _ttcmd.FetchNext(_status);
}

//===========================================================================================

int CDB::connect(const char* szDSN)
{
	_connect.Connect(szDSN, _status);
	if (_status.rc)
	{
		printf("Connect to [%s] Failed::%s\n", szDSN, _status.err_msg);
		return -1;
	}
	_connect.SetAutoCommitOff(_status);
	if (_status.rc)
	{
		printf("Set autocommit = 0 Failed\n");
		return -1;
	}
	return 0;
}

int CDB::commit()
{
	_connect.Commit(_status);
	if (_status.rc)
	{
		printf("DB::Commit failed: %s\n", _status.err_msg);
		return -1;
	}
	return 0;
}
int CDB::rollback()
{
	_connect.Rollback(_status);
	if (_status.rc)
	{
		printf("CBFSQL::Destory rollback failed: %s\n", _status.err_msg);
		return -1;
	}
	return 0;
}
int CDB::disconnect()
{
	_connect.Disconnect(_status);
	if (_status.rc)
	{
		printf("Disconnect TimesTen Failed:: %s\n", _status.err_msg);
		return -1;
	}
	return 0;
}
PCmd CDB::prepare (const char* sql)
{
	PCmd cmd (new CCommand); 
	cmd->db(this);
	cmd->ttcmd().Prepare(&_connect, sql, cmd->status());
	if(cmd->status().rc)
	{
		printf("Prepare sql failed:%s\n", cmd->status().err_msg);
		//todo: return NULL;
	}
	commit();
	return cmd;
}
}

