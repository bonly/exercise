#ifndef __BONLY_DB_HPP__
#define __BONLY_DB_HPP__

#include <boost/shared_ptr.hpp>
#include <ttclasses/TTInclude.h>
namespace bonly{
using namespace boost;

class CDB;

class CCommand
{
public:
  template<typename field>
  void setParam(int i, field key)
  {
	  _ttcmd.setParam(i,key);
  }
  int execute();
  int fetch_next();
  int close();

  TTStatus& status(){return _status;}
  TTCmd&    ttcmd(){return _ttcmd;}
  void      db(CDB* d){_db=d;}
private:
  TTCmd		   _ttcmd;
  TTStatus     _status;
  CDB*         _db;
};

typedef shared_ptr<CCommand> PCmd;

class CDB
{
public:
    int connect(const char* szDSN);
	int commit();
	int rollback();
	int disconnect();
	PCmd prepare (const char* sql);

	TTConnection& connect(){return _connect;}
private:
	TTConnection _connect;
	TTStatus     _status;
};
}
#endif // __BONLY_DB_HPP__