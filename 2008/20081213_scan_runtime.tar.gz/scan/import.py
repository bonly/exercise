#!/usr/bin/python
#auth:bonly

import os;
import time;


if __name__=="__main__":
        os.environ["ORACLE_HOME"]="/data1/oracle/product/9.2.0"
   	os.environ["LANG"]="zh_CN.GB2312";
	os.environ["LANGUAGE"]="zh_CN.GB18030:zh_CN.GB2312:zh_CN";
	os.environ["NLS_LANG"]="american_america.ZHS16GBK";
	os.environ["LD_LIBRARY_PATH"]="$ORACLE_HOME/lib:/data1/bss/interface/boost_1_36_0/stage/lib";


	exe_name = "scan";
        Program_HOME="/data1/bss/interface/bin/scan";
	Program="%s/%s"%(Program_HOME, exe_name);
        Log="%s/log"%(Program_HOME);

	f = open(Log,"a+");

	os.chdir(Program_HOME);
	f.write (time.asctime(time.localtime()));
	f.write ("  begin\n");
	f.write ("    searching file ...\n");
	os.spawnl("P_WAIT","/data1/bss/interface/bin/scan/copy_file","copy_file","/data1/bss/interface/bin/scan/file.cfg");
	f.write ("    search file finished\n");
	f.write ("    scan and import data ...\n");
	os.spawnl("P_WAIT",Program,"scan");
	f.write ("    scan import data finished\n");

	f.write (time.asctime(time.localtime()));
	f.write ("  finish all jobs\n");

	f.close ();


