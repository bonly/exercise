//============================================================================
// Name        : unix_connect.cpp
// Author      : bonly
// Version     :
// Copyright   : bonly's copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
//#define __USE_W32_SOCKETS
//#include <winsock2.h>
//#include <winsock.h>
//lib:ws2_32 wsock32  mswsock
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include <iostream>
using namespace std;

class Connector
{
	public:
		int init()
		{
			_peer.sin_family = AF_INET;

			_socket = ::socket (AF_INET, SOCK_STREAM, 0);
			if (_socket < 0)
			{
				perror ("socket call failed");
				return -1;
			}
			return 0;
		}
    int connect (const char* addr, const unsigned int port)
    {
			_peer.sin_port = htons (port);
			_peer.sin_addr.s_addr = inet_addr (addr);
    	int rc = ::connect (_socket, (struct sockaddr*)&_peer, sizeof (sockaddr_in));
    	if (rc)
    	{
    		perror ("connect call failed");
    		return -1;
    	}
    	return rc;
    }
    static int send(int socket, const char* buf, size_t len)
    {
    	 //MSG_OOB(default��������)/MSG_PEEK(ȡ���ݲ�ɾ������)/MSG_DONTROUTE(����·��)
       int rc = ::send (socket, buf, len, MSG_OOB);
       if (rc<=0)
      	 perror ("send call failed");
       return 0;
    }
    static int recv(int socket, char* buf, size_t len)
    {
    	int rc = ::recv(socket, buf, len, MSG_OOB);
    	if (rc <=0)
    		perror ("recv call failed");
      return rc;
    }
    int& socket(){return _socket;}
	private:
		struct sockaddr_in _peer;
		int		_socket;
};

int main()
{
	Connector cn;
	cn.init();
	cn.connect("127.0.0.1",28989);
	cn.send (cn.socket(),"this is a test",15);
	return 0;
}
