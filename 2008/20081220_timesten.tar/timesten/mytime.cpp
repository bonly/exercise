#include "mytime.h"

#define SECONDS_1900_1970 2208988800L


//======================  CTimeUtil Class  ========================
//
/*
 * ��ȡϵͳ��ǰʱ��: ��00:00:00 on January 1, 1970��ʼ������ 
 */
time_t CTimeUtil::Time()
{
    time_t tTime;
    return time(&tTime);
}

/*
 * �����ж�
 * �ܱ�4���������ܱ�100����������ȴ�ܱ�400��������������
 * ����2�·���29��
 */
int CTimeUtil::IsLeapYear(int nYear)
{
    if (((nYear%4 == 0) && (nYear%100 != 0)) || (nYear%400 == 0))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}


/*
 * ���ڸ�ʽ���
 */
char *CTimeUtil::Format(char *szTime, const char *szFormat, const struct tm *ptm) 
{
    char  chFmt;
    char *pBuf = szTime;
    
    while ((chFmt = *szFormat++) != '\0')
    {
        if (chFmt == '%')
        {
            switch (chFmt = *szFormat++)
            {
            case '%':
                *pBuf ++ = chFmt;
                break;
            case 'y':
                pBuf += sprintf(pBuf, "%2.2d", ptm->tm_year);
                break;
            case 'Y':
                pBuf += sprintf(pBuf, "%4.4d", ptm->tm_year + 1900);
                break;
            case 'm':
                pBuf += sprintf(pBuf, "%2.2d", ptm->tm_mon + 1);
                break;
            case 'd':
                pBuf += sprintf(pBuf, "%2.2d", ptm->tm_mday);
                break;
            case 'H':
                pBuf += sprintf(pBuf, "%2.2d", ptm->tm_hour);
                break;
            case 'M':
                pBuf += sprintf(pBuf, "%2.2d", ptm->tm_min);
                break;
            case 'S':
                pBuf += sprintf(pBuf, "%2.2d", ptm->tm_sec);
                break;
            default:
                perror("Time Format Error:");
                return NULL;
            }
        }
        else
        {
            *pBuf ++ = chFmt;
        }
    } // end of while

    *pBuf = '\0';

    return szTime;
}


/*
 *  second ��ָ��00:00:00 on January 1, 1970��ʼ������ 
 */
char *CTimeUtil::ToString(char *szTime, const char *szFormat, time_t second)
{
	struct tm *ptm = localtime(&second);

    return CTimeUtil::Format(szTime, szFormat, ptm);
}


/*
 * �ɱ���ʱ�乹��һ��time_tʱ��: seconds elapsed since 00:00:00 on January 1, 1970
 */
time_t CTimeUtil::MakeTime(int nYear, int nMonth, int nDay, int nHour, int nMinute, int nSecond)
{
	struct tm tm;
    
    tm.tm_year  = nYear - 1900;
    tm.tm_mon   = nMonth - 1;
    tm.tm_mday  = nDay;
    tm.tm_hour  = nHour;
    tm.tm_min   = nMinute;
    tm.tm_sec   = nSecond;
	tm.tm_isdst = 0;
	tm.tm_wday  = 0;
	tm.tm_yday  = 0;

    return mktime(&tm);
}


//================== CUtcTime Class  =======================
//
/*
 * ��ȡϵͳ��ǰʱ��: ��00:00:00 on January 1, 1900��ʼ������ 
 */
time_t CUtcTime::UtcTime()
{
    time_t tTime;
    
    time(&tTime);
    
    return tTime - timezone + SECONDS_1900_1970;
}


/*
 * ��tTimeת����1900���ʱ��
 */
time_t CUtcTime::ToUtcTime(time_t tLocalTime)
{
    tzset();
    return tLocalTime - timezone + SECONDS_1900_1970;
}


/*
 * ��tTimeת����1970���ʱ��
 * timezone�Ǹ�ϵͳ����������
 */
time_t CUtcTime::ToLocalTime(time_t tUtcTime)
{
    tzset();
    return tUtcTime + timezone - SECONDS_1900_1970;
}



