#ifndef __BFSQL_H__
#define __BFSQL_H__

#include <ttclasses/TTInclude.h>

/* Define SQL
 */
#define BF_SQL_INSERT_SUBSCRIBER        0
#define BF_SQL_UPDATE_SUBSCRIBER        1
#define BF_SQL_SELECT_SUBSCRIBER        2

#define BF_MAX_SQL_COUNT                50

class CBFSQL
{
public:
    CBFSQL();
    ~CBFSQL();
    
    int    Init(TTConnection *pttconn);
    int    Destroy();
    
public:
    int           m_nSQLCnt;
    TTConnection *m_pttconn;

    static TTCmd  ms_ttcmds[BF_MAX_SQL_COUNT];
};

#endif // __BFSQL_H__