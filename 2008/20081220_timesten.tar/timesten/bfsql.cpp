#include <stdio.h>
#include <stdlib.h>

#include "bfsql.h"

/*
 * ȫ�־�̬����
 */
TTCmd  CBFSQL::ms_ttcmds[BF_MAX_SQL_COUNT];


CBFSQL::CBFSQL()
{
    m_pttconn = NULL;
    m_nSQLCnt = 0;
}

CBFSQL::~CBFSQL()
{
}


int CBFSQL::Init(TTConnection *pttconn)
{
    m_pttconn = pttconn;
    
    const char *bfSQLs[] = 
    {
        /* 0) BF_SQL_INSERT_SUBSCRIBER */
        "INSERT INTO test_subscriber"
        " (serv_id, cust_id, acc_nbr, status, eff_date, exp_date)"
        " VALUES (?, ?, ?, ?, SYSDATE, SYSDATE)",

        /* 1) BF_SQL_UPDATE_SUBSCRIBER */
        "UPDATE test_subscriber"
        "   SET status = ?, eff_date = SYSDATE"
        " WHERE acc_nbr = ?",

        /* 2) BF_SQL_QUERY_SUBSCRIBER */
        "SELECT serv_id, cust_id, status, eff_date, exp_date"
        "  FROM test_subscriber "
        " WHERE acc_nbr = ? "
    };

    m_nSQLCnt = sizeof(bfSQLs)/sizeof(char *);
    
    TTStatus stat;
    
    /* Ԥ����BF SQL���
     */
    for (int i=0; i<m_nSQLCnt; i++)
    {
        ms_ttcmds[i].Prepare(m_pttconn, bfSQLs[i], stat);
        if(stat.rc)
        {
            printf("Prepare sql failed: %s\n%s\n", bfSQLs[i], stat.err_msg);
            return -1;
        }
    }
    
    m_pttconn->Commit(stat);
    if (stat.rc)
    {
        printf("Commit sql failed:  %s\n", stat.err_msg);
        return -1;
    }

    return 0;
}


int CBFSQL::Destroy()
{
    TTStatus stat;
    for(int i=0 ; i<m_nSQLCnt; i++)
    {
        /* �ͷ�Ԥ����SQL���ռ�õ���Դ
         */
        ms_ttcmds[i].Drop(stat);
        if (stat.rc)
        {
            printf("TTCmd::Close failed: %s\n", stat.err_msg);
        }
    }

    m_pttconn->Rollback(stat);
    if (stat.rc)
    {
        printf("CBFSQL::Destory rollback failed: %s\n", stat.err_msg);
    }

    m_pttconn = NULL;
    m_nSQLCnt = 0;

    return 0;
}
