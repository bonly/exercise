#ifndef __MY_TIME_H__
#define __MY_TIME_H__

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*
 * ������ʱ���๤��
 */
class CTimeUtil
{
public:
	CTimeUtil(){};
	~CTimeUtil(){};

    static time_t Time();
	static time_t MakeTime(int nYear, int nMonth, int nDay, int nHour=0, int nMinute=0, int nSecond=0);

    static char *ToString(char *szTime, const char *szFormat, time_t tSecond);
    static char *Format(char *szTime, const char *szFormat, const struct tm *ptm);

	static int  IsLeapYear(int nYear);
};



/*
 * UTC Time Class
 * Seconds elapsed since 00:00:00 on January 1, 1900 
 * Attention: not 1970
 */ 

class CUtcTime
{
public:
	CUtcTime(){};
	~CUtcTime(){};

    // ��ȡϵͳUTCʱ��
    static time_t UtcTime();
    static time_t ToUtcTime(time_t tLocalTime);
    static time_t ToLocalTime(time_t tUtcTime);
   
};

#endif // __MY_TIME_H__
