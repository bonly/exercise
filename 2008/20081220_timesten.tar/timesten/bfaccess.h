#ifndef __BF_ACCESS_H__
#define __BF_ACCESS_H__

#include "bfsql.h"

typedef struct tagSubscriber
{
    SQLBIGINT  lSubsId;
    SQLBIGINT  lCustId;
    char       szAccNbr[16+1];
    char       szStatus[2+1];
    time_t     tEffDate;
    time_t     tExpDate;
    
} SUBS_STRUCT;


class CSubscriber
{
public:
    CSubscriber();
    ~CSubscriber();

public:
    int Insert(TTConnection *pttconn, const SUBS_STRUCT *subs);
    int Update(TTConnection *pttconn, const char *szAccNbr, const char *szStatus);
    int Select(const char *szAccNbr);
};


#endif // __BF_ACCSEES_H__

