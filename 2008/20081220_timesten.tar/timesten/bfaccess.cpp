#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bfaccess.h"


char *Timestamp2String(const TIMESTAMP_STRUCT &ts)
{
    static char szTime[64];
    
    sprintf(szTime, "%d-%d-%d %d:%d:%d", 
           ts.year,
           ts.month,
           ts.day,
           ts.hour,
           ts.minute,
           ts.second);
             
    return szTime;
}

CSubscriber::CSubscriber()
{
}

CSubscriber::~CSubscriber()
{
}


int CSubscriber::Insert(TTConnection *pttconn, const SUBS_STRUCT *subs)
{
    TTCmd &ttcmd = CBFSQL::ms_ttcmds[BF_SQL_INSERT_SUBSCRIBER];
        
    TTStatus stat;

    ttcmd.setParam(1, subs->lSubsId);
    ttcmd.setParam(2, subs->lCustId);
    ttcmd.setParam(3, subs->szAccNbr);
    ttcmd.setParam(4, subs->szStatus);
    //ttcmd.setParam(5, subs->tEffDate);
    //ttcmd.setParam(6, subs->tExpDate);

    ttcmd.Execute(stat);
    if (stat.rc)
    {
        printf("SUBS_STRUCT::Insert execute Failed %s\n", stat.err_msg);
        pttconn->Rollback(stat);
        return -1;
    }

    pttconn->Commit(stat);
    
    return 0;
}


/*
 * 1) BF_SQL_UPDATE_SUBS_STRUCT
 *  "UPDATE test_SUBS_STRUCT"
 *  "   SET status = ?, eff_date = SYSDATE"
 *  " WHERE acc_nbr = ?",
 */
int CSubscriber::Update(TTConnection *pttconn, const char *szAccNbr, const char *szStatus)
{
    TTCmd &ttcmd = CBFSQL::ms_ttcmds[BF_SQL_UPDATE_SUBSCRIBER];

    TTStatus stat;

    ttcmd.setParam(1, szStatus);
    ttcmd.setParam(2, szAccNbr);

    ttcmd.Execute(stat);
    if (stat.rc)
    {
        printf("SUBS_STRUCT::Update execute Failed %s\n", stat.err_msg);
        pttconn->Rollback(stat);
        return -1;
    }
    
    /** �ж�UPDATE��¼�Ƿ����
     *  ���UPDATE�ɹ�,���ظ��µļ�¼��
     */
    pttconn->Commit(stat);
    return ttcmd.getRowCount();
}

/*
 * �����û������ѯ�û���Ϣ
 *
 *   2) BF_SQL_QUERY_SUBS_STRUCT
 *   "SELECT serv_id, cust_id, status, eff_date, exp_date"
 *   "  FROM test_SUBS_STRUCT "
 *   " WHERE acc_nbr = ? ",
 */
int CSubscriber::Select(const char *szAccNbr)
{
    TTCmd &ttcmd = CBFSQL::ms_ttcmds[BF_SQL_SELECT_SUBSCRIBER];

    TTStatus stat;

    ttcmd.setParam(1, szAccNbr);
    ttcmd.Execute(stat);
    if(stat.rc)
    {
        printf("SUBS_STRUCT::select execute Failed", stat.err_msg);
        return -1;
    }

    SUBS_STRUCT       subs;
    TIMESTAMP_STRUCT tsEffect;
    TIMESTAMP_STRUCT tsExpire;
    
    while (ttcmd.FetchNext(stat) == 0)
    {
        memset(&subs, 0, sizeof(SUBS_STRUCT));
     
        strcpy(subs.szAccNbr, szAccNbr);
           
        ttcmd.getColumn(1, &(subs.lSubsId));
        ttcmd.getColumn(2, &(subs.lCustId));
        ttcmd.getColumn(3, subs.szStatus);
        ttcmd.getColumn(4, &tsEffect);
        ttcmd.getColumn(5, &tsExpire);

        printf("%ld %ld %s %s %s %s\n", 
            subs.lSubsId, 
            subs.lCustId,
            subs.szAccNbr,
            subs.szStatus,
            Timestamp2String(tsEffect),
            Timestamp2String(tsExpire));
        //PrintSUBS_STRUCT(subs);
    }

    // �ر��α�
    ttcmd.Close(stat);
    if(stat.rc)
    {
        printf("ttcmd close failed:  %s\n", stat.err_msg);
        return -1;
    }

    return 0;
}



/* ***************************
 *   MAIN  FUNCTION
 * ***************************
 */
int main(int argc, char *argv[])
{
    /**
     * �������ݿ� 
     */
    char         szDSN[32] = "dsn=bfs";
    TTConnection conn;
    TTStatus     stat;

    conn.Connect(szDSN, stat);
    if (stat.rc)
    {
        printf("Connect to [%s] Failed::%s\n", szDSN, stat.err_msg);
        return -1;
    }

    /* 
     * ����autocommit = 0 
     * ��ʵ�ϣ�����TTConnection::Connect() ʱ��ϵͳ�Զ�������set autocommit = 0;
     */
    conn.SetAutoCommitOff(stat);
    if (stat.rc)
    {    
        printf("Set autocommit = 0 Failed\n");
        return -1;
    }
    
    
    CBFSQL bfsql;
    
    if (bfsql.Init(&conn) < 0)
    {
        printf("bfsql.Init failed\n");
        conn.Disconnect(stat);
        return -1;
    }

    CSubscriber subs;
    // ҵ����
    char szCommand[256];
    char szAccNbr[16];
    do
    {
        printf("CMMD>");
        gets(szCommand);
        
        if (strncmp(szCommand, "select", 6) == 0)
        {
            strcpy(szAccNbr, szCommand+6);
            subs.Select(szAccNbr);
        }
        else if (strncmp(szCommand, "update", 6) == 0)
        {
            strcpy(szAccNbr, szCommand +6);            
            subs.Update(&conn, szAccNbr, "02");
        }
        else if (strncmp(szCommand, "insert", 6) == 0)
        {
            strcpy(szAccNbr, szCommand+6);
            
            SUBS_STRUCT stSubs;
            
            stSubs.lSubsId = atol(szAccNbr);
            stSubs.lCustId = atol(szAccNbr);
            
            strcpy(stSubs.szAccNbr, szAccNbr);
            strcpy(stSubs.szStatus, "01");
            
            subs.Insert(&conn, &stSubs);
        }
        else if (strncmp(szCommand, "quit", 4) == 0)
        {
            break;
        }
        else
        {
            printf("please enter [select|update|insert]\n");
        }
    } while (1);
    
    
    bfsql.Destroy();
    
    /* �Ͽ����ݿ� */
    conn.Disconnect(stat);
    if (stat.rc)
    {
        printf("Disconnect TimesTen Failed:: %s\n", stat.err_msg);
        return -1;
    }

    return 0;
}