#conf.py
#
# Created on: 2008-12-11
#     Author: Bonly

def test_name():
  return "test";
