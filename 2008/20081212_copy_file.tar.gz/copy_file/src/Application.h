#ifndef APPLICATION_H_
#define APPLICATION_H_
#include <iosfwd>
#include <boost/program_options.hpp>
#include <boost/shared_ptr.hpp>
#include "operate_file.h"

class Application
{
public:
	Application(int argc, char * argv[]);
	virtual ~Application();
	int exec();
	boost::program_options::variables_map & vm(){return _vm;}
	
private:
	boost::program_options::variables_map       _vm;
	boost::program_options::options_description _option;
	boost::shared_ptr<operate_file> _operate;
};

#endif /*APPLICATION_H_*/
