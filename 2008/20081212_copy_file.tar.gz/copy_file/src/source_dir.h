#ifndef SOURCE_DIR_H_
#define SOURCE_DIR_H_
#include <string>
#include <vector>

class source_dir
{
public:
	source_dir(std::string path):_path(path){};
	virtual ~source_dir();
	std::string path(){return _path;}
	std::string back()
	{
		if (_files.empty()) return std::string("");
		return (_files.back());
	}
	void pop(){_files.pop_back();}
	int get_file();
	void print_file();
	
private:
	std::string _path;
	std::vector<std::string> _files;
};

#endif /*SOURCE_DIR_H_*/
