#include "source_dir.h"
#include <boost/filesystem.hpp>
#include <iostream>
#include <boost/foreach.hpp>

int source_dir::get_file()
{
	using namespace std;
	
	int count=0;
	boost::filesystem::path full_path (
			boost::filesystem::system_complete(
					boost::filesystem::path (_path,boost::filesystem::native)
					)
			);
	
	if ( !boost::filesystem::exists( full_path ) )
	{
		cout << "\nNot found: " << full_path.native_file_string() << endl;
		return false;
	}
	
	if (boost::filesystem::is_directory(full_path))
	{
		cout << "Check source dir: "
				 << full_path.native_directory_string() << "\n\n";
		
		boost::filesystem::directory_iterator end_itr;
		for (boost::filesystem::directory_iterator dir_itr (full_path);
		     dir_itr != end_itr;
		     ++dir_itr)
		{
			try
			{
				if (boost::filesystem::is_regular_file( dir_itr->status() ))
				{
					//std::cout << dir_itr->filename() <<"\n";
					_files.push_back(dir_itr->filename());
					++count;
				}
			}
			catch (const std::exception & ex)
			{
				std::cout << dir_itr->filename() << " " << ex.what() << std::endl;
			}
		}
	}	
	return count;
}
void source_dir::print_file()
{
	using namespace std;
	cout << "File in directory [" << _path << "]:\n";
	BOOST_FOREACH(std::string file, _files)
	{
		cout << file << "\n";
	}
	cout << endl;
}

source_dir::~source_dir()
{
}
