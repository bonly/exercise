#include "check_file.h"
#include <boost/filesystem.hpp>
bool 
check_file::operator()(std::string dir, std::string file)
{
	boost::filesystem::path dir_path=
			boost::filesystem::system_complete(
					boost::filesystem::path(dir, boost::filesystem::native));
					
	if ( !exists(dir_path) ) return false;
	boost::filesystem::directory_iterator end_itr;
	for (boost::filesystem::directory_iterator itr(dir_path);
			itr != end_itr;
			++itr)
	{
		if ( itr->filename() == file )
			return true;
	}
	return false;
}

check_file::check_file()
{
}

check_file::~check_file()
{
}
