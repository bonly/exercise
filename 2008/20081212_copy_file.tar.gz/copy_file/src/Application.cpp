#include <iostream>
#include <vector>
#include <string>
#include <fstream>

#include "Application.h"

Application::Application(int argc, char * argv[]):_option("option")
{
	using namespace std;

	_option.add_options()
	     ("help,h","this help message")
	     ("source-dir,s","source directory")
	     ("targe-dir,t", boost::program_options::value< vector<string> >(),"targe directory")
	     ("config-file", boost::program_options::value<string>(), "config file")
	     ;
	boost::program_options::positional_options_description config_file;
	config_file.add("config-file",-1);
	
	boost::program_options::store(
			boost::program_options::command_line_parser(argc,argv).options(_option).positional(config_file).run(), 
			_vm);
	
	if (_vm.count("config-file"))
	{
		ifstream ifs (_vm["config-file"].as<string>().c_str());
		boost::program_options::store(
				boost::program_options::parse_config_file(ifs,_option),
				_vm);
		ifs.close();
	}					
	boost::program_options::notify(_vm);
}

Application::~Application()
{
}

int 
Application::exec()
{
	using namespace std;
	if (_vm.count("help"))
        {
		std::cout << _option << "\n";
                return EXIT_SUCCESS;
        }
	
	if (!_vm.count("source-dir"))
	{
		std::cerr << "No source-dir define!\n";
		exit (EXIT_FAILURE);
	}
	if (!_vm.count("targe-dir"))
	{
		std::cerr << "No targe-dir define!\n";
		exit (EXIT_FAILURE);
	}	

	if (_vm["source-dir"].as<string>().compare( _vm["targe-dir"].as< vector<string> >()[0] )==0)
	{
		std::cerr << "Source dir can't same as first targe dir!\n";
		exit (EXIT_FAILURE);
	}
	
	vector<string> targes = _vm["targe-dir"].as< vector<string> >();
	boost::shared_ptr<operate_file> operate(
			new operate_file(_vm["source-dir"].as<string>(),targes)
			);
	
	_operate = operate;
	operate->operate();
	
	return 0;	
}

int
main (int argc, char * argv[])
{
	Application app(argc, argv);
	app.exec();
	return EXIT_SUCCESS	;
}

	
