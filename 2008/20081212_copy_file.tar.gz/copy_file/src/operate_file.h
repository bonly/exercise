#ifndef OPERATE_FILE_H_
#define OPERATE_FILE_H_
#include "source_dir.h"
#include "check_file.h"
#include <string>
#include <vector>

class operate_file
{
public:
	operate_file(std::string source, std::vector<std::string> &target);
	virtual ~operate_file();
	bool operate();
	
private:
	source_dir  _src;
	std::string _src_dir;
	std::vector<std::string> & _target;
	check_file  _check;
};

#endif /*OPERATE_FILE_H_*/
