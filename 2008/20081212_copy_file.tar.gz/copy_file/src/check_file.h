#ifndef CHECK_FILE_H_
#define CHECK_FILE_H_
#include <string>

class check_file
{
public:
	check_file();
	virtual ~check_file();
	bool operator()(std::string dir, std::string file);
	
private:
};

#endif /*CHECK_FILE_H_*/
