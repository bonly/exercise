#include "operate_file.h"
#include <string>
#include <iostream>
#include <boost/filesystem.hpp>

operate_file::operate_file(std::string source, std::vector<std::string> &target)
		:_src(source),_target(target),_src_dir(source)
{

}

operate_file::~operate_file()
{
}

bool
operate_file::operate()
{
	  using namespace std;
		if(_src.get_file()>0)
		{
			//_src.print_file();
			string sfile;
			while ((sfile=_src.back()).compare("")!=0)
			{
				int size=_target.size();
				bool exist=false;
				
				for (int i=0;i<size; ++i)
				{
					exist=_check(_target[i],sfile);
					if (true == exist) 
					{
						//cout << sfile << " found in " << _target[i] << "\n";
						break;
					}
				}
				
				if (false == exist)
				{
					//cout << sfile << " not found in all targe dirs\n";
					boost::filesystem::path src_file (
							boost::filesystem::system_complete(
									boost::filesystem::path (_src_dir+"/"+sfile,boost::filesystem::native)
									)
							);

					boost::filesystem::path targe_dir (
							boost::filesystem::system_complete(
									boost::filesystem::path (_target[0]+"/"+sfile,boost::filesystem::native)
									)
							);					
					try
					{
						boost::filesystem::copy_file (src_file,targe_dir);
						cout << "Copy file " << sfile << "\n";
					}
					catch(std::exception & e)
					{
						cerr << e.what() << endl;
					}
				}
				_src.pop();				
			}
		}
}
