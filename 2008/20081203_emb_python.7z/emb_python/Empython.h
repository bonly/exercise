/*
 * Empython.h
 *
 *  Created on: 2008-12-5
 *      Author: Bonly
 */

#ifndef EMPYTHON_H_
#define EMPYTHON_H_
#include <boost/python.hpp>
#include <boost/shared_ptr.hpp>
#include <string>
#include <iostream>
using namespace boost::python;

class Empython
{
	public:
		Empython();
		virtual ~Empython();
};

#endif /* EMPYTHON_H_ */
